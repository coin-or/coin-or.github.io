Universal Vehicle Router
~~~~~~~~~~~~~~~~~~~~~~~~
Author: Robert Harder
        rharder@usa.net
STILL UNDER CONSTRUCTION - March 2000

This package provides an architecture for solving vehicle routing problems. Solvers can be added to the bottom end and applications can be built on the top.

Check out the web site available from www.iHarder.net for the latest information.

To install, copy the uvr.jar file to jdk1.x/jre/lib/ext directory where jdk1.x is the directory containing your jdk. Alternatively you can include the jar file at runtime with -classpath uvr.jar.