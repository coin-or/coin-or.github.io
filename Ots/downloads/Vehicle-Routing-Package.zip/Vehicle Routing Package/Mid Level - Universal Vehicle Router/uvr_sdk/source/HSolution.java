/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

/**
 * A solution with vehicles servicing orders.
 *
 * @author Robert Harder
 * @version 1.0
 * @since 1.0
 * @see HOrder
 * @see HVehicle
 * @see HTour
 */
public final class HSolution implements Cloneable
{
    // Tracks whether or not things have not changed. Too many negatives?
    private boolean valid = false;
    
    // Last evaluator used to evaluate the solution
    private HEvaluator lastEvaluatorUsed = null;
    
    /**
     * Returns whether or not the costs associated with the solution
     * are valid. When orders move around in the tours, the costs are invalidated.
     *
     * @return whether or not the costs are validated
     * @since 1.0
     * @see HEvaluator
     */
    public final boolean isValid()
    {   return valid;
    }   // end areCostsValid

    /**
     * Validate a solution based on a given evaluator.
     *
     * @param evaluator the evaluator to use for determing solution costs
     * @since 1.0
     * @see HEvaluator
     */
    public final synchronized void validate( HEvaluator evaluator )
    {   this.validateTours();
        this.costs = evaluator.getCostsForSolution( this );
        this.lastEvaluatorUsed = evaluator;
        this.valid = true;
    }   // end validate
    
    /**
     * Should be called if the solution is changed.
     *
     * @since 1.0
     */
    public final synchronized void invalidate()
    {   this.valid = false;
    }   // end invalidate
    
    // The costs that the user's HEvaluator returns. These are the
    // values that determine which solutions are better than others.
    private double[] costs = {0};
    
    /**
     * Validates each tour.
     *
     * @since 1.0
     * @see HTour
     */
    public final void validateTours()
    {   for( int i = 0; i < tours.length; i++ )
            tours[i].validateTour();
    }   // end validateTours


    /**
     * This array contains all the tours that have real vehicles
     * in them. Each tour has one vehicle and a number of HOrders.
     *
     * @since 1.0
     */
    private HTour[] tours;



    /**
     * This HTour has a null vehicle and holds HOrders that have
     * not been filled (HOrders are only filled entirely, not partially).
     *
     * @since 1.0
     */
    private HTour dummyTour;


    /**
     * Makes a solution based on the passed arguments. The vehicles
     * are immediately cloned.
     *
     * @param vehicles veh
     * @param customers cust
     * @since 1.0
     * @see HOrder
     * @see HVehicle
     */
    public HSolution( HVehicle[] vehicles, HOrder[] orders )
    {   //this.orders = orders;
        HVehicle[] copiedVehicles = new HVehicle[ vehicles.length ];
        for( int i = 0; i < vehicles.length; i++ )
            copiedVehicles[i] = (HVehicle) vehicles[i].clone();
        
        this.tours = createEmptyTours( copiedVehicles );
        this.dummyTour = new HTour( null, orders );
    }   // end constructor


    /**
     * Create a solution that is a copy of <var>copyThis</code>.
     *
     * @param copyThis solution to copy
     * @since 1.0
     */
    public HSolution( HSolution copyThis )
    {
        // Makes a solution that is a complete copy of itself,
        // right down to the last order.

        // Copy Tours
        HTour[] originalTours = copyThis.getHTours();
        this.tours = new HTour[ originalTours.length ];
        for( int i = 0; i < this.tours.length; i++ )
            this.tours[i] = (HTour) originalTours[i].clone();
        
        // Copy dummy tour
        HTour originalDummy = copyThis.getDummyHTour();
        this.dummyTour = (HTour) originalDummy.clone();
        
        // Copy solution costs
        double[] originalCosts = copyThis.getCosts();
        this.costs = new double[ originalCosts.length ];
        System.arraycopy( originalCosts, 0, costs, 0, costs.length );
        this.valid = copyThis.isValid();
        this.lastEvaluatorUsed = copyThis.getLastEvaluatorUsed();
        
    }   // end constructor




    /**
     * Returns the tours in the solution, excluding the dummy tour.
     *
     * @return tours used
     * @since 1.0
     * @see HTour
     */
    public HTour[] getHTours()
    {   return tours;
    }   // end getHTours
    
    /**
     * Returns the dummy tour. This tour holds the orders that are not serviced.
     *
     * @return dummy tour
     * @since 1.0
     * @see HTour
     */
    public HTour getDummyHTour()
    {   return dummyTour;
    }   // end getDummyHTour

    /**
     * Return the costs for this solution. Be sure to check <code>isValid()</code>
     * to know if the costs are meaningful.
     *
     * @return costs for solution
     * @since 1.0
     * @see HEvaluator
     */
    public double[] getCosts()
    {   return this.costs;
    }   // end getCosts
    
    /**
     * Normally this should not be called, but if you have a reason to do it,
     * this sets the costs and does not change the validity of the solution.
     *
     * @param costs new costs for the solution
     * @since 1.0
     * @see HEvaluator
     */
    public void setCosts( double[] costs )
    {   this.costs = costs;
    }   // end setCosts
    
    /**
     * Get the last evaluator that was used to validate this solution.
     *
     * @return last evalutor used
     * @since 1.0
     * @see HEvaluator
     */
    public final HEvaluator getLastEvaluatorUsed()
    {   return this.lastEvaluatorUsed;
    }   // end getLastEvaluatorUsed

    /**
     * Creates an array of tours in which each vehicle services no orders.
     *
     * @param vehicles vehicles to build into tours
     * @return array of tours
     * @since 1.0
     * @see HTour
     * @see HVehicle
     */
    private HTour[] createEmptyTours( HVehicle[] vehicles )
    {
        // Get number of vehicles
        int length = vehicles.length;

        // Make array big enough for each vehicle
        HTour[] tours = new HTour[ length ];

        // Fill array with empty tours
        for( int i = 0; i < length; i++ )
            tours[i] = new HTour( vehicles[i] );

        // Return the array of tours
        return tours;
    }   // end createEmptyTours

    /**
     * Returns a clone of this solution
     *
     * @since 1.0
     */
    public Object clone()
    {   return new HSolution( this );
    }   // end clone

    /**
     * Returns a hashcode for the solution. The actual code used to
     * compute the hashcode follows.
     * <P><tt><pre>
     * 
     *  int hash = 0;
     *  double product = 1;
     *  for( int i = 0; i < costs.length; i++ )
     *      product *= ( costs[i] == 0 ? 1 : costs[i] );
     *  hash = (int) ((product*1000)%Integer.MAX_VALUE);
     *  return hash;
     * </pre></tt><P>
     * 
     * @return hash code
     * @since 1.0
     */
    public int hashCode()
    {   int hash = 0;
        double product = 1;
        for( int i = 0; i < costs.length; i++ )
            product *= ( costs[i] == 0 ? 1 : costs[i] );
        hash = (int) ((product*1000)%Integer.MAX_VALUE);
        return hash;
    }   // end hashCode

    /**
     * Returns a string representation of the costs, including the names for 
     * the costs, if available.
     *
     * @return string representation of costs
     * @since 1.0
     * @see HEvaluator
     */
    public String costsToString()
    {   StringBuffer s = new StringBuffer("[");
        
        String[] names = null;
        if( this.lastEvaluatorUsed != null )
            names = lastEvaluatorUsed.getNamesForCosts( this );
        
        int len = costs.length-1;
        for( int i = 0; i <= len; i++ )
            s.append( (names!=null?names[i]:""+i) + "=" + costs[i] + (i!=len? ", " : "" ) );
        s.append("]");
        return s.toString();
    }   // end costsToString

    public String toString()
    {
        String s = "Costs: ";
        
        int len = costs.length-1;
        for( int i = 0; i <= len; i++ )
            s += i + "=" + costs[i] + (i!=len? ", " : "\n" );

        for( int i = 0; i < tours.length; i++ )
            s += tours[i] + "\n";
        
        // Dummy
        s += "Not visited: " + dummyTour;

        return s;
    }   // end toString
    
    
    
}   // end class HSolution