/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.uvr.solvers.tabusearch4uvr;

import net.usa.rharder.tabusearch22.*;
import mil.af.afit.uvr.*;

class TS4UVRMoveManager implements TSMoveManager
{
    private long lastCall = System.currentTimeMillis();

    // Keep a list of moves to avoid
    // excess instantiation
    private TS4UVRMove[] supplyOfMoves = new TS4UVRMove[10];
    private int availableMovesCount = 0;
    private int nextAvailableMove = 0;
    
    // The counter tracks how often getAllMoves is called.
    // It's used to oscillate among the types of moves that
    // are generated.
    private int counter = 0;
    
    // Effort
    private double requestedSolutionEffort;
    
    public TS4UVRMoveManager( double effort )
    {   this.requestedSolutionEffort = effort;
    }   // end constructor
    
    
    
/* ********  T S M O V E M A N A G E R   C O D E  ******** */
    
    public TSMove[] getAllMoves( TSSolution solution )
    {
//long startMillis = System.currentTimeMillis();
//TS4UVRSolver.out( "TS4UVRMoveManager: Iteration (milliseconds): " +
//(startMillis - lastCall) );
//lastCall = startMillis;
        // Update counter
        counter++;
        
        // Get and cast solution
        HSolution soln = ( (TS4UVRSolution) solution ).getHSolution();
        soln.validateTours();

        // Reset the counter for reused moves
        nextAvailableMove = 0;
        
        // Make a list to hold moves we use
        HList list = new HList();
        
        // Always generate one NO-OP move.
        list.addElement( getMove( -1, -1, -1, -1,null, null ) );
        
        // Add all dumb moves for now
        list.addArray( createAllDumbMoves( soln ) );
        
        // Create relocate moves (within same tour).
        // Do this every other iteration.
        if( counter % 2 == 0 )
            list.addArray( createManyRelocateMoves( 
                soln, requestedSolutionEffort ) );
        
        // Create relocate moves (to other tours).
        // Do this every other iteration.
        if( counter % 2 == 1 )
            list.addArray( createManyChangeTourMoves( 
                soln, requestedSolutionEffort ) );
        
        // Add smart moves. There are three kinds defined here. Rotate
        // which kind is done based on the counter number. Use some
        // modular arithmatic to help out.
/*        
        // Relocate
        if( counter % 10 <= 7 )
            list.addArray( createRelocateMoves( soln, requestedSolutionEffort ) );
        else
        // Add from dummy
        if( counter % 10 <= 8 && soln.getDummyHTour().size() > 0 )
            list.addArray( createAddFromDummyMoves( soln, requestedSolutionEffort ) );
        else
        // Removes. Sort of the garbage collection moves.
            list.addArray( createRemoveMoves( soln, requestedSolutionEffort ) );
*/
        // Return moves
        TSMove[] moves = (TSMove[]) list.toArray( new TSMove[0] );
/*
*/
//TS4UVRSolver.out( "TS4UVRMoveManager: milliseconds to generate moves: " +
//(System.currentTimeMillis() - startMillis) );
TS4UVRSolver.out( "TS4UVRMoveManager: moves generated: " + moves.length );

        return moves;
    }   // end getAllMoves
    
    
    
/* ********  M O V E   G E N E R A T I O N   C O D E  ******** */
    
    private final TS4UVRMove[] createAllDumbMoves( HSolution soln )
    {
        HList list = new HList();
        
        list.addArray( createAllPossibleRemoveMoves( soln ) );
        list.addArray( createAllPossiblePairSwapMoves( soln ) );
        list.addArray( createAllPossibleAddFromDummyMoves( soln ) );

        return (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
    }   // end createAllDumbMoves
    
    
    
    private final TS4UVRMove[] createAllPossibleRemoveMoves( HSolution soln )
    {
        HList list = new HList();
        
        // Get dummy tour
        HTour dummy = soln.getDummyHTour();
        
        // Through each tour
        for( 
        int fromTourNum = 0; 
        fromTourNum < soln.getHTours().length; 
        fromTourNum++ )
        {   
            // Make a shorter variable for the current tour
            HTour tour = soln.getHTours()[fromTourNum];
            
            // Through each order in tour
            for( int jOrder = 0; jOrder < tour.size(); jOrder++ )
            {
                // Add a 'remove' move to the list
                list.addElement( 
                    getMove( fromTourNum, jOrder, -1, 0,
                    tour.getHOrderAt(jOrder),null ) );
            }   // end for: through each order
        }   // end for: through each tour
        
        return (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
    }   // end createAllPossibleRemoveMoves
    
    
    
    private final TS4UVRMove[] createAllPossiblePairSwapMoves( HSolution soln )
    {
        HList list = new HList();
        
        // Through each tour
        for( 
        int toTourNum = 0; 
        toTourNum < soln.getHTours().length; 
        toTourNum++ )
        {   
            // Make a shorter variable for the current tour
            HTour tour = soln.getHTours()[toTourNum];
            
            // Through each order in tour
            if( tour.size() >= 2 )
            {   for( int jOrder = 0; jOrder < tour.size()-1; jOrder++ )
                {   // Add a pair-swap move to the list
                    list.addElement( 
                        getMove( toTourNum, jOrder, toTourNum, jOrder+1,
                        tour.getHOrderAt( jOrder ), null ) );
                }   // end for: through each order
            }   // end if: at least two orders in tour
        }   // end for: through each tour
        
        return (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
    }   // end createAllPossiblePairSwapMoves
    
    
    
    private final TS4UVRMove[] createAllPossibleAddFromDummyMoves( HSolution soln )
    {
        HList list = new HList();
        
        // Get dummy tour
        HTour dummy = soln.getDummyHTour();
        
        // Through each order not being served
        for( int iOrder = 0; iOrder < dummy.size(); iOrder++ )
        {
            // Through each tour
            for( 
            int toTourNum = 0; 
            toTourNum < soln.getHTours().length; 
            toTourNum++ )
            {   
                // Make a shorter variable for the current tour
                HTour tour = soln.getHTours()[toTourNum];
                
                // Through each order in tour
                // Use <= instead of < to allow for putting orders 
                // in an empty tour and putting orders at the end.
                for( int jPosition = 0; jPosition <= tour.size(); jPosition++ )
                {
                    // Add an add-from-dummy move to the list
                    list.addElement( 
                        getMove( -1, iOrder, toTourNum, jPosition,
                        dummy.getHOrderAt(iOrder),null ) );
                }   // end for: through each order
            }   // end for: through each tour
        }   // end for: through each order in dummy
        
        // return moves
        return (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
    }   // end createAllPossibleAddFromDummyMoves
    
    
    private final TS4UVRMove[] createManyRelocateMoves( 
    HSolution soln, double effort )
    {
        HList list = new HList();
        
        // Take each order and move it forward and back in the
        // tour a number of places, depending on the effort
        // requested.
        
        // Through each tour
        final HTour[] tours = soln.getHTours();
        for( int tourNum = 0; tourNum < tours.length; tourNum++ )
        {
            final HTour tour = tours[tourNum];
            final int maxPlacesToOffset = (int) Math.max( 3, 
                0.5 * TS4UVRRunner.MAX_INSERTS_T_FRAC * tour.size()* effort );
            
            // Through each order in tour
            for( 
            int fromPosition = 0; 
            fromPosition < tour.size(); 
            fromPosition++ )
            {
                // Generate moves.
                for( int offset = 1; offset <= maxPlacesToOffset; offset++)
                {
                    // Move-back moves
                    if( fromPosition - offset >= 0 )
                        list.addElement( getMove( tourNum, fromPosition,
                            tourNum, fromPosition - offset,
                            tour.getHOrderAt(fromPosition),null ) );
                    else
                    // Move-forward moves
                    // Subtract one (third line) because the order
                    // is coming out of a position
                    if( fromPosition + offset < tour.size() )
                        list.addElement( getMove( tourNum, fromPosition,
                            tourNum, fromPosition + offset,
                            tour.getHOrderAt(fromPosition),null ) );
                    
                    
                }   // end for: generate moves
                
                
            }   // end for: each order in tour
        }   // end for: each tour
        // return moves
        TS4UVRSolver.out( "TS4UVRMoveManager.createManyRelocateMoves: moves created: " + list.size() );
        return (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
    }   // end createManyRelocateMoves
    
    
    private final TS4UVRMove[] createManyChangeTourMoves( 
    HSolution soln, double effort )
    {
        HList list = new HList();
        
        // Take each order and move it to other tours in a few places
        // depending on the effort requested.

        // Some quick-access variables
        final HTour[] tours = soln.getHTours();
        
        // First, only proceed if there are two or more tours.
        if( tours.length > 1 )
        {
            // Start looping through each tour.
            for( int fromTourNum = 0; 
            fromTourNum < tours.length; fromTourNum++ )
            {   
                final HTour fromTour = tours[fromTourNum];
                
                // Start going through each order to move
                for( int fromOrderNum = 0;
                fromOrderNum < tours[fromTourNum].size();
                fromOrderNum++ )
                {
                    final HOrder fromOrder = fromTour
                        .getHOrderAt( fromOrderNum );
                    final double earliestArrival =
                        fromOrder.getEarliestArrivalTime();
                    final double latestDeparture =
                        fromOrder.getLatestDepartureTime();
                    
                    // Go through other tours to add order
                    for( int toTourNum = 0; 
                    toTourNum < tours.length; toTourNum++ )
                    {
                        // Make sure the tours aren't the same one.
                        if( fromTourNum != toTourNum )
                        {
                            final HTour toTour = tours[toTourNum];
                            boolean withinTimeWindow = false;
                            int numAddedInThisTour = 0;
                            
                            final int maxPlacesToAddInTour = (int) Math.max( 3, 
                                TS4UVRRunner.MAX_INSERTS_T_FRAC * toTour.size()* effort );
                            
                            // Go through positions to add moves
                            for( int toOrderNum = 0; 
                            toOrderNum < toTour.size(); toOrderNum++ )
                            {
                                // See if we're anywhere near the beginning
                                // of the new order's time window before
                                // we start adding moves. Consider the
                                // order close enough to begin adding
                                // moves when the last order's departure
                                // time is within the time window. This
                                // of course ignores the possibility of
                                // putting the new order before this 
                                // other order, but I do it this way
                                // because it's fast and effective.
                                if( ! withinTimeWindow &&
                                toTour.getEstimatedDepartureTime(toOrderNum) 
                                > earliestArrival )
                                withinTimeWindow = true;
                                else
                                // If the order we will have just left
                                // is already being left after our time
                                // window closes, then get out of this
                                // tour, and move on.
                                if( toTour.getEstimatedDepartureTime(toOrderNum)
                                > latestDeparture )
                                {
                                    toOrderNum = Integer.MAX_VALUE;
                                    break;
                                }   // end if: time window has closed
                                else
                                // Go ahead and add a move if we
                                // haven't added too many already.
                                if( 
                                numAddedInThisTour++ 
                                < maxPlacesToAddInTour )
                                {
                                    list.addElement( getMove( 
                                        fromTourNum, fromOrderNum, 
                                        toTourNum, toOrderNum,
                                        fromTour.getHOrderAt(fromOrderNum),
                                        null ) );
                                }   // end else if: add a move
                                else
                                // Just break out if we've got this far
                                {   toOrderNum = Integer.MAX_VALUE;
                                    break;
                                }   // end else: just break out of tour
                            }   // end for: through each place to move to
                        }   // end if: not the same tours
                    }   // end for: through each tour to move to
                }   // end for: through each order to move
            }   // end for: through each tour
        }   // end if: more than one tour

        // return moves
        TS4UVRSolver.out( "TS4UVRMoveManager.createManyChangeTourMoves: moves created: " + list.size() );
        return (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
    }   // end createManyChangeTourMoves
    
    
    
/* ********  S M A R T   M O V E   G E N E R A T I O N  ******** */    
    
    
    private final TS4UVRMove[] createRelocateMoves( 
    HSolution soln, double effort )
    {
        HList list = new HList();
        
        for( int iTour = 0; iTour < soln.getHTours().length; iTour++ )
        {
            // Make some quick access variables
            final HTour fromTour = soln.getHTours()[iTour];
            final int fromTourLength = fromTour.size();
            
            for( int iOrder = 0; iOrder < fromTourLength; iOrder++ )
            {
                list.addArray( createMovesAddingThisOrderToTours(
                    iOrder, iTour, soln, effort ) );
                
            }   // end for: through each tour in order
        }   // end for: through each tour
        
        
        // return moves
        return (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
    }   // end createRelocateMoves
    
    
    
    private final TS4UVRMove[] createAddFromDummyMoves( 
    HSolution soln, double effort )
    {
        HList list = new HList();
        
        // Get dummy tour
        HTour dummy = soln.getDummyHTour();
        
        // Get each unserviced order and try to put it in a tour
        // in a feasible time window.
        for( int i = 0; i < dummy.size(); i++ )
        {
            list.addArray( createMovesAddingThisOrderToTours(
                i, -1, soln, effort ) );


/*
            // Make quick-access variables for this order
            final HOrder order = dummy.getHOrderAt(i);
            final double earliestArrival = order.getEarliestArrival();
            final double latestDeparture = order.getLatestDeparture();
            final double earliestRestricted = order.getEarliestRestrictedTime();
            final double latestRestricted = order.getLatestRestrictedTime();
            
            // Start looking through each tour for a place to go
            for( int j = 0; j < soln.getHTours().length; j++ )
            {
                // Make quick-access variables for this tour
                final HTour tour = soln.getHTours()[j];
                final HVehicle vehicle = tour.getHVehicle();
               
                // Don't bother looking in this tour if this
                // vehicle can't service this order type
                if( vehicle.supportsHOrderType( order.getOrderType() ) )
                {
                    double vehicleAvailable = 
                        vehicle.getEarliestDepartureTime();
                        
                    HOrder previousOrder = null;
                    
                    // Start looking through places to put the order
                    for( 
                    int potentialPosition = 0; 
                    potentialPosition <= tour.size(); // <= to include end of tour
                    potentialPosition++ )
                    {
                        
                        double possibleArrivalTime =
                            vehicleAvailable + vehicle.getTimeToTravel(
                            previousOrder, order );
                        
                        // If it's possible to arrive before the end of the
                        // time window and still service the order,
                        // then go ahead and make a move to do that. 
                        if( 
                        possibleArrivalTime + vehicle.getTimeToService( order )
                        < 
                        latestDeparture )
                        {
                            list.addElement( getMove( dummy, i, 
                                tour, potentialPosition, null ) );
                            
                            // If any orders are dropped because of this 
                            // make a linked-list move that also removes
                            // the offending orders. Use a rough estimate
                            // of the time that would be added. Don't
                            // consider wait times and other messy things.
                            double addedTime = 0;
                            // Time not spent traveling from previous to next
                            addedTime -= vehicle.getTimeToTravel( 
                                previousOrder, 
                                (potentialPosition < tour.size()
                                 ? tour.getHOrderAt( potentialPosition )
                                 : null ) );
                            // Time spent from previous to this order
                            addedTime += vehicle.getTimeToTravel(
                                previousOrder, order );
                            // Time spent from this order to next
                            addedTime += vehicle.getTimeToTravel(
                                order,
                                (potentialPosition < tour.size()
                                 ? tour.getHOrderAt( potentialPosition )
                                 : null ) );
                            
                            // Make a move that may or may not get used
                            TS4UVRMove potentialMove = getMove( dummy, i, 
                                tour, potentialPosition, null );
                            TS4UVRMove lastMove = potentialMove;
                            
                            // Start with the last order and see if
                            // it may need to be dropped.
                            for( int jOrder = tour.size()-1; jOrder >= 0; jOrder-- )
                            {
                                HOrder otherOrder = tour.getHOrderAt( jOrder );
                                // See if the time window is busted.
                                if( 
                                 otherOrder.getEstimatedDepartureTime()
                                 + addedTime
                                 > otherOrder.getLatestDeparture() )
                                {
                                    TS4UVRMove tempMove = getMove(
                                        tour, jOrder, dummy, 0, null );
                                    lastMove.setFollowUpMove( tempMove );
                                    lastMove = tempMove;
                                }   // end if: time window would bust
                                else
                                if(
                                 tour.getTotalTravelTime() + addedTime
                                 > vehicle.getRange() )
                                {
                                    TS4UVRMove tempMove = getMove(
                                        tour, jOrder, dummy, 0, null );
                                    lastMove.setFollowUpMove( tempMove );
                                    lastMove = tempMove;
                                }   // end if: put vehicle past range
                            }   // end for: backwards through tour
                        }   // end if: possible to arrive before end
                        else
                        {   break;  // out of the for loop: this tour.
                        }   // end else: already past the window
                        
                        // Update what the previousOrder is, unless
                        // this is the last time through the loop.
                        if( potentialPosition < tour.size() )
                        {   previousOrder = tour.getHOrderAt( potentialPosition );
                            vehicleAvailable = previousOrder.getEstimatedDepartureTime();
                        }   // end if: not end of loop
                    }   // end for: through each possible position
                }   // end if: vehicle supports this order type
            }   // end for: through each tour
*/
        }   // end for: through each order in dummy
        
        // return moves
        return (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
    }   // end createAddFromDummyMoves
    
    
    private final TS4UVRMove[] createRemoveMoves( 
    HSolution soln, double effort )
    {
        HList list = new HList();
        
        // Get dummy tour
        HTour dummy = soln.getDummyHTour();
        
        // Through each tour
        for( 
        int fromTourNum = 0; 
        fromTourNum < soln.getHTours().length; 
        fromTourNum++ )
        {   
            // Make a shorter variable for the current tour
            HTour tour = soln.getHTours()[fromTourNum];
            
            // Through each order in tour
            for( int jOrder = 0; jOrder < tour.size(); jOrder++ )
            {
                // Add a 'remove' move to the list
                list.addElement( 
                    getMove( fromTourNum, jOrder, -1, 0,
                    tour.getHOrderAt(jOrder),null ) );
            }   // end for: through each order
        }   // end for: through each tour
        
        // return moves
        TS4UVRMove[] moves = (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
        return moves;
    }   // end createRemoveMoves
    
    
    
/* ********  S U P P O R T   M E T H O D S  ******** */
    
    
    
    private TS4UVRMove getMove( 
    int fromTourNum, int fromPosition,
    int toTourNum, int toPosition, HOrder orderToMove,
    TS4UVRMove followUpMove )
    {
        TS4UVRMove move;
        
        // See if there's one we can reuse
        if( nextAvailableMove < availableMovesCount )
        {   // Yes. Reuse this move.
            move = supplyOfMoves[ nextAvailableMove++ ];
            move.setAllParameters( fromTourNum, fromPosition,
                toTourNum, toPosition, orderToMove, null );
        }   // end if: Reused a move
        else    // Need to make a new move.
        {   // See if we need to increase the array that holds
            // the extra moves
            if( supplyOfMoves.length <= nextAvailableMove )
            {   
                // Every time the array needs to be increased, double
                // the length. This prevents a lot of unnecessary
                // array copying. Multiply by two by left-shifting bits.
                TS4UVRMove[] temp = 
                    new TS4UVRMove[ supplyOfMoves.length << 1 ];
                System.arraycopy( supplyOfMoves, 0, 
                    temp, 0, availableMovesCount );
                supplyOfMoves = temp;
            }   // end if: make array much bigger
            
            move = new TS4UVRMove( fromTourNum, 
                fromPosition, toTourNum, toPosition, orderToMove, null );
            supplyOfMoves[ nextAvailableMove++ ] = move;
            availableMovesCount++;
        }   // Make a new move

        return move;
//        return new TS4UVRMove( fromTourNum, fromPosition, toTourNum, toPosition, followUpMove );
    }   // end getMove
    
    
    private final TS4UVRMove[] createMovesAddingThisOrderToThisTour(
    final int orderPosition, final int fromTourNum, final int toTourNum, 
    final HSolution soln, final double effort )
    {
        // The method follows this outline:
        //  1.  At each time window-feasible location, see how
        //      much extra time would be incurred from adding
        //      that order there.
        //  2.  From the list of best locations create moves
        //      to execute that change. The number of moves
        //      created depends on the requested effort.
        
        // Some quick access variables
        final HList list = new HList();
        final HTour fromTour = fromTourNum < 0 
            ? soln.getDummyHTour()
            : soln.getHTours()[fromTourNum];
        final HTour toTour = soln.getHTours()[toTourNum];
        final HVehicle vehicle = toTour.getHVehicle();
        final HOrder order = fromTour.getHOrderAt( orderPosition );
        final boolean isSameTour = fromTourNum == toTourNum;
        
        // Make sure the vehicle supports the order type.
        if( vehicle.supportsHOrderType( order ) )
        {
            // This variable helps with the book keeping.
            HOrder previousOrder = null;
            
            // This array stores the extra time incurred by
            // moving orders around. Initiliaze by making
            // all values really big.
            double[] extraTime = new double[ toTour.size()+1 ];
            for( int i = 0; i < extraTime.length; i++ )
                extraTime[i] = Double.MAX_VALUE;
            
            // Start looking through potential positions.
            for( 
            int potentialPosition = 0;
            potentialPosition <= toTour.size();
            potentialPosition++ )
            {
                // If the order's time window is closed when
                // the vehicle arrives or before the order can
                // be serviced, break out of this for loop. Be
                // careful when this is the first time through
                // the loop: the previous order is null.
                if( 
                ( previousOrder == null
                    ? vehicle.getEarliestDepartureTime()
                    : toTour.getEstimatedDepartureTime(potentialPosition-1) )
                + vehicle.getTimeToTravel( previousOrder, order )
                + vehicle.getTimeToService( order )
                > order.getLatestDepartureTime() )
                {   potentialPosition = Integer.MAX_VALUE;
                    break;  // out of potentialPosition for loop
                }   // end if: arrived too late to service order
                
                // Arrived in time to service order
                else
                {
                    // See how much time would be added by inserting order
                    double addedTime = getTimeAddedByMoving(
                        fromTourNum, orderPosition,
                        toTourNum, potentialPosition, soln );
                    
                    extraTime[ potentialPosition ] = addedTime;
                    
                }   // end else: arrived before window closed
                
            }   // end for: through each potential position
            
            // We now have an array indexed by where we might
            // want to put the order. The array contains the extra
            // time incurred by inserting the order wherever.
            // Places we should not consider have Double.MAX_VALUE
            // as their value, so we'll create a large number
            // as a cut off to help us recognize this.
            final double MAX_VALUE = Double.MAX_VALUE / 10.;
            
            // Make a sorted array that contains the best
            // places to insert the order.
            int[] bestPositions = new int[ extraTime.length ];
            for( int i = 0; i < bestPositions.length; i++ )
                bestPositions[i] = -1;
            
            // Insertion sort
            int numInBPArray = 0;
            for( int i = 0; i < extraTime.length; i++ ) // Each extra time
                if( extraTime[i] < MAX_VALUE ) // Valid extra time
                    for( int j = 0; j <= i; j++ ) // Each valid place
                        if( bestPositions[j] >= 0 ) // Valid position
                        {   if( extraTime[i]  // Better than previous
                             < extraTime[bestPositions[j]] )
                            {   System.arraycopy( 
                                    bestPositions, j,
                                    bestPositions, j+1, numInBPArray-j );
                                bestPositions[j] = i;
                                numInBPArray++;
                                j = Integer.MAX_VALUE;
                                break; // break from j loop
                            }   // end if
                        }   // end if: bestPositions not a -1
                        else
                        {   bestPositions[j] = i;
                            numInBPArray++;
                        }   // end else: just stick the new value at the end
            
            // We now have an array containing the best positions
            // to insert the order. When the value hits -1, that marks
            // the end of the known good positions. Make a number of
            // moves based on how much effort was requested.
            int numOfValidPositions=0;
            for( int i = 0; 
            (i < bestPositions.length) && (bestPositions[i] >= 0); i++ )
                numOfValidPositions++;
            int numOfMovesToMake = numOfValidPositions == 0 ? 0 :
                (int) Math.max( 1, 
                (int) Math.min( 5, (numOfValidPositions * effort) ) );
            
            // Through each move that should be made.
            for( int i = 0; i < numOfMovesToMake; i++ )
            {
                // If an associated linked move should be made,
                // start keeping track of it here and make a copy
                // of every move generated below.
                TS4UVRMove linkedMove = null;
                
                // Add the move, but if the order is being
                // shuffled about inside its own tour, be careful
                // about how you add it.
                if( isSameTour )
                {   if( bestPositions[i] < orderPosition )
                    {   list.addElement( getMove( fromTourNum, 
                            orderPosition, toTourNum, 
                            bestPositions[i],
                            fromTour.getHOrderAt(orderPosition),null ) );
                        linkedMove = getMove( fromTourNum, 
                            orderPosition, toTourNum, 
                            bestPositions[i],
                            fromTour.getHOrderAt(orderPosition),null );
                    }   // end if: insert before its current position
                    else
                    if( bestPositions[i] > orderPosition )
                    {   list.addElement( getMove( fromTourNum,
                            orderPosition, toTourNum,
                            bestPositions[i] - 1,
                            fromTour.getHOrderAt(orderPosition),null ) );
                        linkedMove = getMove( fromTourNum,
                            orderPosition, toTourNum,
                            bestPositions[i] - 1, 
                            fromTour.getHOrderAt(orderPosition),null );
                    }   // end else if: insert after its current position
                    else
                    {   ; // carefule, linkedMove is still null
                    }   // end else: it makes no sense to leave it alone.
                }   // end if: was same tour
                else
                {   list.addElement( getMove( fromTourNum, orderPosition,
                        toTourNum, bestPositions[i],
                        fromTour.getHOrderAt(orderPosition),null ) );
                    linkedMove = getMove( fromTourNum, orderPosition,
                        toTourNum, bestPositions[i],
                        fromTour.getHOrderAt(orderPosition),null );
                }   // end else: must not have been same tour
                
                // See if the linked move structure should be exploited.
                // A move should be removed from the end if the vehicle's
                // range gets busted. Loop through the orders, starting
                // with the last one to see if anything should be removed
                // to preserve the vehicle's range.
                double addedTime = extraTime[ bestPositions[i] ];
                if( addedTime > 0 && linkedMove != null )
                {
                    for( int j = toTour.size()-1; j > bestPositions[i]; j-- )
                    {   final HOrder endingOrder =toTour.getHOrderAt(j);
                        double newTravelTime = toTour.getEstimatedDepartureTime(j) 
                            + vehicle.getTimeToTravel( endingOrder, null )
                            + addedTime;
                        if( newTravelTime > vehicle.getRange() )
                            linkedMove.addFollowUpMove( getMove(
                            toTourNum, j, -1, 0, 
                            toTour.getHOrderAt(j),null ) );
                        else
                        {   j = -Integer.MAX_VALUE;
                            break; // rest of the orders are okay.
                        }   // end else: rest are okay
                    }   // end for: from last tour to inserted tour
                }   // end if: extra time was incurred, and linkedMove != null
                
                // If any moves were linked, add the linked list
                // to the master list of moves.
                if( linkedMove != null )
                    if( linkedMove.getFollowUpMove() != null )
                        list.addElement( linkedMove );
                
            }   // end for: moves to actually make
        }   // end if: vehicle supports order type
        
        // Return moves
        return (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
    }   // end createMovesAddingThisOrderToThisTour
    
/*    
    private final void addFollowUpMovesForRemovingExtraOrders(
    final double addedTime, final HTour toTour )
    {
        
        // We now have a rough estimate of the change in
        // time resulting from the switch. Start seeing
        // if any orders need to be removed because of
        // this change in time. First, if there was a time
        // savings, then no consideration needs to be made
        // for removing anything.
        if( addedTime > 0 )
        {   
            // Track the total travel time to help
            // determine when the range may be broken.
            double travelTime = toTour.getTotalTravelTime()
                + addedTime;
            for( 
            int rOrder = toTour.size()-1; 
            rOrder > potentialPosition;
            rOrder-- )
            {
                // The order will need to be removed if
                // any of the following hold true:
                // 1) the order's time window is busted,
                // 2) the vehicle can no longer service the order
                // 3) the vehicle exceeds its range,
                                    
                final HOrder tempOrder = 
                    toTour.getHOrderAt( rOrder );
                                    
                // Big if block with three "OR's".
                if( 
                // Time Window
                ( tempOrder.getEstimatedDepartureTime() + addedTime
                    >
                    tempOrder.getLatestDeparture() 
                ) // end time window
                                    
                ||
                                    
                // Serviceable
                ( order.getOrderType() == tempOrder.getOrderType()
                    &&
                    vehicle.getCurrentAmountAvailableForOrderType(
                        order.getOrderType() )
                    <
                    order.getCurrentAmountNeeded() 
                ) // end serviceable
                                    
                ||
                                    
                // Vehicle range
                ( travelTime > vehicle.getRange()
                ) // end vehicle range
                )   // Okay, remove this tour.
                {   linkedMove.addFollowUpMove( getMove(
                        toTourNum, rOrder, -1, 0, null ) );
                                        
                    // Adjust the travel time to reflect
                    // this removal.
                    travelTime = addedTime
                        + ( rOrder > 0
                            ? toTour.getHOrderAt(
                                rOrder-1).getEstimatedDepartureTime()
                                - toTour.getEstimatedDepartureTime()
                                + vehicle.getTimeToTravel(
                                toTour.getHOrderAt(rOrder-1),
                                null )
                            : 0 );

                }   // end if: order needed removing
            }   // end for: through each order, possibly removed
                                
            // If any moves were linked, add the linked
            // move to the master list.
            if( linkedMove.getFollowUpMove() != null )
                list.addElement( linkedMove );
                                
        }   // end if: addedTime was positive     
        
        
        
    }   // end 
*/    
    
    
    
    private final double getTimeAddedByMoving(
    int fromTourNum, int fromOrderNum,
    int toTourNum, int toOrderNum, HSolution soln )
    {
        final HTour toTour = soln.getHTours()[toTourNum];
        final HTour fromTour = fromTourNum < 0 
            ? soln.getDummyHTour()
            : soln.getHTours()[fromTourNum];
        final HVehicle vehicle = toTour.getHVehicle();
        final HOrder order = fromTour.getHOrderAt( fromOrderNum );
        final boolean isSameTour = fromTourNum == toTourNum;
        
        double addedTime = 0;
        // Time spent going from new previous
        // order to this order.
        addedTime += vehicle.getTimeToTravel(
            toOrderNum==0
            ? null
            : toTour.getHOrderAt( toOrderNum - 1 ),
            order );
                                
        // Time spent going from this order
        // to the new following order.
        addedTime += vehicle.getTimeToTravel(
            order,
            toOrderNum>=(toTour.size()-1)
            ? null
            : toTour.getHOrderAt( toOrderNum + 1 ) );
                                
        // Time not spent going from new previous
        // order to new following order.
        addedTime -= vehicle.getTimeToTravel(
            toOrderNum==0
            ? null
            : toTour.getHOrderAt( toOrderNum - 1 ),
            toOrderNum>=(toTour.size()-1)
            ? null
            : toTour.getHOrderAt( toOrderNum + 1 ) );
                                
        // If we're working inside the same tour, then
        // there is an additional change from where
        // we are removing the order.
        if( isSameTour )
        {
            // Time spent going from old previous order
            // to old following order.
            addedTime += vehicle.getTimeToTravel(
                fromOrderNum==0
                ? null
                : fromTour.getHOrderAt( fromOrderNum - 1 ),
                fromOrderNum>=(fromTour.size()-1)
                ? null
                : fromTour.getHOrderAt( fromOrderNum + 1 ) );
                                    
            // Time not spent going from old previous
            // order to this order.
            addedTime -= vehicle.getTimeToTravel(
                fromOrderNum==0
                ? null
                : fromTour.getHOrderAt( fromOrderNum - 1 ),
                order );
                                    
            // Time not spent going from this order
            // to old following order.
            addedTime -= vehicle.getTimeToTravel(
                order,
                fromOrderNum >= (fromTour.size()-1)
                ? null
                : fromTour.getHOrderAt( fromOrderNum + 1 ) );
        }   // end if: same tour
                                
        return addedTime;
    }   // end getTimeAddedBy
    
    
    
    private final TS4UVRMove[] createMovesAddingThisOrderToTours(
    final int orderPosition, final int fromTourNum, 
    final HSolution soln, final double effort )
    {
        final HList list = new HList();
        final HTour[] tours = soln.getHTours();
        
        for( int i = 0; i < tours.length; i++ )
            list.addArray( createMovesAddingThisOrderToThisTour(
                orderPosition, fromTourNum, i, soln, effort ) );
        
        
/*        
        // There are two cases: one when the order is being
        // added to a different tour than it's in and one
        // when the order is being shuffled about inside its
        // original tour. When it's being shuffled about, the
        // logic is a bit more complicated.
        
       
        // Make some quick access variables
        final HTour[] tours = soln.getHTours();
        final HTour fromTour = fromTourNum < 0 
            ? soln.getDummyHTour()
            : soln.getHTours()[fromTourNum];
        final HOrder order = fromTour.getHOrderAt( orderPosition );
        final HTour dummy = soln.getDummyHTour();
        
        // Start going through each tour looking for places to put
        // the order. Stop inserting the order when the order's
        // time window closes.
        for( int toTourNum = 0; toTourNum < tours.length; toTourNum++ )
        {
            // Quick access variables
            final HTour toTour = tours[toTourNum];
            final HVehicle vehicle = toTour.getHVehicle();
            final boolean isSameTour = fromTourNum == toTourNum;
            
            // Don't bother looking in this tour if the vehicle
            // can't service this order type.
            if( vehicle.supportsHOrderType( order.getOrderType() ) )
            {   
                // Start looking through each spot in the tour,
                // inserting the order right away. Allow for possible
                // wait time here.
                HOrder previousOrder = null;
                
                for( 
                int potentialPosition = 0; 
                potentialPosition <= toTour.size(); 
                potentialPosition++ )
                {
                    // If the order's time window is closed when
                    // the vehicle arrives or before the order can
                    // be serviced, break out of this for loop. Be
                    // careful when this is the first time through
                    // the loop: the previous order is null.
                    if( 
                    ( previousOrder == null
                        ? vehicle.getEarliestDepartureTime()
                        : previousOrder.getEstimatedDepartureTime() )
                    + vehicle.getTimeToTravel( previousOrder, order )
                    + vehicle.getTimeToService( order )
                    >
                    order.getLatestDeparture() )
                    {   break;
                    }   // end if: arrived too late to service order
                    
                    else
                    {   // Insert the order since the time window
                        // works out okay, but if the from- and to-
                        // tours are the same, be careful about how
                        // the move is made. Make two copies of a
                        // move made here for use a little later when
                        // trying to remove orders at the end of the tour.
                        TS4UVRMove linkedMove=null;
                        if( isSameTour )
                        {   if( potentialPosition < orderPosition )
                            {   list.addElement( getMove( fromTourNum, 
                                    orderPosition, toTourNum, 
                                    potentialPosition, null ) );
                                linkedMove = getMove( fromTourNum, 
                                    orderPosition, toTourNum, 
                                    potentialPosition, null );
                            }   // end if: insert before its current position
                            else
                            if( potentialPosition > orderPosition )
                            {   list.addElement( getMove( fromTourNum,
                                    orderPosition, toTourNum,
                                    potentialPosition - 1, null ) );
                                linkedMove = getMove( fromTourNum,
                                    orderPosition, toTourNum,
                                    potentialPosition - 1, null );
                            }   // end else if: insert after its current position
                            else
                            {   ;
                            }   // end else: it makes no sense to leave it alone.
                        }   // end if: was same tour
                        else
                        {   list.addElement( getMove( fromTourNum, orderPosition,
                                toTourNum, potentialPosition, null ) );
                            linkedMove = getMove( fromTourNum, orderPosition,
                                toTourNum, potentialPosition, null );
                        }   // end else: must not have been same tour
                        
                        // Now that the order has been inserted, see if
                        // any orders need to be removed from the end
                        // of the tour. Start by calculating how much time
                        // has been added (or saved) by inserting this order.
                        // Of course, only spend all this time calculating
                        // if the order actually _was_ inserted anywhere. If
                        // it wasn't, linkedMove will be null.
                        if( linkedMove != null )
                        {   double addedTime = 0;
                            {   // Time spent going from new previous
                                // order to this order.
                                addedTime += vehicle.getTimeToTravel(
                                    potentialPosition==0
                                    ? null
                                    : toTour.getHOrderAt( potentialPosition - 1 ),
                                    order );
                                
                                // Time spent going from this order
                                // to the new following order.
                                addedTime += vehicle.getTimeToTravel(
                                    order,
                                    potentialPosition>=(toTour.size()-1)
                                    ? null
                                    : toTour.getHOrderAt( potentialPosition + 1 ) );
                                
                                // Time not spent going from new previous
                                // order to new following order.
                                addedTime -= vehicle.getTimeToTravel(
                                    potentialPosition==0
                                    ? null
                                    : toTour.getHOrderAt( potentialPosition - 1 ),
                                    potentialPosition>=(toTour.size()-1)
                                    ? null
                                    : toTour.getHOrderAt( potentialPosition + 1 ) );
                                
                                // If we're working inside the same tour, then
                                // there is an additional change from where
                                // we are removing the order.
                                if( isSameTour )
                                {
                                    // Time spent going from old previous order
                                    // to old following order.
                                    addedTime += vehicle.getTimeToTravel(
                                        orderPosition==0
                                        ? null
                                        : fromTour.getHOrderAt( orderPosition - 1 ),
                                        orderPosition>=(fromTour.size()-1)
                                        ? null
                                        : fromTour.getHOrderAt( orderPosition + 1 ) );
                                    
                                    // Time not spent going from old previous
                                    // order to this order.
                                    addedTime -= vehicle.getTimeToTravel(
                                        orderPosition==0
                                        ? null
                                        : fromTour.getHOrderAt( orderPosition - 1 ),
                                        order );
                                    
                                    // Time not spent going from this order
                                    // to old following order.
                                    addedTime -= vehicle.getTimeToTravel(
                                        order,
                                        orderPosition>=(fromTour.size()-1)
                                        ? null
                                        : fromTour.getHOrderAt( orderPosition + 1 ) );
                                }   // end if: same tour
                            }   // end block: finding addedTime
                            
                            // We now have a rough estimate of the change in
                            // time resulting from the switch. Start seeing
                            // if any orders need to be removed because of
                            // this change in time. First, if there was a time
                            // savings, then no consideration needs to be made
                            // for removing anything.
                            if( addedTime > 0 )
                            {   
                                // Track the total travel time to help
                                // determine when the range may be broken.
                                double travelTime = toTour.getTotalTravelTime()
                                    + addedTime;
                                for( 
                                int rOrder = toTour.size()-1; 
                                rOrder > potentialPosition;
                                rOrder-- )
                                {
                                    // The order will need to be removed if
                                    // any of the following hold true:
                                    // 1) the order's time window is busted,
                                    // 2) the vehicle can no longer service the order
                                    // 3) the vehicle exceeds its range,
                                    
                                    final HOrder tempOrder = 
                                        toTour.getHOrderAt( rOrder );
                                    
                                    // Big if block with three "OR's".
                                    if( 
                                    // Time Window
                                    ( tempOrder.getEstimatedDepartureTime() + addedTime
                                      >
                                      tempOrder.getLatestDeparture() 
                                    ) // end time window
                                    
                                    ||
                                    
                                    // Serviceable
                                    ( order.getOrderType() == tempOrder.getOrderType()
                                      &&
                                      vehicle.getCurrentAmountAvailableForOrderType(
                                          order.getOrderType() )
                                      <
                                      order.getCurrentAmountNeeded() 
                                    ) // end serviceable
                                    
                                    ||
                                    
                                    // Vehicle range
                                    ( travelTime > vehicle.getRange()
                                    ) // end vehicle range
                                    )   // Okay, remove this tour.
                                    {   linkedMove.addFollowUpMove( getMove(
                                            toTourNum, rOrder, -1, 0, null ) );
                                        
                                        // Adjust the travel time to reflect
                                        // this removal.
                                        travelTime = addedTime
                                            + ( rOrder > 0
                                                ? toTour.getHOrderAt(
                                                    rOrder-1).getEstimatedDepartureTime()
                                                    - toTour.getEstimatedDepartureTime()
                                                    + vehicle.getTimeToTravel(
                                                    toTour.getHOrderAt(rOrder-1),
                                                    null )
                                                : 0 );

                                    }   // end if: order needed removing
                                }   // end for: through each order, possibly removed
                                
                                // If any moves were linked, add the linked
                                // move to the master list.
                                if( linkedMove.getFollowUpMove() != null )
                                    list.addElement( linkedMove );
                                
                            }   // end if: addedTime was positive     
                        }   // end if: order was inserted somewhere
                    }   // end else: time window is not yet busted
                }   // end for: through each possible position in tour
            }   // end if: vehicle supports order type
        }   // end for: through each tour
*/        
        // return moves
        return (TS4UVRMove[]) list.toArray( new TS4UVRMove[0] );
    }   // end createMovesAddingThisOrderToTours
    
    
}   // end clas TS4UVRMoveManager