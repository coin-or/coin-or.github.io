/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

import java.util.*;
import java.io.*;

/**
 * The <code>HEngine</code> is the main source of interaction between code
 * that uses the Universal Vehicle Router (UVR) and the UVR itself. It accepts
 * information about the vehicles and orders and tries to find a solution
 * based on the parameters you specify. The default solver is the
 * <code>SolomonConstructionSolver</code>. The default evaluator is the
 * <code>EvaluatorWithPriorities</code>.
 *
 * @author Robert Harder, rharder@usa.net
 * @since 1.0
 * @version 1.0
 * @see HEngineEvent
 * @see HEngineListener
 * @see HEvaluator
 * @see HOrder
 * @see HVehicle
 * @see HSolution
 * @see EvaluatorWithPriorities
 * @see mil.af.afit.uvr.solvers.solomonconstruction.SolomonConstructionSolver
 */
public class HEngine implements HSolverListener
{
    private final static boolean DEBUGGING = false;
    
    public final static String 
        UVR_PROPERTIES_DIR_KEY = "java.home",
        UVR_PROPERTIES_FILE_NAME = "uvr.properties",
        SOLVER_KEY_PREFIX = "uvr.solver.",
        PROPERTIES_HEADER = "UVR Properties, v1.0";
    
    protected Properties properties = null;
    private HOrder[] orders = null;
    private HVehicle[] vehicles = null;
    private HSolver[] availableSolvers = null;
    private Vector vecAvailableSolvers = new Vector();
    private HSolver solverToUse = null;
    private HEvaluator evaluator = null;
    private HSolution bestSolution = null;
    private HSolomon solomon = null;
    private boolean engineCanceled = false;
    private boolean finishedLoadingSolvers = false;
    
    private double requestedSolutionEffort = .75;
    private int numberOfThreads = 1;    // Useful on multiprocessor systems
    
    private float percentDone = 0;
    private float percentOfSolveTimeForSolomon = (float).25;
    
    /**
     * Constructs an <code>HEngine</code> that is not yet aware of any
     * orders or vehicles. Since one of the things the <code>HEngine</code>
     * does on construction is begin to load available solvers in another thread, it can
     * be beneficial to use this constructor right before waiting for some
     * user input.
     *
     * @since 1.0
     */
    public HEngine()
    {
        startGettingAvailableSolvers();
        //solverToUse = new mil.af.afit.uvr.solvers.
        //              solomonconstruction.SolomonConstructionSolver();
    }   // end constructor
    
    
    /**
     * Constructs an <code>HEngine</code> that is not yet aware of any
     * orders or vehicles. The <code>HEngine</code> will start with the
     * properties specified. Currently this is only used to specify which
     * solvers to make available. The properties are stored in the following manner:
     * <P><tt><pre>
     * uvr.solver.1=package.subpackage.solverclassname
     * uvr.solver.2=otherpackage.subpack.subpacktoo.othersolverclassname
     * </pre></tt><p>
     * The <code>HEngine</code> will stop loading solvers when the sequence is broken.
     *
     * @since 1.0
     * @see HSolver
     * @see java.util.Properties
     */
    public HEngine( Properties prop )
    {
        this.properties = prop;
        startGettingAvailableSolvers();
        //solverToUse = new mil.af.afit.uvr.solvers.
        //              solomonconstruction.SolomonConstructionSolver();
    }   // end constructor
    
    
    /**
     * Constructs an <code>HEngine</code> based on the passed orders and vehicles.
     *
     * @param vehicles the vehicles to use
     * @param orders the orders to use
     * @since 1.0
     * @see HVehicle
     * @see HOrder
     */
    public HEngine( HVehicle[] vehicles, HOrder[] orders )
    {   startGettingAvailableSolvers();
        this.vehicles = vehicles;
        this.orders = orders;
        //solverToUse = new mil.af.afit.uvr.solvers.
        //              solomonconstruction.SolomonConstructionSolver();
    }   // end constructor
    
    
    /**
     * Constructs an <code>HEngine</code> based on the passed orders and vehicles
     * and specifies the number of threads subsequent solvers should use. This can
     * be helpful on multiprocessor computers.
     *
     * @param vehicles the vehicles to use
     * @param orders the orders to use
     * @param numberOfThreads suggested number of threads to use
     * @since 1.0
     * @see HVehicle
     * @see HOrder
     */
    public HEngine( HVehicle[] vehicles, HOrder[] orders, int numberOfThreads )
    {   this.numberOfThreads = numberOfThreads;
        startGettingAvailableSolvers();
        this.vehicles = vehicles;
        this.orders = orders;
        //solverToUse = new mil.af.afit.uvr.solvers.
        //              solomonconstruction.SolomonConstructionSolver();
    }   // end constructor
    
    // In another thread, start loading solvers. In the future this may
    // load solvers dynamically from one source or another.
    private void startGettingAvailableSolvers()
    {
        // Run this in another thread since there may be
        // some disk access involved. This way control is
        // returned to the calling thread right away.
        final HEngine This = this; // Will allow us to lock
                                  // at the end of the thread
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   
                // Try to load solvers based on the properties. If no properties
                // were specified or loaded in some manner or other, load the
                // two known solvers.
                
                // If a particular properties object was specified (in the
                // constructor) only use those properties. If there were
                // no properties specified, try to load them from a file
                // if access is allowed.
                if( This.properties == null )
                    This.loadPropertiesFile();
                
                // If the properties did not load from a file or were not
                // specified, specify the ones we know about manually
                if( This.properties == null )
                    This.properties = getDefaultProperties();
                
                // Load solvers from properties. Properties will be saved
                // in the form
                //      uvr.solver.1 = package.subpackage.classname
                //      uvr.solver.2 = otherpackage.sub.classname
                for( int i = 1; i < Integer.MAX_VALUE; i++ )
                {
                    HEngine.out( "Solver=" + i );
                    HSolver solver = null;
                    try
                    {   String solverClassName = This.properties.getProperty( SOLVER_KEY_PREFIX + i );
                        if( solverClassName == null || solverClassName == "" )
                            break; // No more solvers listed in properties
                        Class solverClass = Class.forName( solverClassName );
                        Object loadedObject = solverClass.newInstance();
                        if( loadedObject instanceof HSolver )
                            solver = (HSolver) loadedObject;
                    }   // end try
                    catch( Exception e ){ HEngine.err(e); }
                    
                    // If a solver was loaded, add it and move on. Otherwise
                    // stop the looping and get out.
                    if( solver != null )
                        vecAvailableSolvers.addElement( solver );
                    else break;
                }   // end for: solvers in properties
                
                // Save the properties file, if possible, but do it in another
                // thread to return as soon as possible to those interested
                // in getting the solver list.
                final HEngine tHis = This;
                Thread t2 = new Thread( new Runnable()
                {   public void run()
                    {   tHis.savePropertiesFile();
                    }   // end run
                }); // end runnable,thread
                t2.setDaemon( false ); // Finish writing before quitting
                t2.start();
                
                // If no solvers were loaded, we're in big trouble for some
                // unknown reason, but we'll force at least one solver to be
                // loaded.
                if( vecAvailableSolvers.size() == 0 )
                    vecAvailableSolvers.addElement( 
                        new mil.af.afit.uvr.solvers.
                        solomonconstruction.SolomonConstructionSolver() );
                
                // Convert vector to array
                HSolver[] solvers = new HSolver[ vecAvailableSolvers.size() ];
                for( int i = 0; i < solvers.length; i++ )
                    solvers[i] = (HSolver) vecAvailableSolvers.elementAt(i);
                
                // All solvers have been found. Notify interested objects.
                synchronized( This ) // See beginning of method about This
                {   availableSolvers = solvers;
                    finishedLoadingSolvers = true;
                    This.notifyAll();
                }   // end sync
                
            }   // end run
        }); // end runnable,thread
        t.setDaemon( true );
        t.start();
    }   // end startGettingAvailableSolvers
    
    // Save properties file
    private final void savePropertiesFile()
    {   
        String home = null;
        File uvr_prop_file = null;
        FileOutputStream fos = null;
        try
        {   // Get the System property: java.home
            home = System.getProperty( UVR_PROPERTIES_DIR_KEY );

            // Try to access files
            uvr_prop_file = new File( home, UVR_PROPERTIES_FILE_NAME );
                                
            // Make output stream
            fos = new FileOutputStream( uvr_prop_file );
                                
            // Try to save the properties file
            this.properties.save( fos, PROPERTIES_HEADER );
        }   // end try
        catch( Exception e ){}
        try{ fos.close(); }catch(Exception e){}
    }   // end savePropertiesFile
    
    private final void loadPropertiesFile()
    {
        // Execute all the file stuff in one try block. If any point
        // fails, it's time to bail out. No more specifics than that
        // are needed.
        String home = null;
        File uvr_prop_file = null;
        FileInputStream fis = null;
        try
        {   // Get the System property: java.home
            home = System.getProperty( UVR_PROPERTIES_DIR_KEY );

            // Try to access files
            uvr_prop_file = new File( home, UVR_PROPERTIES_FILE_NAME );
                        
            // See if it exists
            if( uvr_prop_file.exists() )
            {
                // Make input stream
                fis = new FileInputStream( uvr_prop_file );
                            
                // Try to load the properties file
                Properties prop = new Properties();
                prop.load( fis );
                this.properties = prop;
            }   // end if: file exists
        }   // end try
        catch( Exception e){}
        try{ fis.close(); }catch( Exception e ){}
    }   // end loadPropertiesFile
    
    /**
     * Return the default properties for the <code>HEngine</code>. Use this
     * to force the default solvers to load in case your <tt>uvr.properties</tt>
     * file got messed up.
     *
     * @since 1.0
     * @return default properties
     * @see java.util.Properties
     */
    public final static Properties getDefaultProperties()
    {
        Properties prop = new Properties();
        String solver = null;
        
        solver = "mil.af.afit.uvr.solvers.tabusearch4uvr.TS4UVRSolver";
        prop.put( SOLVER_KEY_PREFIX + "1", solver );
        solver = "mil.af.afit.uvr.solvers.solomonconstruction.SolomonConstructionSolver";
        prop.put( SOLVER_KEY_PREFIX + "2", solver );
        
        return prop;
    }   // end createDefaultProperties
    
    // Use this to record the percent from 0 to 1 that the solvers report
    private final void setPercentDoneFromSolver( float solverPercent )
    {   this.percentDone = percentOfSolveTimeForSolomon +
            ( 1 - percentOfSolveTimeForSolomon ) * solverPercent;
        fireEnginePercentDoneEvent();
    }   // end setPercentDoneFromSolver
    
    // Use this to record the percent from 0 to 1 that HSolomon reports
    private final void setPercentDoneFromSolomon( float solomonPercent )
    {   this.percentDone = percentOfSolveTimeForSolomon * solomonPercent;
        fireEnginePercentDoneEvent();
    }   // end setPercentDoneFromSolomon
    
    /**
     * This determines how much of the progress is represented as coming
     * from the HSolomon work.
     *
     * @param percentAlotted how much of the overall progress is attributed to HSolomon
     * @since 1.0
     */
    protected final void setPercentAlottedToSolomon( float percentAlotted )
    {   this.percentOfSolveTimeForSolomon = percentAlotted;
    }   // end setPercentAlottedToSolomon

    /**
     * Sets the requested effort. Numbers less than zero or greater than one
     * are set at zero and one, respectively. Less effort results in less
     * work being done by the <code>HEngine</code> and thus reduces solve time.
     * @param effort amount of effort to expend
     * @param return the new effort setting
     * @since 1.0
     * @deprecated Use <code>setEffort()</code>.
     */
    public final double setRequestedSolutionEffort( double effort )
    {   return this.requestedSolutionEffort = Math.max(0, Math.min(1, effort) );
    }   // end setRequestedSolutionEffort
    

    /**
     * Sets the requested effort. Numbers less than zero or greater than one
     * are set at zero and one, respectively. Less effort results in less
     * work being done by the <code>HEngine</code> and thus reduces solve time.
     * @param effort amount of effort to expend
     * @param return the new effort setting
     * @since 1.0.2
     */
    public final double setEffort( double effort )
    {   return this.requestedSolutionEffort = Math.max(0, Math.min(1, effort) );
    }   // end setRequestedSolutionEffort
    
    
    /**
     * Returns the amount of effort that the <code>HEngine</code> will expend.
     *
     * @return effort
     * @since 1.0
     * @deprecated Use <code>getEffort()</code>.
     */
    public final double getRequestedSolutionEffort()
    {   return requestedSolutionEffort;
    }   // end getRequestedSolutionEffort
    
    
    /**
     * Returns the amount of effort that the <code>HEngine</code> will expend.
     *
     * @return effort
     * @since 1.0.2
     */
    public final double getEffort()
    {   return requestedSolutionEffort;
    }   // end getEffort


/* ********  P U B L I C   M E T H O D S  ******** */
    
    /** Returns <tt>true</code> if the user has tried to cancel the </code>HEngine</code>.
     * 
     * @return whether or not the user has tried to cancel the <code>HEngine</code>
     * @since 1.0
     */
    public final boolean isCanceled()
    {   return engineCanceled;
    }   // end isCanceled
    
    /**
     * Stops the <code>HEngine</code>. If in the middle of the tour-building heuristic,
     * there may be a delay before the <code>HEngine</code> actually stops working.
     * An event signaling that the engine has stopped will be fired.
     *
     * @since 1.0
     * @version 1.0.2
     */
    public final void stopSolving()
    {   this.engineCanceled = true;
        if( solomon != null )
            solomon.cancel();
        if( solverToUse != null )
            solverToUse.stopSolving();
        fireEngineFinishedEvent();
    }   // end stopSolving
    
    /**
     * Starts the <code>HEngine</code> solving in another thread. Control returns
     * to the calling method immediately.
     *
     * @since 1.0
     */
    public final void startSolving()
    {
        HEngine.out( "HEngine.startSolving: called" );
        // Setup final variables to be included in the runnable
        final HVehicle[] theVehicles = vehicles;
        final HOrder[] theOrders = orders;
        final HEngine This = this;
        this.bestSolution = null;
        this.engineCanceled = false;
        
        // Get thread going.
        Thread t = new Thread( new Runnable()
        {   public void run()
            {
                // Let people know the engine has started.
                fireEngineStartedEvent();
                    
                // Determine if the solver would like a 
                // bunch of starting solutions
                HSolution[] startingSolutions = null;

                // If no solver has been specified, use the default
                if( solverToUse == null )
                    solverToUse = new mil.af.afit.uvr.solvers.
                                solomonconstruction.SolomonConstructionSolver();
                // If no evaluator has been specified, use the default
                if( evaluator == null )
                    evaluator = new EvaluatorWithPriorities( orders );
                        
                if( This.solverToUse.requestsStartingSolutions() )
                {
                    // Alot 50% of the reported progress done to the solomon code
                    This.setPercentAlottedToSolomon( (float) .50 );
                            
                    // Special case: if they're using the included
                    // solomon solver (which only builds solutions)
                    // set percent alotted to 100%.
                    if( This.solverToUse.getName().equals(
                        mil.af.afit.uvr.solvers.solomonconstruction
                        .SolomonConstructionSolver.NAME ) )
                        This.setPercentAlottedToSolomon( 1 );
                            
                    // Call to Gary Kinney's code.
                    solomon = new HSolomon(
                        evaluator, requestedSolutionEffort);
                    HEngine.out( "HEngine.startSolving: Starting Kinney's code." );
                    startingSolutions = solomon.createMultipleHSolutions(
                        theVehicles, theOrders, This );
                    
                    // If solomon was canceled, it will have returned null
                    if( startingSolutions != null )
                    {
                        HEngine.out( "HEngine: Number of solutions found by solomon: " +
                            startingSolutions.length );
                        solomon = null;
                        Thread.yield();
                        //System.gc(); // A little garbage collection
                                
                        // Make sure at least one solution was found
                        if( startingSolutions.length == 0 )
                        {   startingSolutions = new HSolution[1];
                            startingSolutions[0] = new HSolution( vehicles, orders );
                        }   // end if: solomon made nothing.
                        
                        This.setBestHSolution( startingSolutions[0] );
                        HEngine.out( "HEngine: best solution after solomon: " + This.getBestHSolution() );
                    }   // end if: solomon did not return null
                }   // end if: get good starting solutions from Kinney's code
                else
                {
                    // Alot 0% of the reported progress done to the solomon code
                    This.setPercentAlottedToSolomon( 0 );
                            
                    startingSolutions = new HSolution[1];
                    startingSolutions[0] = new HSolution( vehicles, orders );
                }   // end else: use an empty solution
                
                // Continue only if engine has not been canceled
                if( ! engineCanceled )
                {
                    // Initialize solver
                    This.solverToUse.initializeSolver( 
                        startingSolutions, 
                        evaluator, 
                        This.getRequestedSolutionEffort(),
                        numberOfThreads );
                            
                    // Set up as listener, but first try to remove
                    // self in case it's already been registered.
                    This.solverToUse.removeHSolverListener( This );
                    This.solverToUse.addHSolverListener( This );

                    HEngine.out( "HEngine.startSolving: before solver starts, This.getBestHSolution(): " + This.getBestHSolution() );
                        
                    // Start solver. Call it in another thread in case the solver
                    // does not return control right away.
                    Thread t2 = new Thread( new Runnable()
                    {   public void run()
                        {   This.solverToUse.startSolving();
                        }   // end run
                    }); // end runnable, thread
                    t2.setDaemon( true );
                    t2.start();
                }   // end if: engine not canceled
            }   // end run
        }); // end runnable, thread
        t.setDaemon( true );
        t.start();
        
    }   // end startSolving
    

    /*public HSolver[] getAvailableSolvers()
    {
        // Waits until the list of available solvers is available
        // and then returns. If the list is not available, the thread
        // waits until notifyAll is called on this.
        synchronized( this )
        {   while( availableSolvers == null )
            {   this.notifyAll();
                try
                {   this.wait();
                }   // end try
                catch( InterruptedException e )
                {   HEngine.err( e );
                }   // end catch
            }   // end while
        }   // end sync
        
        // Return array of solvers
        return availableSolvers;
    }   // end getAvailableSolvers
*/
    /**
     * Returns an enumeration of <code>HSolver</code>s already known to the <code>HEngine</code>.
     * You should never use the actual solver objects returned. Always create a new
     * instance with something like the following:
     * <P><tt><pre>
     * HEngine engine = new HEngine();
     * Enumeration enum = engine.getAvailableSolvers();
     * HSolver solverToUse = null;
     * try
     * {    solverToUse = (HSolver) enum.nextElement().getClass().newInstance();
     * }    // end try
     * catch( IllegalAccessException e ){}
     * catch( InstantiationExceptione e ){}
     * </pre></tt>
     *
     * @return <code>HSolver</code>s known to the <code>HEngine</code>
     * @since 1.0
     * @see HSolver
     * @see java.util.Enumeration
     */
    public final Enumeration getAvailableSolvers()
    {   
        // Wait at least until the initial loading is done.
        synchronized( this )
        {   while( !finishedLoadingSolvers )
            {   this.notifyAll();
                try
                {   this.wait();
                }   // end try
                catch( InterruptedException e )
                {   HEngine.err( e );
                }   // end catch
            }   // end while
        }   // end sync
        
        return vecAvailableSolvers.elements();
    }   // end getAvailableSolvers
    
    
    
    /**
     * Returns the solver that will be used or is being used by the <code>HEngine</code>.
     * 
     * @return current solver
     * @since 1.0
     * @see HSolver
     */
    public final HSolver getSolver()
    {   return solverToUse;
    }   // end getSolver
    
    /**
     * Sets the solver to be used by the <code>HEngine</code>. If the solver
     * is different than any already in use, it is added to the engine's list.
     *
     * @param solver solver to use
     * @since 1.0
     * @see HSolver
     */
    public final void setSolver( HSolver solver )
    {   
        String className = solver.getClass().getName();
        boolean alreadyExists = true;
        Enumeration enum = this.getAvailableSolvers();
        while( enum.hasMoreElements() )
            if( ! enum.nextElement().getClass().getName().equals( className ) )
            {   this.vecAvailableSolvers.addElement( solver );
                break;
            }   // end if: solver not already known
        
        this.solverToUse = solver;
    }   // end setSolver
    
    /**
     * Sets the solver to the one named <var>solverName</var>. For this
     * to work, the appropriate solver must be one that would be returned
     * by <code>getAvailableSolvers()</code>.
     * 
     * @param solverName name of solver to use
     * @since 1.0
     * @see HSolver
     * @deprecated Set the solver by using an actual <code>HSolver</code>
     * object. If you must keep a <code>String</code> record
     * of a solver, use the class name and then instantiate a
     * new solver with <code>Class.forName( 
     * strSolverClassName ).newInstance()</code>.
     */
    public final HSolver setSolver( String solverName )
    {
//        HSolver[] solvers = this.getAvailableSolvers();
        Enumeration enumSolvers = this.getAvailableSolvers();
        while( enumSolvers.hasMoreElements() )
        {
            HSolver solver = (HSolver) enumSolvers.nextElement();
            if( solver.getName().equals( solverName ) )
            {   HSolver temp = null;
                try{ temp =(HSolver) solver.getClass().newInstance(); }catch(Exception e){}
                if( temp != null )
                    this.setSolver( temp );
                //i = Integer.MAX_VALUE;
                break;
            }   // end if: selected solver
        }   // end for: through available solvers
        
        return this.solverToUse;
    }   // end setSolver
    
    /**
     * Sets the evaluator to use.
     * 
     * @param evaluator evaluator to use
     * @since 1.0
     * @see HEvaluator
     */
    public final void setHEvaluator( HEvaluator evaluator )
    {   this.evaluator = evaluator;
    }   // end setEvaluator
    
    /**
     * Sets the suggested number of threads to use.
     *
     * @param numberOfThreads number of suggested threads to use
     * @since 1.0
     */
    public final void setNumberOfThreads( int numberOfThreads )
    {   this.numberOfThreads = numberOfThreads;
    }   // end setNumberOfThreads
    
    
    /**
     * Returns the number of threads that was requested for the solver to use.
     *
     * @return number of threads for the solver to use.
     * @since 1.0.2
     */
    public final int getNumberOfThreads()
    {   return this.numberOfThreads;
    }   // end getNumberOfThreads
    
    /**
     * Used internally to set the best known solution
     *
     * @param soln best solution
     * @since 1.0
     * @see HSolution
     */
    protected final synchronized void setBestHSolution( HSolution soln )
    {   this.bestSolution = soln;
        fireNewBestSolutionEvent();
    }   // end setBestHSolution
    
    /**
     * Returns the best solution so far.
     * 
     * @return best solution so far
     * @since 1.0
     * @see HSolution
     */
    public final synchronized HSolution getBestHSolution()
    {   return bestSolution;
    }   // end getBestSolution
    
    /**
     * Returns the evaluator being used.
     *
     * @return the evaluator being used
     * @since 1.0
     * @see HEvaluator
     */
    public final HEvaluator getHEvaluator()
    {   return evaluator;
    }   // end getHEvaluator
    
    /**
     * Returns the properties being used. Currently this only records
     * solvers to try to load.
     *
     * @return properties being used
     * @since 1.0
     * @see HSolver
     * @see java.util.Properties
     */
    public final Properties getProperties()
    {   return properties;
    }   // end getProperties
    
    
    /**
     * Returns the progress of the <code>HEngine</code> as a value
     * between zero and one, inclusively.
     *
     * @return percent done
     * @since 1.0
     */
    public final float getPercentDone()
    {   return this.percentDone;
    }   // end getPercentDone
    
    /**
     * Sets the vehicles used to service the orders.
     *
     * @param vehicles the vehicles to use to server the orders
     * @since 1.0
     * @see HVehicle
     * @see HOrder
     */
    public final synchronized void setHVehicles( HVehicle[] vehicles )
    {   this.vehicles = vehicles;
    }   // end setHVehicles
    
    /**
     * Sets the orders to be served by the vehicles
     *
     * @param orders the orders to be served by the vehicles
     * @since 1.0
     * @see HOrder
     * @see HVehicle
     */
    public final synchronized void setHOrders( HOrder[] orders )
    {   this.orders = orders;
    }   // end setHOrders
    
    /**
     * Used internally by <code>HSolomon</code> to report progress.
     * 
     * @param progress progress between zero and one
     * @since 1.0
     */
    protected final void solomonReportingProgress( float progress )
    {   setPercentDoneFromSolomon( progress );
    }   // end solomonReportingProgress
    
/* ********  H S O L V E R L I S T E N E R   C O D E  ******** */
    
    /**
     * Called when an <code>HSolverEvent</code> is fired.
     *
     * @param e event fired
     * @since 1.0
     * @see HSolverEvent
     * @see HSolverListener
     */
    public void HSolverEventPerformed( HSolverEvent e )
    {   HEngine.out( "HEngine.HSolverEventPerformed: event=" + e );
        final int idType = e.getEventType();
        final HSolver solver = e.getHSolver();
        switch( idType )
        {
            case HSolverEvent.SOLVER_STARTED:
                fireSolverStartedEvent();
                break;
            case HSolverEvent.SOLVER_FINISHED:
                if( !engineCanceled )
                    fireEngineFinishedEvent();
                break;
            case HSolverEvent.PERCENT_DONE:
                this.setPercentDoneFromSolver( solver.getPercentDone() );
                fireEnginePercentDoneEvent();
                break;
            case HSolverEvent.NEW_BEST_SOLUTION:
                this.setBestHSolution( solver.getBestHSolution() );
                HEngine.out( "HEngine.HSolverEventPerformed: new best solution:" + this.bestSolution.costsToString() );
                break;
            default:
                HEngine.out( "DEBUG: Unknown event type received from solver: " + e );
        }   // end switch
    }   // end HSolverEventPerformed
    
    
/* ********  E V E N T   C O D E  ******** */

    /**
     * The list of <code>HEngineListener</code>s that have
     * requested to be notified of engine events. Generally
     * this will only contain a reference to the UVR engine.
     * 
     * @since 1.0
     */
    private HEngineListener[] HEngineListenerList =
        new HEngineListener[0];
    
    /**
     * Add a listener to the engine. This listener will
     * be notified when engine events happen.
     * 
     * @param listener the listener to notify of engine events
     * @since 1.0
     * @see HEngineListener
     * @see HEngineEvent
     */
    public final synchronized void 
    addHEngineListener( HEngineListener listener )
    {  
        HEngineListener[] list = new HEngineListener[
            HEngineListenerList.length + 1 ];
        for( int i = 0; i < list.length - 1; i++ )
            list[i] = HEngineListenerList[i];
                
        list[ list.length-1 ] = listener;
        HEngineListenerList = list;
    }  // end addHEngineListener
    
    
    /**
     * Remove a listener from the engine. This listener will
     * no longer be notified when engine events happen.
     * 
     * @param listener the listener which will no longer 
     *                 receive engine events
     * @since 1.0
     * @see HEngineListener
     * @see HEngineEvent
     */
    
     
    public final synchronized void 
    removeHEngineListener( HEngineListener listener )
    {  // Find location of listener to remove
        int index = -1;
        int j = 0;
        while( index < 0 && j < HEngineListenerList.length )
        {   if( HEngineListenerList[j] == listener )
                index = j;
            else j++;
        }   // end while: through list
            
        // If index is less than zero then it wasn't in the list
        if( index >= 0 )
        {   HEngineListener[] list = new HEngineListener[
                HEngineListenerList.length - 1 ];
            for( int i = 0; i < list.length; i++ )
                list[i] = HEngineListenerList[ i < index ? i : i + 1 ];
            HEngineListenerList = list;
        }   // end if: listener was in the list
    }  // end removeHEngineListener
    
    
    /**
     * Used internally to loop through listener list and send
     * engine events.
     * 
     * @param e the <code>HEngineEvent</code> to send out
     * @since 1.0
     */
    private final void fireHEngineEvent( HEngineEvent e )
    {   
        synchronized( this )
        {   for( int i = 0; i < HEngineListenerList.length; i++ )
                HEngineListenerList[i].HEngineEventPerformed( e );
        }   // end synchronized
    }   // end fireHEngineEvent
    
    
    /**
     * This should be called when the engine starts solving.
     * Interested objects will be notified that the engine
     * has started
     * 
     * @since 1.0
     */
    private final void fireEngineStartedEvent()
    {   HEngineEvent e = new HEngineEvent(
            HEngineEvent.ENGINE_STARTED, this );
        fireHEngineEvent( e );
    }   // end fireEngineStartedEvent
    
    
    /**
     * This should be called when the solver starts solving.
     * Interested objects will be notified that the solver.
     * This will be called after the engine has started and
     * after the initial solutions have been generated, if
     * applicable.
     * 
     * @since 1.0
     */
    private final void fireSolverStartedEvent()
    {   HEngineEvent e = new HEngineEvent(
            HEngineEvent.SOLVER_STARTED, this );
        fireHEngineEvent( e );
    }   // end fireSolverStartedEvent
    
    
    
    /**
     * This method should be called when the engine has finished
     * working. Interested objects, mainly the UVR engine, will
     * be notified that the engine has finished.
     * 
     * @since 1.0
     */
    
    private final void fireEngineFinishedEvent()
    {   HEngineEvent e = new HEngineEvent( 
            HEngineEvent.ENGINE_FINISHED, this );
        fireHEngineEvent( e );
    }   // end fireEngineFinishedEvent
    
    /**
     * This method should be called periodically to keep the
     * user up to date on the engine's progress.
     * 
     * @param percentDone percent completed
     * @since 1.0
     */
    
    private final void fireEnginePercentDoneEvent()
    {   HEngineEvent e = new HEngineEvent(
            HEngineEvent.PERCENT_DONE, this );
        fireHEngineEvent( e );
    }   // /end fireEngineProgressEvent
    
    /**
     * This method should be called when a new best solution is found.
     * 
     * @param percentDone percent completed
     * @since 1.0
     */
    
    private final void fireNewBestSolutionEvent()
    {   HEngineEvent e = new HEngineEvent(
            HEngineEvent.NEW_BEST_SOLUTION, this );
        fireHEngineEvent( e );
    }   // /end fireNewBestSolutionEvent
    
    
/* ********  D E B U G G I N G   C O D E  ******** */
    
    
    // Used to print things to System.out during debugging.
    protected final static void out( Object obj )
    {   if( DEBUGGING )
            System.out.println( obj );
    }   // end out
    
    // Used to print Exceptions to System.err during debugging
    protected final static void err( Exception e )
    {   if( DEBUGGING )
        {   System.err.println( e );
            e.printStackTrace();
        }   // end if
    }   // end err
    
}   // end class HEngine