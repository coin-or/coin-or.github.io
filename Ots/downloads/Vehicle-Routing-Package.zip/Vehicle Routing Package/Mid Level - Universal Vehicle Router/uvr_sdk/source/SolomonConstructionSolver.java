/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr.solvers.solomonconstruction;
import mil.af.afit.uvr.*;


/**
 * This solver just returns the best solution found by the tour building
 * heuristic. It gets very good answers with its "carpet bombing" approach.
 * This is the default solver for the <code>HEngine</code>
 *
 * @author Robert Harder, rharder@usa.net
 * @since 1.0
 * @see mil.af.afit.uvr.HSolver
 * @see mil.af.afit.uvr.HEngine
 */
public class SolomonConstructionSolver extends HSolver
{
    private HSolution[] initialSolutions;
    private double requestedEffort;
    private HSolution bestSolution;
    private HEvaluator evaluator;
    private int numberOfThreads = 1;
    
    /**
     * Name of the solver
     */
    public final static String NAME = "Solomon tour-building";
    
    /**
     * Long description of the solver
     */
    public final static String LONG_DESCR = 
        "This solver doesn't really do anything itself. It merely " +
        "takes the starting solutions provided by the UVR and returns " +
        "the best one. Other solvers can use this same starting list " +
        "by returning true in their requestsStartingSolutions method. " +
        "For more information on how the starting solutions are created, " +
        "see Gary Kinney's thesis (2000) from the Air Force Institute " +
        "of Technology (www.afit.af.mil).";
    
    
    /**
     * Short description of the solver
     */
    public final static String SHORT_DESCR = "Uses only the built in tour-building techniques that other solvers use as starting solutions.";
    
    
/* ********  H S O L V E R   C O D E  ******** */


    public String getName()
    {   return NAME;
    }   // end getName
    
    public String getShortDescription()
    {   return SHORT_DESCR;
    }   // end getShortDescription
    
    public String getLongDescription()
    {   return LONG_DESCR;
    }   // end getLongDescription
    
    public String getCredits()
    {   return "The Solomon heuristic was modified and contributed by Gary Kinney.";
    }   // end getCredits
    
    public String getVersion()
    {   return "v1.0";
    }   // end getVersion
    
    public boolean requestsStartingSolutions()
    {   return true;
    }   // end requestsStartingSolutions
    
    public void initializeSolver( 
    HSolution[] solutions, HEvaluator evaluator,
    double requestedSolutionEffort, int numberOfThreads )
    {   this.numberOfThreads = numberOfThreads;
        this.evaluator = evaluator; 
        this.initialSolutions = solutions;
        this.requestedEffort = requestedSolutionEffort;
        this.bestSolution = initialSolutions[0];
    }   // end initializeSolver
    
    public void startSolving()
    {   
        // Set up thread
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   
                // Tell interested listeners that the solver has started
                fireSolverStartedEvent();
                
                // Update the percent done
                setPercentDone( (float) .50 );
                
                // Pick off the best solution from the already-sorted list
                bestSolution = initialSolutions[0];
                fireNewBestSolutionEvent();

                // Update the percent done
                setPercentDone( 1 );

                // Tell interested listeners that the solver has finished
                fireSolverFinishedEvent();
            }   // end run
        }); // end runnable, thread
        t.setDaemon( true );
        t.start();
    }   // end startSolving

    public final void stopSolving()
    {   
    }   // end stopSolving


    public HSolution getBestHSolution()
    {   return this.bestSolution;
    }   // end getBestHSolutions
        
    
    
    
}   // end class SolomonConstructionSolver