/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;


/**
 * Use this interface in your objects that represent orders, customers, etc.
 * Orders are not cloned during the solve process, so the orders you pass
 * into <code>HEngine</code> are the same ones that come out.
 *
 * @author Robert Harder, rharder@usa.net
 * @since 1.0
 * @see HEngine
 */
public interface HOrder
{
    
    
    /**
     * The order priority. "Higher" priorities are lower numbers; thus priority
     * 1 is a higher priority than priority 2.
     *
     * @return priority
     */
    public abstract int getPriority();
    
    
    /**
     * The earliest time that an order may be serviced. A vehicle that
     * arrives early will wait until this time to begin servicing.
     *
     * @return earliest arrival time
     */
    public abstract double getEarliestArrivalTime();
    
    
    /**
     * The latest time that a vehicle may remain at an order
     * servicing it. If a vehicle begins servicing an order
     * it will continue servicing it even if it busts this
     * time window.
     *
     * @return latest departure time
     */
    public abstract double getLatestDepartureTime();
    
    
    /**
     * The earliest time when a vehicle may not service an order. This
     * is a "time wall." If you are not using time walls, use the following.
     * <P><tt><pre>
     * public final double getEarliestRestrictedTime()
     * {    return -Double.MAX_VALUE;
     * }    // end getEarliestRestrictedTime
     * </pre></tt>
     *
     * @return earliest restricted time
     */
    public abstract double getEarliestRestrictedTime();
    
    
    /**
     * The latest time when a vehicle may not service an order. This
     * is a "time wall." If you are not using time walls, use the following.
     * <P><tt><pre>
     * public final double getLatestRestrictedTime()
     * {    return -Double.MAX_VALUE;
     * }    // end getEarliestRestrictedTime
     * </pre></tt>
     *
     * @return latest restricted time
     */
    public abstract double getLatestRestrictedTime();
    
    
    /**
     * The positive amount of product neeeded by the order. If you are not
     * using amounts, do not return zero. Return one or more.
     *
     * @return amount needed
     */
    public abstract int getAmountNeeded();
    
}   // end interface HOrder