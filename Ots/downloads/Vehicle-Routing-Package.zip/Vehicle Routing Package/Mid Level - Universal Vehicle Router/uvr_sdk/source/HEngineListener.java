/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

/**
 * Implement this interface to listen for <code>HEngine</code> events.
 * 
 * @author Robert Harder, rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see HEngine
 * @see HEngineEvent
 */
public interface HEngineListener
{

    /**
     * Called when an event is triggered.
     * 
     * @param e the triggered event.
     * @since 1.0
     * @see HEngineEvent
     * @see HEngine
     */
    public void HEngineEventPerformed( HEngineEvent e );
    
}   // end interface HEngineListener