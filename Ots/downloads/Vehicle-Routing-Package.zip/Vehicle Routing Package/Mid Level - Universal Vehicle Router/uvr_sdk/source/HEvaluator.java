/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

/**
 * An <code>HEvaluator</code> gives costs for a given solution. The array
 * of values returned by the <code>getCostsForSolution(...)</code> is compared
 * lexicographically against other solutions. That means that each cost in the
 * array is considered to be infinitely more important than the next. For an example
 * minimizing costs, <tt>{ 1.2, 5.4 }</tt> is better than <tt>{ 1.3, 0.0 }</tt>
 * because 1.2 is smaller than 1.3. If you want to have fuzzier costs, combine
 * them all into one element in the array.
 * <P>
 * Here is an example of the kind of code that is used to compare values returned by
 * the <code>HEvaluator</code>s.
 * <P><tt><pre>
 *
 *
 *  private final boolean firstIsBetterThanSecond( double[] first, double[] second )
 *  {
 *      int i=0;
 *      final int valLength = first.length;
 *      boolean result = false;
 *      
 *      for( i = 0; i < valLength; i++ )
 *      {
 *          if( (float)first[0] > (float)second[0] )
 *          {
 *              result = maximizing ? true : false;
 *              i = Integer.MAX_VALUE;
 *              break;
 *          }   // end if
 *          else if( (float)first[0] < (float)second[0] )
 *          {
 *              result = maximizing ? false : true;
 *              i = Integer.MAX_VALUE;
 *              break;
 *          }   // end else
 *          // else it must have been equal
 *      }   // end for: through each value
 *      
 *      return result;
 *  }   // end firstIsBetterThanSecond
 * </pre></tt><P> 
 *
 * The casting to floats is recommended and often used to ignore the 
 * inevitable errors at the tail end of floating point numbers.
 * 
 * @author Robert Harder
 * @version 1.0
 * @since 1.0
 * @see HSolution
 */
public interface HEvaluator
{

    /**
     * This method should weight the appropriate values and return
     * a total cost for the solution, based on whatever is most
     * important. The solution contains some useful values,
     * precalculated, to save time. See the section on
     * <code>HSolution</code> for more information
     * 
     * @param solution
     * @return values representing a cost for this solution
     * @since 1.0
     * @see HSolution
     */
    public abstract double[] getCostsForSolution( HSolution solution );
    
    
    /**
     * This method should return names for the costs given in the
     * method <tt>getCostsForSolution</tt>.
     * 
     * @param solution
     * @return the names for the costs
     * @since 1.0
     * @see HSolution
     */
    public abstract String[] getNamesForCosts( HSolution solution );
    
    
}   // end interface HEvaluator



/*
// Here's some sample code that lexigraphically compares the first
// to the second. It's set up to handle maximizing and minimizing,
// though the UVR will always be minimizing.
    private final boolean firstIsBetterThanSecond( double[] first, double[] second )
    {
        int i=0;
        int valLength = first.length;
        boolean result = false;
        
        for( i = 0; i < valLength; i++ )
        {
            if( first[0] > second[0] )
            {
                result = maximizing ? true : false;
                break;
            }   // end if
            else if( first[0] < second[0] )
            {
                result = maximizing ? false : true;
                break;
            }   // end else
            // else it must have been equal
        }   // end for: through each value
        
        return result;
    }   // end firstIsBetterThanSecond

*/