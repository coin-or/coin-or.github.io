/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;


/**
 * This sample <code>HEvaluator</code> minimizes the following:
 * <P><tt><pre>
 *      1) Number of vehicles that exceed their range
 *      2) Number of busted time windows
 *      3) Vehicles used
 *      4) Travel time plus penalties
 *      5) Wait time
 * </pre></tt><P>
 * Note that the penalties should be on the same scale as the time units.
 * 
 * @author Robert Harder, rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see HEvaluator
 */
public class EvaluatorWithoutPriorities implements HEvaluator
{
    private final static int
        FEASIBLE_RANGE = 0,
        BUSTED_TIME_WINDOWS = 1,
        SKIPPED_ORDERS = 2,
        VEHICLES_USED = 3,
        TRAVEL_PLUS_PENALTIES = 4,
        WAIT_TIME = 5,
        NUMBER_OF_CATEGORIES = 6;
    
    private final static String[] names =
        { "Vehicles past range",
          "Time windows busted",
          "Skipped orders",
          "Vehicles used",
          "Travel plus penalties",
          "Wait time"
        };
    
    
/* ********  H E V A L U A T O R   C O D E  ******** */
    
    /**
     * Returns names for each index in the costs array.
     *
     * @param soln the solution in question, if known. It may be null.
     * @returns names for each cost.
     * @since 1.0
     * @see HSolution
     */
    public final String[] getNamesForCosts( HSolution soln )
    {   return names;
    }   // end getNamesForCosts
    
    
    /**
     * Returns an array representing the costs of the solution.
     * 
     * @param soln The solution to evaluate
     * @return costs for the solution
     * @since 1.0
     * @see HSolution
     */
    public final double[] getCostsForSolution( HSolution soln )
    {
        double[] value = new double[NUMBER_OF_CATEGORIES];
        for( int i = 0; i < value.length; i++ )
            value[i] = 0;
        
        // The obvious skipped orders
        HTour dummy = soln.getDummyHTour();
        value[SKIPPED_ORDERS] = dummy.size();
        
        for( int iTour = 0; iTour < soln.getHTours().length; iTour++ )
        {
            HTour tour = soln.getHTours()[iTour];
            HVehicle vehicle = tour.getHVehicle();
               
            double range = vehicle.getRange();
            double travel = tour.getTotalTravelTime();
            double penalties = tour.getTotalPenalty();
            double waitTime = tour.getTotalWaitingTime();
//            int bustedTimeWindows = tour.getBustedTimeWindows();
            int bustedInclusions = tour.getBustedTimeWindows();
            int bustedRestricteds = tour.getBustedTimeWalls();
           
            // Feasibility: 0 if feasible, add 1 if infeasible
            value[FEASIBLE_RANGE] += (range-travel < 0) ? 1 : 0;
            
            // Busted time windows
            value[BUSTED_TIME_WINDOWS] += 
                bustedInclusions + bustedRestricteds;
            
            // Skipped orders
            for( int i = 0; i < tour.size(); i++ )
            {   if( !tour.serviced(i) )
                {   value[SKIPPED_ORDERS]++;
//HEngine.out( "Skipped order inside tour." );
                }   // end if: skipped order
            }   // end for: each order in tour
            
            if( tour.size() > 0 )
                value[VEHICLES_USED]++;
            
            // Range minus travel time plus penalties
            value[TRAVEL_PLUS_PENALTIES] += Math.max( 
                0, travel + penalties );
            
            // Total wait time
            value[WAIT_TIME] += waitTime;
            
        }   // end for: through each tour
        
        
        return value;
    }   // end getCostForSolution
    

    /**
     * Returns a string representation of the evaluator.
     * 
     * @return string representing the evaluator
     * @since 1.0
     */
    public String toString()
    {
        StringBuffer s = new StringBuffer();
        
        for( int i = 0; i < names.length; i++ )
            s.append( i+"="+ names[i] + ( i < names.length-1 ? "\n" : "") );
        
        return s.toString();
    }   // end toString
        
        
        
}   // end class EvaluatorWithoutPriorities