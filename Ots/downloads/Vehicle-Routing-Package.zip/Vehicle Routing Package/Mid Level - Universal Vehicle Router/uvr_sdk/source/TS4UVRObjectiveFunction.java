/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.uvr.solvers.tabusearch4uvr;

import net.usa.rharder.tabusearch22.*;
import mil.af.afit.uvr.*;

class TS4UVRObjectiveFunction implements TSFunction
{
    private HEvaluator evaluator = null;
    
    public TS4UVRObjectiveFunction( HEvaluator evaluator )
    {   this.evaluator = evaluator;
    }   // end constructor
    
    
/* ********  T S F U N C T I O N   C O D E  ******** */
    
    
    public final double[] evaluate( TSSolution solution )
    {
        HSolution soln = ( (TS4UVRSolution) solution ).getHSolution();
        
        // If I need to update the solution, do it here.
        soln.validate( evaluator );

        return soln.getCosts();
    }   // end evaluate
    

}   // end class TS4UVRObjectiveFunction