/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

/**
 * This sample <code>HEvaluator</code> minimizes the following:
 * <P><tt><pre>
 *      1) Number of vehicles that exceed their range
 *      2) Number of busted time windows
 *      3) Number of skipped orders of priority 'i'
 *      ... skipped orders of each priority level...
 *      k) Vehicles used
 *      k+1) Travel time plus penalties
 *      k+2) Wait time
 * </pre></tt><P>
 * Note that the penalties should be on the same scale as the time units. This
 * is the default evaluator.
 * 
 * @author Robert Harder, rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see HEvaluator
 */
public class EvaluatorWithPriorities 
implements HEvaluator
{
    // Index markers for the arrays
    private int
        FEASIBLE_RANGE = 0,
        BUSTED_TIME_WINDOWS = 1,
        SKIPPED_ORDERS = 2,
        VEHICLES_USED = 3,
        TRAVEL_PLUS_PENALTIES = 4,
        WAIT_TIME = 5,
        NUMBER_OF_CATEGORIES = 6;
    
    // Names of places in arrays
    private String[] names =
        { "Vehicles past range",
          "Time windows busted",
          "Skipped orders",
          "Vehicles used",
          "Travel plus penalties",
          "Wait time"
        };
    
    // The known priorities
    private int[] priorities = new int[0];
    
    /**
     * Constructs an <code>HEvaluator</code> that considers the priorities
     * indicated in <code>orders</code>
     * 
     * @param orders <code>HOrder</code>s that have priorities
     * @since 1.0
     * @see HOrder
     */
    public EvaluatorWithPriorities( HOrder[] orders )
    {
        // The array that determines the value of the solution
        // will have a length based on the number of different
        // priorities that all the orders have.
        
        // Go through each order and find its priority.
        
        for( int i = 0; i < orders.length; i++ )
        {   final HOrder order = orders[i];
            final int priority = order.getPriority();
            if( indexForPriority( priority ) < 0 )
            {   addPriority( priority );
            }   // end if: priority not yet known
        }   // end for: through each order
        
        // Now fix the variables that point to the appropriate
        // array indeces. Priorities.length is the number of
        // different priorities that exist.
        final int extra = priorities.length-1;
        VEHICLES_USED += extra;
        TRAVEL_PLUS_PENALTIES += extra;
        WAIT_TIME += extra;
        NUMBER_OF_CATEGORIES += extra;
        
        // Now fix the strings that describe the values.
        String[] tempNames = new String[ NUMBER_OF_CATEGORIES ];
        for( int i = 0; i < SKIPPED_ORDERS; i++ )
            tempNames[i] = names[i];
        for( int i = 0; i < priorities.length; i++ )
            tempNames[SKIPPED_ORDERS + i] = 
                names[SKIPPED_ORDERS] + " with priority " + priorities[i];
        tempNames[ VEHICLES_USED ] = 
            names[ VEHICLES_USED - extra ];
        tempNames[ TRAVEL_PLUS_PENALTIES ] = 
            names[ TRAVEL_PLUS_PENALTIES - extra ];
        tempNames[ WAIT_TIME ] = 
            names[ WAIT_TIME - extra ];
        
        names = tempNames;
        
    }   // end constructor
    
    // Help with the bookkeeping
    private final int indexForPriority( int priority )
    {
        int index = -1;
        int i = 0;
        while( (index < 0) && (i < priorities.length) )
            if( priorities[i++] == priority )
                index = --i;
        
        return index;
    }   // end indexForPriority
    
    // Add a priority level to the array of known priorities
    private final void addPriority( int priority )
    {
        // Lower values have higher priority, as in
        // Priority 1 is the highest. Technically negative
        // values would be even higher priority.
        final int priorLength = priorities.length;
        int[] temp = new int[ priorLength + 1 ];
        for( int i = 0; i <= priorLength; i++ )
        {   if( i < priorities.length )
            {   if( priority < priorities[i] )
                {   
                    System.arraycopy( priorities, 0, temp, 0, i );
                    System.arraycopy( priorities, i, temp, i+1, priorities.length-i );
                    temp[i] = priority;
                    i = Integer.MAX_VALUE;
                    break;  // Leave the for loop
                }   // end if: new priority goes before the rest
            }   // end if: checking through normal priorities
            else
            {   System.arraycopy( priorities, 0, temp, 0, priorities.length );
                temp[priorities.length] = priority;
                i = Integer.MAX_VALUE;
                break;
            }   // end else: add to end of list
        }   // end for: through each existing priority        
        priorities = temp;
    }   // end addPriority
    
/* ********  H E V A L U A T O R   C O D E  ******** */
    
    /**
     * Returns names for each index in the costs array.
     *
     * @param soln the solution in question, if known. It may be null.
     * @returns names for each cost.
     * @since 1.0
     * @see HSolution
     */
    public final String[] getNamesForCosts( HSolution soln )
    {   return names;
    }   // end getNamesForCosts
    
    
    /**
     * Returns an array representing the costs of the solution.
     * 
     * @param soln The solution to evaluate
     * @return costs for the solution
     * @since 1.0
     * @see HSolution
     */
    public final double[] getCostsForSolution( HSolution soln )
    {
        double[] value = new double[NUMBER_OF_CATEGORIES];
        for( int i = 0; i < value.length; i++ )
            value[i] = 0;
        
        // The obvious skipped orders
        final HTour dummy = soln.getDummyHTour();
        final int dummySize = dummy.size();
        for( int i = 0; i < dummySize; i++ )
        {   value[ SKIPPED_ORDERS + indexForPriority( 
                dummy.getHOrderAt(i).getPriority() ) ]++;
        }   // end for: through each order in dummy tour
        
        
        for( int iTour = 0; iTour < soln.getHTours().length; iTour++ )
        {
            HTour tour = soln.getHTours()[iTour];
            HVehicle vehicle = tour.getHVehicle();
               
            double range = vehicle.getRange();
            double travel = tour.getTotalTravelTime();
            double penalties = tour.getTotalPenalty();
            double waitTime = tour.getTotalWaitingTime();
//            int bustedTimeWindows = tour.getBustedTimeWindows();
            int bustedInclusions = tour.getBustedTimeWindows();
            int bustedRestricteds = tour.getBustedTimeWalls();
           
            // Feasibility: 0 if feasible, add 1 if infeasible
            value[FEASIBLE_RANGE] += (range-travel < 0) ? 1 : 0;
            
            // Busted time windows
            value[BUSTED_TIME_WINDOWS] += 
                bustedInclusions + bustedRestricteds;
            
            // Skipped orders for tour
            for( int i = 0; i < tour.size(); i++ )
            {   if( !tour.serviced(i) )
                {   value[ SKIPPED_ORDERS + indexForPriority( 
                        tour.getHOrderAt(i).getPriority() ) ]++;
                    //HEngine.out( "Skipped order inside tour." );
                }   // end if: skipped order
            }   // end for: each order in tour
            
            if( tour.size() > 0 )
                value[VEHICLES_USED]++;
            
            // Range minus travel time plus penalties
            value[TRAVEL_PLUS_PENALTIES] += Math.max( 
                0, travel + penalties );
            
            // Total wait time
            value[WAIT_TIME] += waitTime;
            
        }   // end for: through each tour
        
        
        return value;
    }   // end getCostForSolution
    

    /**
     * Returns a string representation of the evaluator.
     * 
     * @return string representing the evaluator
     * @since 1.0
     */
    public String toString()
    {
        StringBuffer s = new StringBuffer();
        
        for( int i = 0; i < names.length; i++ )
            s.append( i+"="+ names[i] + ( i < names.length-1 ? "\n" : "") );
        
        return s.toString();
    }   // end toString
        
        
        
}   // end class EvaluatorWithPriorities