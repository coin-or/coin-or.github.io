/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

/**
   Thanks to Sun and Lee Boynton for the inspiration behind this 
   class. HList is basically a lite version of Vector. There are 
   no synchronized methods, and some other things we didn't need
   are not present. 
*/
public class HList
{
    protected Object elementData[] = new Object[0];

    protected int elementCount=0;

    protected int capacityIncrement=1;


    public HList(int initialCapacity, int capacityIncrement) 
    {
	    this.elementData = new Object[initialCapacity];
	    this.capacityIncrement = capacityIncrement;
    }

    public HList(int initialCapacity) 
    {
	    this(initialCapacity, 0);
    }
    
    
    public HList() 
    {
	    this(10);
    }
    
    public HList( Object[] data )
    {
        this.ensureCapacity( data.length );
        this.elementData = data;
        this.elementCount = data.length;
    }   // end constructor

    
    public final void copyInto(Object anArray[]) 
    {
	    int i = elementCount;
	    while (i-- > 0) 
	    {   anArray[i] = elementData[i];
	    }   // end while
    }   // end copyInto

    public final void trimToSize() 
    {
	    int oldCapacity = elementData.length;
	    if (elementCount < oldCapacity) 
	    {   Object oldData[] = elementData;
	        elementData = new Object[elementCount];
	        System.arraycopy(oldData, 0, elementData, 0, elementCount);
	    }   // end if
    }   // end trimToSize


    public final void ensureCapacity(int minCapacity) 
    {
	    if (minCapacity > elementData.length) 
	        ensureCapacityHelper(minCapacity);
    }


    private void ensureCapacityHelper(int minCapacity) 
    {
	    int oldCapacity = elementData.length;
	    Object oldData[] = elementData;
	    int newCapacity = (capacityIncrement > 0) ?
	        (oldCapacity + capacityIncrement) : (oldCapacity * 2);
	    if (newCapacity < minCapacity) 
	        newCapacity = minCapacity;
	    elementData = new Object[newCapacity];
	    System.arraycopy(oldData, 0, elementData, 0, elementCount);
    }

    public final void setSize(int newSize) 
    {
	    if ((newSize > elementCount) && (newSize > elementData.length)) 
	        ensureCapacityHelper(newSize);
	    else 
	        for (int i = newSize ; i < elementCount ; i++) 
		        elementData[i] = null;
	    elementCount = newSize;
    }


    public final int capacity() 
    {   return elementData.length;
    }


    public final int size() 
    {   return elementCount;
    }


    public final boolean isEmpty() 
    {   return elementCount == 0;
    }

    

    public final boolean contains(Object elem) 
    {   return indexOf(elem, 0) >= 0;
    }


    public final int indexOf(Object elem) 
    {   return indexOf(elem, 0);
    }


    public final int indexOf(Object elem, int index) 
    {
	    for (int i = index ; i < elementCount ; i++) 
	        if (elem == elementData[i]) 
		        return i;
	    return -1;
    }   // end indexOf


    public final int lastIndexOf(Object elem) 
    {   return lastIndexOf(elem, elementCount-1);
    }


    
    public final int lastIndexOf(Object elem, int index) 
    {
	    for (int i = index ; i >= 0 ; i--) 
	        if (elem == elementData[i]) 
		        return i;
	    return -1;
    }


    public final Object elementAt(int index) 
    {
        return elementData[index];
    }


    public final Object firstElement() 
    {
	    return elementData[0];
    }


    public final Object lastElement() 
    {
	    return elementData[elementCount - 1];
    }


    public final void setElementAt(Object obj, int index) 
    {
	    elementData[index] = obj;
    }


    public final void removeElementAt(int index) 
    {
	    int j = elementCount - index - 1;
	    if (j > 0) 
	        System.arraycopy(elementData, index + 1, elementData, index, j);

	    elementCount--;
	    elementData[elementCount] = null; 
    }


    public final void insertElementAt(Object obj, int index) 
    {
	    int newcount = elementCount + 1;

	    if (newcount > elementData.length) 
	        ensureCapacityHelper(newcount);
	    
        if( index < elementCount )
    	    System.arraycopy(elementData, index, elementData, index + 1, elementCount - index);
	    elementData[index] = obj;
	    elementCount++;
    }


    public final void addElement(Object obj) 
    {
	    int newcount = elementCount + 1;
	    if (newcount > elementData.length) 
	        ensureCapacityHelper(newcount);
	    
	    elementData[elementCount++] = obj;
    }


    public final boolean removeElement(Object obj) 
    {
	    int i = indexOf(obj);
	    if (i >= 0)
	    {
	        removeElementAt(i);
	        return true;
	    }
	    return false;
    }


    public final void removeAllElements() 
    {
	    for (int i = 0; i < elementCount; i++) 
	        elementData[i] = null;
    	
	    elementCount = 0;
    }

    public Object clone() // "shallow clone": only copies references to elements
    {   Object[] v = new Object[elementCount];
	    System.arraycopy(elementData, 0, v, 0, elementCount);
	    return new HList( v );
    }   // end clone



    public final String toString() 
    {
	    int max = size() - 1;
	    StringBuffer buf = new StringBuffer();
	    buf.append("[");

	    for (int i = 0 ; i <= max ; i++) 
	    {
	        String s = ""+ elementData[i];
	        buf.append(s);
	        if (i < max) 
		        buf.append(", ");
	    }   // end for: each element
	    buf.append("]");
	    return buf.toString();
    }

/* ********  M Y   O W N   S T U F F  ******** */

    public final Object[] toArray()
    {   Object[] array = new Object[ elementCount ];
        System.arraycopy( elementData, 0, array, 0, elementCount );
        return array;
    }   // end toArray
    
    
    public Object[] toArray(Object array[]) 
    {
        if (array.length < elementCount)
            array = (Object[])java.lang.reflect.Array.newInstance(
            array.getClass().getComponentType(), elementCount);
	    System.arraycopy(elementData, 0, array, 0, elementCount);
        if (array.length > elementCount)
            array[elementCount] = null;
        return array;
    }   // end toArray
    
    public final void addArray( Object[] addThese )
    {
	    int newcount = elementCount + addThese.length;
	    if (newcount > elementData.length) 
	        ensureCapacityHelper(newcount);
	    
	    System.arraycopy( addThese, 0, elementData, elementCount, addThese.length );
        elementCount = newcount;
    }   // end addArray

}   // end class HList