/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.uvr.solvers.tabusearch4uvr;

import net.usa.rharder.tabusearch22.*;
import mil.af.afit.uvr.*;

class TS4UVRPenaltyFunction implements TSFunction
{
    private double[] costs = { 0 };
    
    public final double[] evaluate( TSSolution solution )
    {
        HSolution soln = ( (TS4UVRSolution) solution ).getHSolution();
        
        // Make an array of zeroes equal to the length of the costs array
        // but only if the array is not already properly set up.
        if( soln.getCosts().length != costs.length )
            costs = new double[ soln.getCosts().length ];
        
        return costs;
    }   // end evaluate

}   // end class TS4UVRPenaltyFunction