/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.uvr.solvers.tabusearch4uvr;

import net.usa.rharder.tabusearch22.*;
import mil.af.afit.uvr.*;

class TS4UVRSolution extends TSSolution
{
    private HSolution solution;
    
    public TS4UVRSolution( HSolution solution )
    {   this.solution = solution;
        super.setObjectiveValue( solution.getCosts() );
        super.setPenaltyValue( new double[ solution.getCosts().length ] );
    }   // end constructor
    
    
    public TS4UVRSolution( TS4UVRSolution copyThis )
    {   super( copyThis );
        this.solution = (HSolution) copyThis.getHSolution().clone();
    }   // end constructor
    
    
    
    public HSolution getHSolution()
    {   return solution;
    }   // end getHSolution
    
    
    
    
    public final boolean isBetterThan( TS4UVRSolution other )
    {
        boolean result = false;
        double[] first = this.getValue();
        
        if( first != null )
        {   
            if( other != null )
            {
                double[] second = other.getValue();
                
                if( second != null )
                {
                    int i=0;
                    int valLength = first.length;
                    
                    for( i = 0; i < valLength; i++ )
                    {
                        if( (float)first[i] > (float)second[i] )
                        {
                            result = false;
                            i = Integer.MAX_VALUE;
                            break;
                        }   // end if
                        else if( (float)first[i] < (float)second[i] )
                        {
                            result = true;
                            i = Integer.MAX_VALUE;
                            break;
                        }   // end else
                        // else it must have been equal
                    }   // end for: through each value
                }   // end if: second not null
                else
                {
                    // If the other solution is null then
                    // this solution is better.
                    result = true;
                }   // end else: second was null
            }   // end if: other was not null
            else
            {
                // If the other solution is null then
                // this solution is better.
                result = true;
            }   // end else: other was null
        }   // end if: first not null            
        return result;
    }   // end isBetterThan
    
    
    
    
    
    public Object clone()
    {   return new TS4UVRSolution( this );
    }   // end clone
    
    public String toString()
    {   return solution.toString();
    }   // end toString
    
}   // end TS4UVRSolution