/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

/**
 * This is the interface that sets up the information that gets passed
 * to and from the vehicle and the Universal Vehicle Router.
 * 
 * @author Robert Harder
 * @version 1.0
 * @since 1.0
 * @see HOrder
 */
public interface HVehicle 
extends Cloneable
{

    /**
     * Whether or not this vehicle supports this order. This is primarily
     * intended to check the type of order: dog food, infrared imagery, etc.
     * 
     * @param order order to check for support
     * @return whether or not this vehicle supports this order
     * @since 1.0
     * @see HOrder
     */
    public abstract boolean supportsHOrderType( HOrder order );
    

    /**
     * The amount of product that remains for this order type. 
     * 
     * @param orderType order type in question
     * @return amount of product left
     * @since 1.0
     * @see HOrder
     */
    public abstract int getCurrentAmountAvailableForOrderType( HOrder order );
    

    /**
     * Remove product for the specified order type.
     * 
     * @param amount amount to remove
     * @param orderType order type in qustion
     * @since 1.0
     * @see HOrder
     */
    public abstract void removeProductForOrderType( int amount, HOrder order );
    
    
    /**
     * Put product back for the specified order type.
     * 
     * @param amount amount to put back
     * @param orderType order type in question
     * @since 1.0
     * @see HOrder
     */
    public abstract void addProductForOrderType( int amount, HOrder order );
    
    
    /**
     * Reset the vehicle to have all its products for all order types.
     * This is called right before <code>HTour</code>s revalidate themselves.
     * 
     * @return ret
     * @since 1.0
     * @see HTour
     * @see HOrder
     */
    public abstract void resetProductsForAllOrderTypes();
    
    
    /**
     * Return the first time that the vehicle is available to start its journey.
     *
     * @since 1.0
     */
    public abstract double getEarliestDepartureTime();
    

/* ********  T R A V E L   M E T H O D S  ******** */


    
    /**
     * Return the time it takes to travel from <var>from</var> to <var>to</var>.
     * A null value represents the starting point (often the depot) for the first
     * argument and the ending point (also often the depot) for the second argument.
     * 
     * @param from where the vehicle travels from
     * @param to where the vehicle travels to
     * @return time to travel betwen <var>from</var> and <var>to</var>
     * @since 1.0
     * @see HOrder
     */
    public abstract double getTimeToTravel( HOrder from, HOrder to );

    
    /**
     * Return the time it takes to service the order.
     * 
     * @param order order to service
     * @return time to service the order
     * @since 1.0
     * @see HOrder
     */
    public abstract double getTimeToService( HOrder order );

    
    /**
     * Return the penalty for traveling from <var>from</var> to <var>to</var>.
     * A null value represents the starting point (often the depot) for the first
     * argument and the ending point (also often the depot) for the second argument.
     * The penalty should be in the same scale since it will likely be added to
     * the time value to evaluate the solution.
     * 
     * @param from where the vehicle travels from
     * @param to where the vehicle travels to
     * @return penalty for traveling betwen <var>from</var> and <var>to</var>
     * @since 1.0
     * @see HOrder
     */
    public abstract double getPenaltyForTravel( HOrder from, HOrder to );
    
    /**
     * Return the range of the vehicle, in time units.
     * 
     * @return vehicle range
     * @since 1.0
     */
    public abstract double getRange();


    /**
     * Copy the vehicle being careful to keep the product tracking variables
     * separate.
     *
     * @return a copy of this vehicle
     * @since 1.0
     */
    public abstract Object clone();

    
}   // end interface HVehicle