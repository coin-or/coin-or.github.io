/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

/**
 * The engine implements this internal interface 
 * to listen to the solvers.
 * 
 * @author Robert Harder
 * @version 1.0
 * @since 1.0
 * @see HSolver
 * @see HSolverEvent
 */

interface HSolverListener
{

    /**
     * Called when an event is triggered.
     * 
     * @param e the triggered event.
     * @since 1.0
     * @see HSolver
     * @see HSolverEvent
     */
    public abstract void HSolverEventPerformed( HSolverEvent e );
    
}   // end interface HSolverListener