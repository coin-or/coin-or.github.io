/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

/**
 * These events get passed from the engine to interested listeners
 * 
 * @author Robert Harder, rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see HEngine
 * @see HEngineListener
 */
public class HEngineEvent
{

    /**
     * The event type when the engine has started
     * 
     * @since 1.0
     */
    public static final int ENGINE_STARTED = 1;

    /**
     * The event type when the engine has finished.
     * 
     * @since 1.0
     */
    
    public static final int ENGINE_FINISHED = 2;

    /**
     * The event type when the engine has reported its progress.
     * 
     * @since 1.0
     */
    
    public static final int PERCENT_DONE = 3;


    /**
     * The event type when the engine has found a new best solution.
     * 
     * @since 1.0
     */
    
    public static final int NEW_BEST_SOLUTION = 4;
    
    
    /**
     * The event type when a solver has started
     * 
     * @since 1.0
     */
    public static final int SOLVER_STARTED = 5;


    /**
     * The event type.
     * 
     * @since 1.0
     */
    private int eventType;

    /**
     * The source of the event. It should be of type
     * <code>HEngine</code>.
     * 
     * @since 1.0
     */
    private Object source;


    /**
     * Constructor for <code>HEngineEvent</code>
     * 
     * @param eventType event type
     * @param source source of the event. 
     *               Normally <code>this</code> is passed.
     * @since 1.0
     */
    
    public HEngineEvent( int eventType, Object source )
    {   this.eventType = eventType;
        this.source = source;
    }   // end constructor

    /**
     * Returns the source of the event. It should be of type <code>HEngine</code>
     * 
     * @return source of the event.
     * @since 1.0
     * @see HEngine
     */
    public final Object getSource()
    {   return source;
    }   // end getSource

    /**
     * Returns the source of the event, casted to <code>HEngine</code>. This
     * is identical to
     * <P><tt><pre>
     *     (HEngine) e.getSource();
     * </pre</tt>
     *
     * @return source of the event.
     * @since 1.0
     * @see HEngine
     */
    public final HEngine getHEngine()
    {   return (HEngine) source;
    }   // end getHEngine

    /**
     * Returns the event type.
     * 
     * @return event type
     * @since 1.0
     */
    public final int getEventType()
    {   return eventType;
    }   // end getEventType
    
    
    public String toString()
    {   switch( eventType )
        {   case ENGINE_STARTED:
                return "ENGINE_STARTED";
            case ENGINE_FINISHED:
                return "ENGINE_FINISHED";
            case PERCENT_DONE:
                return "PERCENT_DONE (" + (int)(((HEngine)source).getPercentDone()*100) + "%)";
            case NEW_BEST_SOLUTION:
                return "NEW_BEST_SOLUTION";
            default:
                return null;
        }   // end switch
    }   // end toString
    
}   // end class HEngineEvent