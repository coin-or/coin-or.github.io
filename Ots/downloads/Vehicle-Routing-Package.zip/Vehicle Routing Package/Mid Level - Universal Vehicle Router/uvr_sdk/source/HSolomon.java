/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr; 

/**
 * Uses a modified version of Solomon's insertion heurisitc 
 * criterion(i) (1987) to create an initial solution
 * 
 * @author Gary Kinney
 * @author gkinney@ix.netcom.com
 * @version 1.0
 * @since 1.0
 */
class HSolomon
{
    public static final int COST_BASED = 0;
    public static final int TW_BASED = 1;
    
    private double bestalpha1=.5;
    private double bestalpha2=.5;
    private double bestmu=1;
    private double bestlambda=1;
    private int bestinitmethod=0;
    private double requestedSolutionEffort;
    private HEvaluator evaluator;
//    private int maxparams = 176;
    private double[][] parameters = new double[176][5];
    private boolean usepriorities;
    private boolean canceled = false;
    
    /**
     * Returns the init method used to generate the best solution found
     *
     * @return int
     * @since 1.0
     */
    public final int getBestInitMethod()
    {
        return bestinitmethod;
    }
    
    /**
     * Returns the alpha1 parameter used to generate the best solution found
     *
     * @return double
     * @since 1.0
     */
    public final double getBestAlpha1()
    {
        return bestalpha1;
    }
 
    /**
     * Returns the alpha2 parameter used to generate the best solution found
     *
     * @return double
     * @since 1.0
     */
    public final double getBestAlpha2()
    {
        return bestalpha2;
    }
 
    /**
     * Returns the mu parameter used to generate the best solution found
     *
     * @return double
     * @since 1.0
     */
    public final double getBestMu()
    {
        return bestmu;
    }
 
    /**
     * Returns the alpha2 parameter used to generate the best solution found
     *
     * @return double
     * @since 1.0
     */
    public final double getBestLambda()
    {
        return bestlambda;
    }
    
    public HSolomon( HEvaluator evaluator, double requestedSolutionEffort )
    {   
        int i = 0;
        double a1, a2, mu, la;
        
        this.requestedSolutionEffort = requestedSolutionEffort;
        this.evaluator = evaluator;
        
        // Used in calculating step sizes:
        double U, L, s;
        int S, P;

        final double e1 = requestedSolutionEffort;
        double U1 = 1.0;
        double L1 = 0.0;
        int P1 = 11;
        int S1 = 1 + (int)((P1-1)*e1);
        double s1 = (U1 - L1) / (S1 - 1);
        //double s1 = (U1 - L1)/((int)((P1 - 2)*e1+1));
        double e = ( e1 * (-1 + P1))%1;
        if( e1 > 0 && (float)e == 0 )
            e = 1;
//System.out.println( "HSolomon.constructor: outer step size=" + s1);
//System.out.println( "HSolomon.constructor: e1="+e1+" e="+e);

        for( a1 = L1; a1 <= U1; a1 += s1 )
//        for ( a1 = 0.0; a1 <= 1.0; a1 += 0.1 )
        {
            a2 = 1.0 - a1;
            mu = 1;

            U = 1.5;
            L = 0.0;
            P = 4;
            S = 1 + (int)((P-1)*e);
            s = (U - L) / (S - 1);
            //s = (U - L)/((int)((P - 2)*e+1));
//System.out.println( "HSolomon.constructor: first s=" + s );
            for( la = L; la <= U; la += s )
//            for ( la = 0.0; la <= 1.5; la += 0.5 )
            {
//System.out.println( "HSolomon.constructor: first la=" + la );
                parameters[i][0] = a1;
                parameters[i][1] = a2;
                parameters[i][2] = mu;
                parameters[i][3] = la;
                parameters[i][4] = COST_BASED;
                i++;
                parameters[i][0] = a1;
                parameters[i][1] = a2;
                parameters[i][2] = mu;
                parameters[i][3] = la;
                parameters[i][4] = TW_BASED;
                i++;
            } // end for
                

            U = 2.0;
            L = 1.25;
            P = 4;
            S = 1 + (int)((P-1)*e);
            s = (U - L) / (S - 1);
            //s = (U - L)/((int)((P - 2)*e+1));
//System.out.println( "HSolomon.constructor: second s=" + s );
            for( la = L; la <= U; la += s )
//            for ( la = 1.25; la <= 2.0; la += 0.25 )
            {
//System.out.println( "HSolomon.constructor: la=" + la );
                mu = la - 1;
                parameters[i][0] = a1;
                parameters[i][1] = a2;
                parameters[i][2] = mu;
                parameters[i][3] = la;
                parameters[i][4] = COST_BASED;
                i++;
                parameters[i][0] = a1;
                parameters[i][1] = a2;
                parameters[i][2] = mu;
                parameters[i][3] = la;
                parameters[i][4] = TW_BASED;
                i++;
            } // end for
        } // end for
        
        // Now trim paramaters array down to size. 'i' = length;
        double[][] temp = new double[i][parameters[0].length];
        System.arraycopy( parameters,0, temp,0, i );
        parameters = temp;
        //System.out.println( "HSolomon.constructor: (fixed) parameters: " + parameters.length );
    }   // end constructor
       
    /**
     * Returns an array of type <code>HSolution</code> containing initial feasible 
     * solutions generated using Solomon's insertion heuristic over a range of
     * parameter values.  The array is sorted best to worst based on evaluation 
     * criterea provide in the HEvaluate object.
     * 
     * @param vehicles    vehicles used to service orders
     * @param orders   orders to be serviced
     * @return <code>HSolution</code>[]
     * @since 1.0
     */
   public final HSolution[] createMultipleHSolutions( 
   HVehicle[] vehicles, HOrder[] orders, HEngine parent )
   {
        double alpha1, alpha2, mu, lambda;
        HSolution solution;
        HSolution[] solutions = new HSolution[parameters.length];
        //int maxsolutions = (int) Math.max( 5,
        //    (maxparams*requestedSolutionEffort) );
        
        usepriorities = false;
        
        for ( int i = 0; i < parameters.length; i++ )
        {
            if( canceled )
                return null;
            
            solution = createHSolution( vehicles, orders, 
            parameters[i][0], parameters[i][1], parameters[i][2], parameters[i][3], (int) parameters[i][4], usepriorities );
            
            Thread.yield();
            
            if( i == 0 && solution.getDummyHTour().size() > 0 )
            {   usepriorities = true;
            }   // end if: skipped orders, so make sure priorities are being used
            
            insertHSolution( solution, solutions, parameters[i][0], parameters[i][1], parameters[i][2], parameters[i][3], (int) parameters[i][4] );
                
            // reset the supplies and demands
            for( int j = 0; j < vehicles.length; j++)
                vehicles[j].resetProductsForAllOrderTypes();
                        
//                for( int j = 0; j < orders.length; j++)
//                    orders[j].resetOrder();
                
            // Report progress of heuristic (code at end of file)
            if( parent != null )
                parent.solomonReportingProgress( (float) i / parameters.length );
        } // end for        
        
        // Make array from 0 to first null solution-1
        int posOfFirstNull = -1;
        int i = 0;
        while( posOfFirstNull < 0 && i < solutions.length )
        {   if( solutions[i] == null )
            {   posOfFirstNull = i;
            }   // end if
            i++;
        }   // end while
        
        HSolution[] tempSolutions;
        if( posOfFirstNull >= 0 )
        {   tempSolutions = new HSolution[ posOfFirstNull ];
            System.arraycopy( solutions, 0, tempSolutions, 0, posOfFirstNull );
            solutions = tempSolutions;
        }   // end if
        
        return solutions;
   } // end createMultipleHSolutions

   /**
    * Inserts a solution in the array of solutions based on user defined  
    * quality.  Duplicate solutions are dropped.
    * 
    * @param solution    solution to be inserted
    * @param solutions   array of solutions sorted by objective function value
    * @param a1          alpha1 parameter used to generate the solution
    * @param a2          alpha2 parameter used to generate the solution
    * @param mu          mu parameter used to generate the solution
    * @param lam         lam parameter used to generate the solution
    * @param method      init method used to generate the solution
    * @since 1.0
    */
   private final void insertHSolution( 
   HSolution solution, HSolution[] solutions, 
   double a1, double a2, double mu, double la, double im )
   {
        boolean done = false, better, same;
        double[] costs, newcosts;
        int i;
        
        i = 0;
        while ( !done )
        {
            if ( solutions[i] == null )
            {
                solutions[i] = solution;
                done = true;
                if ( i == 0 )
                {
                    bestalpha1 = a1;
                    bestalpha2 = a2;
                    bestmu = mu;
                    bestlambda = la;
                    bestinitmethod = (int) im;
                }
            } // end if
            else 
            {
                costs = solutions[i].getCosts();
                newcosts = solution.getCosts();
                better = false;
                same = true;
                
                for ( int j = 0; j < costs.length; j++ )
                {
                    if ( newcosts[j] < costs[j] )
                    {
                        better = true;
                        same = false;
                    } // end if
                    else if ( (int) newcosts[j] != (int) costs[j] )
                    {
                        better = false;
                        same = false;
                    } // end else if
                    if ( !same )
                        break;
                } // end for   
                
                if ( !same && better )
                {
                    System.arraycopy( solutions, i, solutions, i+1, 
                        parameters.length-1-i );
                    solutions[i] = solution;
                    done = true;
                    if ( i == 0 )
                    {
                        bestalpha1 = a1;
                        bestalpha2 = a2;
                        bestmu = mu;
                        bestlambda = la;
                        bestinitmethod = (int) im;
                    }
                } // end if
                
                if ( same )
                    done = true;
                    
            } // end else
            i++;                    
        } // end while
    } // end insertHSolution

    /**
     * Returns an <code>HSolution</code> based on Solomon's insertion
     * heuristic and the default parameters.
     * 
     * @param vehicles    vehicles used to service orders
     * @param orders      orders to be serviced
     * @return <code>HSolution</code>
     * @since 1.0
     */
    public final HSolution createHSolution( 
    HVehicle[] vehicles, HOrder[] orders )
    {
        return createHSolution( vehicles, orders, bestalpha1, bestalpha2, bestmu, bestlambda, bestinitmethod, usepriorities );
    }
    
    /**
     * Returns an <code>HSolution</code> based on Solomon's insertion
     * heuristic and the parameters provided.
     * 
     * @param vehicles    vehicles used to service orders
     * @param orders      orders to be serviced
     * @param alpha1      influence of route cost in insertion cost
     * @param alpha2      influence of delay in insertion cost
     * @param mu          influence of previous segment in insertion cost
     * @param lambda      influence of direct service cost in next 
     *                    order selection
     * @param initmethod  0 for cost based, 1 for timewindow based 
     * @param usepriorities  true if priorities are to be used in routing
     * @return <code>HSolution</code>
     * @since 1.0
     */
    public final HSolution createHSolution( 
    HVehicle[] vehicles, HOrder[] orders, double alpha1,
    double alpha2, double mu, double lambda, int initmethod, boolean usepriorities )
    {   
        HTour tour;
        boolean toursfull=false;
        boolean unroutedorders=orders.length > 0 ? true : false;
        double[] costs = new double[3];
        
        HSolution solution = new HSolution( vehicles, orders );
        
        while ( !toursfull && unroutedorders )
        {
            tour = initializeHTour( solution, initmethod, usepriorities );
            fillHTour( solution.getDummyHTour(), tour, alpha1, alpha2, mu, lambda, usepriorities );
 
            // Check to see if more tours are available, assume no
            toursfull = true;
            for ( int i = 0; i < solution.getHTours().length; i++ )
                if ( solution.getHTours()[i].size() == 0 )
                    toursfull = false;
            
            // Check to see if there are unrouted orders, assume no
            if ( solution.getDummyHTour().size() == 0 )
                unroutedorders = false;
                
        }
        // validate the solution and set costs
        solution.validateTours();
                    
        solution.validate( evaluator );
        
        return solution;
    }   // end createHSolution

    /**
     * Initializes the tour based on one of two methods: 
     *     0 - costliest from depot
     *     1 - earliest latest arrival time
     * 
     * @param solution  solution containing the tours to initialize
     * @param method    0 for cost-based 1 for timewindow-based
     * @param usepriorities  true if priorities are to be used in routing
     * @return HTour     
     * @since 1.0
     */
    private final HTour initializeHTour( HSolution solution, int method, boolean usepriorities )
    {
        HTour tour;
        
        switch ( method ) 
        {
            case COST_BASED:
                tour = costliestFirst( solution, usepriorities );
                break;
            case TW_BASED:
                tour = earliestFirst( solution, usepriorities );
                break;
            default:
                tour = costliestFirst( solution, usepriorities );
        }   // end switch
        return tour;
    }   // end initializeHTour 
    
    /**
     * Finds the order with the earliest deadline 
     * and assigns it to the nearest vehicle
     * 
     * @param solution  solution containing the tours to initialize
     * @param usepriorities  true if priorities are to be used in routing
     * @return HTour
     * @since 1.0
     */
    private final HTour earliestFirst( HSolution solution, boolean usepriorities )
    {
        int cheapestroute = 0;
        double cheapestcost;
        double cost;
        double time = Double.MAX_VALUE;
        int priority = Integer.MAX_VALUE;
        int amount;
        int candidate = 0;
        HTour[] tours = solution.getHTours();
        HTour orders = solution.getDummyHTour();
        boolean gotsome;
        
        // find the highest priority order with the earliest deadline
        for( int i = 0; i < orders.size(); i++ )
        {
            if ( usepriorities )
                if ( orders.getHOrderAt(i).getPriority() < priority )
                {
                    priority = orders.getHOrderAt(i).getPriority();
                    time = orders.getHOrderAt(i).getLatestDepartureTime();
                    candidate = i;
                } else if ( orders.getHOrderAt(i).getPriority() == priority && orders.getHOrderAt(i).getLatestDepartureTime() < time )
                {
                    time = orders.getHOrderAt(i).getLatestDepartureTime();
                    candidate = i;
                } // end if
            else
                if ( orders.getHOrderAt(i).getLatestDepartureTime() < time )
                {
                    priority = orders.getHOrderAt(i).getPriority();
                    time = orders.getHOrderAt(i).getLatestDepartureTime();
                    candidate = i;
                } // end if
            
            
        } //end for

        cheapestcost = Double.MAX_VALUE;
        for ( int j = 0; j < tours.length; j++ )
        {
            // if the route is empty
            if ( tours[j].size() == 0 )
            {
                gotsome = false;
                if ( tours[j].getHVehicle().supportsHOrderType( orders.getHOrderAt(candidate) ) )
                    if ( tours[j].getHVehicle().getCurrentAmountAvailableForOrderType( orders.getHOrderAt(candidate) ) 
                        >= orders.getHOrderAt(candidate).getAmountNeeded() )
                        gotsome = true;
                        
                // if the vehicle has the needed supplies       
                if ( gotsome )
                {
                    // is it the cheapest so far?
                    if ( tours[j].getHVehicle().getTimeToTravel( null, orders.getHOrderAt(candidate) ) +
                         tours[j].getHVehicle().getPenaltyForTravel( null, orders.getHOrderAt(candidate) ) < cheapestcost )
                    {
                        cheapestroute = j;
                        cheapestcost = tours[j].getHVehicle().getTimeToTravel( null, orders.getHOrderAt(candidate) );
                    }   // end if
                } // end if
            }   // end if
        }   // end for
        
        // insert the candidate in the cheapest route and remove from dummy
        
        tours[cheapestroute].insertHOrderAt( orders.getHOrderAt(candidate), 0 );
        orders.removeHOrderAt( candidate );
        
        // service the order
        amount = tours[cheapestroute].getHOrderAt(0).getAmountNeeded();
        tours[cheapestroute].getHVehicle().removeProductForOrderType( amount, tours[cheapestroute].getHOrderAt(0) );
    
        return tours[cheapestroute];
    }   // end earliestFirst    

    /**
     * Finds the orders with the costliest segment to the nearest vehicle 
     * and assigns it to the nearest vehicle
     * 
     * @param solution  solution containing the tours to initialize
     * @param usepriorities  true if priorities are to be used in routing
     * @return HTour
     * @since 1.0
     */
    private final HTour costliestFirst( HSolution solution, boolean usepriorities )
    {
        int cheapestroute, maxcostminroute, candidate;
        int amount, priority = Integer.MAX_VALUE;
        double cheapestcost, maxcost;
        HTour[] tours = solution.getHTours();
        HTour orders = solution.getDummyHTour();
        boolean gotsome;
                    
        maxcost = 0;
        candidate = 0;
        maxcostminroute = 0;
        cheapestroute = 0;
            
        // for each order not serviced, find the cheapest route for insertion and insert it
        for ( int i = 0; i < orders.size(); i++ )
        {
            cheapestcost = Double.MAX_VALUE;
            for ( int j = 0; j < tours.length; j++ )
            {
                // if the route is empty
                if ( tours[j].size() == 0 )
                {
                    gotsome = false;
                    if ( tours[j].getHVehicle().supportsHOrderType( orders.getHOrderAt(i) ) )
                        if ( tours[j].getHVehicle().getCurrentAmountAvailableForOrderType( orders.getHOrderAt(i) ) 
                            >= orders.getHOrderAt(i).getAmountNeeded() )
                            gotsome = true;
                        
                    // if the vehicle has the needed supplies       
                    if ( gotsome )
                    {
                        // is it the cheapest so far?
                        if ( tours[j].getHVehicle().getTimeToTravel( null, orders.getHOrderAt(i) ) +
                             tours[j].getHVehicle().getPenaltyForTravel( null, orders.getHOrderAt(i) ) < cheapestcost )
                        {
                            cheapestroute = j;
                            cheapestcost = tours[j].getHVehicle().getTimeToTravel( null, orders.getHOrderAt(i) );
                        } // end if
                    } // end if
                } // end if
            } // end for
                
            // is this order's priority higher or min cost greater than the incumbent maxcost
            if ( usepriorities )
                if ( orders.getHOrderAt(i).getPriority() < priority && cheapestcost != Double.MAX_VALUE )
                {
                    priority = orders.getHOrderAt(i).getPriority();
                    candidate = i;
                    maxcostminroute = cheapestroute;
                    maxcost = cheapestcost;
                } else if ( orders.getHOrderAt(i).getPriority() == priority && cheapestcost > maxcost )
                {
                    candidate = i;
                    maxcostminroute = cheapestroute;
                    maxcost = cheapestcost;
                } // end if
            else
                if ( cheapestcost > maxcost )
                {
                    priority = orders.getHOrderAt(i).getPriority();
                    candidate = i;
                    maxcostminroute = cheapestroute;
                    maxcost = cheapestcost;
                } // end if
            
        } // end for
        
        // insert the candidate in the cheapest route and remove from dummy
  
        tours[maxcostminroute].insertHOrderAt( orders.getHOrderAt(candidate), 0 );
        orders.removeHOrderAt( candidate );

        // service the order
        amount = tours[maxcostminroute].getHOrderAt(0).getAmountNeeded();
        tours[maxcostminroute].getHVehicle().removeProductForOrderType( amount, tours[maxcostminroute].getHOrderAt(0) );
        
        return tours[maxcostminroute];
    } // end costliestFirst

    /**
     * Assigns the remaining orders based on the heuristic
     * parameters provided
     * 
     * @param orders      a dummy tour containing unfilled orders
     * @param tour        current working tour
     * @param alpha1      influence of route cost in insertion cost
     * @param alpha2      influence of delay in insertion cost
     * @param mu          influence of previous route in route cost
     * @param lambda      influence of direct service cost in next 
     * @param usepriorities  true if priorities are to be used in routing
     *                    order selection
     * @since 1.0
     */
    private final void fillHTour(
    HTour orders, HTour tour, double alpha1, double alpha2, double mu, double lambda, boolean usepriorities )
    {
        int best, amount, priority = Integer.MAX_VALUE;
        boolean unroutedorders = true;
        boolean tourfull = false;
        boolean gotsome;
        double[] cost = new double[orders.size()]; 
        int[] index = new int[orders.size()];
        double[] temp = new double[2];
        
        // fill the tours until all orders are serviced or all tours are full
        while ( unroutedorders && !tourfull )
        {
            // initialize insertion point costs
            for ( int p = 0; p < orders.size(); p++ )
                cost[p] = Double.MAX_VALUE;
                
            // assume all custmers are serviced until we find one that isn't
            unroutedorders = false;
            // assume tours full until we find a spot
            tourfull = true;

            for( int i = 0; i < orders.size(); i++)
            {
                if ( orders.getHOrderAt(i).getAmountNeeded() > 0 )
                {
                    unroutedorders = true;
                    
                    gotsome = false;
                    if ( tour.getHVehicle().supportsHOrderType( orders.getHOrderAt(i) ) )
                        if ( tour.getHVehicle().getCurrentAmountAvailableForOrderType( orders.getHOrderAt(i) ) 
                            >= orders.getHOrderAt(i).getAmountNeeded() )
                            gotsome = true;

                    if ( gotsome )
                    {
                        temp = getBestInsertionPoint( orders.getHOrderAt(i), tour, alpha1, alpha2, mu );
                        index[i] = (int) temp[0];
                        cost[i] = temp[1];
                        if ( index[i] != -1 )
                            tourfull = false;
                    } // end if 
                } // end if                
            } // end for
            
            // find the best candidate to insert and insert it
            if ( !tourfull )
            {
                best = 0;
                priority = Integer.MAX_VALUE;
                for ( int k = 0; k < orders.size(); k++ )
                    if ( index[k] != -1 )
                    {
                        if ( usepriorities )
                        {
                            if ( orders.getHOrderAt(k).getPriority() < priority && cost[k] != Double.MAX_VALUE )
                            {
                                priority = orders.getHOrderAt(k).getPriority();
                                best = k;
                            }    
                            else if ( orders.getHOrderAt(k).getPriority() == priority &&
                                    (lambda * tour.getHVehicle().getTimeToTravel( null, orders.getHOrderAt(k) ) + 
                                    lambda * tour.getHVehicle().getPenaltyForTravel( null, orders.getHOrderAt(k) ) - cost[k] )
                                    > (lambda * tour.getHVehicle().getTimeToTravel( null, orders.getHOrderAt(best) ) +
                                    lambda * tour.getHVehicle().getPenaltyForTravel( null, orders.getHOrderAt(best) ) - cost[best] ) )
                                    {
                                        best = k;
                                    }
                        }
                        else if ( ( lambda * tour.getHVehicle().getTimeToTravel( null, orders.getHOrderAt(k) ) + 
                               lambda * tour.getHVehicle().getPenaltyForTravel( null, orders.getHOrderAt(k) ) - cost[k] )
                               > (lambda * tour.getHVehicle().getTimeToTravel( null, orders.getHOrderAt(best) ) +
                               lambda * tour.getHVehicle().getPenaltyForTravel( null, orders.getHOrderAt(best) ) - cost[best] ) )
                               {
                                    best = k;
                                    priority = orders.getHOrderAt(k).getPriority();
                               }
                    }       
                
                tour.insertHOrderAt( orders.getHOrderAt( best ), index[best] );
                orders.removeHOrderAt( best );
                
                // service the order
                amount = tour.getHOrderAt( index[best] ).getAmountNeeded();
                tour.getHVehicle().removeProductForOrderType( amount, tour.getHOrderAt( index[best] ) );

            } // end if
        } // end while
    } // end fillHTour
    
    /**
     * Returns two doubles, the first is the index of the best insertion
     * point and the second is the heuristic cost of the insertion at that
     * point
     *
     * @param order       order to be inserted
     * @param tour        tours to insert order
     * @return double[]
     * @since 1.0
     */
    public final double[] getBestInsertionPoint(
    HOrder order, HTour tour )
    {
        return getBestInsertionPoint( order, tour, bestalpha1, bestalpha2, bestmu );
    }
    
    /**
     * Returns two doubles, the first is the index of the best insertion
     * point and the second is the heuristic cost of the insertion at that
     * point
     *
     * @param order       order to be inserted
     * @param tour        tours to insert order
     * @param alpha1      influence of route cost in insertion cost
     * @param alpha2      influence of delay in insertion cost
     * @param mu          influence of previous segment in insertion cost
     * @return double[]
     * @since 1.0
     */
    public final double[] getBestInsertionPoint( 
    HOrder order, HTour tour, double alpha1, double alpha2, double mu )
    {
        double diu, duj, dij;
        double piu, puj, pij;
        double bi, bj, buj, si, eaj, laj, sj, bu, su, eau, lau;
        double jert, jlrt, uert, ulrt;
        double distancecost, delaycost, cost, cheapestcost;
        HOrder iorder, jorder;
        boolean TWfeasible;
        double[] insertiondata = new double[2];
        
        insertiondata[1] = Double.MAX_VALUE;
        insertiondata[0] = -1;
        
        cheapestcost = Double.MAX_VALUE;
        bi = 0;
        
        // initialize values for the order to be inserted
        su = tour.getHVehicle().getTimeToService( order );
        eau = order.getEarliestArrivalTime();
        lau = order.getLatestDepartureTime() - su;
        uert = order.getEarliestRestrictedTime();
        ulrt = order.getLatestRestrictedTime();
        
        for( int i = -1; i < tour.size(); i++ )
        {
            TWfeasible = true;
            
            // get values for the orders on either side of the insertion point
            if ( i == -1 )
            {
                iorder = null;
                si = 0;
            } 
            else 
            {
                iorder = tour.getHOrderAt(i);
                si = tour.getHVehicle().getTimeToService( iorder );
            } // end if
            
            if ( i == tour.size() - 1 )
            {
                jorder = null;
                eaj = 0;
                sj = 0;
                laj = tour.getHVehicle().getRange();
                jert = Double.MIN_VALUE;
                jlrt = Double.MIN_VALUE;
            }
            else
            {
                jorder = tour.getHOrderAt(i+1);
                sj = tour.getHVehicle().getTimeToService( jorder );
                eaj = jorder.getEarliestArrivalTime();
                laj = jorder.getLatestDepartureTime() - sj;
                jert = jorder.getEarliestRestrictedTime();
                jlrt = jorder.getLatestRestrictedTime();
            } // end if
            
            // calculate distances
            diu = tour.getHVehicle().getTimeToTravel( iorder, order );
            duj = tour.getHVehicle().getTimeToTravel( order, jorder );
            dij = tour.getHVehicle().getTimeToTravel( iorder, jorder );
            distancecost = diu + duj - ( mu * dij );
            
            // calculate penalties
            piu = tour.getHVehicle().getPenaltyForTravel( iorder, order );
            puj = tour.getHVehicle().getPenaltyForTravel( order, jorder );
            pij = tour.getHVehicle().getPenaltyForTravel( iorder, jorder );
            distancecost = distancecost + piu + puj - ( mu * pij );
            
            // calculate the delay in service to order j when order u is inserted before it
            bj = Math.max( bi + dij + si, eaj );
            if ( bj < jlrt && bj + sj > jert )
                bj = jlrt;
            bu = Math.max( bi + diu + si, eau );
            if ( bu < ulrt && bu + su > uert )
                bu = ulrt;
            buj = Math.max( bu + su + duj, eaj);
            if ( buj < jlrt && buj + sj > jert )
                buj = jlrt;
            delaycost = buj - bj;
                               
            // check to see if insertion is time window feasible
            cost = alpha1 * distancecost + alpha2 * delaycost;
            if ( cost < cheapestcost )
            {
                if ( buj < laj && bu < lau )
                    if ( i == tour.size() - 1 )
                        TWfeasible = true;
                    else    
                        TWfeasible = isTWFeasible( i+1, buj + sj, tour );
                else
                    TWfeasible = false;

                // if the insertion point is TWfeasible compare it to the cheapest so far
                if ( TWfeasible )
                {
                    cheapestcost = cost;
                    insertiondata[0] = i+1;
                    insertiondata[1] = cost;
                } // end if
            } // end if
            
            // set time for next iteration
            bi = bj;
        } // end for
        return insertiondata;
    } // end getBestInsertionPoint;
    
    /**
     * Checks from index i to the end of the route to check for 
     * time window feasibility.  By Solomon's lemma 1.1 as soon as
     * a node is found that has not been delayed by the insertion
     * the rest of the tour remains TW feasible
     * 
     * @param i           index to start checking
     * @param ei          time service ended at node i
     * @param tour        tours to insert order
     * @return boolean
     * @since 1.0
     */
    private final boolean isTWFeasible( 
    int i, double ei, HTour tour )
    {
        double time = ei;
        int j = i;
        boolean done = false, TWfeasible=true;
        double ea, la, st;
        double ert, lrt;
        HOrder start, end;
        
        while ( !done )
        {
            // get node info
            if ( j == tour.size() - 1 )
            {
                start = tour.getHOrderAt( j );
                end = null;
                ea = 0;
                la = tour.getHVehicle().getRange();
                ert = Double.MIN_VALUE;
                lrt = Double.MIN_VALUE;
                st = 0;
                done = true;
            }
            else
            {
                start = tour.getHOrderAt( j );
                end = tour.getHOrderAt(j+1);
                st = tour.getHVehicle().getTimeToService( end );
                ea = end.getEarliestArrivalTime();
                la = end.getLatestDepartureTime() - st;
                ert = end.getEarliestRestrictedTime();
                lrt = end.getLatestRestrictedTime();
            } // end if
            
            // update time of arrival to next node
            time = time + tour.getHVehicle().getTimeToTravel( start, end );
            
            // if time of arrival is too late, the route is not TW feasible 
            if ( time > la )
            {
                TWfeasible = false;
                done = true;
            } // end if
             
            // if time of arrival is too early, the rest off the route remains TW feasible    
            if ( time < ea )
                done = true;
            
            // update time to reflect end of service
            if ( Math.max( time, ea ) + st > ert && Math.max( time, ea ) < lrt )
                time = lrt + st;
            else
                time = Math.max( time, ea ) + st;
            j++;
        } // end while
        return TWfeasible; 
    } // end isTWfeasible
    
    
    public void cancel()
    {   canceled = true;
    }   // end cancel
    
}   // end class JSolomon