/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

/**
 * These events get passed from the solvers to the UVR engines.
 * 
 * @author Robert Harder
 * @version 1.0
 * @since 1.0
 * @see HSolverListener
 * @see HSolver
 */
class HSolverEvent
{

    /**
     * The event type when the solver has started.
     * 
     * @since 1.0
     */
    public static final int SOLVER_STARTED = 1;

    /**
     * The event type when the solver has finished.
     * 
     * @since 1.0
     */
    public static final int SOLVER_FINISHED = 2;

    /**
     * The event type when the solver has reported its progress.
     * 
     * @since 1.0
     */
    public static final int PERCENT_DONE = 3;

    /**
     * The event type when the solver has found a new best solution.
     * 
     * @since 1.0
     */
    public static final int NEW_BEST_SOLUTION = 4;

    /**
     * The event type.
     * 
     * @since 1.0
     */
    private int eventType;

    /**
     * The source of the event. It should be of type
     * <code>HSolver</code>.
     * 
     * @since 1.0
     * @see HSolver
     */
    private Object source;


    /**
     * Constructor for <code>HSolverEvent</code>
     * 
     * @param eventType event type
     * @param source source of the event. 
     *               Normally <code>this</code> is passed.
     * @since 1.0
     * @see HSolver
     */
    
    public HSolverEvent( int eventType, Object source )
    {   this.eventType = eventType;
        this.source = source;
    }   // end constructor

    /**
     * Returns the source of the event.
     * 
     * @return source of the event.
     * @since 1.0
     * @see HSolver
     */
    public final Object getSource()
    {   return source;
    }   // end getSource

    /**
     * Equivalent to <code>(HSolver)e.getSource()</code>.
     *
     * @return source
     * @since 1.0
     * @see HSolver
     */
    public final HSolver getHSolver()
    {   return (HSolver) source;
    }   // end getHSolver

    /**
     * Returns the event type.
     * 
     * @return event type
     * @since 1.0
     */
    public final int getEventType()
    {   return eventType;
    }   // end getEventType
    
    
    
    public String toString()
    {   switch( eventType )
        {   case SOLVER_STARTED:
                return "SOLVER_STARTED";
            case SOLVER_FINISHED:
                return "SOLVER_FINISHED";
            case PERCENT_DONE:
                return "PERCENT_DONE (" + (int)(((HSolver)source).getPercentDone()*100) + "%)";
            case NEW_BEST_SOLUTION:
                return "NEW_BEST_SOLUTION";
            default:
                return "UNKNOWN EVENT TYPE";
        }   // end switch
    }   // end toString
    
}   // end class HSolverEvent