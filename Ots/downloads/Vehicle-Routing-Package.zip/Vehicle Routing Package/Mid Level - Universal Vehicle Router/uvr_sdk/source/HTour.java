/*  Universal Vehicle Router (UVR)
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/uvr
 */
package mil.af.afit.uvr;

/**
 * A tour contains a vehicle and a list of customers to visit. If it is changed,
 * the associated <code>HSolution</code> object should be <code>invalidate</code>ed.
 * 
 * @author Robert Harder
 * @version 1.0
 * @since 1.0
 * @see HOrder
 * @see HVehicle
 * @see HSolution
 */
public final class HTour implements Cloneable//ReallyCloneable
{
    // Return time minus departure time
    private double totalTravelTime = 0;
    
    // Time spent waiting at orders because of time windows/walls
    private double totalWaitingTime = 0;
    
    // Penalties for traveling certain legs of a journey. Should be
    // in the same units as time.
    private double totalPenalty = 0;
    
    // Number of busted time windows
    private int bustedTimeWindows = 0;
    
    // Number of busted time walls
    private int bustedTimeWalls = 0;
    
    // Time the vehicle departs
    private double departureTime = 0;
    
    // Time the vehicle returns
    private double returnTime = 0;
    
    // Route containing the orders
    protected HList route;
    
    // Whether or not the tour is valid after whatever has changed
    private boolean tourValid = false;
    
    
    // These three arrays track useful information about individual orders
    private  double[] estimatedArrivalTimes = null;
    private double[] estimatedDepartureTimes = null;
    private double[] estimatedWaitTimes = null;
    private boolean[] serviced = null;

    /**
     * The vehicle associated with the tour.
     * 
     * @since 1.0
     */
    private HVehicle vehicle;

    /**
     * Constructs a tour based on the given vehicle
     * 
     * @param vehicle the vehicle to associate with the tour
     * @since 1.0
     * @see HVehicle
     */
    public HTour( HVehicle vehicle )
    {   this.vehicle = vehicle;
        this.route = new HList();
    }   // end constructor
    
    /**
     * Constructs a tour based on the given vehicle and places
     * the orders in the tour in the same order as in the array.
     *
     * @param vehicle vehicle for the tour
     * @param orders orders to put in the array
     * @since 1.0
     * @see HVehicle
     * @see HOrder
     */
    public HTour( HVehicle vehicle, HOrder[] orders )
    {
        this.vehicle = vehicle;
        this.route = new HList();
        for( int i = 0; i < orders.length; i++ )
        {   route.addElement( orders[i] );
        }   // end for: through each order
    }   // end constructor
    
    /**
     * Constructs a copy of the tour based on the passed tour.
     *
     * @param copyThis tour to copy
     * @since 1.0
     */
    public HTour( HTour copyThis )
    {
        // Makes a new HTour that is an exact copy of this, right
        // down to the last order.
        
        // Copy vehicle
        HVehicle copyVehicle = (HVehicle) copyThis.getHVehicle();
        if( copyVehicle != null )
            this.vehicle = (HVehicle) copyVehicle.clone();
        else
            this.vehicle = null; // Hopefully the dummy tour.
        
        // Copy route
        this.route = (HList) copyThis.route.clone();
        
    }   // end constructor


    
/* ********  G E T   M E T H O D S  ******** */


    /**
     * Returns the vehicle associated with the tour.
     * 
     * @return the vehicle associated with the tour.
     * @since 1.0
     * @see HVehicle
     */
    public HVehicle getHVehicle()
    {   return vehicle;
    }   // end getHVehicle

    /**
     * Returns the total travel time for the tour. Be sure to check
     * <code>isValid()</code> to see if the value is meaningful.
     * 
     * @return travel time
     * @since 1.0
     */
    public final double getTotalTravelTime()
    {   return totalTravelTime;
    }   // end getTotalTravelTime
    

    /**
     * Returns the waiting time for the tour. Be sure to check
     * <code>isValid()</code> to see if the value is meaningful.
     * 
     * @return wait time
     * @since 1.0
     */
    public final double getTotalWaitingTime()
    {   return totalWaitingTime;
    }   // end getTotalWaitingTime
    
    /**
     * Returns the penalty for the tour. Be sure to check
     * <code>isValid()</code> to see if the value is meaningful.
     * The penalty should be in the same units as time.
     * 
     * @return penalty
     * @since 1.0
     */
    public final double getTotalPenalty()
    {   return totalPenalty;
    }   // end getTotalPenalty
    
    
    
    /**
     * Returns the number of busted time windows for the tour. Be sure to check
     * <code>isValid()</code> to see if the value is meaningful.
     * 
     * @return number of time windows
     * @since 1.0
     */
    public final int getBustedTimeWindows()
    {   return bustedTimeWindows;
    }   // end getBustedTimeWindows
    
    
    /**
     * Returns the number of busted time walls for the tour. Be sure to check
     * <code>isValid()</code> to see if the value is meaningful.
     * 
     * @return number of time walls
     * @since 1.0
     */
    public final int getBustedTimeWalls()
    {   return bustedTimeWalls;
    }   // end getBustedTimeWalls()
    
    
    /**
     * Returns the departure time for the tour. Be sure to check
     * <code>isValid()</code> to see if the value is meaningful.
     * 
     * @return departure time
     * @since 1.0
     */
    public final double getDepartureTime()
    {   return departureTime;
    }   // end getDepartureTime
    
    
    /**
     * Returns the estimated return time for the tour. Be sure to check
     * <code>isValid()</code> to see if the value is meaningful.
     * 
     * @return estimated return time
     * @since 1.0
     */
    public final double getReturnTime()
    {   return returnTime;
    }   // end getReturnTime
    
    
    /**
     * Returns the order at the <var>position</var>th position. The index
     * starts at zero.
     *
     * @param position position of order to return
     * @return order at <var>position</var>
     * @since 1.0
     * @see HOrder
     */
    public final HOrder getHOrderAt( int position )
    {   return (HOrder) route.elementAt( position );
    }   // end getHOrderAt

    
    /**
     * Returns the first order in the tour.
     *
     * @param position position of order to return
     * @return first order
     * @since 1.0
     * @see HOrder
     */
    public final HOrder firstHOrder()
    {   return (HOrder) route.firstElement();
    }   // end firstHOrder
    
    /**
     * Return the estimated arrival time at the order in position <I>i</I>.
     * This may be before the time window.
     *
     * @param i position of order in question
     * @return estimated arrival time
     * @since 1.0
     * @see HOrder
     */
    public final double getEstimatedArrivalTime( int i )
    {   return estimatedArrivalTimes != null
        ? estimatedArrivalTimes[ i ]
        : -1;
    }   // end getEstimatedArrivalTime
    
    
    /**
     * Return the estimated departure time at the order in position <I>i</I>.
     *
     * @param i position of order in question
     * @return estimated departure time
     * @since 1.0
     * @see HOrder
     */
    public final double getEstimatedDepartureTime( int i )
    {   return estimatedDepartureTimes != null
        ? estimatedDepartureTimes[ i ]
        : -1;
    }   // end getEstimatedDepartureTime
    
    
    /**
     * Return the estimated wait time at the order in position <I>i</I>.
     *
     * @param i position of order in question
     * @return estimated wait time
     * @since 1.0
     * @see HOrder
     */
    public final double getEstimatedWaitTime( int i )
    {   return estimatedWaitTimes != null
        ? estimatedWaitTimes[ i ]
        : -1;
    }   // end getEstimatedWaitTime
    
    /** 
     * Returns <tt>true</tt> if the order has been serviced. An order
     * should not be in the tour if it's not being serviced, but it could be.
     *
     * @param i position of order in question
     * @return whether or not order is serviced
     * @since 1.0
     * @see HOrder
     */
    public final boolean serviced( int i )
    {   return serviced != null
        ? serviced[ i ]
        : false;
    }   // end serviced

   
    
/* ********  V A L I D A T I O N   C O D E  ******** */
    
    /**
     * Validate the tour. This tracks travel time, wait time, penalties,
     * etc based on the vehicle and orders.
     *
     * @since 1.0
     * @see HOrder
     * @see HVehicle
     */
    public final void validateTour()
    {
        // Only validate if it's not already valid and
        // it's not a dummy 'this'.
        if( 
         ! this.tourValid
         &&
         this.vehicle != null ) // Dummy
        {
            // Clear vehicle
            this.vehicle.resetProductsForAllOrderTypes();
            
            // Tour variables to track
            double totalWaitingTime = 0;
            double totalPenalty = 0;
            double departureTime = 0;
            int bustedTimeWindows = 0;
            int bustedTimeWalls = 0;
            
            // Order variables to track
            estimatedArrivalTimes = new double[ this.size() ];
            estimatedDepartureTimes = new double[ this.size() ];
            estimatedWaitTimes = new double[ this.size() ];
            serviced = new boolean[ this.size() ];
                
            // Track when vehicle is next available
            double vehicleAvailable = departureTime = this.vehicle
                .getEarliestDepartureTime();

            // If this is not empty...
            if( this.size() > 0 )
            {
                // Go through whole tour
                final int thisLength = this.size();
                HOrder previousOrder = null;
                for( int iOrder = 0; iOrder < thisLength; iOrder++ )
                {   
                    // Get shorter variable for current order
                    HOrder order = this.getHOrderAt( iOrder );
                    
                    // Find time to travel to next order
                    double travel = this.vehicle.getTimeToTravel( 
                        previousOrder, order );
                    double penalty = this.vehicle.getPenaltyForTravel(
                        previousOrder, order );
                    
                    // Update this variables dealing with travel
                    vehicleAvailable += travel;
                    totalPenalty += penalty;
                    
                    // Although the vehicle may wait around for the
                    // time window to open, go ahead and record the
                    // current time as the arrival time at that order.
                    estimatedArrivalTimes[iOrder] = vehicleAvailable;
//                    order.setEstimatedArrivalTime( vehicleAvailable );
                        
                    // If vehicle arrives before the earliest arrival time
                    // then wait around until the earliest arrival time
                    double earliestArrival = order.getEarliestArrivalTime();
                    if( vehicleAvailable < earliestArrival )
                    {   
                        // If this was the first customer, don't wait around.
                        // Instead delay takeoff.
                        if( iOrder == 0 )
                        {   vehicleAvailable = earliestArrival;
                            departureTime = earliestArrival - travel;
                            estimatedArrivalTimes[iOrder] = vehicleAvailable;
                        }   // end if: was first order
                        else// else continue with other orders
                        {   double waitTime = earliestArrival - vehicleAvailable;
                            estimatedWaitTimes[iOrder] = waitTime;
//                            order.setWaitTime( waitTime );
                            totalWaitingTime += waitTime;
                            vehicleAvailable += waitTime;
                        }   // end else: not first order
                    }   // end if: vehicle arrived early
                    
                    // Record arrival time for use later in
                    // evaluating time windows.
                    double arrivalTime = vehicleAvailable;
                    
                    // Make this available in this scope so
                    // it can be used later when working
                    // with the restricted time windows.
                    double timeToService = 0;
                    
                    // Try to service the next order    
                    // See if vehicle supports the order type
                    //int orderType = order.getOrderType();
                    if( this.vehicle.supportsHOrderType( order ) )
                    {
                        // See if vehicle has enough product left
                        int orderDemand = order.getAmountNeeded();
                        if( 
                        orderDemand > 0
                        &&
                        this.vehicle
                            .getCurrentAmountAvailableForOrderType( order )
                        >= orderDemand )
                        {  // Deliver product
                            this.vehicle
                                .removeProductForOrderType( orderDemand, order );
                            this.serviced[ iOrder ] = true;
                            // Update this variables
                            timeToService = vehicle.getTimeToService( order );
                            vehicleAvailable += timeToService;
                            }  // end if: vehicle had supply left
                    }   // end if: vehicle supports order type
                    else
                    {   this.serviced[ iOrder ] = false;
                    }   // end else: vehicle does not support this order type
                                       
                    // If inclusion time window was busted,
                    // then make a note of it.
                    if( vehicleAvailable > order.getLatestDepartureTime() )
                        bustedTimeWindows++;
                    
                    // If exclusion time window was busted,
                    // then make a note of it. There are different
                    // scenarios here.
                    
                    // Scenario 1: Vehicle arrives at order after
                    //  the restricted time window closes. Result:
                    //  A-okay. No problems.
                    if( arrivalTime >= order.getLatestRestrictedTime() )
                    {   ;   // No operation (NO-OP)
                    }   // end if: arrived after restrictions ended
                    else
                    
                    // Scenario 2: Vehicle leaves before restriction
                    //  begins.
                    // Result: A-okay. No problems.
                    if( 
                    vehicleAvailable <= order.getEarliestRestrictedTime() )
                    {   ;   // NO-OP
                    }   // end else: vehicle left before restriction
                    else
                    
                    // Scenario 3: Vehicle arrives before the restriction
                    //  begins and leaves after the restriction begins.
                    // Result: see if it's possible to wait until the
                    //  restriction ends and then service the order. If
                    //  that's not possible, then just service the order
                    //  right away and bust the restricted time window.
                    if( 
                    arrivalTime < order.getEarliestRestrictedTime()
                    &&
                    vehicleAvailable > order.getEarliestRestrictedTime() )
                    {
                        // See if it's possible to wait until
                        // the restriction has lifted. This is possible
                        // if latestRestricted + serviceTime <=
                        // latestDeparture
                        if( order.getLatestRestrictedTime() +
                        timeToService <= order.getLatestDepartureTime() )
                        {
                            double waitTime = 
                                order.getLatestRestrictedTime() 
                                - arrivalTime;
                            totalWaitingTime += waitTime;
                            vehicleAvailable += waitTime;
                        }   // end if: possible to wait
                        else
                        {   bustedTimeWalls++;
                        }   // end else: couldn't wait
                    }   // end else if: arrived before restricted time began
                    else
                    
                    // Scenario 4: Vehicle arrives after the 
                    //  restriction begins but before it ends.
                    // Result: Again try to wait until restriction ends.
                    if( arrivalTime > order.getEarliestRestrictedTime() )
                    {   // This would only happen now, if it arrived
                        // in the middle of the restricted time.
                        
                        // See if it's possible to wait until
                        // the restriction has lifted. This is possible
                        // if latestRestricted + serviceTime <=
                        // latestDeparture
                        if( order.getLatestRestrictedTime() +
                        timeToService <= order.getLatestDepartureTime() )
                        {
                            double waitTime = 
                                order.getLatestRestrictedTime() 
                                - arrivalTime;
                            totalWaitingTime += waitTime;
                            vehicleAvailable += waitTime;
                        }   // end if: possible to wait
                        else
                        {   bustedTimeWalls++;
                        }   // end else: couldn't wait
                    }   // end else if: arrived in the middle
                    
                    // Record some order stats
                    estimatedDepartureTimes[iOrder] = vehicleAvailable;
//                    order.setEstimatedDepartureTime( vehicleAvailable );
                        
                    // Update value of previousOrder
                    previousOrder = order;
                }   // end for: through each order
                    
                // Now go home
                double travel = this.vehicle.getTimeToTravel( 
                    previousOrder, null );
                double penalty = this.vehicle.getPenaltyForTravel(
                    previousOrder, null );
                        
                // Update this variables dealing with travel
 //               totalTravelTime += travel;
                vehicleAvailable += travel; // This turns out to be return to base time.
                totalPenalty += penalty;
            }   // end if: this was not empty
            // Done with this.
                
            // Set this variables
            this.totalTravelTime = vehicleAvailable - departureTime;
            this.totalWaitingTime = totalWaitingTime;
            this.totalPenalty = totalPenalty;
            this.departureTime = departureTime;
            this.returnTime = vehicleAvailable;
            this.bustedTimeWindows = bustedTimeWindows;
            this.bustedTimeWalls = bustedTimeWalls;
            
        }   // end if: this was not already valid
        
        // Record that tour is now validated
        this.tourValid = true;
    }   // end validateTour
    
    
    
    
/* ********  O T H E R   M E T H O D S  ******** */
    
    /**
     * Number of orders in the tour.
     *
     * @return number of orders in the tour
     * @since 1.0
     * @see HOrder
     */ 
    public int size()
    {   return route.size();
    }   // end size
    
    /**
     * Whether or not the costs and such associated with the tour
     * are valid with respect to the latest changes.
     *
     * @return whether or not the costs, etc are valid
     * @since 1.0
     */
    public final boolean isValid()
    {   return tourValid;
    }   // end isValid
    
    /**
     * Inserts the given order into <var>position</var>. If
     * <var>position</var> = <code>size()</code> the order is
     * appended to the end of the tour. The tour costs are then invalidated.
     *
     * @param order order to insert
     * @param position where to put the order
     * @since 1.0
     * @see HOrder
     */
    public void insertHOrderAt( HOrder order, int position )
    {   route.insertElementAt( order, position );
        invalidate();
    }   // end insertHOrderAt
    
    
    /**
     * Removes the given order from <var>position</var>. 
     * The tour costs are then invalidated.
     *
     * @param order order to remove
     * @param position where the order is coming from
     * @since 1.0
     * @see HOrder
     */
    public void removeHOrderAt( int position )
    {   route.removeElementAt( position );
        invalidate();
    }   // end removeHOrderAt
    
    
    /**
     * Adds the order to the end of the tour.
     * The tour costs are then invalidated.
     *
     * @param order order to add
     * @since 1.0
     * @see HOrder
     */
    public void addHOrder( HOrder order )
    {   route.addElement( order );
        invalidate();
    }   // end addHOrder
    
    /**
     * Indicates that the tour costs are no longer valid.
     *
     * @since 1.0
     */
    public final void invalidate()
    {   this.tourValid = false;
        this.estimatedArrivalTimes = null;
        this.estimatedDepartureTimes = null;
        this.estimatedWaitTimes = null;
    }   //end ivalidate
    
    public Object clone()
    {   return new HTour( this );
    }   // end clone
    
    
    public String toString()
    {
        String s = "Vehicle=" + vehicle + ", Route=" + route;
        return s;
    }   // end toString
    
    
    
}   // end class HTour