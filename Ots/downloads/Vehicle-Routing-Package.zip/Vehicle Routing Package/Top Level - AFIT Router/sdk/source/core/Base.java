/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.io.*;
import java.util.*;

/**
 * A base is associated with vehicles as a way to determine
 * where the vehicles leave from and return to. A vehicle
 * may actual depart from a latitude and longitude other than
 * that of the base, if the vehicle is designated as being 
 * "Not at home."
 * 
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see BaseList
 * @see Vehicle
 */
public class Base 
extends Observable 
implements Serializable
{
    private String name;
    private double latitude;
    private double longitude;

    /**
     * Constructs a base from a name and a latitude and longitude.
     * Latitudes and longitudes are degrees and fractions of degrees
     * (not DDMMSS, for example) where positive is north and east.
     * 
     * @param name Name of the base
     * @param latitude Latitude of the base
     * @param longitude Longitude of the base
     * @since 1.0
     */
    public Base( String name, double latitude, double longitude )
    {
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
    }   // end constructor

    /**
     * Constructs a base with a default untitled name and latitudes
     * and longitude equal to zero.
     * 
     * @since 1.0
     */
    public Base()
    {
    }   // end constructor
    
    /**
     * Returns the name of the base
     *
     * @return name of base
     * @since 1.0
     */
    public final String getName()
    {   return name;
    }   // end getName
    
    /**
     * Returns the latitude of the base. Positive is north.
     *
     * @since 1.0
     */
    public final double getLatitude()
    {   return latitude;
    }   // end getLatitude
    
    
    /**
     * Returns the longitude of the base. Positive is east.
     *
     * @since 1.0
     */
    public final double getLongitude()
    {   return longitude;
    }   // end getLongitude
    
    /**
     * Sets the name of the base and notifies registered <code>Observer</code>s.
     * The <code>BaseList</code> is registered as an <code>Observer</code> so
     * listening for changes to the list will also alert you to changes in
     * individual bases.
     * 
     * @since 1.0
     * @see BaseList
     * @see java.util.Observer
     */
    public final void setName( String name )
    {   this.name = name;
        setChanged();
        notifyObservers( name );
    }   // end setName
    
    
    /**
     * Sets the latitude of the base and notifies registered <code>Observer</code>s.
     * The <code>BaseList</code> is registered as an <code>Observer</code> so
     * listening for changes to the list will also alert you to changes in
     * individual bases.
     * 
     * @since 1.0
     * @see BaseList
     * @see java.util.Observer
     */
    public final void setLatitude( double latitude )
    {   this.latitude = latitude;
        setChanged();
        notifyObservers( new Double( latitude ) );
    }   // end setLatitude
    
    /**
     * Sets the longitude of the base and notifies registered <code>Observer</code>s.
     * The <code>BaseList</code> is registered as an <code>Observer</code> so
     * listening for changes to the list will also alert you to changes in
     * individual bases.
     * 
     * @since 1.0
     * @see BaseList
     * @see java.util.Observer
     */
    public final void setLongitude( double longitude )
    {   this.longitude = longitude;
        setChanged();
        notifyObservers( new Double( longitude ) );
    }   // end setLongitude
    
    public String toString()
    {   return getName();
    }   // end toString
    
}   // end class Base