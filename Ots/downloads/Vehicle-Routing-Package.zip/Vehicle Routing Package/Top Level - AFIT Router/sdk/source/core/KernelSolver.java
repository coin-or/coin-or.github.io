/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import mil.af.afit.uvr.*;


/**
 * This runs in another thread and handles the solving calls to the 
 * Universal Vehicle Router (available at <A HREF="http://www.crosswinds.net/~rharder/afit/uvr/" TARGET="_parent">
 * http://www.crosswinds.net/~rharder/afit/uvr/</A>). You can listen for events
 * by implementing <code>KernelSolverListener</code>.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Kernel
 * @see mil.af.afit.uvr.HEngine
 */
public class KernelSolver
implements HEngineListener, Runnable
{
    // Kinda hard-coded. It would be better to test using class name. oh well.
    //private final static String
    //    SOLOMON_SOLVER = "Solomon tour-building",
    //    TABU_SOLVER = "Tabu search";
        
        
    /**
     * Class name of solver to use when no post-optimization is requested.
     *
     * @see mil.af.afit.uvr.HSolver
     */
    //public static String NO_POST_OP_SOLVER_CLASSNAME = "mil.af.afit.uvr.solvers.solomonconstruction.SolomonConstructionSolver";
    public static String NO_POST_OP_SOLVER_CLASSNAME = "mil.af.afit.router.simpletabusearch.SimpleTSSolver";
        
    /**
     * Class name of solver to use when post-optimization is requested.
     *
     * @see mil.af.afit.uvr.HSolver
     */
    public static String POST_OP_SOLVER_CLASSNAME = "mil.af.afit.uvr.solvers.tabusearch4uvr.TS4UVRSolver";
    
    private Kernel kernel;
    private PriorityModel[] priorityModels;
    private int currentPriorityModelIndex = -1;
    private Site[] sites;
    private Vehicle[] vehicles;
    private float percentDone = 0f;
    private HEngine engine;
    
    /**
     * Creates a new <code>KernelSolver</code> based on the passed kernel
     *
     * @param kernel host kernel
     * @see Kernel
     * @since 1.0
     */
    public KernelSolver( Kernel kernel )
    {
        this.kernel = kernel;
        PriorityModel[] allPriorityModels = 
            kernel.getPriorityModelList().getPriorityModels();
        PriorityModel[] temp = new PriorityModel[ allPriorityModels.length ];
        int numEnabled = 0;
        for( int i = 0; i < temp.length; i++ )
            if( allPriorityModels[i].isEnabled() )
                temp[numEnabled++] = allPriorityModels[i];
        priorityModels = new PriorityModel[ numEnabled ];
        System.arraycopy(temp,0, priorityModels,0,numEnabled);
        this.sites = kernel.getSiteList().getSites();
        this.vehicles = kernel.getVehicleList().getVehicles();
    }   // end constructor
    
    /**
     * Starts solving in another thread and immediately returns control
     *
     * @since 1.0
     */
    public final void startSolving()
    {   Thread t = new Thread( this );
        t.setDaemon( true );
        t.start();
    }   // end startSolving
    
    /**
     * Stops solving.
     *
     * @since 1.0.1
     */
    public final void stopSolving()
    {   if( engine != null)
            engine.stopSolving();
    }   // end stopSolving
    
    
    /**
     * Returns the percent done between zero and one.
     *
     * @return percent done
     * @since 1.0
     */
    public final float getPercentDone()
    {   return percentDone;
    }   // end getPercentDone
    
    /**
     * Used internally to set the percent done amount.
     */
    private final void setPercentDone( float percentDone )
    {   this.percentDone = percentDone;
        this.fireKernelSolverPercentDoneEvent();
    }   // end setPercentDone
    
    /**
     * Returns the current priority model being used.
     *
     * @return current priority model
     * @since 1.0
     */
    public final PriorityModel getCurrentPriorityModel()
    {   return (currentPriorityModelIndex >= 0)
            && (currentPriorityModelIndex< priorityModels.length)
            ? priorityModels[currentPriorityModelIndex]
            : null;
    }   // end getCurrentPriorityModel
    
    /**
     * As required by <code>Runnable</code>.
     */
    public void run()
    {
        // Start solving
        fireKernelSolverStartedEvent();
        
        // Get first priority model
        if( priorityModels.length > 0 )
        {   
            currentPriorityModelIndex = 0;
            
            // Setup HEngine
            engine = new HEngine();
            
            // Get customers and vehicles ready
            UVRSite[] uSites = convertToUVRSites(sites );
            UVRVehicle[] uVehicles = convertToUVRVehicles(
                vehicles, sites );
            

            // Tell the engine what we have
            String solverToUse = kernel.getPrefs().usePostOptimization()
                ? POST_OP_SOLVER_CLASSNAME : NO_POST_OP_SOLVER_CLASSNAME ;
            engine.setHVehicles( uVehicles );
            engine.setHOrders( uSites );
            engine.setNumberOfThreads( 
                kernel.getPrefs().getLastNumberOfThreads() );
            engine.setRequestedSolutionEffort( 
                kernel.getPrefs().getLastRequestedSolutionEffort() );
            HSolver solver = null;
            try{ solver = (HSolver)Class.forName( solverToUse ).newInstance(); }
            catch(Exception e){}
            engine.setSolver( solver );
            engine.setHEvaluator( new SolutionEvaluator( 
                priorityModels[currentPriorityModelIndex] ) );
            engine.addHEngineListener( this );
            
            firePriorityModelChangedEvent();
            
            engine.startSolving();
        }   // end if: at least one priority model requested
        else
            fireKernelSolverFinishedEvent();
        // The rest is event-driven.
        Kernel.out( "KernelSolver.run: end of run code." );
    }   // end run
    
    
    /**
     * This converts the site objects used in this code to the kind of
     * object required by the Universal Vehicle Router available at
     * <A HREF="http://www.crosswinds.net/~rharder/afit/uvr/" TARGET="_parent">
     * http://www.crosswinds.net/~rharder/afit/uvr/</A>.
     *
     * @param list list of sites
     * @see SiteList
     * @see mil.af.afit.uvr.HOrder
     * @since 1.0
     */
    private final UVRSite[] convertToUVRSites( Site[] sites )
    {
        UVRSite[] uSites = new UVRSite[sites.length];
        int uIndex = 0;
        for( int i = 0; i < sites.length; i++ )
            if( sites[i].isEnabled() )
                uSites[uIndex++] = new UVRSite( sites[i] );
        UVRSite[] temp = new UVRSite[ uIndex ];
        System.arraycopy( uSites,0, temp,0,uIndex );
        return temp;
    }   // end convertToUVRSites
    
    
    /**
     * This converts the vehicle objects used in this code to the kind of
     * object required by the Universal Vehicle Router available at
     * <A HREF="http://www.crosswinds.net/~rharder/afit/uvr/" TARGET="_parent">
     * http://www.crosswinds.net/~rharder/afit/uvr/</A>.
     *
     * @param vList list of vehicles
     * @param sList list of sites
     * @see SiteList
     * @see VehicleList
     * @see mil.af.afit.uvr.HVehicle
     * @see mil.af.afit.uvr.HOrder
     * @since 1.0
     */
    private final UVRVehicle[] convertToUVRVehicles( 
    final Vehicle[] vehicles, final Site[] sites )
    {
        UVRVehicle[] uVehicles = new UVRVehicle[vehicles.length];
        int uIndex = 0;
        for( int i = 0; i < vehicles.length; i++ )
            if( vehicles[i].isEnabled() )
                uVehicles[uIndex++] = 
                    new UVRVehicle( vehicles[i], sites, kernel );
        UVRVehicle[] temp = new UVRVehicle[ uIndex ];
        System.arraycopy( uVehicles,0, temp,0,uIndex );
        return temp;
        
    }   // end convertToUVRVehicles
    
    
    
    
/* ********  H E N G I N E L I S T E N E R   C O D E  ******** */
    
    /**
     * Receives events from the <code>HEngine</code>.
     *
     * @param e event
     * @since 1.0
     * @see mil.af.afit.uvr.HEngine
     * @see mil.af.afit.uvr.HEngineEvent
     */
    public void HEngineEventPerformed( HEngineEvent e )
    {
        final int eventType = e.getEventType();
        final HEngine engine = e.getHEngine();
        
        switch( eventType )
        {   case HEngineEvent.ENGINE_STARTED:
                handleEngineStarted( engine );
                break;
            case HEngineEvent.ENGINE_FINISHED:
                handleEngineFinished( engine );
                break;
            case HEngineEvent.SOLVER_STARTED:
                handleHSolverStarted( engine );
                break;
            case HEngineEvent.PERCENT_DONE:
                handlePercentDone( engine );
                break;
            default:
                break;
        }   // end switch
        
    }   // end HEngineEventPerformed
    
    /**
     * Handle engine started events. Not currently used. The <code>KernelSolver</code>
     * event reporting that it has started is fired at the beginning of the run method.
     *
     * @param engine engine reporting
     * @since 1.0
     */
    private final void handleEngineStarted( HEngine engine )
    {
    }   // end handleEngineStarted
    
    /**
     * Handle the even when the engine has finished a round of solving.
     *
     * @param engine engine reporting
     * @since 1.0
     */
    private final void handleEngineFinished( HEngine engine )
    {   
        Kernel.out( "KernelSolver.handleEngineFinished: called." );
        // Record the best solution that this priority model found.
        HSolution bestH = engine.getBestHSolution();
        if( bestH != null )
        {   if( ! bestH.isValid() )
                if( bestH.getLastEvaluatorUsed() != null )
                bestH.validate( bestH.getLastEvaluatorUsed() );

            this.kernel.getSolutionList().addSolution(
                new Solution( bestH, 
                priorityModels[currentPriorityModelIndex] ) );
        }   // end if: bestH not null
        else Kernel.out( "KernelSolver.handleEngineFinished: engine returned null solution" );
        
        // If there are more priority models to try, do them.
        if( currentPriorityModelIndex < priorityModels.length-1 )
        {
            //Kernel.out( "KernelSolver.handleEngineFinished: more priority models" );
            // Update current priority model
            currentPriorityModelIndex++;
            firePriorityModelChangedEvent();
            
            engine.setHEvaluator( new SolutionEvaluator(
                priorityModels[currentPriorityModelIndex] ) );
            
            engine.startSolving();
        }   // end if: solve with next priority model
        else
        {   engine.removeHEngineListener( this );
            setPercentDone( 1 );
            fireKernelSolverFinishedEvent();
        }   // end else: no more to try
    }   // end handleEngineFinished
    
    /**
     * This event is called when the solver within the Universal Vehicle Router
     * has started. This is not always at the same time that the UVR's engine
     * has started.
     *
     * @param engine engine reporting
     * @since 1.0
     */
    private final void handleHSolverStarted( HEngine engine )
    {
    }   // end handleHSolverStarted
    
    /**
     * Handle the event when the HEngine reports an updated
     * percent-done value.
     *
     * @param engine engine reporting
     * @since 1.0
     */
    private final void handlePercentDone( HEngine engine )
    {   final float ePD = engine.getPercentDone();
        final float base = (float) currentPriorityModelIndex 
            / priorityModels.length;
        final float pd = base + ePD / priorityModels.length;
        this.setPercentDone( pd );
        Thread.yield(); // Healthy scattering for better responsiveness
    }   // end handlePercentDone
    
/* ********  K E R N E L S O L V E R L I S T E N E R   C O D E  ******** */
    
    private KernelSolverListener[] kernelSolverListenerList =
        new KernelSolverListener[0];
    
    
    /**
     * Add a listener to the solver. This listener will
     * be notified when solver events happen.
     * 
     * @param listener the listener to notify of engine events
     * @since 1.0
     */
    
    public final synchronized void 
    addKernelSolverListener( KernelSolverListener listener )
    {  
        KernelSolverListener[] list = new KernelSolverListener[
            kernelSolverListenerList.length + 1 ];
        for( int i = 0; i < list.length - 1; i++ )
            list[i] = kernelSolverListenerList[i];
                
        list[ list.length-1 ] = listener;
        kernelSolverListenerList = list;
    }  // end addKernelSolverListener
    
    
    /**
     * Remove a listener from the solver. This listener will
     * no longer be notified when solver events happen.
     * 
     * @param listener the listener which will no longer 
     *                 receive solver events
     * @since 1.0
     */
    public final synchronized void 
    removeKernelSolverListener( KernelSolverListener listener )
    {  // Find location of listener to remove
        int index = -1;
        int j = 0;
        while( index < 0 || j < kernelSolverListenerList.length )
        {   if( kernelSolverListenerList[j] == listener )
                index = j;
            else j++;
        }   // end while: through list
            
        // If index is less than zero then it wasn't in the list
        if( index >= 0 )
        {   KernelSolverListener[] list = new KernelSolverListener[
                kernelSolverListenerList.length - 1 ];
            for( int i = 0; i < list.length; i++ )
                list[i] = kernelSolverListenerList[ i < index ? i : i + 1 ];
            kernelSolverListenerList = list;
        }   // end if: listener was in the list
    }  // end removeKernelSolverListener
    
    
    /**
     * Used internally to loop through listener list and send
     * solver events.
     * 
     * @param e the <code>KernelSolverEvent</code> to send out
     * @since 1.0
     */
    private final void fireKernelSolverEvent( KernelSolverEvent e )
    {   
        synchronized( this )
        {   for( int i = 0; i < kernelSolverListenerList.length; i++ )
                kernelSolverListenerList[i].kernelSolverEventPerformed( e );
        }   // end synchronized
    }   // end fireKernelSolverEvent

    /**
     * This should be called when the solver starts solving.
     * Interested objects will be notified that the solver
     * has started.
     * 
     * @since 1.0
     */
    public final void fireKernelSolverStartedEvent()
    {   KernelSolverEvent e = new KernelSolverEvent(
            KernelSolverEvent.SOLVER_STARTED, this );
        fireKernelSolverEvent( e );
    }   // end fireSolverStartedEvent
    
    /**
     * This method should be called when the kernelSolver has finished
     * working. Interested objects, mainly the UVR kernelSolver, will
     * be notified that the kernelSolver has finished.
     * 
     * @since 1.0
     */
    public final void fireKernelSolverFinishedEvent()
    {   KernelSolverEvent e = new KernelSolverEvent( 
            KernelSolverEvent.SOLVER_FINISHED, this );
        fireKernelSolverEvent( e );
    }   // end fireKernelSolverFinishedEvent
    
    
    /**
     * This method should be called periodically to keep the
     * user up to date on the kernelSolver's progress.
     * 
     * @since 1.0
     */
    public final void fireKernelSolverPercentDoneEvent()
    {   KernelSolverEvent e = new KernelSolverEvent(
            KernelSolverEvent.PERCENT_DONE, this );
        fireKernelSolverEvent( e );
    }   // /end fireKernelSolverProgressEvent
    
    
    /**
     * This method should be called when the kernel solver
     * changes to a new priority model.
     * 
     * @since 1.0
     */
    public final void firePriorityModelChangedEvent()
    {   KernelSolverEvent e = new KernelSolverEvent(
            KernelSolverEvent.PRIORITY_MODEL_CHANGED, this );
        fireKernelSolverEvent( e );
    }   // /end fireKernelSolverProgressEvent
    
    
    /**
     * This method should be called when a new best solution is found.
     * 
     * @param percentDone percent completed
     * @since 1.0
     */
    
    public final void fireNewBestSolutionEvent()
    {   KernelSolverEvent e = new KernelSolverEvent(
            KernelSolverEvent.NEW_BEST_SOLUTION, this );
        fireKernelSolverEvent( e );
    }   // /end fireNewBestSolutionEvent
    
    
    
    
}   // end class KernelSolver