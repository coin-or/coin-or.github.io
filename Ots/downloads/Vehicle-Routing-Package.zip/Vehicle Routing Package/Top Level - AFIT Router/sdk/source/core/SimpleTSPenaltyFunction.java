/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.router.simpletabusearch;

import net.usa.rharder.tabusearch22.*;
import mil.af.afit.uvr.*;

class SimpleTSPenaltyFunction implements TSFunction
{
    private double[] costs = { 0 };
    
    public final double[] evaluate( TSSolution solution )
    {
        HSolution soln = ( (SimpleTSSolution) solution ).getHSolution();
        
        // Make an array of zeroes equal to the length of the costs array
        // but only if the array is not already properly set up.
        if( soln.getCosts().length != costs.length )
            costs = new double[ soln.getCosts().length ];
        
        return costs;
    }   // end evaluate

}   // end class SimpleTSPenaltyFunction