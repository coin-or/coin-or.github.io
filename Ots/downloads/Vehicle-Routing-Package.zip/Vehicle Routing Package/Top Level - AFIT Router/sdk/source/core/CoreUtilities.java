/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.text.*;

public class CoreUtilities
{
    
/* ********  S T A T I C   U T I L I T I E S  ******** */
    
    /**
     * Specifies the use of military (24hour) time when
     * converting integer time to a string. 
     * 
     * @see #intTimeToString
     * @since 1.0
     */
    public final static int MILITARY    = 1;
    
    /**
     * Specifies the use of AM/PM (12hour) time when
     * converting integer time to a string. 
     * 
     * @see #intTimeToString
     * @since 1.0
     */
    public final static int AMPM        = 2;
    
    /**
     * Calculates the time it take to travel from a starting point
     * to an ending point taking into consideration wind speed and direction
     * and vehicle speed.
     *
     * @param startLat starting latitude
     * @param startLon starting longitude
     * @param endLat ending latitude
     * @param endLon ending longitude
     * @param windBearing bearing of wind, clockwise from North
     * @param windSpeed wind speed in knots
     * @param airSpeed vehicle speed in knots
     * @return time in minutes to travel from one point to another
     * @since 1.0
     */
    public final static int getTimeToTravel(
    double startLat, double startLon,   // Starting point
    double endLat,   double endLon,     // Ending point
    double windBearing,     // Direction the wind is blowing
    double windSpeed,       // Wind speed in knots
    double airSpeed )       // Vehicle's air speed in knots
    {
        int travelTime = 0;
        
        // Distance between two points
        double distance = getGreatCircleDistance(
            startLat, startLon, endLat, endLon );
        
        // The true heading
        double heading = getTrueHeading(
            startLat, startLon, endLat, endLon, distance );
        
        // Difference between heading and wind bearing
        double delta = heading - windBearing;
        
        // Ground speed
        double GS = getGroundSpeed( airSpeed, windSpeed, delta );
        
        // Travel time
        travelTime = (int) ((distance / GS) * 60); // Hours to minutes
        
        return travelTime;
    }   // end getTimeToTravel
    
    /**
     * Calculates the great circle distance between two
     * latitudes and longitudes (in degrees and fractions of
     * degrees). The formula is as follows:
     * <P>
     * <tt>d = 60 * arccos[ sin L1 * sin L2 + cos L1 * cos L2 *
     * cos( l2 - l1 ) ]</tt>
     * <P>
     * where <var>L1</var> and <var>L2</var> are latitudes and 
     * little L's <var>l1</var> and <var>l2</var> are longitudes.
     * <P>
     * The code was adapted from Kevin O'Rourke's earlier code.
     * 
     * @param lat1 first latitude
     * @param lon1 first longitude
     * @param lat2 second latitude
     * @param lon2 second longitude
     */
    public final static double getGreatCircleDistance( 
    double lat1, double lon1,  // First point
    double lat2, double lon2 ) // Second point
    {
        double distance = 0;
        
        // Convert numbers to appropriate "units" (radians)
        final double rlat1 = lat1 / 57.2958;
        final double rlon1 = lon1 / 57.2958;
        final double rlat2 = lat2 / 57.2958;
        final double rlon2 = lon2 / 57.2958;
        
        // Some intermediate calculations
        final double sineCalcs = Math.sin( rlat1 ) * Math.sin( rlat2 );
        final double lonDiffs = rlon2 - rlon1;
        final double sineCosineCalcs = Math.cos( rlat1 ) * 
            Math.cos( rlat2 ) * Math.cos( lonDiffs );
            
        distance = Math.acos( sineCalcs + sineCosineCalcs ) *
            57.2958 * 60;
        
        return distance;
    }   // end getGreatCircleDistance
    
    
    /**
     * Calculates the true heading on the so-called great circle's
     * spherical triangle. First an intermediate heading <var>H</var>
     * is calculated, and then a true heading is calculated.
     *
     * <P>
     * <tt><pre>
     *                             d
     *               sin[L2] -(cos[--] sin[L1])
     *                             60
     *   H = arccos[----------------------------]
     *                                d
     *                    cos[L1] sin[--]
     *                                60
     * </pre></tt><P>
     * The true heading, then, is
     * <P>
     * <tt><pre>
     *                |  H,        sin( l2 - l1 ) < 0
     * trueHeading =  |
     *                |  360 - H,  sin( l2 - l1 ) >= 0
     * </pre></tt>
     *
     * @param startLat starting latitude
     * @param startLon starting longitude
     * @param endLat ending latitude
     * @param endLon ending longitude
     * @param distance distance between the points
     * @return true heading in degrees, clockwise from North
     * @since 1.0
     */
    public final static double getTrueHeading( 
    double startLat, double startLon,
    double endLat, double endLon, double distance )
    {
        double trueHeading = 0;
        
        // Convert numbers to appropriate "units" (radians)
        final double rStartLat = startLat / 57.2958;
        final double rStartLon = startLon / 57.2958;
        final double rEndLat = endLat / 57.2958;
        final double rEndLon = endLon / 57.2958;
                
        // Intermediate calculations for H
        double numerator = Math.sin( rEndLat ) -
            Math.sin( rStartLat ) * Math.cos( distance / 60 );
        double denominator = Math.sin( distance / 60 ) * 
            Math.cos( rStartLat );
        double H = Math.acos( numerator / denominator );
        
        // Find correct true heading
        double compare = Math.sin( rEndLon - rStartLon );
        trueHeading = compare < 0
            ? H
            : 360 - H;
        
        return trueHeading;
    }   // end getTrueHeading
    
    
    /**
     * This calculates the ground speed based on the air speed,
     * wind speed, and difference between their headings, <var>delta</var>.
     * The calculations are shown below, where AS = ground speed, and
     * WS = wind speed.
     * <P>
     * <tt><pre>
     *     A = WS * cos( 180 - delta )
     *     C = WS * sin( 180 - delta )
     *            _________
     *           /  2    2
     *     B = \/ AS  - C
     *     ground speed = A + B
     * </pre></tt>
     * 
     * @param airSpeed vehicle's air speed in knots
     * @param windSpeed wind speed in knots
     * @param delta distance in degrees between the wind and vehicle directions
     * @return ground speed in knots
     * @since 1.0
     */
    public final static double getGroundSpeed( 
    double airSpeed, double windSpeed, double delta )
    {
        double GS = 0;
        
        // Intermediate calculations
        final double A = windSpeed * Math.cos( 180 - delta );
        final double C = windSpeed * Math.sin( 180 - delta );
        final double B = Math.sqrt( airSpeed*airSpeed - C*C );
        
        // Ground speed
        GS = A + B;
        
        return GS;
    }   // end getGroundSpeed
    
    /**
     * Converts an integer time to a string in military (24hour) format.
     * Integer time is stored as minutes after midnight starting at the
     * first day in question.
     *
     * @param iTime integer time to convert to a string
     * @return time as a string in military (24hour) format
     * @since 1.0
     */
    public final static String intTimeToString( int iTime )
    {   return intTimeToString( iTime, MILITARY );
    }   // end intTimeToString
    
    
    /**
     * Converts an integer time to a string in <var>Kernel.MILITARY</var> (24hour) format
     * or 12hour <var>Kernel.AMPM</var> format.
     * Integer time is stored as minutes after midnight starting at the
     * first day in question.
     *
     * @param iTime integer time to convert to a string
     * @return time as a string
     * @since 1.0
     */
    public final static String intTimeToString( int iTime, int type )
    {
        StringBuffer s = new StringBuffer();

        // If time is negative, assume it means null
        if( iTime <= 0 )
            ;
        // If time is huge, assume it means null
        else 
        if( iTime >= Integer.MAX_VALUE>>1 )
            ;
        else
        {
            NumberFormat nf = NumberFormat.getInstance();
            nf.setMinimumIntegerDigits(2);
            int hours = iTime/60;
            int minutes = iTime%60;
            int days = hours / 24;
            hours %= 24;
            s.append( 
                (type==AMPM 
                    ? (hours%12==0 ? "12" : nf.format(hours%12) ) 
                    : (type==MILITARY ? nf.format(hours) : nf.format(hours)) ) 
                + (type==AMPM 
                    ? ":" 
                    : (type==MILITARY ? "" : "") ) 
                + nf.format( minutes )
                + (type==AMPM 
                    ? (hours >= 12 ? "PM" : "AM" ) 
                    : (type==MILITARY ? "h" : "") )  
                +( days > 0 
                    ? " +" + days + " day" + ( days > 1 ? "s" : "" )
                    : "" ) );
        }   // end else
        
        return s.toString();
    }   // end intTimeToString
    
    
    /**
     * Converts a string time to integer time. The string time is
     * expected to be in the format returned by <code>intTimeToString</code>
     * such as "1040h" or "1330h +1 day". It is fairly robust against
     * alternates involving extra spaces and characters.
     *
     * @param sTime string time to convert
     * @return integer time
     * @since 1.0
     */
    public final static int stringTimeToInt( String sTime )
    {
        int iTime = 0;
        try
        {   
            // See if they're saying "Now"
            if( sTime.equalsIgnoreCase( "NOW" ) )
            {   Calendar c = Calendar.getInstance();
                iTime = c.get( Calendar.HOUR_OF_DAY );
                iTime += c.get( Calendar.MINUTE ) / 60d;
            }   // end if: set to current time
            else
            {   sTime = sTime.trim();
                // Get the string up to the first space or letter
                int lengthOfNumber = sTime.length();
                for( int i = 0; i < sTime.length(); i++ )
                {   if( ! Character.isDigit(sTime.charAt(i)) )
                    {   lengthOfNumber = i;
                        break;
                    }   // end if end of number
                }   // end for: looking for end of number
                String sNum = sTime.substring( 0, lengthOfNumber );
                
                // Get time of day
                int minutes = new Integer( sNum.substring( Math.max(0,sNum.length()-2) ) ).intValue();
                int hours = new Integer( sNum.substring( 0, Math.max(0,sNum.length()-2) ) ).intValue();
                iTime = hours*60 + minutes;
                
                // See if the time falls on another day
                int indexOfPlus = sTime.indexOf('+');
                if( indexOfPlus >= 0 )
                {   if( indexOfPlus+1 < sTime.length() )
                    {   String afterPlus = sTime.substring( indexOfPlus+1 ).trim();
                        int lengthOfDayNumber = afterPlus.length();
                        for( int i = 0; i < afterPlus.length(); i++ )
                        {   if( ! Character.isDigit(afterPlus.charAt(i)) )
                            {   lengthOfDayNumber = i;
                                break;
                            }   // end if end of number
                        }   // end for: looking for end of number
                        String sDayNum = afterPlus.substring( 0, lengthOfDayNumber );
                        int days = new Integer( sDayNum ).intValue();
                        iTime += days * 24 * 60;
                    }   // end if: something is after the plus
                }   // end if: another day
                
            }   // end else: get time from string
        }   // end try
        catch( Exception e )
        {}//e.printStackTrace();}  // end catch: just press on
        return iTime;
    }   // end stringTimeToInt
    
    /**
     * Converts a latitude to a string.
     * Supported formats: dddmmss, dddmmhh, & ddd.hh (degrees, minutes, seconds; 
     * degrees, minutes, hundredths; and degrees, hundredths of degrees).
     *
     * @param lat latitude to convert
     * @return string representation of latitude
     * @since 1.0
     */
    public final static String doubleLatToString( double lat, String format )
    {
        NumberFormat nf2 = NumberFormat.getInstance();
        nf2.setMinimumIntegerDigits(2);
        
        final int deg = (int)Math.abs( lat );
        final double decDeg = Math.abs( lat )%1;
        final double dMin = decDeg * 60;
        final int iMin = (int)(dMin+.5);
        final double decMin = dMin%1;
        final double dSec = decMin * 60;
        final int iSec = (int)(dSec+.5);
        final int iHun = (int)(decMin+.5);

        if( format == null )
            format = "";
            
        // degrees, minutes, hundredths
        if( format.indexOf("ddmmhh")>=0 )
            return "" + deg + nf2.format(iMin)+nf2.format(iHun)+( lat >= 0 ? " N" : " S" );
        // degrees, decimal degrees
        else if( format.indexOf("dd.hh")>=0 )
            return "" + Math.abs(lat) +( lat >= 0 ? " N" : " S" );
        // default to degrees, minutes,seconds
        else //if( format.indexOf("ddmmss")>=0 )
            return "" + deg + nf2.format(iMin)+nf2.format(iSec)+( lat >= 0 ? " N" : " S" );
        
    }   // end doubleLatToString
    
    
    
    /**
     * Converts a longitude to a string in the form "DDDMMSS E" where "DDD"
     * could be two or three digits and "E" could be "E" or "W" for east
     * or west, respectively.
     *
     * @param lat longitude to convert
     * @return string representation of longitude
     * @since 1.0
     */
    public final static String doubleLonToString( double lon, String format )
    {   
        NumberFormat nf2 = NumberFormat.getInstance();
        nf2.setMinimumIntegerDigits(2);
        
        final int deg = (int)Math.abs( lon );
        final double decDeg = Math.abs( lon )%1;
        final double dMin = decDeg * 60;
        final int iMin = (int)(dMin+.5);
        final double decMin = dMin%1;
        final double dSec = decMin * 60;
        final int iSec = (int)(dSec+.5);
        final int iHun = (int)(decMin+.5);

        if( format == null )
            format = "";
            
        // degrees, minutes, hundredths
        if( format.indexOf("ddmmhh")>=0 )
            return "" + deg + nf2.format(iMin)+nf2.format(iHun)+( lon >= 0 ? " E" : " W" );
        // degrees, decimal degrees
        else if( format.indexOf("dd.hh")>=0 )
            return "" + Math.abs(lon) +( lon >= 0 ? " E" : " W" );
        // default to degrees, minutes,seconds
        else //if( format.indexOf("ddmmss")>=0 )
            return "" + deg + nf2.format(iMin)+nf2.format(iSec)+( lon >= 0 ? " E" : " W" );
        
    }   // end doubleLonToString
    
    /**
     * Converts a latitude stored as a string into a double. 
     * Supported formats: dddmmss, dddmmhh, & ddd.hh (degrees, minutes, seconds; 
     * degrees, minutes, hundredths; and degrees, hundredths of degrees). Also
     * required is a N,S,E, or W after the number.
     * 
     * @param sLat latitude as string
     * @return latitude as double
     * @since 1.0
     */
    public final static double stringLatToDouble( String sLat, String format )
    {   return stringLatLonToDouble( sLat, format );
    }   // end stringLatToDouble
    
    
    /**
     * Converts a longitude stored as a string into a double.
     * Supported formats: dddmmss, dddmmhh, & ddd.hh (degrees, minutes, seconds; 
     * degrees, minutes, hundredths; and degrees, hundredths of degrees). Also
     * required is a N,S,E, or W after the number.
     * 
     * @param sLat longitude as string
     * @return longitude as double
     * @since 1.0
     */
    public final static double stringLonToDouble( String sLon, String format )
    {   return stringLatLonToDouble( sLon, format );
    }   // end stringLonToDouble
    
    
    /**
     * Used to convert a string representation of N/S/E/W lat/lons to a double.
     * Supported formats: dddmmss, dddmmhh, & ddd.hh (degrees, minutes, seconds; 
     * degrees, minutes, hundredths; and degrees, hundredths of degrees). Also
     * required is a N,S,E, or W after the number.
     *
     * @author Gary Kinney
     * @author Robert Harder (modified)
     * @since 1.0
     * @param coord string representation of a lat/lon
     * @return lat/lon as a double
     */
    public final static double stringLatLonToDouble( String coord, String format )
    {   if( format == null )
            format = "";
        boolean dddmmss = format.indexOf("ddmmss") >= 0 ? true : false;
        boolean dddmmhh = format.indexOf("ddmmhh") >=0 ? true : false;
        boolean ddddec  = format.indexOf("dd.hh") >= 0 ? true : false;
        coord = coord.toUpperCase().trim();
        
        // Simplest case, the coord is in dd.hh, which is just a double
        if( ddddec )
        {
            // Make sure there's nothing there but a number
            StringBuffer s = new StringBuffer();
            for( int i = 0; i < coord.length(); i++ )
                if( Character.isDigit(coord.charAt(i)) || coord.charAt(i)=='.' )
                s.append( coord.charAt(i) );
            double val = 0;
            try{ val = new Double(s.toString()).doubleValue(); }
            catch(Exception e){}
            if( coord.indexOf('W') >= 0 || coord.charAt(0)=='-')
                val = -val;
            else if( coord.indexOf('S') >= 0 || coord.charAt(0)=='-' )
                val = -val;
            return val;
        }   // end if: dd.hh (easy double)
        
        // Degrees, minutes, hundredths
        else if( dddmmhh )
        {
            // Make sure there's nothing there but a number
            StringBuffer s = new StringBuffer();
            for( int i = 0; i < coord.length(); i++ )
                if( Character.isDigit(coord.charAt(i)) )
                s.append( coord.charAt(i) );
            String num = s.toString();
            
            // format should be dddmmhh, but if it's ddmm let that slide
            if( num.length() >= 4 )
            {   int hhOff = num.length() >= 6 ? 2 : 0;
                String strHH = hhOff != 0 ? num.substring( num.length()-hhOff, num.length() ) : "0";
                String strMM = num.substring( num.length()-2-hhOff, num.length()-hhOff );
                String strDD = num.substring( 0, num.length()-2-hhOff );
                int deg = Integer.parseInt( strDD );
                int min = Integer.parseInt( strMM );
                int hun = Integer.parseInt( strHH );
                double val = deg + ((min+(hun/100.))/60.);
                if( coord.indexOf('W') >= 0 )
                    val = -val;
                else if( coord.indexOf('S') >= 0 )
                    val = -val;
                return val;
            }   // end if: proper length
            else return 0;
        }   // end else if: ddmmhh
        
        // Default to degrees, minutes, seconds
        else //if( dddmmss)
        {
            // Make sure there's nothing there but a number
            StringBuffer s = new StringBuffer();
            for( int i = 0; i < coord.length(); i++ )
                if( Character.isDigit(coord.charAt(i)) )
                s.append( coord.charAt(i) );
            String num = s.toString();
            
            // format should be dddmmss, but if it's ddmm let that slide
            if( num.length() >= 4 )
            {   int ssOff = num.length() >= 6 ? 2 : 0;
                String strSS = ssOff != 0 ? num.substring( num.length()-ssOff, num.length() ) : "0";
                String strMM = num.substring( num.length()-2-ssOff, num.length()-ssOff );
                String strDD = num.substring( 0, num.length()-2-ssOff );
                int deg = Integer.parseInt( strDD );
                int min = Integer.parseInt( strMM );
                int sec = Integer.parseInt( strSS );
                double val = deg + ((min+(sec/60.))/60.);
                if( coord.indexOf('W') >= 0 )
                    val = -val;
                else if( coord.indexOf('S') >= 0 )
                    val = -val;
                return val;
            }   // end if: proper length
            else return 0;
        }   // end else: dddmmss
            
/*          
            // Kinney's version
            boolean north, south, east, west;
            int pos;
            Double temp;
            double hours, minutes,seconds;
            
            coord = coord.trim();
            
            try
            {    
                north = coord.endsWith("N") || coord.endsWith( "n" ) 
                    || coord.startsWith("N") || coord.startsWith( "n" );
                south = coord.endsWith("S") || coord.endsWith( "s" ) 
                    || coord.startsWith("S") || coord.startsWith( "s" );
                east = coord.endsWith("E") || coord.endsWith( "e" ) 
                    || coord.startsWith("E") || coord.startsWith( "e" );
                west = coord.endsWith("W") || coord.endsWith( "w" ) 
                    || coord.startsWith("W") || coord.startsWith( "w" );
                     
                if ( north || south || east || west )
                {
                    pos = coord.length() - 1;
                    while ( ! Character.isDigit(coord.charAt( pos )) )
                        pos--;
                        
                    temp = Double.valueOf( coord.substring( pos-1, pos+1 ) );
                    seconds = temp.doubleValue();
                    
                    pos = pos - 2;
                    while ( ! Character.isDigit(coord.charAt( pos )) )
                        pos--;
                    
                    temp = Double.valueOf( coord.substring( pos-1, pos+1 ) );
                    minutes = temp.doubleValue();

                    pos = pos - 2;
                    while ( ! Character.isDigit(coord.charAt( pos )) )
                        pos--;
                    
                    if ( pos-2 >= 0 && Character.isDigit(coord.charAt( pos-2 )) )
                    {
                    temp = Double.valueOf( coord.substring( pos-2, pos+1 ) );
                    hours = temp.doubleValue();
                    }
                    else if ( pos-1 >= 0 && Character.isDigit(coord.charAt( pos-1 )) )
                    {
                    temp = Double.valueOf( coord.substring( pos-1, pos+1 ) );
                    hours = temp.doubleValue();
                    }
                    else
                    {
                    temp = Double.valueOf( coord.substring( pos, pos+1 ) );
                    hours = temp.doubleValue();
                    } 
                    
                    minutes = minutes + ( seconds / 60.0 );
                    hours = hours + ( minutes / 60.0 );
                    
                    if ( south  || west )
                        hours = hours * -1.0;
                } 
                else
                {
                    temp = Double.valueOf( coord );
                    hours = temp.doubleValue();
                }
                return hours;
            }   // end try    
            catch( Exception e )
            {   return 0;
            }   // end catch
        }   // end else: default to dddmmss
        */
    }   // end stringLatLonToDouble
    
    
    /**
     * Assigns the time windows and walls contained in the restricted
     * operating zone to the sites contained in the site list.
     *
     * @param roz restricted operating zone from which to get time windows and walls
     * @param siteList site list containing sites to modify based on the restricted operating zone
     * @since 1.0
     */
    public final static void assignROZTimesToSites( 
    RestrictedOperatingZone roz, SiteList siteList )
    {
        GeographicRegion region = roz.getRegion();
        int windowStart = roz.getEarliestAllowedTime();
        int windowEnd = roz.getLatestAllowedTime();
        int wallStart = roz.getEarliestRestrictedTime();
        int wallEnd = roz.getLatestRestrictedTime();
        
        // Go through each site in the site list. If any sites
        // are in the region, set the time windows and time walls
        Site[] sites = siteList.getSites();
        for( int i = 0; i < sites.length; i++ )
            if( region.contains( sites[i].getLatitude(), sites[i].getLongitude() ) )
            {
                sites[i].setEarliestArrivalTime( windowStart );
                sites[i].setLatestDepartureTime( windowEnd );
                sites[i].setEarliestRestrictedTime( wallStart );
                sites[i].setLatestRestrictedTime( wallEnd );
            }   // end if: site is in region
        
        
    }   // end assignROZTimesToSites
    
    
    /**
     * This takes a direction (in degrees, clockwise from North)
     * and returns the opposite direction. For instance given a
     * bearing for a wind, this would return where the wind is
     * coming from: the standard way to report wind.
     *
     * @param originalDirection original direction
     * @return opposite direction
     * @since 1.0.2
     */
    public final static int reverseDirection( int originalDirection )
    {   return (originalDirection + 180) % 360;
    }   // end reverseDirection
    
    
    
}   // end class Utilities
