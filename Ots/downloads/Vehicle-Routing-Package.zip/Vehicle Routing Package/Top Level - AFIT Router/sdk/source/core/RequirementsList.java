/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;

/**
 * Keeps a list of all the requirement types that the sites
 * request. The list is used when editing vehicles and other
 * places. This needs more work before it can be successfully
 * exploited.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 */
public class RequirementsList extends Observable 
implements Observer
{
    private String[] reqFromSites = {};
    private String[] reqFromVehicles = {};
    
    /**
     * Constructs a list based on the site list and vehicle list
     *
     * @param siteList site list to use
     * @param vehicleList vehicle list to use
     * @since 1.0
     * @see VehicleList
     * @see Vehicle
     * @see SiteList
     * @see Site
     */
    public RequirementsList( SiteList siteList, VehicleList vehicleList )
    {   siteList.addObserver( this );
        vehicleList.addObserver( this );
        update( siteList, null );
        update( vehicleList, null );
    }   // end constructor
    
    /**
     * Returns an array of requirement types.
     *
     * @return an array of requirement types
     * @since 1.0
     */
    public synchronized String[] getRequirementTypes()
    {   
        String[] reqs = new String[ reqFromSites.length 
            + reqFromVehicles.length ];
        System.arraycopy( reqFromSites, 0, reqs, 0, reqFromSites.length );
        System.arraycopy( reqFromVehicles, 0, reqs, 
            reqFromSites.length, reqFromVehicles.length );
        return reqs;
    }   // end getRequirementTypes
    
    public synchronized void setSiteRequirementTypes( String[] reqList )
    {   this.reqFromSites = reqList;
        this.setChanged();
        this.notifyObservers();
    }   // end setSiteRequirementTypes
    
    public synchronized void setVehicleRequirementTypes( String[] reqList )
    {   this.reqFromVehicles = reqList;
        this.setChanged();
        this.notifyObservers();
    }   // end setVehicleRequirementTypes
    
    public synchronized boolean contains( String requirement )
    {   boolean contains = false;
        for( int i = 0; i < reqFromSites.length; i++ )
            if( reqFromSites[i].equals( requirement ) )
            {   contains = true;
                i = Integer.MAX_VALUE;
                break;
            }   // end if: contains requirement
        if( ! contains )
            for( int i = 0; i < reqFromVehicles.length; i++ )
                if( reqFromVehicles[i].equals( requirement ) )
                {   contains = true;
                    i = Integer.MAX_VALUE;
                    break;
                }   // end if: contains requirement
        return contains;
    }   // end contains
    
/* ********  O B S E R V E R   C O D E  ******** */    
    
    public final void update( Observable thing, Object arg )
    {
        // Make sure it's the SiteList that came through
        if( thing instanceof SiteList )
        {
            final SiteList List = (SiteList) thing;
            final RequirementsList This = this;
            Thread t = new Thread( new Runnable()
            {   public void run()
                {   
                    //final ArrayList reqList = new ArrayList();
                    String[] reqs = new String[0];
                    
                    synchronized( List )
                    {   final Site[] sites = List.getSites();
                        for( int i = 0; i < sites.length; i++ )
                        {   
                            final String req = sites[i].getRequirementType();
                            
                            // If it's null, just skip it
                            if( !req.equals( "" ) )
                            {
                                boolean alreadyInList = false;
                                
                                // See if the requirement is already
                                // in the list.
                                for( int j = 0; j < reqs.length; j++ )
                                {   if( req.equals( reqs[j] ) )
                                    {   // already in list
                                        alreadyInList = true;
                                        j = Integer.MAX_VALUE;
                                        break;
                                    }   // end if: already in list
                                }   // end for: through list
                                
                                // If it's not already in list, add it.
                                if( !alreadyInList )
                                {
                                    String[] temp = new String[ 
                                        reqs.length+1 ];
                                    System.arraycopy( reqs, 0, temp, 
                                        0, reqs.length );
                                    temp[reqs.length] = req;
                                    reqs = temp;
                                }   // end if: not in list
                            }   // end if: not empty requirement
                        }   // end for: through each site
                    }   // end sync: List
                    
                    // Store and notify of change
                    This.setSiteRequirementTypes( reqs );
                }   // end run
            }); // end runnable, thread
            t.setDaemon( true );
            t.start();
        }   // end if: site list came through
        else
        // Maybe the vehicle list changed
        if( thing instanceof VehicleList )
        {
            final VehicleList List = (VehicleList) thing;
            final RequirementsList This = this;
            Thread t = new Thread( new Runnable()
            {   public void run()
                {   
                    //final ArrayList reqList = new ArrayList();
                    String[] reqs = new String[0];
                    
                    synchronized( List )
                    {   final Vehicle[] vehicles = List.getVehicles();
                        for( int i = 0; i < vehicles.length; i++ )
                        {   
                            final String[] vreqs = vehicles[i]
                                .getSupportedRequirementTypes();
                            
                            // Through each supported requirement
                            for( int k = 0; k < vreqs.length; k++ )
                            {
                                final String req = vreqs[k];
                                // If it's null, just skip it
                                if( !req.equals( "" ) )
                                {
                                    boolean alreadyInList = false;
                                    
                                    // See if the requirement is already
                                    // in the list.
                                    for( int j = 0; j < reqs.length; j++ )
                                    {   if( req.equals( reqs[j] ) )
                                        {   // already in list
                                            alreadyInList = true;
                                            j = Integer.MAX_VALUE;
                                            break;
                                        }   // end if: already in list
                                    }   // end for: through list
                                    
                                    // If it's not already in list, add it.
                                    if( !alreadyInList )
                                {
                                    String[] temp = new String[ 
                                        reqs.length+1 ];
                                    System.arraycopy( reqs, 0, temp, 
                                        0, reqs.length );
                                    temp[reqs.length] = req;
                                    reqs = temp;
                                }   // end if: not in list
                                }   // end if: not empty requirement
                            }   // end for: through each supported reqmt
                        }   // end for: through each vehicle
                    }   // end sync: List
                    
                    // Store and notify of change
                    This.setVehicleRequirementTypes( reqs );
                }   // end run
            }); // end runnable, thread
            t.setDaemon( true );
            t.start();
        
        }   // end if: vehicle list came through
    }   // end update
    
    public String toString()
    {   final String[] reqs = this.getRequirementTypes();
        StringBuffer s = new StringBuffer("[");
        
        for( int i = 0; i < reqs.length; i++ )
            s.append( reqs[i] + (i==reqs.length-1? "]": ", ") );
        
        return s.toString();
    }   // end toString
    
/* ********  R E S E T   C O D E  ******** */
    
    public final void reset( SiteList siteList, VehicleList vehicleList )
    {   
        siteList.addObserver( this );
        vehicleList.addObserver( this );
        update( siteList, null );
        update( vehicleList, null );
    }   // end reset
    
}   // end class RequirementsList