/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import mil.af.afit.uvr.*;
import java.util.*;
import java.io.*;


/**
 * A vehicle travels to the sites that it can service based on the vehicle's
 * capabilities and the sites' requirements. By default a vehicle leaves from
 * and returns to its home base, but it can also leave from an "alternate location"
 * in which case it will start there and return to its home base.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @since 1.0
 * @version 1.0
 * @see Site
 * @see Base
 */
public class Vehicle 
extends Observable 
implements Serializable
{
    private static final int defaultSpeed = 100;
    
    private String name=null;
    private transient Base homeBase=null;
    private String homeBaseName=null;
    private boolean enabled=true;
    private boolean atHome=true;
    private int earliestStartTime=0;
    private int priority=1; // Take this out.
    private double alternateLatitude=0;
    private double alternateLongitude=0;
    private int range=0;    // Minutes
    private int speed=defaultSpeed;   // knots
    private int altitude=0; // Feet
    
    private String[] supportedRequirementTypes = { "EO/IR","SAR"};
    
    /**
     * Constructs a vehicle with default values.
     *
     * @since 1.0
     */
    public Vehicle()
    {   
    }   // end constructor
    
    /**
     * Constructs a vehicle with the specified name
     *
     * @param name vehicle name
     * @since 1.0
     */
    public Vehicle( String name )
    {   initializeVehicle( name, defaultSpeed );
    }   // end constructor
    
    
    /**
     * Constructs a vehicle with the specified name and speed
     *
     * @param name vehicle name
     * @param speed vehicle speed (in knots)
     * @since 1.0
     */
    public Vehicle( String name, int speed )
    {   initializeVehicle( name, speed );
    }   // end constructor
    
    
    /**
     * Constructs a vehicle copied from the specified vehicle
     *
     * @param copyThis vehicle to copy
     * @since 1.0
     */
    public Vehicle( Vehicle copyThis )
    {
        this.name = copyThis.getName();
        this.homeBase = copyThis.getHomeBase();
        this.homeBaseName = homeBase.getName();
        this.enabled = copyThis.isEnabled();
        this.atHome = copyThis.isAtHome();
        this.earliestStartTime = copyThis.getEarliestStartTime();
        this. priority = copyThis.getPriority();
        this.alternateLatitude = copyThis.getAlternateLatitude();
        this.alternateLongitude = copyThis.getAlternateLongitude();
        this.range = copyThis.getRange();
        this.speed = copyThis.getSpeed();   // knots
        this.altitude = copyThis.getAltitude(); // feet
    }   // end constructor
    
    
    private void initializeVehicle( String name, int speed )
    {
        this.name = name;
        this.speed = speed;
        this.enabled = true;
    }   // end initializeVehicle
    
    /**
     * Returns whether or not the vehicl is enabled.
     *
     * @return whether or not the vehicl is enabled
     * @since 1.0
     */
    public boolean isEnabled()
    {   return enabled;
    }   // end isEnabled
    
    
    
    
/* ********  G E T   C O D E  ******** */

    /**
     * Returns the vehicle's priority.
     * 
     * @return vehicle's priority
     * @since 1.0
     */
    public final int getPriority()
    {   return priority;
    }   // end getPriority


    /**
     * Returns the vehicle's name.
     * 
     * @return vehicle's name
     * @since 1.0
     */
    public final String getName()
    {   return name;
    }   // end getName


    /**
     * Returns the vehicle's home base.
     * 
     * @return vehicle's home base
     * @since 1.0
     */
    public final Base getHomeBase()
    {   return homeBase;
    }   // end getBase


    /**
     * Returns the vehicle's alternate starting latitude.
     * 
     * @return vehicle's alternate starting latitude
     * @since 1.0
     */
    public final double getAlternateLatitude()
    {   return this.alternateLatitude;
    }   // end getAlternateLatitude
    

    /**
     * Returns the vehicle's alternate starting longitude.
     * 
     * @return vehicle's alternate starting longitude
     * @since 1.0
     */
    public final double getAlternateLongitude()
    {   return this.alternateLongitude;
    }   // end getAlternateLongitude
    

    /**
     * Returns the vehicle's starting latitude. This is a little inefficient
     * at the moment and could use some cleaning up.
     * 
     * @return vehicle's starting latitude
     * @since 1.0
     */
    public final double getStartingLatitude()
    {
        double startLat, startLong, endLat, endLong = 0;
        if( isAtHome() )
        {   if( getHomeBase() != null )
            {   startLat = getHomeBase().getLatitude();
                startLong = getHomeBase().getLongitude();
                endLat = startLat;
                endLong = startLong;
            }   // end if: home base not null
            else
            {   startLat = getAlternateLatitude();
                startLong = getAlternateLongitude();
                endLat = startLat;
                endLong = startLong;
            }   // end else: at home but no base
        }   // end if: at home
        else
        {   startLat = getAlternateLatitude();
            startLong = getAlternateLongitude();
            if( getHomeBase() != null )
            {   endLat = getHomeBase().getLatitude();
                endLong = getHomeBase().getLongitude();
            }   // end if: home not null
            else
            {   endLat = startLat;
                endLong = startLong;
            }   // end else: home was null
        }   // end else: away from home
        
        return startLat;
    }   // end getStartingLatitude
    
    

    /**
     * Returns the vehicle's starting longitude. This is a little inefficient
     * at the moment and could use some cleaning up.
     * 
     * @return vehicle's starting longitude
     * @since 1.0
     */
    public final double getStartingLongitude()
    {
        double startLat, startLong, endLat, endLong = 0;
        if( isAtHome() )
        {   if( getHomeBase() != null )
            {   startLat = getHomeBase().getLatitude();
                startLong = getHomeBase().getLongitude();
                endLat = startLat;
                endLong = startLong;
            }   // end if: home base not null
            else
            {   startLat = getAlternateLatitude();
                startLong = getAlternateLongitude();
                endLat = startLat;
                endLong = startLong;
            }   // end else: at home but no base
        }   // end if: at home
        else
        {   startLat = getAlternateLatitude();
            startLong = getAlternateLongitude();
            if( getHomeBase() != null )
            {   endLat = getHomeBase().getLatitude();
                endLong = getHomeBase().getLongitude();
            }   // end if: home not null
            else
            {   endLat = startLat;
                endLong = startLong;
            }   // end else: home was null
        }   // end else: away from home
        
        return startLong;
    }   // end getStartingLongitude
    

    /**
     * Returns the vehicle's ending latitude. This is a little inefficient
     * at the moment and could use some cleaning up.
     * 
     * @return vehicle's ending latitude
     * @since 1.0
     */
    public final double getEndingLatitude()
    {
        double startLat, startLong, endLat, endLong = 0;
        if( isAtHome() )
        {   if( getHomeBase() != null )
            {   startLat = getHomeBase().getLatitude();
                startLong = getHomeBase().getLongitude();
                endLat = startLat;
                endLong = startLong;
            }   // end if: home base not null
            else
            {   startLat = getAlternateLatitude();
                startLong = getAlternateLongitude();
                endLat = startLat;
                endLong = startLong;
            }   // end else: at home but no base
        }   // end if: at home
        else
        {   startLat = getAlternateLatitude();
            startLong = getAlternateLongitude();
            if( getHomeBase() != null )
            {   endLat = getHomeBase().getLatitude();
                endLong = getHomeBase().getLongitude();
            }   // end if: home not null
            else
            {   endLat = startLat;
                endLong = startLong;
            }   // end else: home was null
        }   // end else: away from home
        
        return endLat;
    }   // end getEndingLatitude
    

    /**
     * Returns the vehicle's ending longitude. This is a little inefficient
     * at the moment and could use some cleaning up.
     * 
     * @return vehicle's ending longitude
     * @since 1.0
     */
    public final double getEndingLongitude()
    {
        double startLat, startLong, endLat, endLong = 0;
        if( isAtHome() )
        {   if( getHomeBase() != null )
            {   startLat = getHomeBase().getLatitude();
                startLong = getHomeBase().getLongitude();
                endLat = startLat;
                endLong = startLong;
            }   // end if: home base not null
            else
            {   startLat = getAlternateLatitude();
                startLong = getAlternateLongitude();
                endLat = startLat;
                endLong = startLong;
            }   // end else: at home but no base
        }   // end if: at home
        else
        {   startLat = getAlternateLatitude();
            startLong = getAlternateLongitude();
            if( getHomeBase() != null )
            {   endLat = getHomeBase().getLatitude();
                endLong = getHomeBase().getLongitude();
            }   // end if: home not null
            else
            {   endLat = startLat;
                endLong = startLong;
            }   // end else: home was null
        }   // end else: away from home
        
        return endLong;
    }   // end getEndingLongitude
    
    /**
     * Returns whether or not the vehicle is currently at its home base.
     *
     * @return whether or not the vehicle is at its home base
     * @since 1.0
     */
    public final boolean isAtHome()
    {   return this.atHome;
    }   // end isAtHome
    
    
    /**
     * Returns the earliest time when the vehicle is available for takeoff.
     *
     * @return the earliest time when the vehicle is available for takeoff
     * @since 1.0
     */
    public final int getEarliestStartTime()
    {   return earliestStartTime;
    }   // end getEarliestStartTime
    
    /**
     * Returns the vehicle's speed (in knots).
     *
     * @return the vehicle's speed (in knots)
     * @since 1.0
     */
    public final int getSpeed()
    {   return this.speed;
    }   // end getSpeed
    
    
    /**
     * Returns the vehicle's range (in minutes).
     *
     * @return the vehicle's range (in minutes)
     * @since 1.0
     */
    public final int getRange()
    {   return range;
    }   // end getRange
    
    
    /**
     * Returns the vehicle's supported requirement types.
     *
     * @return the vehicle's supported requirement types
     * @since 1.0
     */
    public final String[] getSupportedRequirementTypes()
    {   return supportedRequirementTypes;
    }   // end getSupportedDemands

    
    /**
     * Returns the vehicle's altitude (in feet).
     *
     * @return the vehicle's altitude (in feet)
     * @since 1.0
     */
    public final int getAltitude()
    {   return altitude;
    }   // end getAltitude

/* ********  S E T   C O D E  ******** */
    
    /**
     * Sets whether or not the vehicle is enabled.
     *
     * @param state whether or not the vehicle is enabled
     * @since 1.0
     */
    public void setEnabled( boolean state )
    {   this.enabled = state;
        this.setChanged();
        this.notifyObservers();
    }   // end setEnabled
    
    /**
     * Sets the vehicle's name.
     * 
     * @param name the vehicle's name
     * @since 1.0
     */
    public final void setName( String name )
    {   this.name = name;
        this.setChanged();
        this.notifyObservers();
    }   // end setName
    
    
    /**
     * Sets the vehicle's home base.
     * 
     * @param name the vehicle's home base
     * @since 1.0
     */
    public final void setHomeBase( Base home )
    {   this.homeBase = home;
        this.homeBaseName = home.getName();
        this.setChanged();
        this.notifyObservers();
    }   // end setHomeBase
    
    
    /**
     * Sets the vehicle's home base name. This value is saved when a vehicle
     * is serializd.
     * 
     * @param name the vehicle's home base name
     * @since 1.0
     */
    public final void setHomeBaseName( String name )
    {   setHomeBaseName( name, null );
    }   // end setHomeBaseName
    
    
    
    /**
     * Sets the vehicle's home base name. This value is saved when a vehicle
     * is serializd. Try to match up the base name to an actual base object
     * in <var>baseList</var>.
     * 
     * @param name the vehicle's home base name
     * @param baseList the base list to use for finding bases
     * @since 1.0
     */
    public final void setHomeBaseName( String name, BaseList baseList )
    {   this.homeBaseName = name.trim();
        // If it's in the known baselist, set the base to go with it
        if( baseList != null )
        {   Base[] bases = baseList.getBases();
            for( int i = 0; i < bases.length; i++ )
                if( homeBaseName.equals( bases[i].getName() ) )
                {   setHomeBase( bases[i] );
                    break;
                }   // end if: name equals base name
        }   // end if: baseList not null
        this.setChanged();
        this.notifyObservers();
    }   // end setHomeBaseName
    
    
    /**
     * Sets the vehicle's alternate latitude.
     * 
     * @param altLat the vehicle's alternate latitude
     * @since 1.0
     */
    public final void setAlternateLatitude( double altLat )
    {   this.alternateLatitude = altLat;
        this.setChanged();
        this.notifyObservers();
    }   // end setAlternateLatitude
    
    
    /**
     * Sets the vehicle's alternate longitude.
     * 
     * @param altLong the vehicle's alternate latitude
     * @since 1.0
     */
    public final void setAlternateLongitude( double altLong )
    {   this.alternateLongitude = altLong;
        this.setChanged();
        this.notifyObservers();
    }   // end setAlternateLongitude
    
    
    /**
     * Sets whether or not the vehicle is at its home base. If <tt>false</tt>,
     * the vehicle must be at its alternate latitude and longitude.
     * 
     * @param state whether or not the vehicle is at its home base
     * @since 1.0
     */
    public final void setAtHome( boolean state )
    {   this.atHome = state;
        this.setChanged();
        this.notifyObservers();
    }   // end setAtHome
    
    
    /**
     * Sets the earliest time that the vehicle can take off.
     * 
     * @param time the earliest time that the vehicle can take off
     * @since 1.0
     */
    public final void setEarliestStartTime( int time )
    {   earliestStartTime = time;
        this.setChanged();
        this.notifyObservers();
    }   // end setEarliestStartTime
    
    
    /**
     * Sets the vehicle's range (in minutes).
     * 
     * @param range the vehicle's range (in minutes).
     * @since 1.0
     */
    public final void setRange( int range )
    {   this.range = range;
        this.setChanged();
        this.notifyObservers();
    }   // end setRange
    
    
    /**
     * Sets the vehicle's speed (in knots).
     * 
     * @param range the vehicle's speed (in knots).
     * @since 1.0
     */
    public final void setSpeed( int speed )
    {   this.speed = speed;
        this.setChanged();
        this.notifyObservers();
    }   // end setSpeed
    
    
    
    /**
     * Sets the vehicle's altitude (in feet). Used in wind calculations.
     * 
     * @param range the vehicle's altitude (in feet).
     * @since 1.0
     */
    public final void setAltitude( int altitude )
    {   this.altitude = altitude;
        this.setChanged();
        this.notifyObservers();
    }   // end setAltitude
    
/* ********  M I S C E L L A N E O U S   M E T H O D S  ******** */
    
    /**
     * Adds a requirement type to the list of vehicle capabilities.
     *
     * @param reqType requirement type to add to capabilities list
     * @since 1.0
     */
    public final synchronized void addSupportedRequirementType( String reqType )
    {
        String[] temp = new String[ supportedRequirementTypes.length + 1 ];
        System.arraycopy( supportedRequirementTypes, 0, 
            temp, 0, supportedRequirementTypes.length );
        temp[ supportedRequirementTypes.length ] = reqType;
        supportedRequirementTypes = temp;
        this.setChanged();
        this.notifyObservers( supportedRequirementTypes );
    }   // end addSupportedRequirementType
    
    
    /**
     * Adds the requirement types to the list of vehicle capabilities.
     *
     * @param reqTypes requirement types to add to capabilities list
     * @since 1.0
     */
    public final synchronized void setSupportedRequirementTypes( String[] reqTypes )
    {   this.supportedRequirementTypes = 
            reqTypes == null
            ? new String[0]
            : reqTypes;
        this.setChanged();
        this.notifyObservers(this.supportedRequirementTypes);
    }   // end setSupportedRequirementTypes
    
    
    
    /**
     * Removes a requirement type from the list of vehicle capabilities.
     *
     * @param reqType requirement type to remove from capabilities list
     * @since 1.0
     */
    public final synchronized void removeSupportedRequirementType( String reqType )
    {
        int index = -1;
        for( int i = 0; i < supportedRequirementTypes.length; i++ )
        {
            if( supportedRequirementTypes[i].equals( reqType ) )
            {   index = i;
                i = Integer.MAX_VALUE;
                break;
            }   // end if: req found
        }   // end for: through each req type
        if( index >= 0 )
        {   String[] temp = new String[ supportedRequirementTypes.length - 1];
            System.arraycopy( supportedRequirementTypes, 0, temp, 0, index );
            System.arraycopy( supportedRequirementTypes, index+1, 
                temp, index, supportedRequirementTypes.length - index );
            supportedRequirementTypes = temp;
            this.setChanged();
            this.notifyObservers();
        }   // end if: req found
    }   // end removeSupportedRequirementType
    
    /**
     * Returns whether or not the vehicle supports the requirement type.
     *
     * @param reqType requirement type to check
     * @since 1.0
     */
    public final boolean supportsRequirementType( String reqType )
    {   
        for( int i = 0; i < supportedRequirementTypes.length; i++ )
            if( supportedRequirementTypes[i].equals( reqType ) )
                return true;
        return false;
    }   // end supportsRequirementType
    
    /**
     * Determines a base object from the home base named stored during serialization.
     *
     * @param list base list to search through
     * @since 1.0
     */
    public final void determineHomeBaseFromList( BaseList list )
    {
        Base[] bases = list.getBases();
        for( int i = 0; i < bases.length; i++ )
        {
            if( bases[i].getName() != null )
            {
                if( bases[i].getName().equals( homeBaseName ) )
                {   homeBase = bases[i];
                    setChanged();
                    notifyObservers( homeBase );
                    break;
                }   // end if: equals
            }   // end if: name not null
        }   // end for: each base
    
    }   // end determineHomeBaseFromList
        
        
        
        
    public String toString()
    {
        String s = name + ", speed=" + speed;
        return s;
    }   // end toString
    
    
    
}   // end class Vehicle