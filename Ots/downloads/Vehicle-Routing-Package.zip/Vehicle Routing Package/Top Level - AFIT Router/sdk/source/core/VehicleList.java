/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.io.*;





/**
 * This maintains a list of Vehicles and allows interested objects to listen
 * for changes by implementing the <code>Observer</code> interface.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Vehicle
 * @see java.util.Observer
 */
public class VehicleList 
extends Observable 
implements Observer, Serializable
{
    Vehicle[] vehicles;
    
    /**
     * Constructs an empty Vehicle list
     *
     * @since 1.0
     */
    public VehicleList()
    {   super();
        vehicles = new Vehicle[0];
    }   // end constructor
    
    
    
    /**
     * Adds the array of Vehicles to the end of the Vehicle list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param moreVehicles array of Vehicles to add to list
     * @see Vehicle
     * @see java.util.Observer
     */
    public synchronized final void addVehicles( Vehicle[] moreVehicles )
    {
        // Make a larger array to hold the two vehicle arrays
        Vehicle[] tempVehicles = new Vehicle[ vehicles.length + moreVehicles.length ];
        
        // Copy to the two arrays into the larger array
        System.arraycopy( 
            vehicles,      // Source
            0,          // Start
            tempVehicles,  // Destination
            0,          // Start
            vehicles.length ); // Length
        System.arraycopy( 
            moreVehicles,      // Source
            0,              // Start
            tempVehicles,      // Destination
            vehicles.length,   // Start
            moreVehicles.length ); // Length
        
        // Save change
        this.vehicles = tempVehicles;
        
        // Notify observers of the change
        setChanged();
        notifyObservers( moreVehicles );
    }   // end addVehicles
    
    
    
    
    /**
     * Adds a single Vehicle to the end of the Vehicle list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param Vehicle Vehicle to add to list
     * @see Vehicle
     * @see java.util.Observer
     */
    public synchronized final void addVehicle( Vehicle vehicle )
    {
        if( vehicle != null )
        {
            // Make a larger array to hold the two vehicle arrays
            Vehicle[] tempVehicles = new Vehicle[ vehicles.length + 1 ];
            
            // Copy to the two arrays into the larger array
            System.arraycopy( 
                vehicles,      // Source
                0,          // Start
                tempVehicles,  // Destination
                0,          // Start
                vehicles.length ); // Length
            
            tempVehicles[ vehicles.length ] = vehicle;
            vehicles = tempVehicles;
            
            // Register with new vehicle
            vehicle.addObserver( this );
        
            // Notify observers of the change
            setChanged();
            notifyObservers( vehicle );
        }   // end if: vehicle was not null
    }   // end addVehicle
    
    
    /**
     * Removes a Vehicle at a particular index and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param index index of Vehicle to remove
     * @see Vehicle
     * @see java.util.Observer
     */
    public synchronized final void removeVehicleAt( int index )
    {
        if( index >= 0 && index < vehicles.length )
        {   Vehicle[] temp = new Vehicle[ vehicles.length-1 ];
            System.arraycopy( vehicles, 0, temp, 0, index );
            System.arraycopy( vehicles, index, temp, index, vehicles.length-index-1 );
            vehicles = temp;
            setChanged();
            notifyObservers();
        }   // end if: found vehicle
    }   // end removeVehicleAt
    
    
    
    /**
     * Removes a Vehicle by checking <code>Vehicle == Vehicles[i]</code> for
     * each Vehicle in the list and notifies registered <code>Observer</code>s
     * of the change
     *
     * @param Vehicle Vehicle to remove
     * @see Vehicle
     * @see java.util.Observer
     */
    public synchronized final void removeVehicle( Vehicle vehicle )
    {   int index = -1;
        for( int i = 0; i < vehicles.length; i++ )
            if( vehicles[i] == vehicle )
            {   index = i;
                removeVehicleAt( i );
                i = Integer.MAX_VALUE;
                break;
            }   // end if: found vehicle
        
    }   // end removeVehicle
    
    
    /**
     * Removes Vehicles at the specified indeces and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param Vehicle Vehicle to remove
     * @see Vehicle
     * @see java.util.Observer
     */
    public synchronized final void removeVehiclesAt( int[] indeces )
    {   
        // Nullify vehicles to remove
        for( int i = 0; i < indeces.length; i++ )
            vehicles[ indeces[i] ] = null;
        
        // Make new array
        Vehicle[] temp = new Vehicle[ vehicles.length - indeces.length ];
        int index = 0;
        for( int i = 0; i < vehicles.length; i++ )
            if( vehicles[i] != null )
                temp[index++] = vehicles[i];
        vehicles = temp;
        setChanged();
        notifyObservers();
    }   // end removeVehiclesAt
    
    
    
    /**
     * Returns an array of the Vehicles in the list.
     *
     * @return array of Vehicles in the list
     * @since 1.0
     */
    public synchronized final Vehicle[] getVehicles()
    {   return vehicles;
    }   // end getVehicles
    
    /**
     * Assigns a Vehicle object to each vehicle Vehicled on the home Vehicle name
     * stored in the vehicles.
     *
     * @param list Vehicle list to use
     * @since 1.0
     */
    private final void determineHomeBasesFromList( BaseList list )
    {   for( int i = 0; i < vehicles.length; i++ )
            vehicles[i].determineHomeBaseFromList( list );
    }   // end determineHomeBasesFromList
    
    /**
     * After deserialization, reconnect links.
     *
     * @param kernel kernel being used
     * @since 1.0
     */
    public final void initializeAfterDeserialization(Kernel kernel)
    {   BaseList baseList = kernel.getBaseList();
        determineHomeBasesFromList( baseList );
        setChanged();
        notifyObservers();
    }   // end initializeAfterDeserialization
    

    
    public synchronized String toString()
    {   return "Number of vehicles: " + vehicles.length;
    }   // end toString
    
    
/* ********  O B S E R V E R   C O D E  ******** */    
    
    
    /**
     * Called when an <code>Observable</code> registers a change. The
     * list registers with bases. The list then notifies its own
     * registered <code>Observer</code>s of the change.
     *
     * @param thing thing that was updated
     * @param arg argument passed by thing
     * @since 1.0
     * @see java.util.Observable
     * @see java.util.Observer
     */
    public final void update( Observable thing, Object arg )
    {   this.setChanged();
        this.notifyObservers( thing );
    }   // end update
    
/* ********  C O U N T   C O D E  ******** */



    /**
     * Returns the number of enabled vehicles in list.
     *
     * @return the number of enabled vehicles in list
     * @since 1.0
     */
    public final synchronized int countEnabledVehicles()
    {   // Count the number of enabled vehicles
        int enabledCount = 0;
        for( int i = 0; i < vehicles.length; i++ )
            if( vehicles[i].isEnabled() )
                enabledCount++;
        return enabledCount;
    }   // end countEnabledVehicles

    
    
    
/* ********  S E R I A L I Z A B L E   C O D E  ******** */
    
    
    /**
     * The standard "write" for an object.
     */
    private void writeObject( ObjectOutputStream out )
    throws IOException, ClassNotFoundException
    {   out.defaultWriteObject();
    }   // end writeObject
    
    
    /**
     * Reads in the list and then registers the list as an <code>Observer</code>
     * with each vehicle.
     */
    private void readObject( ObjectInputStream in )
    throws IOException, ClassNotFoundException
    {   in.defaultReadObject();
        try
        {   for( int i = 0; i < vehicles.length; i++ )
                vehicles[i].addObserver( this );
        }   // end try
        catch( Exception e )
        {   vehicles = new Vehicle[0];
        }   // end catch
    }   // end readObject
    
    

/* ********  R E P L A C E   C O D E  ******** */


    /**
     * Replaces this list with <code>newList</code>. This is used
     * when loading a new <code>Kernel</code>. <code>Observer</code>s
     * registered with the original list will still be registered, but
     * anything registered with <code>newList</code> will not still
     * be registered.
     *
     * @param newList the new vehicle list to use
     * @since 1.0
     */
    public final void replace( VehicleList newList, BaseList baseList )
    {   this.vehicles = newList.getVehicles();
        
        // Fix base links
        determineHomeBasesFromList( baseList );
        
        // Register with new vehicles as a listener
        for( int i = 0; i < vehicles.length; i++ )
            vehicles[i].addObserver( this );
        this.setChanged();
        this.notifyObservers( vehicles );
    }   // end replace
    
    
    
    
}   // end class VehicleList