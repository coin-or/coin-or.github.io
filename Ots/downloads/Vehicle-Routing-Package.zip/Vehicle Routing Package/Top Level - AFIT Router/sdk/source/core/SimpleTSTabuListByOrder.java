/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.router.simpletabusearch;

import mil.af.afit.uvr.*;
import net.usa.rharder.tabusearch22.*;

class SimpleTSTabuListByOrder 
implements TSTabuList,
TSNewCurrentSolutionListener,
TSUnimprovingMoveListener,
TSNewBestSolutionListener
{
    private int LIST_LENGTH = 1000;
    int tenure = 10;
    int nextNumber = 0;
    int[] list = new int[ LIST_LENGTH ];
    
    public SimpleTSTabuListByOrder( int initialTenure )
    {
        //LIST_LENGTH = 10 * initialTenure;
        //list = new int[ LIST_LENGTH ];
        nextNumber = initialTenure;
    }   // end constructor
    
    public final void setTenure( int tenure )
    {   
        // Make sure we won't go negative
        if( nextNumber < tenure )
            nextNumber = tenure;
        this.tenure = tenure;
    }   // end setTenure
    
    private final void registerValue( int val )
    {
        list[ nextNumber++ % LIST_LENGTH ] = val;
    }   // end registerValue
    
    
/* ********  T S T A B U L I S T   C O D E  ******** */
    
    public void registerMoves( TSMove[] moves, TSSolution toSolution )
    {
        for( int i = 0; i < moves.length; i++ )
        {   HOrder order = ((SimpleTSMove)moves[i]).getHOrderToMove();
            registerValue( order != null ? order.hashCode() : -1 );
        }   // end for: through each move
    }   // end registerMoves
    
    public final boolean allowMove( TSMove move, TSSolution toSolution )
    {
        // Hash code for move
        HOrder order = ((SimpleTSMove)move).getHOrderToMove();
        final int hash = order != null ? order.hashCode() : -1;
        
        boolean allow = true;
        int i = 1;
        
        while( 
        allow == true
        &&
        i <= tenure )
        {   // See if hash code is in the list
            if( hash == list[ ( nextNumber - i ) % LIST_LENGTH ] )
                allow = false;
            i++;
        }   // end while
//System.out.print( allow ? "." : "N" );
//System.out.print( "." + tenure );
        return allow;
    }   // end allowMove
    
    
    
/* ********  T S N E W C U R R E N T S O L U T I O N  ******** */
    
    public final void newCurrentSolutionFound( TSTabuEvent e )
    {
        //System.out.print (" N ");
        // If nothing special is happening, increase tabu tenure
        // slowly.
        setTenure( tenure + 1 );
        //System.out.print( "   " + tenure );
    }   // end newCurrentSolutionFound
    
    
/* ********  T S U N I M P R O V I N G M O V E  ******** */
    
    public final void unimprovingMoveMade( TSTabuEvent e )
    {
        //System.out.print( " U " );
        // If unimproving moves start happening, increase tabu
        // tenure more drastically.
        setTenure( Math.max(1, tenure<<1) ); // double
    }   // end newCurrentSolutionFound
    
/* ********  T S N E W B E S T S O L U T I O N  ******** */
    
    public final void newBestSolutionFound( TSTabuEvent e )
    {
        //System.out.print( " B " );
        // When a new best solution is found, cut the tabu
        // tenure down to allow for intensification.
        setTenure( Math.max( 10, tenure>>1 ) ); // cut in half
    }   // end newBestSolutionFound
    
    
}   // end class SimpleTSTabuList