/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import mil.af.afit.uvr.*;

import java.io.*;
import java.text.*;
import java.util.*;

/**
 * The <code>Kernel</code> is the main point of contact between higher level
 * applications like mapping software and the data storage and routing abilities
 * of this software. The <code>Kernel</code> maintains the lists of sites, vehicles
 * bases, solutions, etc. and allows interested <code>Observer</code>s to listen
 * for changes. The <code>Kernel</code> maintains the points of contact for starting
 * the solving process. 
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0.2
 * @since 1.0
 * @see SiteList
 * @see VehicleList
 * @see BaseList
 * @see RestrictedOperatingZoneList
 * @see PriorityModelList
 * @see SolutionList
 * @see WindList
 * @see Site
 * @see Vehicle
 * @see Base
 * @see RestrictedOperatingZone
 * @see PriorityModel
 * @see Solution
 * @see Wind
 * @see Preferences
 */
public class Kernel 
extends Observable 
implements Observer, Serializable
{
    private final static boolean DEBUGGING = false;
    
    private SiteList siteList = null;
    private VehicleList vehicleList = null;
    private BaseList baseList = null;
    private WindList windList = null;
    private transient SolutionList solutionList = null;
    private transient RequirementsList requirementsList = null;
    private RestrictedOperatingZoneList rozList = null;
    private Preferences prefs = null;
    private PriorityModelList priorityModelList = null;
    
    // Allows kernel users to arbitrarily add anything at all
    // to the kernel and pass it around.
    private transient Hashtable hashtable = null;
    
    private transient boolean runningAsApplet = true;
    
    /**
     * Constructs a <code>Kernel</code> with empty lists and default preferences.
     *
     * @since 1.0
     */
    public Kernel()
    {
        // Instantiate lists
        siteList = new SiteList();
        vehicleList = new VehicleList();
        baseList = new BaseList();
        windList = new WindList();
        solutionList = new SolutionList();
        requirementsList = new RequirementsList( siteList, vehicleList );
        rozList = new RestrictedOperatingZoneList();
        priorityModelList = new PriorityModelList();
        
        // Hashtable
        hashtable = new Hashtable();
        
        // Preferences
        prefs = new Preferences();
        prefs.addObserver( this );
        
        // Set self as observer for lists
        siteList.addObserver( this );
        vehicleList.addObserver( this );
        baseList.addObserver( this );
        windList.addObserver( this );
        solutionList.addObserver( this );
        requirementsList.addObserver( this );
        rozList.addObserver( this );
        priorityModelList.addObserver( this );
        
    }   // end constructor
    
    
/* ********  G E T   C O D E  ******** */
    
    /**
     * Returns the site list.
     * 
     * @return the site list
     * @see SiteList
     * @since 1.0
     */
    public final SiteList getSiteList()
    {   return siteList;
    }   // end getSiteList
    
    
    /**
     * Returns the Vehicle list.
     * 
     * @return the vehicle list
     * @see VehicleList
     * @since 1.0
     */
    public final VehicleList getVehicleList()
    {   return vehicleList;
    }   // end getVehicleList
    
    
    /**
     * Returns the Base list.
     * 
     * @return the base list
     * @see BaseList
     * @since 1.0
     */
    public final BaseList getBaseList()
    {   return baseList;
    }   // end getBaseList
    
    
    /**
     * Returns the Wind list.
     * 
     * @return the wind list
     * @see WindList
     * @since 1.0
     */
    public final WindList getWindList()
    {   return windList;
    }   // end getWindList
    
    
    /**
     * Returns the Solution list.
     * 
     * @return the solution list
     * @see SolutionList
     * @since 1.0
     */
    public final SolutionList getSolutionList()
    {   return solutionList;
    }   // end getSolutionList
    
    
    /**
     * Returns the Requirements list.
     * 
     * @return the requirements list
     * @see RequirementsList
     * @since 1.0
     */
    public final RequirementsList getRequirementsList()
    {   return requirementsList;
    }   // end getRequirementsList
    
    
    /**
     * Returns the restricted operating zones list.
     * 
     * @return the reqrestricted operating zones list
     * @see RestrictedOperatingZoneList
     * @since 1.0
     */
    public final RestrictedOperatingZoneList getROZList()
    {   return rozList;
    }   // end getROZList
    
    /**
     * Returns the preferences
     *
     * @return preferences
     * @see Preferences
     * @since 1.0
     */
    public final Preferences getPrefs()
    {   return prefs;
    }   // end getPrefs
    
    
    /**
     * Returns the priority model list.
     * 
     * @return the priority model list
     * @see PriorityModelList
     * @since 1.0
     */
    public final PriorityModelList getPriorityModelList()
    {   return priorityModelList;
    }   // end getPriorityModelList
    
    /** 
     * Returns the object stored in the kernel's <code>key</code> entry
     * in its transient hashtable.
     * 
     * @param key key of object to retrieve
     * @see java.util.Hashtable
     */
    public final Object getClientProperty( String key )
    {   return hashtable.get( key );
    }   // end getClientProperty
    
    /**
     * Returns whether or not the kernel is being run in an applet
     * environment. This is dependent on this property being set after
     * a kernel is instantiated or deserialized.
     * 
     * @return whether or not kernel is running in an applet environment
     * @since 1.0
     */
    public final synchronized boolean isRunningAsApplet()
    {   return runningAsApplet;
    }   // end isRunningAsApplet
    
    
    /**
     * Returns whether or not the kernel is being run in an application
     * environment. This is dependent on this property being set after
     * a kernel is instantiated or deserialized.
     * 
     * @return whether or not kernel is running in an application environment
     * @since 1.0
     */
    public final synchronized boolean isRunningAsApplication()
    {   return !runningAsApplet;
    }   // end isRunningAsApplication
    
/* ********  S E T   C O D E  ******** */
    
    /**
     * Sets the Preferences object being used by the kernel and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param prefs new preferences to use
     * @see Preferences
     * @since 1.0
     */
    public final void setPrefs( Preferences prefs )
    {   this.prefs = prefs;
        this.setChanged();
        this.notifyObservers( prefs );
    }   // end setPrefs
    
    /**
     * Stores an object in the kernel's transient hashtable. These objects
     * will not be saved when the kernel is serialized. It is intended to save
     * objects relevant to a particular instance of the kernel, such as
     * a hosting window or application.
     *
     * @param key key for object to store
     * @thing thing to store
     * @see java.util.Hashtable
     * @since 1.0
     */
    public final void putClientProperty( String key, Object thing )
    {   this.hashtable.put( key, thing );
        this.setChanged();
        this.notifyObservers( thing );
    }   // end putClientProperty
    
    /**
     * Marks kernel as being run in an applet environment. This is not used
     * by any internal objects but is provided as a convenience for calling codes.
     * Using the get/put client property methods is the preferred way of saving
     * runtime information.
     * 
     * @since 1.0
     */
    public final synchronized void setRunningAsApplet()
    {   this.runningAsApplet = true;
    }   // end setRunningAsApplet
    
    
    /**
     * Marks kernel as being run in an application environment. This is not used
     * by any internal objects but is provided as a convenience for calling codes.
     * Using the get/put client property methods is the preferred way of saving
     * runtime information.
     * 
     * @since 1.0
     */
    public final synchronized void setRunningAsApplication()
    {   this.runningAsApplet = false;
    }   // end setRunningAsApplication
    
    
/* ********  S O L V E R   C O D E  ******** */
    
    /**
     * Starts the kernel solving and immediately returns control.
     *
     * @since 1.0
     */
    public final synchronized void startSolving()
    {
        KernelSolver solver = new KernelSolver( this );
        solver.startSolving();
    }   // end startSolving
    
    /**
     * Starts the kernel solving and immediately registers <var>listener</var>
     * as a <code>KernelSolverListener</code>. 
     *
     * @see KernelSolverListener
     * @since 1.0
     */
    public final void startSolving( KernelSolverListener listener )
    {
        KernelSolver ks = new KernelSolver( this );
        ks.addKernelSolverListener( listener );
        ks.startSolving();
    }   // end startSolving
    
    /**
     * Creates an <code>HEngine</code> used for solving. The <code>HEngine</code>
     * is an object from the Universal Vehicle Router available at
     * <A HREF="http://www.crosswinds.net/~rharder/afit/uvr/" TARGET="_parent">
     * http://www.crosswinds.net/~rharder/afit/uvr/</A>.
     *
     * @return <code>HEngine</code> to use for solving
     * @since 1.0
     * @see mil.af.afit.uvr.HEngine
     */
/*    private final HEngine createEngineForSolving()
    {
        // Start an HEngine going
        HEngine engine = new HEngine();
        
        // Load prefs
        final String solverName = prefs.getLastSolverUsed();
        final double effort = prefs.getLastRequestedSolutionEffort();
        final int numberOfThreads = prefs.getLastNumberOfThreads();
        
        // Convert Vehicles and Sites into UVR objects
        UVRSite[] sites = convertSitesToUVRSites( this.siteList );
        UVRVehicle[] vehicles = convertVehiclesToUVRVehicles(
            this.vehicleList, this.siteList );
        
        // Tell HEngine about the vehicles and sites
        engine.setHVehicles( vehicles );
        engine.setHOrders( sites );
        
        // Tell HEngine about the prefs
        engine.setRequestedSolutionEffort( effort );
        engine.setNumberOfThreads( numberOfThreads );
        HSolver solver = engine.setSolver( solverName );
        
        // Return
        return engine;
    }   // end createEngineForSolving
    */
    /**
     * This converts the vehicle objects used in this code to the kind of
     * object required by the Universal Vehicle Router available at
     * <A HREF="http://www.crosswinds.net/~rharder/afit/uvr/" TARGET="_parent">
     * http://www.crosswinds.net/~rharder/afit/uvr/</A>.
     *
     * @param vList list of vehicles
     * @param sList list of sites
     * @see SiteList
     * @see VehicleList
     * @see mil.af.afit.uvr.HVehicle
     * @see mil.af.afit.uvr.HOrder
     * @since 1.0
     */
/*    private final UVRVehicle[] convertVehiclesToUVRVehicles( 
    VehicleList vList, SiteList sList )
    {
        final Site[] sites = sList.getSites();
        final Vehicle[] vehicles = vList.getVehicles();
        final UVRVehicle[] fullList = new UVRVehicle[ vehicles.length ];
        
        int index = 0; // Not counting disabled vehicles.
        for( int i = 0; i < vehicles.length; i++ )
            if( vehicles[i].isEnabled() )
                fullList[index++] = 
                    new UVRVehicle( vehicles[i], sites, this );
        
        // Strip away ending null uvrvehicles
        UVRVehicle[] trimmedList = new UVRVehicle[ index ];
        System.arraycopy( fullList, 0, trimmedList, 0, index );
        
        return trimmedList;
    }   // end convertSitesToUVRSites
    */
    
    
    /**
     * This converts the site objects used in this code to the kind of
     * object required by the Universal Vehicle Router available at
     * <A HREF="http://www.crosswinds.net/~rharder/afit/uvr/" TARGET="_parent">
     * http://www.crosswinds.net/~rharder/afit/uvr/</A>.
     *
     * @param list list of sites
     * @see SiteList
     * @see mil.af.afit.uvr.HOrder
     * @since 1.0
     */
/*    private final UVRSite[] convertSitesToUVRSites( SiteList list )
    {
        Site[] sites = list.getSites();
        UVRSite[] fullList = new UVRSite[ sites.length ];
        
        int index = 0; // Not counting disabled sites.
        for( int i = 0; i < sites.length; i++ )
            if( sites[i].isEnabled() )
                fullList[index++] = new UVRSite( sites[i] );
        
        // Strip away ending null uvrsites
        UVRSite[] trimmedList = new UVRSite[ index ];
        System.arraycopy( fullList, 0, trimmedList, 0, index );
        
        return trimmedList;
    }   // end convertSitesToUVRSites
    */
    
/* ********  R E P L A C E   K E R N E L   C O D E  ******** */
    
    
    /**
     * Replaces this kernel with <var>newKernel</var> while maintaining
     * the <code>Observer</code>s registered with all objects.
     *
     * @param newKernel new kernel to use
     * @since 1.0
     */
    public synchronized void replace( Kernel newKernel )
    {
        // Go through each list and replace the data inside it.
        this.siteList.replace( newKernel.getSiteList() );
        this.baseList.replace( newKernel.getBaseList() );
        this.windList.replace( newKernel.getWindList() );
        this.vehicleList.replace( newKernel.getVehicleList(), this.baseList );
        this.rozList.replace( newKernel.getROZList() );
        this.prefs.replace( newKernel.getPrefs() );
        this.solutionList.clear();
        this.requirementsList.reset( this.siteList, this.vehicleList );
        this.priorityModelList.replace( newKernel.getPriorityModelList() );
        
    }   // end replace
    
    
/* ********  O B S E R V E R   C O D E  ******** */
    
    /**
     * When notfied, the kernel just passes on the notification to 
     * interested <code>Observer</code>s. The <code>Observable</code>
     * that called <code>update</code> is passed as the argument to the
     * kernel's <code>Observer</code>s.
     *
     * @param thing thing that changed
     * @arg argument passed from thing that changed
     * @see java.util.Observer
     * @see java.util.Observable
     * @since 1.0
     */
    public final void update( Observable thing, Object arg )
    {   Kernel.out( "Kernel.update: " + thing.getClass()+"..." );
        setChanged();
        notifyObservers( thing );
    }   // end update
    
/* ********  S E R I A L I Z A B L E   C O D E  ******** */
    
    /**
     * Saves the kernel a stream. Sites will be saved if <var>saveSitesToo</var>
     * is <tt>true</tt>.
     *
     * @since 1.0
     */
    private void writeObject( ObjectOutputStream out )
    throws IOException, ClassNotFoundException
    {   final boolean saveSitesToo = true;//prefs.saveSitesWithKernel();
        if( ! saveSitesToo )
        {   SiteList temp = siteList;
            siteList = new SiteList();
            out.defaultWriteObject();
            siteList = temp;
        }   // end if: don't save sites
        else
        {   out.defaultWriteObject();
        }   // end else: save sites too
    }   // end writeObject
    
    /**
     * Reads a kernel back in from a stream and rebuilds links.
     */
    private void readObject( ObjectInputStream in )
    throws IOException, ClassNotFoundException
    {   in.defaultReadObject();
        try
        {   // Transient objects
            requirementsList = new RequirementsList( siteList, vehicleList );
            solutionList = new SolutionList();
            hashtable = new Hashtable();
            
            // Rebuild links
            vehicleList.initializeAfterDeserialization( this );
            priorityModelList.initializeAfterDeserialization( this );
            
            // Preferences
            prefs.addObserver( this );
            
            // Set self as observer for lists
            siteList.addObserver( this );
            vehicleList.addObserver( this );
            baseList.addObserver( this );
            windList.addObserver( this );
            solutionList.addObserver( this );
            requirementsList.addObserver( this );
            rozList.addObserver( this );
            priorityModelList.addObserver( this );
        }   // end try
        catch( Exception e )
        {   
            // If anything gets screwed up, just make a fresh kernel.
            
            // Instantiate lists
            siteList = new SiteList();
            vehicleList = new VehicleList();
            baseList = new BaseList();
            windList = new WindList();
            solutionList = new SolutionList();
            requirementsList = new RequirementsList( siteList, vehicleList );
            rozList = new RestrictedOperatingZoneList();
            
            // Hashtable
            hashtable = new Hashtable();
            
            // Preferences
            prefs = new Preferences();
            prefs.addObserver( this );
            
            // Set self as observer for lists
            siteList.addObserver( this );
            vehicleList.addObserver( this );
            baseList.addObserver( this );
            windList.addObserver( this );
            solutionList.addObserver( this );
            requirementsList.addObserver( this );
            rozList.addObserver( this );
                
        }   // end catch
    }   // end readObject
    
    
/* ********  M I S C E L L A N E O U S   C O D E  ******** */
    
    /**
     * Used in debugging.
     */
    public final static void out( Object obj )
    {   if( DEBUGGING )
            System.out.println( obj );
    }   // end out
    
    /**
     * Used in debugging.
     */
    public final static void err( Exception e )
    {   if( DEBUGGING )
        {   System.err.println( e );
            e.printStackTrace();
        }   // end if: DEBUGGING
    }   // end err
    
    
    
}   // end class Kernel