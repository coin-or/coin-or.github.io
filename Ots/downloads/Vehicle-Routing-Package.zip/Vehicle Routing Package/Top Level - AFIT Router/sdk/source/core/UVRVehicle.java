/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import mil.af.afit.uvr.*;



/**
 * Vehicles are converted to this for the Universal Vehicle Router. You can get
 * back to the original vehicle by calling <code>getParentVehicle()</code>.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Vehicle
 * @see mil.af.afit.uvr.HVehicle
 */
public class UVRVehicle 
implements HVehicle
{
    private final static int DEPOT = 0;
    
    private static int idCounter=1;
    private int ID;
    private double range;
    private double earliestDepartureTime;
    //private int priority;
    private int[] supportedDemands;
    private double[][] timeMatrix;
    private double[][] penaltyMatrix;
    private int[] mapSiteIDtoArrayIndex;
    private Vehicle parentVehicle;
    private double startLat;
    private double startLong;
    private double endLat;
    private double endLong;
    
    /**
     * Constructs a UVRVehicle based on the specified vehicle. Travel
     * matrices are constructed based on the sites given.
     *
     * @param fromThis vehicle to base it on
     * @param sites sites to use for calculating travel matrices
     * @param kernel kernel being used
     * @since 1.0
     * @see Vehicle
     * @see Site
     * @see Kernel
     */
    public UVRVehicle( Vehicle fromThis, Site[] sites, Kernel kernel )
    {
        this.earliestDepartureTime = fromThis.getEarliestStartTime();
        //this.priority = fromThis.getPriority();
        this.range = fromThis.getRange();
        this.ID = idCounter++;
        this.parentVehicle = fromThis;
        
        if( parentVehicle.isAtHome() )
        {   if( parentVehicle.getHomeBase() != null )
            {   startLat = parentVehicle.getHomeBase().getLatitude();
                startLong = parentVehicle.getHomeBase().getLongitude();
                endLat = startLat;
                endLong = startLong;
            }   // end if: home base not null
            else
            {   startLat = parentVehicle.getAlternateLatitude();
                startLong = parentVehicle.getAlternateLongitude();
                endLat = startLat;
                endLong = startLong;
            }   // end else: at home but no base
        }   // end if: at home
        else
        {   startLat = parentVehicle.getAlternateLatitude();
            startLong = parentVehicle.getAlternateLongitude();
            if( parentVehicle.getHomeBase() != null )
            {   endLat = parentVehicle.getHomeBase().getLatitude();
                endLong = parentVehicle.getHomeBase().getLongitude();
            }   // end if: home not null
            else
            {   endLat = startLat;
                endLong = startLong;
            }   // end else: home was null
        }   // end else: away from home
        
        
        // Convert demand names to ints by using the hashCode() method
        final String[] supportedDemandNames = 
            fromThis.getSupportedRequirementTypes();
        supportedDemands = new int[ supportedDemandNames.length ];
        for( int i = 0; i < supportedDemands.length; i++ )
            supportedDemands[i] = supportedDemandNames[i].hashCode();
        
        // Setup costs
        setupCosts( fromThis, sites, kernel );
    }   // end constructor
    
    /**
     * Constructs a copy of the specificed UVRVehicle.
     *
     * @param copyThis vehicle to copy
     * @since 1.0
     */
    public UVRVehicle( UVRVehicle copyThis )
    {
        this.earliestDepartureTime = copyThis.getEarliestDepartureTime();
        //this.priority = copyThis.getPriority(); // Not supported for now.
        this.ID = copyThis.getID();
        this.range = copyThis.getRange();
        this.supportedDemands = copyThis.getSupportedDemands();
        this.timeMatrix = copyThis.getTimeMatrix();
        this.penaltyMatrix = copyThis.getPenaltyMatrix();
        this.mapSiteIDtoArrayIndex = copyThis.getMapSiteIDtoArrayIndex();
        this.parentVehicle = copyThis.getParentVehicle();
        this.startLat = copyThis.getStartingLatitude();
        this.startLong = copyThis.getStartingLongitude();
        this.endLat = copyThis.getEndingLatitude();
        this.endLong = copyThis.getEndingLongitude();
    }   // end constructor
    
    
/* ********  G E T   M E T H O D S   N O T   I N   H V E H I C L E  ******** */

    /**
     * Returns id.
     *
     * @return id
     * @since 1.0
     */
    public final int getID()
    {   return ID;
    }   // end getID


    /**
     * Returns parent vehicle.
     *
     * @return parent vehicle
     * @since 1.0
     * @see Vehicle
     */
    public final Vehicle getParentVehicle()
    {   return parentVehicle;
    }   // end getParentVehicle


    /**
     * Returns vehicle capabilities.
     *
     * @return vehicle capabilities
     * @since 1.0
     */
    public final int[] getSupportedDemands()
    {   return supportedDemands;
    }   // end getSupportedDemands
    

    /**
     * Returns the time matrix in use.
     *
     * @return the time matrix in use
     * @since 1.0
     */
    public final double[][] getTimeMatrix()
    {   return timeMatrix;
    }   // end getTimeMatrix
    

    /**
     * Returns the penalty matrix in use.
     *
     * @return the penalty matrix in use
     * @since 1.0
     */
    public final double[][] getPenaltyMatrix()
    {   return penaltyMatrix;
    }   // end getPenaltyMatrix
    

    /**
     * Returns a mapping array. Tracks site id's in matrices.
     *
     * @return mapping array
     * @since 1.0
     */
    public final int[] getMapSiteIDtoArrayIndex()
    {   return mapSiteIDtoArrayIndex;
    }   // end getMapSiteIDtoArrayIndex
    

    /**
     * Returns vehicle's starting latitude
     *
     * @return vehicle's starting latitude
     * @since 1.0
     */
    public final double getStartingLatitude()
    {   return startLat;
    }   // end getStartingLatitude
    

    /**
     * Returns vehicle's starting longitude
     *
     * @return vehicle's starting longitude
     * @since 1.0
     */
    public final double getStartingLongitude()
    {   return startLong;
    }   // end getStartingLongitude
    

    /**
     * Returns vehicle's ending latitude
     *
     * @return vehicle's ending latitude
     * @since 1.0
     */
    public final double getEndingLatitude()
    {   return endLat;
    }   // end getEndingLatitude
    

    /**
     * Returns vehicle's ending longitude
     *
     * @return vehicle's ending longitude
     * @since 1.0
     */
    public final double getEndingLongitude()
    {   return endLong;
    }   // end getEndingLongitude
    
    
/* ********  P R E P R O C E S S I N G   C O D E  ******** */    
    
    /**
     * Start setting up costs.
     */
    private void setupCosts( final Vehicle vehicle, 
    final Site[] sites, Kernel kernel )
    {
        // Setup mapping from site ID to array index
        int largestSiteID = 0;
        
        // Find largest value of site ID
        for( int i = 0; i < sites.length; i++ )
            largestSiteID = Math.max( largestSiteID, sites[i].getID() );
        
        // Make array large enough to hold that value by index
        mapSiteIDtoArrayIndex = new int[ largestSiteID + 1 ];
        
        // Map the possibly strange numbering of site ID to simple array indeces
        // Add one for depot
        for( int i = 0; i < sites.length; i++ )
            mapSiteIDtoArrayIndex[ sites[i].getID() ] = i+1;
        
        // Find what the wind is like for this vehicle
        Wind[] winds = kernel.getWindList().getWinds();
        Wind wind = null;
        int altitude = vehicle.getAltitude();
        for( int i = 0; i < winds.length; i++ )
        {   if( ( winds[i].getLowerAltitude() <= altitude )
            && ( winds[i].getUpperAltitude() >= altitude ) )
            {   wind = winds[i];
                i = Integer.MAX_VALUE;
                break;
            }   // end if: found a matching wind for altitude
        }   // end for: through each wind
        
        // Start making a matrix that computes travel time
        timeMatrix = new double[ sites.length + 1 ][ sites.length + 1 ];
        penaltyMatrix = new double[ sites.length + 1 ][ sites.length + 1 ];
        
        for( int i = 0; i < sites.length; i++ )
        {   
            final Site site = sites[i];
            final int siteID = site.getID();
            final int siteArrayPos = mapSiteIDtoArrayIndex[ siteID ];
            
            // From depot
            timeMatrix[ DEPOT ][ siteArrayPos ] = 
                getTimeBetween( vehicle, null, site, wind );
            penaltyMatrix[ DEPOT ][ siteArrayPos ] = 
                getPenaltyBetween( vehicle, null, site );
            
            // To depot
            timeMatrix[ siteArrayPos ][ DEPOT ] = 
                getTimeBetween( vehicle, site, null, wind );
            penaltyMatrix[ siteArrayPos ][ DEPOT ] = 
                getPenaltyBetween( vehicle, site, null );
            
            // Now time to rest of sites
            for( int j = i; j < sites.length; j++ )
            {
                final Site otherSite = (Site)sites[j];
                final int otherSiteID = otherSite.getID();
                final int otherSiteArrayPos = 
                    mapSiteIDtoArrayIndex[ otherSiteID ];
                
                timeMatrix[ siteArrayPos ][ otherSiteArrayPos ] =
                    getTimeBetween( vehicle, site, otherSite, wind );
                penaltyMatrix[ siteArrayPos ][ otherSiteArrayPos ] =
                    getPenaltyBetween( vehicle, site, otherSite );
                    
                timeMatrix[ otherSiteArrayPos ][ siteArrayPos ] =
                    getTimeBetween( vehicle, otherSite, site, wind );
                penaltyMatrix[ otherSiteArrayPos ][ siteArrayPos ] =
                    getPenaltyBetween( vehicle, otherSite, site );
            }   // end for: through each site
        }   // end for: through each site
        
        
    }   // end setupCosts
    
    /**
     * Travel time between to sites.
     */
    private final double getTimeBetween( 
    Vehicle vehicle, Site fromSite, Site toSite, Wind wind )
    {
        final double fromLat = fromSite == null ? startLat : fromSite.getLatitude();
        final double fromLon = fromSite == null ? startLong : fromSite.getLongitude();
        final double toLat = toSite == null ? endLat : toSite.getLatitude();
        final double toLon = toSite == null ? endLong : toSite.getLongitude();
        
        final double windBearing = wind != null ? wind.getBearing() : 0;
        final double windSpeed = wind != null ? wind.getSpeed() : 0;
        
        return CoreUtilities.getTimeToTravel(
            fromLat, fromLon,
            toLat, toLon,
            windBearing, windSpeed, vehicle.getSpeed() );
        
//        final double diffLat = toLat - fromLat;
//        final double diffLon = toLon - fromLon;
//        final double distDeg = Math.sqrt( diffLat*diffLat + diffLon*diffLon );
//        //final double time = distDeg / vehicle.getSpeed();
//        return distDeg;//time;
    }   // end getTimeBetween
    
    /**
     * Penalty between to sites. Not used. This could be used to account
     * for threats and bad weather. Penalties should be in the same
     * "units" as time.
     */
    private final double getPenaltyBetween( 
    Vehicle parentVehicle, Site fromSite, Site toSite )
    {   // For now, penalties are not calculated, but they are
        // supported. All that's required is for this method
        // to return actual penalties on the same scale as the
        // getTimeBetween method.
        return 0;
    }   // end getPenaltyBetween
    
    
/* ********  H V E H I C L E   C O D E  ******** */
    
    /**
     * Returns whether or not the vehicle supports the given order.
     *
     * @return whether or not the vehicle supports the given order
     * @since 1.0
     */
    public final boolean supportsHOrderType( HOrder order )
    {
        boolean result = false;
        int orderType = ((UVRSite)order).getOrderType();
        int i = 0;
        while( i < supportedDemands.length && !result )
            if( orderType == 0 || // null requirement type yields 0 hash.
            supportedDemands[i] == orderType )
                result = true;
            else i++;
        return result;
    }   // end supportsHOrderType
    
    /**
     * Returns <code>Integer.MAX_VALUE</code>.
     *
     * @return <code>Integer.MAX_VALUE</code>
     * @since 1.0
     */
    public final int getCurrentAmountAvailableForOrderType( HOrder order )
    {   return Integer.MAX_VALUE;
    }   // end getCurrentAmountAvailableForOrderType
    
    
    /**
     * Does nothing since this problem does not deliver any goods.
     *
     * @since 1.0
     */
    public final void removeProductForOrderType( int amount, HOrder order )
    {   // Nothing to do since this is really a TSP
    }   // end removeProductForOrderType
    
    
    /**
     * Does nothing since this problem does not deliver any goods.
     *
     * @since 1.0
     */
    public final void addProductForOrderType( int amount, HOrder order )
    {   // Nothing to do since this is really a TSP
    }   // end addProductForOrderType
    
    
    
    /**
     * Does nothing since this problem does not deliver any goods.
     *
     * @since 1.0
     */
    public final void resetProductsForAllOrderTypes()
    {   // Nothing to do since this is really a TSP
    }   // end resetProductsForAllOrderTypes
    
    
    /**
     * Returns the first time when the vehicle can takeoff.
     *
     * @return the first time when the vehicle can takeoff
     * @since 1.0
     */
    public final double getEarliestDepartureTime()
    {   return earliestDepartureTime;
    }   // end getEarliestDepartureTime
    
    
    
    /**
     * Returns the time to travel between two sites (or depot and a site).
     *
     * @return time to travel
     * @since 1.0
     */
    public final double getTimeToTravel( HOrder from, HOrder to )
    {
        int fromArrayIndex = from == null ? 0 : mapSiteIDtoArrayIndex[
            ((UVRSite)from).getID() ];
        int toArrayIndex = to == null ? 0 : mapSiteIDtoArrayIndex[
            ((UVRSite)to).getID() ];
        return timeMatrix[ fromArrayIndex ][ toArrayIndex ];
    }   // end getTimeToTravel
    
    
    /**
     * Returns the service time.
     *
     * @return the service time
     * @since 1.0
     */
    public final double getTimeToService( HOrder from )
    {   return ((UVRSite)from).getServiceTime();
    }   // end getTimeToService
    
    
    
    /**
     * Returns the penalty to travel between two sites (or depot and a site).
     *
     * @return penalty to travel
     * @since 1.0
     */
    public final double getPenaltyForTravel( HOrder from, HOrder to )
    {
        int fromArrayIndex = from == null ? 0 : mapSiteIDtoArrayIndex[
            ((UVRSite)from).getID() ];
        int toArrayIndex = to == null ? 0 : mapSiteIDtoArrayIndex[
            ((UVRSite)to).getID() ];
        return penaltyMatrix[ fromArrayIndex ][ toArrayIndex ];
    }   // end getPenaltyForTravel
    
    
    /**
     * Returns the vehicle's range.
     *
     * @return penalty to travel
     * @since 1.0
     */
    public final double getRange()
    {   return range;
    }   // end getRange
    
    
    
    /**
     * Makes a copy of the vehicle.
     *
     * @return copy of the vehicle
     * @since 1.0
     */
    public Object clone()
    {   return new UVRVehicle( this );
    }   // end clone
    
    
    public String toString()
    {   return "name=" + parentVehicle.getName() + ", timeMatrix=" + timeMatrix;
    }   // end toString
    
}   // end class UVRVehicle