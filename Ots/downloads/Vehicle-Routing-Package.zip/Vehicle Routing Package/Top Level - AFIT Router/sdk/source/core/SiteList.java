/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.io.*;
import com.ibm.sort.SortBean;




/**
 * This maintains a list of sites and allows interested objects to listen
 * for changes by implementing the <code>Observer</code> interface.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Site
 * @see java.util.Observer
 */
public class SiteList 
extends Observable 
implements Observer, Serializable
{
    public final static int ASCENDING = 1, DESCENDING = 2;
    private Site[] sites;
    private transient SortBean sortBean = new SortBean();
    private String lastSortKey="";
    private boolean lastSortAscending=true;
    
    
    /**
     * Constructs an empty site list
     *
     * @since 1.0
     */
    public SiteList()
    {   super();
        sites = new Site[0];
    }   // end constructor
    
    
    /**
     * Adds the array of sites to the end of the site list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param moreSites array of sites to add to list
     * @see Site
     * @see java.util.Observer
     */
    public synchronized final void addSites( Site[] moreSites )
    {
        // Make a larger array to hold the two site arrays
        Site[] tempSites = new Site[ sites.length + moreSites.length ];
        
        // Copy to the two arrays into the larger array
        System.arraycopy( 
            sites,      // Source
            0,          // Start
            tempSites,  // Destination
            0,          // Start
            sites.length ); // Length
        System.arraycopy( 
            moreSites,      // Source
            0,              // Start
            tempSites,      // Destination
            sites.length,   // Start
            moreSites.length ); // Length
        
        // Register with new sites as a listener
        for( int i = 0; i < moreSites.length; i++ )
            moreSites[i].addObserver( this );
        
        // Save change
        this.sites = tempSites;
        
        // Notify observers of the change
        setChanged();
        notifyObservers( moreSites );
    }   // end addSites
    
    
    
    /**
     * Adds a single site to the end of the site list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param site site to add to list
     * @see Site
     * @see java.util.Observer
     */
    public synchronized final void addSite( Site site )
    {
        if( site != null )
        {
            // Make a larger array to hold the two site arrays
            Site[] tempSites = new Site[ sites.length + 1 ];
            
            // Copy to the two arrays into the larger array
            System.arraycopy( 
                sites,      // Source
                0,          // Start
                tempSites,  // Destination
                0,          // Start
                sites.length ); // Length
            
            tempSites[ sites.length ] = site;
            sites = tempSites;
            
            // Register with new site
            site.addObserver( this );
        
            // Notify observers of the change
            setChanged();
            notifyObservers( site );
        }   // end if: site was not null
    }   // end addSite
    
    
    /**
     * Removes a site at a particular index and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param index index of site to remove
     * @see Site
     * @see java.util.Observer
     */
    public synchronized final void removeSiteAt( int index )
    {
        if( index >= 0 && index < sites.length )
        {   Site[] temp = new Site[ sites.length-1 ];
            System.arraycopy( sites, 0, temp, 0, index );
            System.arraycopy( sites, index, temp, index, sites.length-index-1 );
            sites = temp;
            setChanged();
            notifyObservers();
        }   // end if: found site
    }   // end removeSiteAt
    
    
    
    /**
     * Removes a site by checking <code>site == sites[i]</code> for
     * each site in the list and notifies registered <code>Observer</code>s
     * of the change
     *
     * @param site site to remove
     * @see Site
     * @see java.util.Observer
     */
    public synchronized final void removeSite( Site site )
    {   int index = -1;
        for( int i = 0; i < sites.length; i++ )
            if( sites[i] == site )
            {   index = i;
                removeSiteAt( i );
                i = Integer.MAX_VALUE;
                break;
            }   // end if: found site
        //System.out.println( "Removing site" );
    }   // end removeSite
    
    
    /**
     * Removes sites at the specified indeces and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param site site to remove
     * @see Site
     * @see java.util.Observer
     */
    public synchronized final void removeSitesAt( int[] indeces )
    {   
        // Nullify sites to remove
        for( int i = 0; i < indeces.length; i++ )
            try{ sites[ indeces[i] ] = null;}
            catch(Exception e){}
        
        // Make new array
        Site[] temp = new Site[ sites.length - indeces.length ];
        int index = 0;
        for( int i = 0; i < sites.length; i++ )
            if( sites[i] != null )
                temp[index++] = sites[i];
        sites = temp;
        setChanged();
        notifyObservers();
    }   // end removeSitesAt
    
    
    
/* ********  S O R T I N G   C O D E  ******** */
    
    /**
     * Returns whether or not the last sort performed was ascending.
     * 
     * @return whether or not the last sort performed was ascending
     * @since 1.0
     */
    public final boolean lastSortWasAscending()
    {   return this.lastSortAscending;
    }   // end lastSortWasAscending
    
    
    /**
     * Returns whether or not the last sort performed was descending.
     * 
     * @return whether or not the last sort performed was descending
     * @since 1.0
     */
    public final boolean lastSortWasDescending()
    {   return ! this.lastSortAscending;
    }   // end lastSortWasDescending
    
    
    /**
     * Returns last key used to sort.
     * 
     * @return last key used to sort
     * @since 1.0
     */
    public final String lastSortKey()
    {   return this.lastSortKey;
    }   // end lastSortKey
    
    
    /**
     * Sort by name.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByName( boolean ascending )
    {   sortByMethod( "getName", ascending );
    }   // end sortByName
    
    
    /**
     * Sort by priority.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByPriority( boolean ascending )
    {   sortByMethod( "getPriority", ascending );
    }   // end sortByPriority
    
    
    /**
     * Sort by service time.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByServiceTime( boolean ascending )
    {   sortByMethod( "getServiceTime", ascending );
    }   // end sortByPriority
    
    
    /**
     * Sort by beginning of time window.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByEarliestArrivalTime( boolean ascending )
    {   sortByMethod( "getEarliestArrivalTime", ascending );
    }   // end sortByEarliestArrivalTime
    
    
    /**
     * Sort by ending of time window.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByLatestDepartureTime( boolean ascending )
    {   sortByMethod( "getLatestDepartureTime", ascending );
    }   // end sortByLatestDepartureTime
    
    
    /**
     * Sort by beginning of time wall.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByEarliestRestrictedTime( boolean ascending )
    {   sortByMethod( "getEarliestRestrictedTime", ascending );
    }   // end sortByEarliestRestrictedTime
    
    
    /**
     * Sort by ending of time wall.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByLatestRestrictedTime( boolean ascending )
    {   sortByMethod( "getLatestRestrictedTime", ascending );
    }   // end sortByLatestRestrictedTime
    
    
    /**
     * Sort by enabled.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByEnabled( boolean ascending )
    {   sortByMethod( "isEnabledAsNumber", ascending );
    }   // end sortByEnabled
    
    
    /**
     * Sort by requirement type.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByRequirementType( boolean ascending )
    {   sortByMethod( "getRequirementType", ascending );
    }   // end setByRequirement
    
    
    /**
     * Sort by latitude.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByLatitude( boolean ascending )
    {   sortByMethod( "getLatitude", ascending );
    }   // end sortByLatitude
    
    
    /**
     * Sort by longitude.
     * 
     * @param ascending whether or not sort should be in ascending order
     * @since 1.0
     */
    public final synchronized void sortByLongitude( boolean ascending )
    {   sortByMethod( "getLongitude", ascending );
    }   // end sortByLongitude
    
    /**
     * Used internally for sorting.
     */
    private final void sortByMethod( String method, boolean ascending )
    {   
        // Determine sort order
        sortBean.setAscending( ascending );

        Object[] sorted = null;
        try
        {   sorted = sortBean.sortObjectArray(
                sites, method );
        }   // end try
        catch( Exception e )
        {   Kernel.err( e );
        }   // end catch
        
        // Continue only if the sort worked
        if( sorted != null )
        {
            // Place to store sorted array
            Site[] sortedSites = new Site[ sorted.length ];
            for( int i = 0; i < sorted.length; i++ )
                sortedSites[i] = (Site) sorted[i];
            
            // Record stats
            this.lastSortAscending = sortBean.getAscending();
            this.lastSortKey = method;
            
            // Notify of changes
            sites = sortedSites;
            setChanged();
            notifyObservers();
        }   // end if: sort worked
    }   // end sortByMethod
    
/* ********  O B S E R V E R   C O D E  ******** */
    
    
    /**
     * Called when an <code>Observable</code> registers a change. The
     * list registers with sites. The list then notifies its own
     * registered <code>Observer</code>s of the change.
     *
     * @param thing thing that was updated
     * @param arg argument passed by thing
     * @since 1.0
     * @see java.util.Observable
     * @see java.util.Observer
     */
    public void update( Observable thing, Object arg )
    {   this.setChanged();
        this.notifyObservers( thing );
    }   // end update
    
/* ********  G E T   C O D E  ******** */    
    
    
    /**
     * Returns an array of the sites in the list.
     *
     * @return array of sites in the list
     * @since 1.0
     */
    public synchronized final Site[] getSites()
    {   return sites;
    }   // end getSites
    
    
    public synchronized String toString()
    {
        return "Number of sites: " + sites.length;
    }   // end toString

/* ********  S T A T S   C O D E  ******** */

    /**
     * Returns the number of enabled sites in list.
     *
     * @return the number of enabled sites in list
     * @since 1.0
     */
    public final synchronized int countEnabledSites()
    {   // Count the number of enabled sites
        int enabledCount = 0;
        for( int i = 0; i < sites.length; i++ )
            if( sites[i].isEnabled() )
                enabledCount++;
        return enabledCount;
    }   // end countEnabledSites


    /**
     * Returns earliest time window.
     *
     * @return earliest time window
     * @since 1.0
     */
    public final synchronized int getEarliestTimeWindow()
    {   int earliestTimeWindow = Integer.MAX_VALUE;
        for( int i = 0; i < sites.length; i++ )
            if( sites[i].getEarliestArrivalTime() < earliestTimeWindow )
                earliestTimeWindow = sites[i].getEarliestArrivalTime();
        return earliestTimeWindow;
    }   // end getEarliestTimeWindow
    

    /**
     * Returns latest time window.
     *
     * @return latest time window
     * @since 1.0
     */
    public final int getLatestTimeWindow()
    {   int latestTimeWindow = -Integer.MAX_VALUE;
        for( int i = 0; i < sites.length; i++ )
            if( sites[i].getLatestDepartureTime() > latestTimeWindow )
                latestTimeWindow = sites[i].getLatestDepartureTime();
        return latestTimeWindow;
    }   // end getLatestTimeWindow

/* ********  S E R I A L I Z A B L E   C O D E  ******** */
    
    
    /**
     * The standard "write" for an object.
     */
    private synchronized void writeObject( ObjectOutputStream out )
    throws IOException, ClassNotFoundException
    {   out.defaultWriteObject();
    }   // end writeObject
    
    
    /**
     * Reads in the list and then registers the list as an <code>Observer</code>
     * with each site.
     */
    private synchronized void readObject( ObjectInputStream in )
    throws IOException, ClassNotFoundException
    {   in.defaultReadObject();
        try
        {   for( int i = 0; i < sites.length; i++ )
                sites[i].addObserver( this );
        }   // end try
        catch( Exception e )
        {   sites = new Site[0];
        }   // end catch
        
        // Restore transients
        sortBean = new SortBean();
    }   // end readObject
    

/* ********  R E P L A C E   C O D E  ******** */


    /**
     * Replaces this list with <code>newList</code>. This is used
     * when loading a new <code>Kernel</code>. <code>Observer</code>s
     * registered with the original list will still be registered, but
     * anything registered with <code>newList</code> will not still
     * be registered.
     *
     * @param newList the new site list to use
     * @since 1.0
     */
    public final void replace( SiteList newList )
    {   this.sites = newList.getSites();
        // Register with new sites as a listener
        for( int i = 0; i < sites.length; i++ )
            sites[i].addObserver( this );
        this.setChanged();
        this.notifyObservers( sites );
    }   // end replace
    
}   // end class SiteList