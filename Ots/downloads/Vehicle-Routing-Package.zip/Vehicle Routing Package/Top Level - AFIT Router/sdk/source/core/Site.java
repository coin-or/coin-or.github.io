/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.io.*;


/**
 * A site is a location to visit. It may have a time window or time wall
 * associated with it. It may have a specific requirement for what kind of
 * vehicle needs to service it.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @since 1.0
 * @version 1.0
 * @see SiteList
 */
public class Site extends Observable implements Serializable
{
    // Unless preferences overrides these
    private static int defaultPriority = 3;
    private static int defaultServiceTime = 90;
    
    private static int nextAvailableId = 1;
    
    private String name = "Untitled";
    private int id = 0;
    private double latitude = 0;
    private double longitude = 0;
    private int earliestArrivalTime = Integer.MIN_VALUE; // All in
    private int latestDepartureTime = Integer.MAX_VALUE;  // minutes.
    private int earliestRestrictedTime = Integer.MIN_VALUE;
    private int latestRestrictedTime = Integer.MIN_VALUE;
    private int priority = defaultPriority;
    private boolean enabled = true;
    private String requirementType = "";
    private int serviceTime = defaultServiceTime;
    
    /**
     * Constructs a site with default values.
     *
     * @since 1.0
     */
    public Site()
    {   this.id = nextAvailableId++;
    }   // end constructor
    
    /**
     * Constructs a site with specified name, latitude, and longitude.
     * 
     * @param name site name
     * @param latitude site's latitude
     * @param longitude site's longitude
     * @since 1.0
     */
    public Site( String name, double latitude, double longitude )
    {   
        // Site construction code
        this.id = nextAvailableId++;
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
    }   // end constructor
    
    
    /**
     * Constructs a site with specified name, latitude, longitude, and priority.
     * 
     * @param name site name
     * @param latitude site's latitude
     * @param longitude site's longitude
     * @param priority site's priority
     * @since 1.0
     */
    public Site( String name, double latitude, 
    double longitude, int priority )
    {   
        // Site construction code
        this.id = nextAvailableId++;
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.priority = priority;
    }   // end constructor
    
    
    /**
     * Constructs a site identical to <var>copyThis</var>.
     * 
     * @param copyThis site to copy
     * @since 1.0
     */
    public Site( Site copyThis )
    {   
        // Site construction code
        this.id = copyThis.getID();
        this.name = copyThis.getName();
        this.latitude = copyThis.getLatitude();
        this.longitude = copyThis.getLongitude();
        this.setEnabled( copyThis.isEnabled() );
    }   // end constructor
    
    
/* ********  S T A T I C   M E T H O D S  ******** */
    
    /**
     * Set default service time for sites (a static variable).
     * 
     * @param time default service time (in minutes) for new sites
     * @since 1.0
     */
    public final static void setDefaultServiceTime( int time )
    {   defaultServiceTime = time;
    }   // end setDefaultServiceTime
    
    
    /**
     * Set default priority for sites (a static variable).
     * 
     * @param priority default priority for new sites
     * @since 1.0
     */
    public final static void setDefaultPriority( int priority )
    {   defaultPriority = priority;
    }   // end setDefaultPriority
    
    
/* ********  S E T   M E T H O D S  ******** */
    
    /**
     * Sets the name for the site.
     * 
     * @param name name of the site
     * @since 1.0
     */
    public void setName( String name )
    {   this.name = name;
        this.setChanged();
        this.notifyObservers();
    }   // end setName
    
    /**
     * Sets whether or not the site is enabled. A disabled site will not
     * be visited the next time a solution is found.
     *
     * @param state whether or not the site is enabled
     * @since 1.0
     */
    public void setEnabled( boolean state )
    {   this.enabled = state;
        this.setChanged();
        this.notifyObservers();
    }   // end setEnabled
    
    
    /**
     * Sets the latitude for the site.
     *
     * @param latitude the latitude for the site
     * @since 1.0
     */
    public void setLatitude( double latitude )
    {   this.latitude = latitude;
        this.setChanged();
        this.notifyObservers();
    }   // end setLatitude
    
    
    /**
     * Sets the longitude for the site.
     *
     * @param longitude the longitude for the site
     * @since 1.0
     */
    public void setLongitude( double longitude )
    {   this.longitude = longitude;
        this.setChanged();
        this.notifyObservers();
    }   // end setLongitude
    
    
    /**
     * Sets the beginning of the time window for the site.
     *
     * @param time the beginning of the time window for the site
     * @since 1.0
     */
    public final void setEarliestArrivalTime( int time )
    {   this.earliestArrivalTime = time;
        this.setChanged();
        this.notifyObservers();
    }   // end setEarliestArrivalTime
    
    
    /**
     * Sets the ending of the time window for the site.
     *
     * @param time the ending of the time window for the site
     * @since 1.0
     */
    public final void setLatestDepartureTime( int time )
    {   this.latestDepartureTime = time;
        this.setChanged();
        this.notifyObservers();
    }   // end setLatestDepartureTime
    
    
    /**
     * Sets the beginning of the time wall for the site.
     *
     * @param time the beginning of the wall window for the site
     * @since 1.0
     */
    public final void setEarliestRestrictedTime( int time )
    {   this.earliestRestrictedTime = time;
        this.setChanged();
        this.notifyObservers();
    }   // end setEarliestRestrictedTime
    
    
    /**
     * Sets the ending of the time wall for the site.
     *
     * @param time the ending of the wall window for the site
     * @since 1.0
     */
    public final void setLatestRestrictedTime( int time )
    {   this.latestRestrictedTime = time;
        this.setChanged();
        this.notifyObservers();
    }   // end setLatestRestrictedTime
    
    
    /**
     * Sets the priority for the site.
     *
     * @param priority the priority for the site
     * @since 1.0
     */
    public final void setPriority( int priority )
    {   this.priority = priority;
        this.setChanged();
        this.notifyObservers();
    }   // end setPriority
    
    
    /**
     * Sets the requirement type for the site.
     *
     * @param type the requirement type for the site
     * @since 1.0
     */
    public final void setRequirementType( String type )
    {   this.requirementType = type;
        this.setChanged();
        this.notifyObservers();
    }   // end setRequirementType
    
    
    /**
     * Sets the service time (in minutes) for the site.
     *
     * @param minutes the service time (in minutes) for the site
     * @since 1.0
     */
    public final void setServiceTime( int minutes )
    {   this.serviceTime = minutes;
        this.setChanged();
        this.notifyObservers();
    }   // end setServiceMinutes
    
    
/* ********  G E T   M E T H O D S  ******** */
    
    
    /**
     * Returns the service time (in minutes) for the site.
     *
     * @return the service time (in minutes) for the site
     * @since 1.0
     */
    public final int getServiceTime()
    {   return serviceTime;
    }   // end getServiceTime
    
    
    /**
     * Returns whether or not the site is enabled.
     *
     * @return whether or not the site is enabled
     * @since 1.0
     */
    public final boolean isEnabled()
    {   return enabled;
    }   // end isEnabled
    
    /**
     * Returns whether or not the site is enabled, 1 for true, 2 for false.
     * This is used in a sorting algorithm elsewhere.
     *
     * @return whether or not the site is enabled
     * @since 1.0
     */
    public final int isEnabledAsNumber()
    {   return enabled ? 1 : 2;
    }   // end isEnabledAsNumber
    
    
    /**
     * Returns the id of the site.
     *
     * @return id of the site
     * @since 1.0
     */
    public final int getID()
    {   return id;
    }   // end getID
    
    
    /**
     * Returns the name of the site.
     *
     * @return name of the site
     * @since 1.0
     */
    public String getName()
    {   return name;
    }   // end getName
    
    
    /**
     * Returns the latitude of the site.
     *
     * @return latitude of the site
     * @since 1.0
     */
    public double getLatitude()
    {   return latitude;
    }   // end getLatitude
    
    
    /**
     * Returns the longitude of the site.
     *
     * @return longitude of the site
     * @since 1.0
     */
    public double getLongitude()
    {   return longitude;
    }   // end getLongitude
    
    
    
    /**
     * Returns the beginning of time window for the site.
     *
     * @return the beginning of time window for the site
     * @since 1.0
     */
    public final int getEarliestArrivalTime()
    {   return earliestArrivalTime;
    }   // end getEarliestArrivalTime
    
    
    /**
     * Returns the ending of time window for the site.
     *
     * @return the ending of time window for the site
     * @since 1.0
     */
    public final int getLatestDepartureTime()
    {   return latestDepartureTime;
    }   // end getLatestDepartureTime
    
    
    /**
     * Returns the beginning of time wall for the site.
     *
     * @return the beginning of time wall for the site
     * @since 1.0
     */
    public final int getEarliestRestrictedTime()
    {   return earliestRestrictedTime;
    }   // end getEarliestRestrictedTime
    
    
    /**
     * Returns the ending of time wall for the site.
     *
     * @return the ending of time wall for the site
     * @since 1.0
     */
    public final int getLatestRestrictedTime()
    {   return latestRestrictedTime;
    }   // end getLatestRestrictedTime
    
    
    /**
     * Returns the priority of the site.
     *
     * @return the priority of the site
     * @since 1.0
     */
    public final int getPriority()
    {   return priority;
    }   // end getPriority
    
    
    /**
     * Returns the requirement type of the site.
     *
     * @return the requirement type of the site
     * @since 1.0
     */
    public final String getRequirementType()
    {   return requirementType;
    }   // end getRequirementType
    
    public String toString()
    {
        String s = name + " " + latitude + " by " + longitude + " Priority: " + priority;
        return s;
    }   // end toString
    
    
}   // end class Site