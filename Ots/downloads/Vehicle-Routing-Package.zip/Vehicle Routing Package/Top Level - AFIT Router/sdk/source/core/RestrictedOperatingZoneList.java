/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.io.*;


/**
 * This maintains a list of rozs and allows interested objects to listen
 * for changes by implementing the <code>Observer</code> interface.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see RestrictedOperatingZone
 * @see java.util.Observer
 */
public class RestrictedOperatingZoneList extends Observable 
implements Observer, Serializable
{
    RestrictedOperatingZone[] rozs;
    
    /**
     * Constructs an empty roz list
     *
     * @since 1.0
     */
    public RestrictedOperatingZoneList()
    {   super();
        rozs = new RestrictedOperatingZone[0];
    }   // end constructor
    
    
    /**
     * Adds the array of rozs to the end of the roz list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param moreRestrictedOperatingZones array of rozs to add to list
     * @see RestrictedOperatingZone
     * @see java.util.Observer
     */
    public synchronized final void addROZs( RestrictedOperatingZone[] moreRestrictedOperatingZones )
    {
        // Make a larger array to hold the two roz arrays
        RestrictedOperatingZone[] tempRestrictedOperatingZones = new RestrictedOperatingZone[ rozs.length + moreRestrictedOperatingZones.length ];
        
        // Copy to the two arrays into the larger array
        System.arraycopy( 
            rozs,      // Source
            0,          // Start
            tempRestrictedOperatingZones,  // Destination
            0,          // Start
            rozs.length ); // Length
        System.arraycopy( 
            moreRestrictedOperatingZones,      // Source
            0,              // Start
            tempRestrictedOperatingZones,      // Destination
            rozs.length,   // Start
            moreRestrictedOperatingZones.length ); // Length
        
        // Save change
        this.rozs = tempRestrictedOperatingZones;
        
        // Record as observers
        for( int i = 0; i < moreRestrictedOperatingZones.length; i++ )
            moreRestrictedOperatingZones[i].addObserver( this );
        
        // Notify observers of the change
        setChanged();
        notifyObservers( moreRestrictedOperatingZones );
    }   // end addRestrictedOperatingZones
    
    
    
    /**
     * Adds a single roz to the end of the roz list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param roz roz to add to list
     * @see RestrictedOperatingZone
     * @see java.util.Observer
     */
    public synchronized final void addROZ( RestrictedOperatingZone roz )
    {
        if( roz != null )
        {
            // Make a larger array to hold the two roz arrays
            RestrictedOperatingZone[] tempRestrictedOperatingZones = new RestrictedOperatingZone[ rozs.length + 1 ];
            
            // Copy to the two arrays into the larger array
            System.arraycopy( 
                rozs,      // Source
                0,          // Start
                tempRestrictedOperatingZones,  // Destination
                0,          // Start
                rozs.length ); // Length
            
            tempRestrictedOperatingZones[ rozs.length ] = roz;
            rozs = tempRestrictedOperatingZones;
        
            // Register with roz as observer
            roz.addObserver( this );
        
            // Notify observers of the change
            setChanged();
            notifyObservers( roz );
        }   // end if: roz was not null
    }   // end addRestrictedOperatingZone
    
    
    /**
     * Removes a roz at a particular index and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param index index of roz to remove
     * @see RestrictedOperatingZone
     * @see java.util.Observer
     */
    public synchronized final void removeRestrictedOperatingZoneAt( int index )
    {
        if( index >= 0 && index < rozs.length )
        {   RestrictedOperatingZone[] temp = new RestrictedOperatingZone[ rozs.length-1 ];
            System.arraycopy( rozs, 0, temp, 0, index );
            System.arraycopy( rozs, index, temp, index, rozs.length-index-1 );
            rozs = temp;
            setChanged();
            notifyObservers();
        }   // end if: found roz
    }   // end removeRestrictedOperatingZoneAt
    
    
    /**
     * Removes a roz by checking <code>roz == rozs[i]</code> for
     * each roz in the list and notifies registered <code>Observer</code>s
     * of the change
     *
     * @param roz roz to remove
     * @see RestrictedOperatingZone
     * @see java.util.Observer
     */
    public synchronized final void removeRestrictedOperatingZone( RestrictedOperatingZone roz )
    {   int index = -1;
        for( int i = 0; i < rozs.length; i++ )
            if( rozs[i] == roz )
            {   index = i;
                removeRestrictedOperatingZoneAt( i );
                i = Integer.MAX_VALUE;
                break;
            }   // end if: found roz
        
    }   // end removeRestrictedOperatingZone
    
    
    /**
     * Removes rozs at the specified indeces and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param roz roz to remove
     * @see RestrictedOperatingZone
     * @see java.util.Observer
     */
    public synchronized final void removeRestrictedOperatingZonesAt( int[] indeces )
    {   
        // Nullify rozs to remove
        for( int i = 0; i < indeces.length; i++ )
            rozs[ indeces[i] ] = null;
        
        // Make new array
        RestrictedOperatingZone[] temp = new RestrictedOperatingZone[ rozs.length - indeces.length ];
        int index = 0;
        for( int i = 0; i < rozs.length; i++ )
            if( rozs[i] != null )
                temp[index++] = rozs[i];
        rozs = temp;
        setChanged();
        notifyObservers();
    }   // end removeRestrictedOperatingZonesAt
    
    
    
    private final void setThisAsObserverForAllRestrictedOperatingZones()
    {   for( int i = 0; i < rozs.length; i++ )
            rozs[i].addObserver( this );
    }   // end setThisAsObserverForAllRestrictedOperatingZones
    
    
    
    /**
     * Returns an array of the rozs in the list.
     *
     * @return array of rozs in the list
     * @since 1.0
     */
    public synchronized final RestrictedOperatingZone[] getROZs()
    {   return rozs;
    }   // end getRestrictedOperatingZones
    
    public synchronized String toString()
    {
        return "Number of rozs: " + rozs.length;
    }   // end toString
    
    
/* ********  O B S E R V E R   C O D E  ******** */
    
    
    /**
     * Called when an <code>Observable</code> registers a change. The
     * list registers with rozs. The list then notifies its own
     * registered <code>Observer</code>s of the change.
     *
     * @param thing thing that was updated
     * @param arg argument passed by thing
     * @since 1.0
     * @see java.util.Observable
     * @see java.util.Observer
     */
    public final void update( Observable thing, Object arg )
    {
        setChanged();
        notifyObservers( thing );
    }   // end update

    
/* ********  S E R I A L I Z A B L E   C O D E  ******** */
    
    
    /**
     * The standard "write" for an object.
     */
    private synchronized void writeObject( ObjectOutputStream out )
    throws IOException, ClassNotFoundException
    {   out.defaultWriteObject();
    }   // end writeObject
    
    
    /**
     * Reads in the list and then registers the list as an <code>Observer</code>
     * with each roz.
     */
    private synchronized void readObject( ObjectInputStream in )
    throws IOException, ClassNotFoundException
    {   in.defaultReadObject();
        try
        {   for( int i = 0; i < rozs.length; i++ )
                rozs[i].addObserver( this );
        }   // end try
        catch( Exception e )
        {   rozs = new RestrictedOperatingZone[0];
        }   // end catch
    }   // end readObject
    
    

/* ********  R E P L A C E   C O D E  ******** */


    /**
     * Replaces this list with <code>newList</code>. This is used
     * when loading a new <code>Kernel</code>. <code>Observer</code>s
     * registered with the original list will still be registered, but
     * anything registered with <code>newList</code> will not still
     * be registered.
     *
     * @param newList the new roz list to use
     * @since 1.0
     */
    public final void replace( RestrictedOperatingZoneList newList )
    {   this.rozs = newList.getROZs();
        // Register with new rozs as a listener
        for( int i = 0; i < rozs.length; i++ )
            rozs[i].addObserver( this );
        this.setChanged();
        this.notifyObservers( rozs );
    }   // end replace
    
    
    
    
}   // end class RestrictedOperatingZoneList