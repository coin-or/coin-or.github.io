/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

/**
 * This class only serves to display a message if a user mistakenly double-clicks
 * on the packaged jar file or tries to run the jar file with <code>java -jar</code>.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @since 1.0.1
 */
public class Main
{   
    private final static String[] credits =
        { "AFIT Router",
          "Version 1.0.1",
          "Robert Harder",
          "rharder@usa.net",
          "",
          "Use this jar file to add",
          "airframe routing to your projects.",
          "See the API Guide for details."
        };
          
    
    public static void main( String[] args )
    {   
        System.out.println("");
        for( int i = 0; i < credits.length; i++ )
            System.out.println( credits[i] );
        System.out.println("");
        
        try
        {   java.awt.Frame f = new java.awt.Frame( credits[0] );
            f.setLayout( new java.awt.GridLayout(credits.length,1) );
            for( int i = 0; i < credits.length; i++ )
                f.add( new java.awt.Label( credits[i], java.awt.Label.CENTER ) );
            f.pack();
            java.awt.Toolkit t = f.getToolkit();
            f.setLocation( (t.getScreenSize().width-f.getSize().width)/2, (t.getScreenSize().height-f.getSize().height)/2 );
            f.addWindowListener( new java.awt.event.WindowAdapter()
            {   public void windowClosing( java.awt.event.WindowEvent e )
                {   System.exit(0);
                }   // end windowClosed
            }); // end WindowAdapter
            f.show();
        }   // end try
        catch( Exception e ){}
    }   // end main
}   // end class Main