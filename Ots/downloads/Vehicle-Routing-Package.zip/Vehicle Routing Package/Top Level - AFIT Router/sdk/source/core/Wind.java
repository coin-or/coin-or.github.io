/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.io.*;

/**
 * A simple wind model that stores speed, direction, and lower and upper
 * altitudes. Vehicle altitudes are matched up with wind altitudes when calculating
 * travel times.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Vehicle
 * @see WindList
 */
public class Wind 
extends Observable
implements Serializable
{
    private int speed=0;
    private int bearing=0;
    private int lowerAltitude=0;
    private int upperAltitude=Integer.MAX_VALUE;
    
    /**
     * Constructs a wind with default values.
     *
     * @since 1.0
     */
    public Wind()
    {   super();
    }   // end constructor
    
    /**
     * Constructs a wind with the specified speed.
     *
     * @param speed wind speed (in knots)
     * @since 1.0
     */
    public Wind( int speed )
    {   super();
        this.setSpeed( speed );
    }   // end constructor
    
    
    /**
     * Constructs a wind with the specified speed and bearing.
     *
     * @param speed wind speed (in knots)
     * @param bearin wind bearing (in degrees clockwise from north)
     * @since 1.0
     */
    public Wind( int speed, int bearing )
    {   super();
        this.setSpeed( speed );
        this.setBearing( bearing );
    }   // end constructor
    
    
/* ********  G E T   C O D E  ******** */
    
    /**
     * Returns the wind's speed.
     *
     * @return the wind's speed (in knots)
     * @since 1.0
     */
    public final int getSpeed()
    {   return speed;
    }   // end getSpeed
    
    
    /**
     * Returns the wind's bearing.
     *
     * @return the wind's bearing (in degrees clockwise from north)
     * @since 1.0
     */
    public final int getBearing()
    {   return bearing;
    }   // end getBearing
    
    
    /**
     * Returns the wind's upper Altitude.
     *
     * @return the wind's upper Altitude (in feet)
     * @since 1.0
     */
    public final int getUpperAltitude()
    {   return upperAltitude;
    }   // end getUpperAltitude
    
    
    /**
     * Returns the wind's lower Altitude.
     *
     * @return the wind's lower Altitude (in feet)
     * @since 1.0
     */
    public final int getLowerAltitude()
    {   return lowerAltitude;
    }   // end getLowerAltitude
    
/* ********  S E T   C O D E  ******** */
    
    
    /**
     * Sets the wind's speed.
     *
     * @param speed the wind's speed (in knots)
     * @since 1.0
     */
    public final void setSpeed( int speed )
    {   this.speed = speed >= 0 ? speed : this.speed;
        this.setChanged();
        this.notifyObservers();
    }   // end setSpeed
    
    /**
     * Sets the wind's bearing.
     *
     * @param bearing the wind's bearing (in degrees clockwise from north)
     * @since 1.0
     */
    public final void setBearing( int bearing )
    {   this.bearing = bearing >= 0 ? bearing % 360 : (360-bearing)%360;
        this.setChanged();
        this.notifyObservers();
    }   // end setBearing
    
    
    /**
     * Sets the wind's lower altitude.
     *
     * @param lower the wind's lower altitude (in feet)
     * @since 1.0
     */
    public final void setLowerAltitude( int lower )
    {   this.lowerAltitude = lower;
        this.setChanged();
        this.notifyObservers();
    }   // end setLowerAltitude
    
    
    /**
     * Sets the wind's upper altitude.
     *
     * @param upper the wind's upper altitude (in feet)
     * @since 1.0
     */
    public final void setUpperAltitude( int upper )
    {   this.upperAltitude = upper;
        this.setChanged();
        this.notifyObservers();
    }   // end setUpperAltitude

    
}   // end class Wind