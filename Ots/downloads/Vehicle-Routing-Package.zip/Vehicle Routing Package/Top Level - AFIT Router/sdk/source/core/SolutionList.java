/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;




/**
 * This maintains a list of solutions and allows interested objects to listen
 * for changes by implementing the <code>Observer</code> interface.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Solution
 * @see java.util.Observer
 */
public class SolutionList 
extends Observable
{
    private transient Solution[] solutions = new Solution[0];
    private transient Solution shortestSolution;
    
    
    /**
     * Constructs an empty solution list
     *
     * @since 1.0
     */
    public SolutionList()
    {   super();
        solutions = new Solution[0];
    }   // end constructor
    
    
    /**
     * Adds the array of solutions to the end of the solution list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param moresolutions array of solutions to add to list
     * @see Solution
     * @see java.util.Observer
     */
    public synchronized final void addSolutions( Solution[] moreSolutions )
    {
        // Make a larger array to hold the two solution arrays
        Solution[] tempSolutions = new Solution[ solutions.length + moreSolutions.length ];
        
        // Copy to the two arrays into the larger array
        System.arraycopy( 
            solutions,      // Source
            0,          // Start
            tempSolutions,  // Destination
            0,          // Start
            solutions.length ); // Length
        System.arraycopy( 
            moreSolutions,      // Source
            0,              // Start
            tempSolutions,      // Destination
            solutions.length,   // Start
            moreSolutions.length ); // Length
        
        // Save change
        this.solutions = tempSolutions;
        
        // Notify observers of the change
        this.setChanged();
        this.notifyObservers( moreSolutions );

    }   // end addSolutions
    
    
    /**
     * Adds a single solution to the end of the solution list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param solution solution to add to list
     * @see Solution
     * @see java.util.Observer
     */
    public synchronized final void addSolution( Solution solution )
    {
        if( solution != null )
        {
            // Make a larger array to hold the two solution arrays
            Solution[] tempSolutions = new Solution[ solutions.length + 1 ];
            
            // Copy to the two arrays into the larger array
            System.arraycopy( 
                solutions,      // Source
                0,          // Start
                tempSolutions,  // Destination
                0,          // Start
                solutions.length ); // Length
            
            tempSolutions[ solutions.length ] = solution;
            solutions = tempSolutions;

            // Notify observers of the change
            this.setChanged();
            this.notifyObservers( solution );
        }   // end if: solution was not null
    }   // end addSolution
    
    
    
    
    /**
     * Removes a solution at a particular index and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param index index of solution to remove
     * @see Solution
     * @see java.util.Observer
     */
    public synchronized final void removeSolutionAt( int index )
    {
        if( index >= 0 && index < solutions.length )
        {   Solution[] temp = new Solution[ solutions.length-1 ];
            System.arraycopy( solutions, 0, temp, 0, index );
            System.arraycopy( solutions, index, temp, index, solutions.length-index-1 );
            solutions = temp;
            setChanged();
            notifyObservers();
        }   // end if: found solution
    }   // end removeSolutionAt
    
    
    
    /**
     * Removes a solution by checking <code>solution == solutions[i]</code> for
     * each solution in the list and notifies registered <code>Observer</code>s
     * of the change
     *
     * @param solution solution to remove
     * @see Solution
     * @see java.util.Observer
     */
    public synchronized final void removeSolution( Solution solution )
    {   int index = -1;
        for( int i = 0; i < solutions.length; i++ )
            if( solutions[i] == solution )
            {   index = i;
                removeSolutionAt( i );
                i = Integer.MAX_VALUE;
                break;
            }   // end if: found solution
        
    }   // end removeSolution
    
    
    /**
     * Removes solutions at the specified indeces and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param solution solution to remove
     * @see Solution
     * @see java.util.Observer
     */
    public synchronized final void removeSolutionsAt( int[] indeces )
    {   
        // Nullify solutions to remove
        for( int i = 0; i < indeces.length; i++ )
            solutions[ indeces[i] ] = null;
        
        // Make new array
        Solution[] temp = new Solution[ solutions.length - indeces.length ];
        int index = 0;
        for( int i = 0; i < solutions.length; i++ )
            if( solutions[i] != null )
                temp[index++] = solutions[i];
        solutions = temp;
        setChanged();
        notifyObservers();
    }   // end removeSolutionsAt
    
    
    
    /**
     * Returns an array of the solutions in the list.
     *
     * @return array of solutions in the list
     * @since 1.0
     */
    public synchronized final Solution[] getSolutions()
    {   return solutions;
    }   // end getSolutions


    
    /**
     * Empties list.
     *
     * @since 1.0
     */
    public final synchronized void clear()
    {   
        solutions = new Solution[0];
        this.setChanged();
        this.notifyObservers();
    }   // end clear
    
    public synchronized String toString()
    {
        return "Number of solutions: " + solutions.length;
    }   // end toString
    
}   // end class SolutionList