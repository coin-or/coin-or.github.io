/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.io.*;


/**
 * This maintains a list of bases and allows interested objects to listen
 * for changes by implementing the <code>Observer</code> interface.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Base
 * @see java.util.Observer
 */
public class BaseList 
extends Observable 
implements Observer, Serializable
{
    private Base[] bases;
    
    /**
     * Constructs an empty base list
     *
     * @since 1.0
     */
    public BaseList()
    {   super();
        bases = new Base[0];
    }   // end constructor
    
    /**
     * Adds the array of bases to the end of the base list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param moreBases array of bases to add to list
     * @see Base
     * @see java.util.Observer
     */
    public synchronized final void addBases( Base[] moreBases )
    {
        // Make a larger array to hold the two base arrays
        Base[] tempBases = new Base[ bases.length + moreBases.length ];
        
        // Copy to the two arrays into the larger array
        System.arraycopy( 
            bases,      // Source
            0,          // Start
            tempBases,  // Destination
            0,          // Start
            bases.length ); // Length
        System.arraycopy( 
            moreBases,      // Source
            0,              // Start
            tempBases,      // Destination
            bases.length,   // Start
            moreBases.length ); // Length
        
        // Save change
        this.bases = tempBases;
        
        // Record as observer
        for( int i = 0; i < moreBases.length; i++ )
            moreBases[i].addObserver( this );
        
        // Notify observers of the change
        setChanged();
        notifyObservers( moreBases );
    }   // end addBases
    
    
    /**
     * Adds a single base to the end of the base list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param base base to add to list
     * @see Base
     * @see java.util.Observer
     */
    public synchronized final void addBase( Base base )
    {
        if( base != null )
        {
            // Make a larger array to hold the two base arrays
            Base[] tempBases = new Base[ bases.length + 1 ];
            
            // Copy to the two arrays into the larger array
            System.arraycopy( 
                bases,      // Source
                0,          // Start
                tempBases,  // Destination
                0,          // Start
                bases.length ); // Length
            
            tempBases[ bases.length ] = base;
            bases = tempBases;
        
            // Register with base as observer
            base.addObserver( this );
        
            // Notify observers of the change
            setChanged();
            notifyObservers( base );
        }   // end if: base was not null
    }   // end addBase
    
    
    /**
     * Removes a base at a particular index and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param index index of base to remove
     * @see Base
     * @see java.util.Observer
     */
    public synchronized final void removeBaseAt( int index )
    {
        if( index >= 0 && index < bases.length )
        {   Base[] temp = new Base[ bases.length-1 ];
            System.arraycopy( bases, 0, temp, 0, index );
            System.arraycopy( bases, index, temp, index, bases.length-index-1 );
            bases = temp;
            setChanged();
            notifyObservers();
        }   // end if: found base
    }   // end removeBaseAt
    
    
    /**
     * Removes a base by checking <code>base == bases[i]</code> for
     * each base in the list and notifies registered <code>Observer</code>s
     * of the change
     *
     * @param base base to remove
     * @see Base
     * @see java.util.Observer
     */
    public synchronized final void removeBase( Base base )
    {   int index = -1;
        for( int i = 0; i < bases.length; i++ )
            if( bases[i] == base )
            {   index = i;
                removeBaseAt( i );
                i = Integer.MAX_VALUE;
                break;
            }   // end if: found base
        
    }   // end removeBase
    
    /**
     * Removes bases at the specified indeces and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param base base to remove
     * @see Base
     * @see java.util.Observer
     */
    public synchronized final void removeBasesAt( int[] indeces )
    {   
        // Nullify bases to remove
        for( int i = 0; i < indeces.length; i++ )
            bases[ indeces[i] ] = null;
        
        // Make new array
        Base[] temp = new Base[ bases.length - indeces.length ];
        int index = 0;
        for( int i = 0; i < bases.length; i++ )
            if( bases[i] != null )
                temp[index++] = bases[i];
        bases = temp;
        setChanged();
        notifyObservers();
    }   // end removeBasesAt
    
    /**
     * Returns an array of the bases in the list.
     *
     * @return array of bases in the list
     * @since 1.0
     */
    public synchronized final Base[] getBases()
    {   return bases;
    }   // end getBases
    
    /**
     * Returns <code>"Number of bases: " + bases.length;</code>
     *
     * @return a string representation
     * @since 1.0
     */
    public synchronized String toString()
    {
        return "Number of bases: " + bases.length;
    }   // end toString
    
    
/* ********  O B S E R V E R   C O D E  ******** */
    
    /**
     * Called when an <code>Observable</code> registers a change. The
     * list registers with bases. The list then notifies its own
     * registered <code>Observer</code>s of the change.
     *
     * @param thing thing that was updated
     * @param arg argument passed by thing
     * @since 1.0
     * @see java.util.Observable
     * @see java.util.Observer
     */
    public final void update( Observable thing, Object arg )
    {   this.setChanged();
        this.notifyObservers( thing );
    }   // end update
    
    
/* ********  S E R I A L I Z A B L E   C O D E  ******** */

    
    /**
     * The standard "write" for an object.
     */
    private synchronized void writeObject( ObjectOutputStream out )
    throws IOException, ClassNotFoundException
    {   out.defaultWriteObject();
    }   // end writeObject
    
    /**
     * Reads in the list and then registers the list as an <code>Observer</code>
     * with each base.
     */
    private synchronized void readObject( ObjectInputStream in )
    throws IOException, ClassNotFoundException
    {   in.defaultReadObject();
        try
        {   for( int i = 0; i < bases.length; i++ )
                bases[i].addObserver( this );
        }   // end try
        catch( Exception e )
        {   bases = new Base[0];
        }   // end catch
    }   // end readObject
    

/* ********  R E P L A C E   C O D E  ******** */

    /**
     * Replaces this list with <code>newList</code>. This is used
     * when loading a new <code>Kernel</code>. <code>Observer</code>s
     * registered with the original list will still be registered, but
     * anything registered with <code>newList</code> will not still
     * be registered.
     *
     * @param newList the new base list to use
     * @since 1.0
     */
    public final void replace( BaseList newList )
    {   this.bases = newList.getBases();
        // Register with new bases as a listener
        for( int i = 0; i < bases.length; i++ )
            bases[i].addObserver( this );
        this.setChanged();
        this.notifyObservers( bases );
    }   // end replace
    
    
    
}   // end class BaseList