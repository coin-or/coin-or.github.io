/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.io.*;

/**
 * This maintains a list of priority models and allows interested objects to listen
 * for changes by implementing the <code>Observer</code> interface.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see PriorityModel
 * @see java.util.Observer
 */
public class PriorityModelList 
extends Observable 
implements Observer, Serializable
{
    PriorityModel[] priorityModels = new PriorityModel[0];
    
    
    /**
     * Constructs an empty priority model list
     *
     * @since 1.0
     */
    public PriorityModelList()
    {   super();
    }   // end constructor
    
    /**
     * Makes the standard models which includes three models:<BR>
     * <LI>Infinite relative worths (not editable)</LI>
     * <LI>Relative worths of 5 to 1 (not editable)</LI>
     * <LI>Customizable relative worths with a default of 10</LI>
     *
     * @param kernel kernel being used
     * @since 1.0
     */
    public final synchronized void makeStandardModels( Kernel kernel )
    {   // Setup default priority models
        priorityModels = new PriorityModel[3];
        priorityModels[0] = new PriorityModel( "Absolute Priorities",
            kernel, Integer.MAX_VALUE, false );
        priorityModels[1] = new PriorityModel( "Flex Priorities",
            kernel, 5, false );
        priorityModels[2] = new PriorityModel( "Custom Priorities",
            kernel, 10, true );
        for( int i = 0; i < priorityModels.length; i++ )
            priorityModels[i].addObserver( this );
    }   // end makeStandardModels
    
    
    /**
     * Adds the array of models to the end of the list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param morePriorityModels array of models to add to list
     * @see PriorityModel
     * @see java.util.Observer
     */
    public synchronized final void addPriorityModels( PriorityModel[] morePriorityModels )
    {
        // Make a larger array to hold the two priorityModel arrays
        PriorityModel[] tempPriorityModels = new PriorityModel[ priorityModels.length + morePriorityModels.length ];
        
        // Copy to the two arrays into the larger array
        System.arraycopy( 
            priorityModels,      // Source
            0,          // Start
            tempPriorityModels,  // Destination
            0,          // Start
            priorityModels.length ); // Length
        System.arraycopy( 
            morePriorityModels,      // Source
            0,              // Start
            tempPriorityModels,      // Destination
            priorityModels.length,   // Start
            morePriorityModels.length ); // Length
        
        // Save change
        this.priorityModels = tempPriorityModels;
        
        // Record as observer
        for( int i = 0; i < morePriorityModels.length; i++ )
            morePriorityModels[i].addObserver( this );
        
        // Notify observers of the change
        setChanged();
        notifyObservers( morePriorityModels );
    }   // end addPriorityModels
    
    
    /**
     * Adds a single priorityModel to the end of the priorityModel list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param priorityModel priorityModel to add to list
     * @see PriorityModel
     * @see java.util.Observer
     */
    public synchronized final void addPriorityModel( PriorityModel priorityModel )
    {
        if( priorityModel != null )
        {
            // Make a larger array to hold the two priorityModel arrays
            PriorityModel[] tempPriorityModels = new PriorityModel[ priorityModels.length + 1 ];
            
            // Copy to the two arrays into the larger array
            System.arraycopy( 
                priorityModels,      // Source
                0,          // Start
                tempPriorityModels,  // Destination
                0,          // Start
                priorityModels.length ); // Length
            
            tempPriorityModels[ priorityModels.length ] = priorityModel;
            priorityModels = tempPriorityModels;
        
            // Register with priorityModel as observer
            priorityModel.addObserver( this );
        
            // Notify observers of the change
            setChanged();
            notifyObservers( priorityModel );
        }   // end if: priorityModel was not null
    }   // end addPriorityModel
    
    
    /**
     * Removes a priorityModel at a particular index and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param index index of priorityModel to remove
     * @see PriorityModel
     * @see java.util.Observer
     */
    public synchronized final void removePriorityModelAt( int index )
    {
        if( index >= 0 && index < priorityModels.length )
        {   PriorityModel[] temp = new PriorityModel[ priorityModels.length-1 ];
            System.arraycopy( priorityModels, 0, temp, 0, index );
            System.arraycopy( priorityModels, index, temp, index, priorityModels.length-index-1 );
            priorityModels = temp;
            setChanged();
            notifyObservers();
        }   // end if: found priorityModel
    }   // end removePriorityModelAt
    
    
    
    /**
     * Removes a priorityModel by checking <code>priorityModel == priorityModels[i]</code> for
     * each priorityModel in the list and notifies registered <code>Observer</code>s
     * of the change
     *
     * @param priorityModel priorityModel to remove
     * @see PriorityModel
     * @see java.util.Observer
     */
    public synchronized final void removePriorityModel( PriorityModel priorityModel )
    {   int index = -1;
        for( int i = 0; i < priorityModels.length; i++ )
            if( priorityModels[i] == priorityModel )
            {   index = i;
                removePriorityModelAt( i );
                i = Integer.MAX_VALUE;
                break;
            }   // end if: found priorityModel
        
    }   // end removePriorityModel
    
    
    /**
     * Removes priorityModels at the specified indeces and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param priorityModel priorityModel to remove
     * @see PriorityModel
     * @see java.util.Observer
     */
    public synchronized final void removePriorityModelsAt( int[] indeces )
    {   
        // Nullify priorityModels to remove
        for( int i = 0; i < indeces.length; i++ )
            priorityModels[ indeces[i] ] = null;
        
        // Make new array
        PriorityModel[] temp = new PriorityModel[ priorityModels.length - indeces.length ];
        int index = 0;
        for( int i = 0; i < priorityModels.length; i++ )
            if( priorityModels[i] != null )
                temp[index++] = priorityModels[i];
        priorityModels = temp;
        setChanged();
        notifyObservers();
    }   // end removePriorityModelsAt
    
    
    /**
     * Returns an array of the priorityModels in the list.
     *
     * @return array of priorityModels in the list
     * @since 1.0
     */
    public synchronized final PriorityModel[] getPriorityModels()
    {   return priorityModels;
    }   // end getPriorityModels
    
    
    /**
     * Returns <code>"Number of priorityModels: " + priorityModels.length;</code>
     *
     * @return a string representation
     * @since 1.0
     */
    public synchronized String toString()
    {
        return "Number of priorityModels: " + priorityModels.length;
    }   // end toString
    
    
/* ********  O B S E R V E R   C O D E  ******** */
    
    
    /**
     * Called when an <code>Observable</code> registers a change. The
     * list registers with priorityModels. The list then notifies its own
     * registered <code>Observer</code>s of the change.
     *
     * @param thing thing that was updated
     * @param arg argument passed by thing
     * @since 1.0
     * @see java.util.Observable
     * @see java.util.Observer
     */
    public final void update( Observable thing, Object arg )
    {   this.setChanged();
        this.notifyObservers( thing );
    }   // end update
    
    
/* ********  S E R I A L I Z A B L E   C O D E  ******** */
    
    /**
     * The standard "write" for an object.
     */
    private synchronized void writeObject( ObjectOutputStream out )
    throws IOException, ClassNotFoundException
    {   out.defaultWriteObject();
    }   // end writeObject
    
    /**
     * Reads in the list and then registers the list as an <code>Observer</code>
     * with each priorityModel.
     */
    private synchronized void readObject( ObjectInputStream in )
    throws IOException, ClassNotFoundException
    {   in.defaultReadObject();
        try
        {   for( int i = 0; i < priorityModels.length; i++ )
                priorityModels[i].addObserver( this );
        }   // end try
        catch( Exception e )
        {   priorityModels = new PriorityModel[0];
        }   // end catch
    }   // end readObject
    
    /**
     * Register as observer after deserialization.
     *
     * @param kernel kernel being used
     * @since 1.0
     */
    public final void initializeAfterDeserialization( Kernel kernel )
    {   for( int i = 0; i < priorityModels.length; i++ )
            priorityModels[i].initializeAfterDeserialization( kernel );
    }   // end initializeAfterDeserialization

/* ********  R E P L A C E   C O D E  ******** */


    /**
     * Replaces this list with <code>newList</code>. This is used
     * when loading a new <code>Kernel</code>. <code>Observer</code>s
     * registered with the original list will still be registered, but
     * anything registered with <code>newList</code> will not still
     * be registered.
     *
     * @param newList the new priorityModel list to use
     * @since 1.0
     */
    public final void replace( PriorityModelList newList )
    {   this.priorityModels = newList.getPriorityModels();
        // Register with new priorityModels as a listener
        for( int i = 0; i < priorityModels.length; i++ )
            priorityModels[i].addObserver( this );
        this.setChanged();
        this.notifyObservers( priorityModels );
    }   // end replace
    
    
    
}   // end class PriorityModelList