/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.router.simpletabusearch;

import net.usa.rharder.tabusearch22.*;

class SimpleTSTabuList implements TSTabuList,
 TSNewCurrentSolutionListener,
 TSUnimprovingMoveListener
{
    private int LIST_LENGTH;
    int tenure = 10;
    int currentOpenNumber = 0;
    int[] list = new int[0];
    
    public SimpleTSTabuList( int initialTenure )
    {
        LIST_LENGTH = 10 * initialTenure;
        list = new int[ LIST_LENGTH ];
        currentOpenNumber = initialTenure;
    }   // end constructor
    
    public final void setTenure( int tenure )
    {   
        // Make sure we won't go negative
        if( currentOpenNumber < tenure )
            currentOpenNumber = tenure;
        this.tenure = tenure;
    }   // end setTenure
    
    
/* ********  T S T A B U L I S T   C O D E  ******** */
    
    public void registerMoves( TSMove[] moves, TSSolution toSolution )
    {
//System.out.println( "SimpleTSTabuList.registerMoves: moves: " );
//for( int i = 0; i < moves.length; i++ )
//System.out.println( "  moves[" + i + "]=" + moves[i] );
//System.out.println("");
        // Hash code for solution
        int hash = ((SimpleTSSolution)toSolution).getHSolution().hashCode();
        
        // Record hash value at current open position
        list[ currentOpenNumber % LIST_LENGTH ] = hash;
        
        // Increment counter
        currentOpenNumber++;
    }   // end registerMoves
    
    public final boolean allowMove( TSMove move, TSSolution toSolution )
    {
        // Hash code for solution
        final int hash = ((SimpleTSSolution)toSolution)
            .getHSolution().hashCode();
        
        boolean allow = true;
        int i = 1;
        
        while( 
        allow == true
        &&
        i <= tenure )
        {   // See if hash code is in the list
            if( hash == list[ ( currentOpenNumber - i ) % LIST_LENGTH ] )
                allow = false;
            i++;
        }   // end while
//System.out.print( allow ? "." : "N" );
        return allow;
    }   // end allowMove
    
    
    
/* ********  T S N E W C U R R E N T S O L U T I O N  ******** */
    
    public final void newCurrentSolutionFound( TSTabuEvent e )
    {
        
    }   // end newCurrentSolutionFound
    
    
/* ********  T S U N I M P R O V I N G M O V E  ******** */
    
    public final void unimprovingMoveMade( TSTabuEvent e )
    {
        
    }   // end newCurrentSolutionFound
    
    
    
}   // end class SimpleTSTabuList