/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.io.*;

/**
 * A restricted operating zone (ROZ) is a geographic region that may have
 * a collective time window or time wall. A user can specify these restrictions
 * for the entire area and assign the time window/wall values to all of the sites.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @see GeographicRegion
 * @see Site
 * @version 1.0
 * @since 1.0
 */
public class RestrictedOperatingZone 
extends Observable 
implements Observer, Serializable
{
    private static int untitledCounter = 1;
    
    private String name;
    private GeographicRegion region;
    private int earliestAllowed = -Integer.MAX_VALUE;
    private int latestAllowed = Integer.MAX_VALUE;
    private int earliestRestricted = -Integer.MAX_VALUE;
    private int latestRestricted = -Integer.MAX_VALUE;
    
    /**
     * Constructs a ROZ with no region.
     *
     * @since 1.0
     */
    public RestrictedOperatingZone()
    {   region = new GeographicRegion();
        region.addObserver( this );
        name = "Untitled" + untitledCounter++;
    }   // end constructor
    
    /**
     * Constructs a ROZ based on the latitude and longitude pairs given
     * by <var>verticesLatLong</var>. This is a matrix whose first index
     * represents the lat/lon pair and whose second index is zero for
     * latitudes and one for longitudes.
     *
     * @param verticesLatLong vertices of ROZ
     * @since 1.0
     */
    public RestrictedOperatingZone( double[][] verticesLatLong )
    {   region = new GeographicRegion( verticesLatLong );
        region.addObserver( this );
        name = "Untitled" + untitledCounter++;
    }   // end constructor
    
    
/* ********  G E T   C O D E  ******** */
    
    /** 
     * Returns the name of the ROZ.
     * 
     * @return name of the ROZ
     * @since 1.0
     */
    public final String getName()
    {   return name;
    }   // end getName
    
    
    /** 
     * Returns the geographic region of the ROZ.
     * 
     * @return geographic region of the ROZ
     * @since 1.0
     */
    public final GeographicRegion getRegion()
    {   return region;
    }   // end getRegion
    
    
    /** 
     * Returns the beginning of the time window for the ROZ.
     * 
     * @return beginning of the time window for the ROZ
     * @since 1.0
     */
    public final int getEarliestAllowedTime()
    {   return earliestAllowed;
    }   // end getEarliestAllowedTime
    
    
    /** 
     * Returns the ending of the time window for the ROZ.
     * 
     * @return ending of the time window for the ROZ
     * @since 1.0
     */
    public final int getLatestAllowedTime()
    {   return latestAllowed;
    }   // end getLatestAllowedTime
    
    
    /** 
     * Returns the beginning of the time wall for the ROZ.
     * 
     * @return beginning of the time wall for the ROZ
     * @since 1.0
     */
    public final int getEarliestRestrictedTime()
    {   return earliestRestricted;
    }   // end getEarliestRestricted
    
    
    /** 
     * Returns the ending of the time wall for the ROZ.
     * 
     * @return ending of the time wall for the ROZ
     * @since 1.0
     */
    public final int getLatestRestrictedTime()
    {   return latestRestricted;
    }   // end getLatestRestrictedTime
    
    
/* ********  S E T   C O D E  ******** */
    
    /**
     * Sets the geographic region for the ROZ
     * 
     * @param region geographic region for the ROZ
     * @see GeographicRegion
     * @since 1.0
     */
    public final void setRegion( GeographicRegion region )
    {   this.region.deleteObserver( this );
        this.region = region;
        this.region.addObserver( this );
        this.setChanged();
        this.notifyObservers();
    }   // end setRegion
    
    /**
     * Sets the name for the ROZ
     *
     * @param name name for the ROZ
     * @since 1.0
     */
    public final void setName( String name )
    {   this.name = name;
        this.setChanged();
        this.notifyObservers( name );
    }   // end setName
    
    
    /** 
     * Sets the beginning of the time window for the ROZ.
     * 
     * @param time beginning of the time window for the ROZ
     * @since 1.0
     */
    public final void setEarliestAllowedTime( int time )
    {   this.earliestAllowed = time;
        this.setChanged();
        this.notifyObservers();
    }   // end setEarliestAllowedTime
    
    
    /** 
     * Sets the ending of the time window for the ROZ.
     * 
     * @param time ending of the time window for the ROZ
     * @since 1.0
     */
    public final void setLatestAllowedTime( int time )
    {   this.latestAllowed = time;
        this.setChanged();
        this.notifyObservers();
    }   // end setLatestAllowedTime
    
    
    /** 
     * Sets the beginning of the time wall for the ROZ.
     * 
     * @param time beginning of the time wall for the ROZ
     * @since 1.0
     */
    public final void setEarliestRestrictedTime( int time )
    {   this.earliestRestricted = time;
        this.setChanged();
        this.notifyObservers();
    }   // end setEarliestRestrictedTime
    
    
    /** 
     * Sets the ending of the time wall for the ROZ.
     * 
     * @param time ending of the time wall for the ROZ
     * @since 1.0
     */
    public final void setLatestRestrictedTime( int time )
    {   this.latestRestricted = time;
        this.setChanged();
        this.notifyObservers();
    }   // end setLatestRestrictedTime
    
    
/* ********  M I S C E L L A N E O U S   C O D E  ******** */
    
    /**
     * Returns whether or not the site is in this ROZ.
     * 
     * @param site site to check
     * @return whether or not the site is in this ROZ
     * @since 1.0
     * @see Site
     */
    public final boolean contains( Site site )
    {   return region.contains( site.getLatitude(), site.getLongitude() );
    }   // end contains
    
/* ********  O B S E R V E R   C O D E  ******** */
    
    /**
     * Listens for udpates and notifies observers
     */
    public void update( Observable thing, Object arg )
    {   setChanged();
        notifyObservers( thing );
    }   // end update
    
}   // end class RestrictedOperatingZone