/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

/**
 * These events get passed from the kernel solver to interested listeners.
 * 
 * @author Robert Harder
 * @version 1.0
 * @since 1.0
 * @see Kernel
 * @see KernelSolver
 * @see KernelSolverListener
 */
public class KernelSolverEvent
{

    /**
     * The event type when the <code>KernelSolver</code> has started.
     * 
     * @since 1.0
     */
    public static final int SOLVER_STARTED = 1;

    /**
     * The event type when the <code>KernelSolver</code> has finished.
     * 
     * @since 1.0
     */
    
    public static final int SOLVER_FINISHED = 2;

    /**
     * The event type when the <code>KernelSolver</code> has reported its progress.
     * 
     * @since 1.0
     */
    
    public static final int PERCENT_DONE = 3;


    /**
     * The event type when the <code>KernelSolver</code> has found a new best solution.
     * 
     * @since 1.0
     */
    
    public static final int NEW_BEST_SOLUTION = 4;
    
    
    /**
     * The event type when the <code>KernelSolver</code> is working on a new priority model.
     * 
     * @since 1.0
     */
    public static final int PRIORITY_MODEL_CHANGED = 5;

    /**
     * The event type.
     * 
     * @since 1.0
     */
    private int eventType;

    /**
     * The source of the event. It should be of type
     * <code>KernelSolver</code>.
     * 
     * @since 1.0
     */
    private Object source;


    /**
     * Constructor for <code>KernelSolverEvent</code>
     * 
     * @param eventType event type
     * @param source source of the event. 
     *               Normally <code>this</code> is passed.
     * @since 1.0
     */
    
    public KernelSolverEvent( int eventType, Object source )
    {   this.eventType = eventType;
        this.source = source;
    }   // end constructor

    /**
     * Returns the source of the event.
     * 
     * @return source of the event.
     * @since 1.0
     */
    
    public final Object getSource()
    {   return source;
    }   // end getSource

    /**
     * Returns the source as a <code>KernelSolver</code>. This is identical
     * to <code>(KernelSolver) e.getSource()</code>.
     *
     * @return source of the event as a <code>KernelSolver</code>
     * @since 1.0
     * @see KernelSolver
     */
    public final KernelSolver getKernelSolver()
    {   return (KernelSolver) source;
    }   // end getKernelSolver

    /**
     * Returns the event type.
     * 
     * @return event type
     * @since 1.0
     */
    public final int getEventType()
    {   return eventType;
    }   // end getEventType
    
    
    
}   // end class KernelSolverEvent