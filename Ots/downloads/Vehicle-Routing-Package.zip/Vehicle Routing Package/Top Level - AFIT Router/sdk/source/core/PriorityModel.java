/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.io.*;

/**
 * This records how a user wishes to treat priorities. For example
 * a user may never want to trade even 100 priority 2 sites for a priority 1 site,
 * or maybe five priority 2 sites are worth one priority 1 site. Whatever the case,
 * <code>PriorityModel</code> tracks the relative worth of the priorities
 * specified by the sites in the kernel's site list.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Site
 * @see SiteList
 * @see PriorityModelList
 */
public class PriorityModel
extends Observable
implements Observer, Serializable
{
    /**
     * A relative worth equal to or greater than this number is considered infinity.
     * 
     * @since 1.0
     */
    final public static int NEAR_INF = 1000;
    
    /**
     * This maintains the relative worth of one priority
     * level to another. Although the actual priority values
     * may not be contiguous, the array here simply relates
     * one priority level to the next. The indexing is such
     * that index 0 is how many second priority sites are worth
     * one first level priority sites.
     */
    private int[] relativeWorths = new int[0];
    
    /**
     * This keeps a record of what priority levels are being
     * used based on the SiteList for which each model is
     * registered as an Observer.
     */
    private int[] priorities = new int[0];
    
    
    private boolean isEditable = true;
    
    private int defaultRelativeWorth = Integer.MAX_VALUE;
    
    private String name;
    
    private boolean enabled = true;
    
    /**
     * Constructs a priority model with a default relative worth of infinity.
     *
     * @param name name of priority model
     * @param kernel kernel being used
     * @since 1.0
     */
    public PriorityModel( String name, Kernel kernel )
    {   this.name = name;
        kernel.getSiteList().addObserver( this );
        this.update( kernel.getSiteList(), null );
    }   // end constructor
    
    
    
    /**
     * Constructs a priority model with the specifie default relative worth
     * and editable state.
     *
     * @param name name of priority model
     * @param kernel kernel being used
     * @param defaultRelativeWorth default relative worth for model
     * @param isEditable whether or not this model's worths can be changed
     * @since 1.0
     */
    public PriorityModel( String name, Kernel kernel, 
    int defaultRelativeWorth, boolean isEditable )
    {   this.name = name;
        this.defaultRelativeWorth = defaultRelativeWorth;
        this.isEditable = isEditable;
        kernel.getSiteList().addObserver( this );
        this.update( kernel.getSiteList(), null );
    }   // end constructor
    
    
    /**
     * Constructs a shell of a priority model from the passed priority model.
     * A shell has all of the relative worths specified by the original,
     * but it is not registered with the kernel.
     *
     * @param shellFromThis priority model from which to construct a shell
     * @since 1.0
     */
    public PriorityModel( PriorityModel shellFromThis )
    {   this.name = shellFromThis.getName();
        this.isEditable = shellFromThis.isEditable();
        this.enabled = shellFromThis.isEnabled();
        this.defaultRelativeWorth = shellFromThis.getDefaultRelativeWorth();
        
        // Arrays need to be copied
        int[] sftPriorities = shellFromThis.getPriorities();
        this.priorities = new int[ sftPriorities.length ];
        System.arraycopy( sftPriorities,0, priorities,0,sftPriorities.length );
        int[] sftWorths = shellFromThis.getAllRelativeWorths();
        this.relativeWorths = new int[ sftWorths.length ];
        System.arraycopy( sftWorths,0, relativeWorths,0,sftWorths.length );
    }   // end construtor
    
    
    
    
    /**
     * Registers with the kernel and updates self based on the site list.
     *
     * @param kernel the kernel to register with
     * @since 1.0
     */
    public final void initializeAfterDeserialization( Kernel kernel )
    {   kernel.getSiteList().addObserver( this );
        this.update( kernel.getSiteList(), null );
    }   // end initializeAfterDeserialization
    
    
/* ********  M O D E L   A C C E S S   C O D E  ******** */
    
    
    
    /**
     * Returns the default relative worth.
     *
     * @return the default relative worth
     * @since 1.0
     */
    public final int getDefaultRelativeWorth()
    {   return defaultRelativeWorth;
    }   // end getDefaultRelativeWorth
    
    
    /**
     * Returns all of relative worths. The first element of the array
     * is the relative worth of the highest priority to the next highest priority.
     * This continues through the array. This array may store values beyond the
     * range of priorities currently represented in the site list. When priorities
     * that were taken out of the site list are added again, the priority model
     * will still save the original values.
     *
     * @return all of the relative worths
     * @since 1.0
     */
    public final int[] getAllRelativeWorths()
    {   return relativeWorths;
    }   // end getAllRelativeWorths
    
    
    /**
     * Returns a shell of this model. A shell is not registered with the kernel.
     *
     * @return shell of this model
     * @since 1.0
     */
    public final PriorityModel makeShell()
    {   return new PriorityModel( this );
    }   // end makeShell
    
    
    /**
     * Whether or not the model is marked as enabled. This is used when the
     * kernel begins solving.
     *
     * @return whether or not the model is enabled
     * @since 1.0
     */
    public final boolean isEnabled()
    {   return enabled;
    }   // end isEnabled
    
    
    /**
     * Sets whether or not the model is enabled. This is used when the
     * kernel begins solving.
     *
     * @param state whether or not the model is enabled
     * @since 1.0
     */
    public final void setEnabled( boolean state )
    {   this.enabled = state;
    }   // end setEnabled
    
    
    /**
     * Returns the name of the model.
     *
     * @return name of the model
     * @since 1.0
     */
    public final String getName()
    {   return name;
    }   // end getName
    
    
    /**
     * Returns an array of priorities currently in the site list
     *
     * @return array of priorities
     * @since 1.0
     */
    public final int[] getPriorities()
    {   return priorities;
    }   // end getPriorities
    
    
    /**
     * Returns an array of relative worths. The first element of the array
     * is the relative worth of the highest priority to the next highest priority.
     * This continues through the array. The size of this array will be one less
     * than the number of priorities.
     *
     * @return relative worths
     * @since 1.0
     */
    public final int[] getRelativeWorths()
    {   int[] temp = new int[ priorities.length ];
        System.arraycopy( relativeWorths, 0, temp, 0, temp.length );
        return temp;
    }   // end getRelativeWorth
    
    
    /**
     * Returns a specific relative worth. The first element of the array
     * is the relative worth of the highest priority to the next highest priority.
     * This continues through the array.
     *
     * @param index position of relative worth to return
     * @return relative worth
     * @since 1.0
     */
    public final int getRelativeWorthAt( int index )
    {   return (index >= 0) && (index < relativeWorths.length)
            ? relativeWorths[index]
            : -Integer.MAX_VALUE;
    }   // end getRelativeWorthAt
    
    
    /**
     * Sets the name of the model.
     *
     * @param name name of the model
     * @since 1.0
     */
    public final void setName( String name )
    {   this.name = name;
    }   // end setName
    
    
    /**
     * Sets the relative worths for the model.
     *
     * @param worths new relative worths for the model
     * @since 1.0
     */
    public final void setRelativeWorths( int[] worths )
    {
        int[] temp = new int[ Math.max( worths.length, priorities.length) ];
        System.arraycopy( worths, 0, temp, 0, worths.length );
        for( int i = worths.length; i < temp.length; i++ )
            temp[i] = defaultRelativeWorth;
        this.relativeWorths = temp;
        this.setChanged();
        this.notifyObservers();
    }   // end setRelativeWorths
    
    
    /**
     * Sets a specific relative worth for the model.
     *
     * @param worths new relative worth
     * @param index position of new relative worth
     * @since 1.0
     */
    public final void setRelativeWorthAt( int worth, int index )
    {   // See if index is within range
        if( (index >= 0) && (index < relativeWorths.length) )
            relativeWorths[index] = worth > 1 ? worth : 1;
        else 
        // If index is greater than known range for relative worth
        // then add to the array, filling in defaults where appropriate.
        if( index > relativeWorths.length )
        {
            int[] temp = new int[ index + 1 ];
            System.arraycopy( relativeWorths, 0, temp, 0, relativeWorths.length );
            for( int i = relativeWorths.length; i < index; i++ )
                temp[i] = defaultRelativeWorth;
            temp[index] = worth;
            relativeWorths = temp;
        }   // end else if: index greater than existing range.
        this.setChanged();
        this.notifyObservers();
    }   // end setRelativeWorth
    
    
    /**
     * Sets whether or not this model is marked as editable.
     *
     * @param state whether or not this model is marked as editable
     * @since 1.0
     */
    public final void setIsEditable( boolean state )
    {   this.isEditable = state;
        this.setChanged();
        this.notifyObservers();
    }   // end setIsEditable
    
    
    /**
     * Returns whether or not this model is marked as editable.
     *
     * @return  whether or not this model is marked as editable
     * @since 1.0
     */
    public final boolean isEditable()
    {   return isEditable;
    }   // end isEditable
    
    
/* ********  S T A T I C   C O D E  ******** */
    
    /**
     * Converts a relative worth to a text value. A value greater
     * than <var>NEAR_INF</var> will be considered infinity
     *
     * @param n number to convert
     * @return relative worth as string
     * @since 1.0
     */
    public final static String textValue( int n )
    {   try
        {   return n > (NEAR_INF)
                ? "INF"
                : String.valueOf( n );
        }   // end try
        catch( Exception e )
        {   return "err";
        }   // end catch
    }   // end textValue
    
    
    /**
     * Converts a string relative worth to an int value.
     *
     * @param s string to convert
     * @return relative worth as an int
     * @since 1.0
     */
    public final static int intValue( String s )
    {   try
        {   return s.toUpperCase().indexOf( "INF" ) >= 0
                ? Integer.MAX_VALUE
                : new Integer( s ).intValue();
        }   // end try
        catch( Exception e )
        {   return Integer.MAX_VALUE;
        }   //end catch
    }   // end intValue
    
    
/* ********  O B S E R V E R   C O D E  ******** */
    
    /**
     * Listens for updates to the kernel and its SiteList
     */
    public void update( Observable thing, Object arg )
    {
        // Find all known priorities
        if( thing instanceof SiteList)
        {
            final Site[] sites = ((SiteList)thing).getSites();
            priorities = new int[0];
            for( int i = 0; i < sites.length; i++ )
            {   final Site site = sites[i];
                if( site != null )
                {   final int priority = site.getPriority();
                    if( indexForPriority( priority ) < 0 )
                    {   addPriority( priority );
                    }   // end if: priority not yet known
                }   // end if: site not null (Shouldn't ever be)
            }   // end for: through each order
            
            // Now that all possible priorities have been located,
            // see if the relative worth array needs any modification
            // based on priorities being added, removed, or changed.
            // If the priorities array and relative worth array have
            // the same length, then do nothing, even if the priority
            // values have changed.
            if( priorities.length == relativeWorths.length )
            {
            }   // end if: Do nothing.
            else if( relativeWorths.length < priorities.length )
            {   // Fewer relative worth values: fill in the excess
                // with "infinity."
                int[] temp = new int[ priorities.length ];
                System.arraycopy( relativeWorths, 0, temp, 0, relativeWorths.length );
                for( int i = relativeWorths.length; i < temp.length; i++ )
                    temp[i] = defaultRelativeWorth;
                relativeWorths = temp;
            }   // end else if: fewer relative worth values
            
            this.setChanged();
            this.notifyObservers();
        }   // end if: sitelist
    }   // end update
    
    
/* ********  I N D E X I N G   C O D E  ******** */
    
    private final int indexForPriority( int priority )
    {   int index = -1;
        int i = 0;
        while( (index < 0) && (i < priorities.length) )
            if( priorities[i++] == priority )
                index = --i;
        return index;
    }   // end indexForPriority
    
    
    private final void addPriority( int priority )
    {
        // Lower values have higher priority, as in
        // Priority 1 is the highest. Technically negative
        // values would be even higher priority.
        final int priorLength = priorities.length;
        int[] temp = new int[ priorLength + 1 ];
        for( int i = 0; i <= priorLength; i++ )
        {   if( i < priorities.length )
            {   if( priority < priorities[i] )
                {   
                    System.arraycopy( priorities, 0, temp, 0, i );
                    System.arraycopy( priorities, i, temp, i+1, priorities.length-i );
                    temp[i] = priority;
                    i = Integer.MAX_VALUE;
                    break;  // Leave the for loop
                }   // end if: new priority goes before the rest
            }   // end if: checking through normal priorities
            else
            {   System.arraycopy( priorities, 0, temp, 0, priorities.length );
                temp[priorities.length] = priority;
                i = Integer.MAX_VALUE;
                break;
            }   // end else: add to end of list
        }   // end for: through each existing priority        
        priorities = temp;
    }   // end addPriority
    
    
    public String toString()
    {
        StringBuffer s = new StringBuffer( "[" );
        
        for( int i = 0; i < priorities.length-1; i++ )
            s.append( "" + priorities[i] + "-" + priorities[i+1]
                + "=" + textValue(relativeWorths[i])
                + ( i < priorities.length-2
                ? ", "
                : "" ) );
        s.append("]");
        return s.toString();
    }   // end toString
    
}   // end class PriorityModel