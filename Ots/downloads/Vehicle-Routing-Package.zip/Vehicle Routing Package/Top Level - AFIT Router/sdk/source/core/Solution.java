/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import mil.af.afit.uvr.*;


/**
 * A solution represents a suggested route for the vehicles to visit the sites.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Vehicle
 * @see Site
 * @see UVRVehicle
 * @see UVRSite
 */
public class Solution
{
    private HSolution solution;
    private PriorityModel modelShell;
    private long creation;
    
    /**
     * Constructs a new solution based on the <code>HSolution</code> and
     * the priority model that was used to get there.
     *
     * @param solution <code>HSolution</code> (from UVR)
     * @param priorityModel model used to get the solution
     * @see mil.af.afit.uvr.HSolution
     * @see PriorityModel
     * @since 1.0
     */
    public Solution( HSolution solution, PriorityModel priorityModel )
    {   this.solution = solution;
        this.modelShell = priorityModel.makeShell();
        this.creation = System.currentTimeMillis();
    }   // end constructor
    
    /**
     * Returns the <code>HSolution</code>.
     * 
     * @return the <code>HSolution</code>
     * @see mil.af.afit.uvr.HSolution
     * @since 1.0
     */
    public final HSolution getHSolution()
    {   return this.solution;
    }   // end getHSolution
    
    /**
     * Get time stamp for the creation of this solution.
     *
     * @return time stamp as millis at point of creation
     * @since 1.0
     */
    public final long getCreationMillis()
    {   return this.creation;
    }   // end getCreationMillis
    
    /**
     * Returns the total mission length in minutes. This is the first takeoff
     * to that last landing.
     *
     * @reurn mission time
     * @since 1.0
     */
    public final int getMissionLength()
    {
        // Quick access variables
        HTour[] tours = solution.getHTours();
        
        // When does the first vehicle leave
        int earliestVehicleDeparture = Integer.MAX_VALUE;
        for( int i = 0; i < tours.length; i++ )
            if( tours[i].size() > 0 )
                if( tours[i].getDepartureTime() < earliestVehicleDeparture )
                    earliestVehicleDeparture = (int) tours[i].getDepartureTime();
        
        // When does the last vehicle get back
        int latestVehicleReturn = -Integer.MAX_VALUE;
        for( int i = 0; i < tours.length; i++ )
            if( tours[i].size() > 0 )
                if( tours[i].getReturnTime() > latestVehicleReturn )
                    latestVehicleReturn = (int) tours[i].getReturnTime();
        
        // Mission length
        final int intMissionLength = 
            latestVehicleReturn - earliestVehicleDeparture;
        
        return intMissionLength;
    }   // end getMissionLength
    
    /**
     * Returns the mission length in a string format.
     * 
     * @returnthe mission length in a string format
     * @since 1.0
     */
    public final String getMissionLengthString()
    {
        final int intMissionLength = this.getMissionLength();
        final int hours = (int) (intMissionLength / 60f);
        final int minutes = (intMissionLength % 60);
        
        return ""
            + hours + " hrs. "
            + minutes + " min.";
    }   // end getMissionLengthString
    
    /**
     * Returns the number of sites that are visited.
     * 
     * @return number of sites that are visited
     * @since 1.0
     */
    public final int countSitesVisited()
    {
        int count = 0;
        final HTour[] tours = solution.getHTours();
        for( int i = 0; i < tours.length; i++ )
            count += tours[i].size();
        return count;
    }   // end countVisitedSites
    
    public String toString()
    {   return solution == null ? "" : this.solution.toString() + "\nwith priority model " + modelShell + "\ncreation="+creation;
    }   // end toString
    
}   // end class Solution