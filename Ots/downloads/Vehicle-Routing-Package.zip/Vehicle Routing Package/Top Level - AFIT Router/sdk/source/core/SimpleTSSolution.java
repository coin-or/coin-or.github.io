/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.router.simpletabusearch;

import net.usa.rharder.tabusearch22.*;
import mil.af.afit.uvr.*;

class SimpleTSSolution extends TSSolution
{
    private HSolution solution;
    
    public SimpleTSSolution( HSolution solution )
    {   this.solution = solution;
        super.setObjectiveValue( solution.getCosts() );
        super.setPenaltyValue( new double[ solution.getCosts().length ] );
    }   // end constructor
    
    
    public SimpleTSSolution( SimpleTSSolution copyThis )
    {   super( copyThis );
        this.solution = (HSolution) copyThis.getHSolution().clone();
    }   // end constructor
    
    
    
    public HSolution getHSolution()
    {   return solution;
    }   // end getHSolution
    
    
    
    
    public final boolean isBetterThan( SimpleTSSolution other )
    {
        boolean result = false;
        double[] first = this.getValue();
        
        if( first != null )
        {   
            if( other != null )
            {
                double[] second = other.getValue();
                
                if( second != null )
                {
                    int i=0;
                    int valLength = first.length;
                    
                    for( i = 0; i < valLength; i++ )
                    {
                        if( (float)first[i] > (float)second[i] )
                        {
                            result = false;
                            i = Integer.MAX_VALUE;
                            break;
                        }   // end if
                        else if( (float)first[i] < (float)second[i] )
                        {
                            result = true;
                            i = Integer.MAX_VALUE;
                            break;
                        }   // end else
                        // else it must have been equal
                    }   // end for: through each value
                }   // end if: second not null
                else
                {
                    // If the other solution is null then
                    // this solution is better.
                    result = true;
                }   // end else: second was null
            }   // end if: other was not null
            else
            {
                // If the other solution is null then
                // this solution is better.
                result = true;
            }   // end else: other was null
        }   // end if: first not null            
        return result;
    }   // end isBetterThan
    
    
    
    
    
    public Object clone()
    {   return new SimpleTSSolution( this );
    }   // end clone
    
    public String toString()
    {   return solution.toString();
    }   // end toString
    
}   // end SimpleTSSolution