/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

/**
 * Implement this interface to listen for events from the <code>KernelSolver</code>
 * that is performing some solving task for the <code>Kernel</code>.
 * 
 * @author Robert Harder
 * @version 1.0
 * @since 1.0
 * @see KernelSolver
 * @see KernelSolverEvent
 * @see Kernel
 */
public interface KernelSolverListener
{
    /**
     * This method is called when an event is fired. The event <var>e</var> contains
     * the type of event and the source <code>KernelSolver</code>.
     *
     * @since 1.0
     * @param e the event that was fired
     * @see KernelSolverEvent
     * @see KernelSolver
     */
    public abstract void kernelSolverEventPerformed( KernelSolverEvent e );
    
}   // end interface KernelSolverListener