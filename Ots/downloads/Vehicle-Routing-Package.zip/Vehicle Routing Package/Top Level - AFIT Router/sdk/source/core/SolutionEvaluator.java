/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;
import mil.af.afit.uvr.*;

/** 
 * The <code>HEvaluator</code> is required by the <code>HEngine</code> in the
 * Universal Vehicle Router package. It determines a set of costs for a solution.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Solution
 * @see mil.af.afit.uvr.HSolution
 * @see mil.af.afit.uvr.HEvaluator
 */
class SolutionEvaluator 
implements HEvaluator
{
    // Try to evenly distribute the vehicle workload to within this percent.
    //private static double VEH_TRAVEL_TOLERANCE = .33;
    
    private int
        FEASIBLE_RANGE = 0,
        BUSTED_TIME_WINDOWS = 1,
        SKIPPED_ORDERS = 2,
        VEHICLES_USED = 3,
        //DIFF_AMONG_VEHICLE_TRAVEL = 4, // Tries to evenly distribute work load
        TRAVEL_PLUS_PENALTIES = 4,
        WAIT_TIME = 5,
        NUMBER_OF_CATEGORIES = 6;
    
    private String[] names =
        { "Vehicles past range",
          "Time windows busted",
          "Skipped orders",
          "Vehicles used",
          //"Difference among vehicle travel times",
          "Travel plus penalties",
          "Wait time"
        };
    
    private int prioritySlots;
    private int[] priorities;
    private int[] relativeWorths;
    private int[] priorityValuePlacementInCostsArray;
    private int[] priorityWeights;
    private PriorityModel model;
    
    /**
     * Constructs an evaluator based on the specified priority model.
     *
     * @param model priority model to use
     * @since 1.0
     */
    public SolutionEvaluator( PriorityModel model )
    {
        this.model = model.makeShell();
        this.priorities = this.model.getPriorities();
        this.relativeWorths = this.model.getRelativeWorths();
        
        // Set up the priority stuff
        setupPriorities();
        
        // Now fix the variables that point to the appropriate
        // array indeces.
        final int extra = priorityValuePlacementInCostsArray[
            priorityValuePlacementInCostsArray.length-1 ] - SKIPPED_ORDERS;
        VEHICLES_USED += extra;
        TRAVEL_PLUS_PENALTIES += extra;
        WAIT_TIME += extra;
        NUMBER_OF_CATEGORIES += extra;
        
        // Now fix the strings that describe the values.
        String[] tempNames = new String[ NUMBER_OF_CATEGORIES ];
        for( int i = 0; i < SKIPPED_ORDERS; i++ )
            tempNames[i] = names[i];
        for( int i = 0; i <= extra; i++ )
            tempNames[SKIPPED_ORDERS + i] = 
                names[SKIPPED_ORDERS];// + " with priority " + priorities[i];
        tempNames[ VEHICLES_USED ] = 
            names[ VEHICLES_USED - extra ];
        tempNames[ TRAVEL_PLUS_PENALTIES ] = 
            names[ TRAVEL_PLUS_PENALTIES - extra ];
        tempNames[ WAIT_TIME ] = 
            names[ WAIT_TIME - extra ];
        
        names = tempNames;
        
    }   // end constructor
    
    
    private final int indexForPriority( int priority )
    {
        int index = -1;
        int i = 0;
        while( (index < 0) && (i < priorities.length) )
            if( priorities[i++] == priority )
                index = --i;
        
        return index;
    }   // end indexForPriority
    
    
    private final void setupPriorities()
    {
        // Tasks to accomplish by this method:
        // 1) Determine how much weight to give each priority level
        // 2) Determine where to put the weights in the costs array
        
        // Set up some arrays
        priorityValuePlacementInCostsArray = new int[ priorities.length ];
        priorityWeights = new int[ priorities.length ];
        
        // Start with the back and work forward
        int[] backwardsSlotNumbers = new int[ priorities.length ];
        int currentBackwardSlotNumber = 0;
        int previousWeight = 1;
        priorityWeights[ priorityWeights.length-1 ] = previousWeight;
        backwardsSlotNumbers[ backwardsSlotNumbers.length-1 ] = currentBackwardSlotNumber;
        final int NEAR_INF = PriorityModel.NEAR_INF;
        for( int i = priorities.length-2; i >= 0; i-- )
        {
            // See if a new slot should be started.
            if( relativeWorths[i] > NEAR_INF )
            {   // Starting a new slot
                backwardsSlotNumbers[i] = ++currentBackwardSlotNumber;
                priorityWeights[i] = previousWeight = 1;
            }   // end if: new slot should be started
            else
            {   // A relative weight
                previousWeight = priorityWeights[i] =
                    ( previousWeight * relativeWorths[i] );
                backwardsSlotNumbers[i] = currentBackwardSlotNumber;
            }   // end else: a relative weight
        }   // end for: through each relative worth
        
        // Now fix the array dealing with the final costs array
        for( int i = 0; i < priorityValuePlacementInCostsArray.length; i++ )
        {   priorityValuePlacementInCostsArray[i] = 
                SKIPPED_ORDERS + currentBackwardSlotNumber 
                - backwardsSlotNumbers[i];
        }   // end for: through each priority level
        
    }   // end setupPriorities
    
    
/* ********  H E V A L U A T O R   C O D E  ******** */
    
    /** 
     * Returns an array of names to go with the costs.
     * 
     * @return an array of names to go with the costs
     * @since 1.0
     */
    public final String[] getNamesForCosts( HSolution soln )
    {   return names;
    }   // end getNamesForCosts
    
    
    
    /** 
     * Returns an array of costs to go with the solution.
     * 
     * @return an array of costs to go with the solution
     * @since 1.0
     */
    public final double[] getCostsForSolution( HSolution soln )
    {
        double[] value = new double[NUMBER_OF_CATEGORIES];
        for( int i = 0; i < value.length; i++ )
            value[i] = 0;
        
        // The obvious skipped orders
        final HTour dummy = soln.getDummyHTour();
        final int dummySize = dummy.size();
        for( int i = 0; i < dummySize; i++ )
        {   final int index = indexForPriority( 
                dummy.getHOrderAt(i).getPriority() );
            value[ priorityValuePlacementInCostsArray[ index ] ] += 
                priorityWeights[index];
        }   // end for: through each order in dummy tour
        
        HTour[] tours = soln.getHTours();
        double[] travelTimes = new double[ tours.length ];
        for( int iTour = 0; iTour < tours.length; iTour++ )
        {
            HTour tour = tours[iTour];
            HVehicle vehicle = tour.getHVehicle();
               
            double range = vehicle.getRange();
            double travel = tour.getTotalTravelTime();
            double penalties = tour.getTotalPenalty();
            double waitTime = tour.getTotalWaitingTime();
            int bustedInclusions = tour.getBustedTimeWindows();
            int bustedRestricteds = tour.getBustedTimeWalls();
            travelTimes[iTour] = travel;
           
            // Feasibility: 0 if feasible, add 1 if infeasible
            value[FEASIBLE_RANGE] += (range-travel < 0) ? 1 : 0;
            
            // Busted time windows
            value[BUSTED_TIME_WINDOWS] += 
                bustedInclusions + bustedRestricteds;
            
            
            
            // Skipped orders for tour
            for( int i = 0; i < tour.size(); i++ )
            {   if( !tour.serviced(i) )
                {   value[ SKIPPED_ORDERS + indexForPriority( 
                        tour.getHOrderAt(i).getPriority() ) ]++;
                    //HEngine.out( "Skipped order inside tour." );
                }   // end if: skipped order
            }   // end for: each order in tour
            
            
            if( tour.size() > 0 )
                value[VEHICLES_USED]++;
            
            // Range minus travel time plus penalties
            value[TRAVEL_PLUS_PENALTIES] += Math.max( 
                0, travel + penalties );
            
            // Total wait time
            value[WAIT_TIME] += waitTime;
            
        }   // end for: through each tour
        
        // Based on the variation in travel times alone, adjust the value reflecting
        // the total travel times and penalties.
        
        /*double largest = -Double.MAX_VALUE;
        double smallest = Double.MAX_VALUE;
        if( travelTimes.length > 1 )
        {   // Find smallest and largest travel time
            for( int i = 0; i < travelTimes.length; i++ )
            {   if( travelTimes[i] > largest )
                    largest = travelTimes[i];
                if( travelTimes[i] < smallest )
                    smallest = travelTimes[i];
            }   // end for: through each travel time
            double ratio = (largest-smallest) / largest;
            System.out.println( "SolutionEvaluator.ratio=" + ratio );
            if( ratio > VEH_TRAVEL_TOLERANCE )
            {   
                value[TRAVEL_PLUS_PENALTIES]=(1+ratio);
            }   // end if: enough difference to cause concern
        }   // end if: more than one vehicle in use
        //value[TRAVEL_PLUS_PENALTIES]
        */
        return value;
    }   // end getCostForSolution
    

    public String toString()
    {
        StringBuffer s = new StringBuffer();
        
        for( int i = 0; i < names.length; i++ )
            s.append( i+"="+ names[i] + ( i < names.length-1 ? "\n" : "") );
        
        return s.toString();
    }   // end toString
        
        
        
}   // end class EvaluatorWithPriorities