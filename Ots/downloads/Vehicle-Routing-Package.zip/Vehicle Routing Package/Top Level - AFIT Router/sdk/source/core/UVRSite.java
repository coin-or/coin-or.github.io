/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import mil.af.afit.uvr.*;

/**
 * Sites are converted to this for the Universal Vehicle Router. You can get
 * back to the original site by calling <code>getParentSite()</code>.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Site
 * @see mil.af.afit.uvr.HOrder
 */
public class UVRSite 
implements HOrder
{
    private int id;
    private int serviceTime;
    private Site parentSite;
    
    // HOrder vars
    private int orderType;
    private int priority;
    private double earliestArrivalTime;
    private double latestDepartureTime;
    private double earliestRestrictedTime;
    private double latestRestrictedTime;
    private int amountNeeded;
    
    /**
     * This constructor makes a <tt>UVRSite</tt>, which implements
     * <tt>HOrder</tt>, from a <tt>Site</tt>.
     */
    public UVRSite( Site fromThis )
    {
        // HOrder constructor
        /*super(
            fromThis.getRequirementType().hashCode(),    // order type
            1, // Amount needed. Not used.
            fromThis.getEarliestArrivalTime(),  // earliest arrival time
            fromThis.getLatestDepartureTime(),  // latest departure time
            fromThis.getEarliestRestrictedTime(),
            fromThis.getLatestRestrictedTime(),
            fromThis.getPriority() );  // priority
        */
        
        this.id = fromThis.getID();
        this.serviceTime = fromThis.getServiceTime();
        this.parentSite = fromThis;
        
        this.orderType = fromThis.getRequirementType().hashCode();
        this.amountNeeded = 1; // not used
        this.priority = fromThis.getPriority();
        this.earliestArrivalTime = fromThis.getEarliestArrivalTime();
        this.latestDepartureTime = fromThis.getLatestDepartureTime();
        this.earliestRestrictedTime = fromThis.getEarliestRestrictedTime();
        this.latestRestrictedTime = fromThis.getLatestRestrictedTime();
    }   // end constructor
    
 /*   public UVRSite( UVRSite copyThis )
    {   super( copyThis );
        this.parentSite = copyThis.getParentSite();
        this.serviceTime = copyThis.getServiceTime();
        this.id = copyThis.getID();
    }   // end constructor
   */ 
    
/* ********  G E T   C O D E  ******** */
    
    /**
     * Returns id.
     *
     * @return id
     * @since 1.0
     */
    public final int getID()
    {   return id;
    }   // end getId
    
    
    /**
     * Returns parent <code>Site</code> object.
     *
     * @return parent site
     * @see Site
     * @since 1.0
     */
    public final Site getParentSite()
    {   return parentSite;
    }   // end getParentSite
    
    
    /**
     * Returns service time
     *
     * @return service time
     * @since 1.0
     */
    public final int getServiceTime()
    {   return serviceTime;
    }   // end getServiceTime
    
    
    public String toString()
    {   return "" + id;
    }   // end toString
    
    
    /**
     * Returns order type (requirement type)
     *
     * @return service time
     * @since 1.0
     */
    public int getOrderType()
    {   return orderType;
    }   // end getOrderType
    
    
/* ********  H O R D E R   C O D E  ******** */    
    

    
    /**
     * Returns priority.
     *
     * @return priority
     * @since 1.0
     */
    public int getPriority()
    {   return priority;
    }   // end getPriority
    
    
    /**
     * Returns beginning of time window.
     *
     * @return beginning of time window
     * @since 1.0
     */
    public double getEarliestArrivalTime()
    {   return earliestArrivalTime;
    }   // end getEarliestArrivalTime
    
    
    /**
     * Returns end of time window.
     *
     * @return end of time window
     * @since 1.0
     */
    public double getLatestDepartureTime()
    {   return latestDepartureTime;
    }   // end getLatestDepartureTime
    
    
    /**
     * Returns beginning of time wall.
     *
     * @return beginning of time wall
     * @since 1.0
     */
    public double getEarliestRestrictedTime()
    {   return earliestRestrictedTime;
    }   // end getEarliestRestrictedTime
    
    
    /**
     * Returns end of time wall.
     *
     * @return end of time wall
     * @since 1.0
     */
    public double getLatestRestrictedTime()
    {   return latestRestrictedTime;
    }   // end getLatestRestrictedTime
    
    
    /**
     * Returns amount needed. Not used.
     *
     * @return amount needed
     * @since 1.0
     */
    public int getAmountNeeded()
    {   return amountNeeded;
    }   // end getAmountNeeded
    
    
}   // end class UVRSite