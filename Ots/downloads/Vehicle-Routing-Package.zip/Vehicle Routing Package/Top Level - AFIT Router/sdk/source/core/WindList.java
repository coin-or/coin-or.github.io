/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.util.*;
import java.io.*;



/**
 * This maintains a list of winds and allows interested objects to listen
 * for changes by implementing the <code>Observer</code> interface.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Wind
 * @see java.util.Observer
 */
public class WindList 
extends Observable 
implements Observer, Serializable
{
    Wind[] winds;
    
    
    /**
     * Constructs a wind list with a single wind.
     *
     * @since 1.0
     */
    public WindList()
    {   super();
        winds = new Wind[0];
        
        // Add simple wind
        addWind( new Wind() );
    }   // end constructor
    
    
    /**
     * Adds the array of winds to the end of the wind list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param moreWinds array of winds to add to list
     * @see Wind
     * @see java.util.Observer
     */
    public synchronized final void addWinds( Wind[] moreWinds )
    {
        // Make a larger array to hold the two wind arrays
        Wind[] tempWinds = new Wind[ winds.length + moreWinds.length ];
        
        // Copy to the two arrays into the larger array
        System.arraycopy( 
            winds,      // Source
            0,          // Start
            tempWinds,  // Destination
            0,          // Start
            winds.length ); // Length
        System.arraycopy( 
            moreWinds,      // Source
            0,              // Start
            tempWinds,      // Destination
            winds.length,   // Start
            moreWinds.length ); // Length
        
        // Save change
        this.winds = tempWinds;
        
        // Record as observer
        for( int i = 0; i < moreWinds.length; i++ )
            moreWinds[i].addObserver( this );
        
        // Notify observers of the change
        setChanged();
        notifyObservers( moreWinds );
    }   // end addWinds
    
    
    /**
     * Adds a single wind to the end of the wind list and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param wind wind to add to list
     * @see Wind
     * @see java.util.Observer
     */
    public synchronized final void addWind( Wind wind )
    {
        if( wind != null )
        {
            // Make a larger array to hold the two wind arrays
            Wind[] tempWinds = new Wind[ winds.length + 1 ];
            
            // Copy to the two arrays into the larger array
            System.arraycopy( 
                winds,      // Source
                0,          // Start
                tempWinds,  // Destination
                0,          // Start
                winds.length ); // Length
            
            tempWinds[ winds.length ] = wind;
            winds = tempWinds;
        
            // Register with wind as observer
            wind.addObserver( this );
        
            // Notify observers of the change
            setChanged();
            notifyObservers( wind );
        }   // end if: wind was not null
    }   // end addWind
    
    
    
    /**
     * Removes a wind at a particular index and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param index index of wind to remove
     * @see Wind
     * @see java.util.Observer
     */
    public synchronized final void removeWindAt( int index )
    {
        if( index >= 0 && index < winds.length )
        {   Wind[] temp = new Wind[ winds.length-1 ];
            System.arraycopy( winds, 0, temp, 0, index );
            System.arraycopy( winds, index, temp, index, winds.length-index-1 );
            winds = temp;
            setChanged();
            notifyObservers();
        }   // end if: found wind
    }   // end removeWindAt
    
    
    
    /**
     * Removes a wind by checking <code>wind == winds[i]</code> for
     * each wind in the list and notifies registered <code>Observer</code>s
     * of the change
     *
     * @param wind wind to remove
     * @see Wind
     * @see java.util.Observer
     */
    public synchronized final void removeWind( Wind wind )
    {   int index = -1;
        for( int i = 0; i < winds.length; i++ )
            if( winds[i] == wind )
            {   index = i;
                removeWindAt( i );
                i = Integer.MAX_VALUE;
                break;
            }   // end if: found wind
        
    }   // end removeWind
    
    
    /**
     * Removes winds at the specified indeces and notifies
     * registered <code>Observer</code>s of the change.
     *
     * @param wind wind to remove
     * @see Wind
     * @see java.util.Observer
     */
    public synchronized final void removeWindsAt( int[] indeces )
    {   
        // Nullify winds to remove
        for( int i = 0; i < indeces.length; i++ )
            winds[ indeces[i] ] = null;
        
        // Make new array
        Wind[] temp = new Wind[ winds.length - indeces.length ];
        int index = 0;
        for( int i = 0; i < winds.length; i++ )
            if( winds[i] != null )
                temp[index++] = winds[i];
        winds = temp;
        setChanged();
        notifyObservers();
    }   // end removeWindsAt
    
    
    /**
     * Returns an array of the winds in the list.
     *
     * @return array of winds in the list
     * @since 1.0
     */
    public synchronized final Wind[] getWinds()
    {   return winds;
    }   // end getWinds
    
    public synchronized String toString()
    {
        return "Number of winds: " + winds.length;
    }   // end toString
    
    
/* ********  O B S E R V E R   C O D E  ******** */
    
    
    /**
     * Called when an <code>Observable</code> registers a change. The
     * list registers with winds. The list then notifies its own
     * registered <code>Observer</code>s of the change.
     *
     * @param thing thing that was updated
     * @param arg argument passed by thing
     * @since 1.0
     * @see java.util.Observable
     * @see java.util.Observer
     */
    public final void update( Observable thing, Object arg )
    {   this.setChanged();
        this.notifyObservers( thing );
    }   // end update
    
    
/* ********  S E R I A L I Z A B L E   C O D E  ******** */
    
    
    /**
     * The standard "write" for an object.
     */
    private synchronized void writeObject( ObjectOutputStream out )
    throws IOException, ClassNotFoundException
    {   out.defaultWriteObject();
    }   // end writeObject
    
    
    /**
     * Reads in the list and then registers the list as an <code>Observer</code>
     * with each wind.
     */
    private synchronized void readObject( ObjectInputStream in )
    throws IOException, ClassNotFoundException
    {   in.defaultReadObject();
        try
        {   for( int i = 0; i < winds.length; i++ )
                winds[i].addObserver( this );
        }   // end try
        catch( Exception e )
        {   winds = new Wind[0];
        }   // end catch
    }   // end readObject
    

/* ********  R E P L A C E   C O D E  ******** */


    /**
     * Replaces this list with <code>newList</code>. This is used
     * when loading a new <code>Kernel</code>. <code>Observer</code>s
     * registered with the original list will still be registered, but
     * anything registered with <code>newList</code> will not still
     * be registered.
     *
     * @param newList the new wind list to use
     * @since 1.0
     */
    public final void replace( WindList newList )
    {   this.winds = newList.getWinds();
        // Register with new winds as a listener
        for( int i = 0; i < winds.length; i++ )
            winds[i].addObserver( this );
        this.setChanged();
        this.notifyObservers( winds );
    }   // end replace
    
    
    
}   // end class WindList