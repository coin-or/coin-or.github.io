/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.router.simpletabusearch;

import mil.af.afit.uvr.*;
import net.usa.rharder.tabusearch22.*;

class SimpleTSRunner implements Runnable, 
TSNewBestSolutionListener, 
TSNewCurrentSolutionListener, 
TSUnimprovingMoveListener,
TSEngineFinishedListener
{
    protected final static double
        DEF_ITER_N_FRAC = 1,  // Default iters. Fraction of num of orders
        BAD_START_M_FRAC = .20, // Bad starts before quitting. Frac of # of starting solutions
        MAX_INSERTS_T_FRAC = .50;   // Max inserts. Frac of tour size
    
    
    private double requestedSolutionEffort;
    
    private SimpleTSSolver parent = null;
    private SimpleTSSolution bestSolution = null;
    private SimpleTSSolution[] initialSolutions = null;
    private boolean startSolving = false;
    private float percentDone;
    private int nextSolutionToTry = 0;
    private boolean finishedSolving = false;
    private long millisToFillInPercentage = 500L;
    
    // Variables that determine how much work is to be done
    // Each starting solution will get at least this many iterations.
    private int defaultIterationsPerSolution = 1;
        
    // When considering giving a solution more iterations, do so if
    // it has yielded a new best solution this recently.
    private int recencyOfLastBestNeededToGiveMoreIterations = 0;
        
    // When giving a solution more iterations, give it this many
    // at a time.
    private int extraIterationsToGiveASolution = 1;
    
    // Iteration when last best solution was found.
    //private int iterationOfLastBestSolution = -Integer.MAX_VALUE>>1;
    
    // Tracks if the current working starting solution has generated
    // a globally new best solution.
    private boolean aBestSolutionWasFoundOnThisStartingSolution = false;
    
    // Number of starting solutions tried since last new best solution
    // was found.
    private int numTriedSinceLastNewBest=0;
    
    // Number of starting solutions in a row that do not generate 
    // a global new best solution we should try before quitting altogether.
    private int numBadStartsBeforeQuitting = 3;
    
    // Helpful for reporting progress
    private int totalEstimatedIterations = 1;
    private int probableCurrentIteration = 1;
    
    // Some tabu objects
    //private TSEngine[] engines = null;  // use this if I do multiple engines
    private TSEngine engine = null;     // use this if I do only one engine
    private SimpleTSObjectiveFunction objectiveFunction = null;
    private SimpleTSPenaltyFunction penaltyFunction = null;
    private TSTabuList tabuList = null;
    private SimpleTSMoveManager moveManager = null;
    private boolean maximizing = false;
    private int numberOfThreads = 1;
    
    
    public SimpleTSRunner( double requestedSolutionEffort,
    SimpleTSSolution[] initialSolutions, int numberOfThreads,
    SimpleTSSolver parent )
    {   this.numberOfThreads = numberOfThreads;
        this.requestedSolutionEffort = requestedSolutionEffort;
        this.initialSolutions = initialSolutions;
        this.parent = parent;
SimpleTSSolver.out( "SimpleTSRunner.constructor: initialSolutions.length=" + initialSolutions.length );
//SimpleTSSolver.out( "SimpleTSRunner.constructor: initialSolutions[0]=" + initialSolutions[0] );
SimpleTSSolver.out( "SimpleTSRunner.constructor: number of threads: " + numberOfThreads );
    }   // end constructor
    
    
    public void run()
    {
        // Wait for word to start solving
        synchronized( this )
        {   while( ! startSolving )
            {   this.notifyAll();
                try
                {   this.wait();
                }   // end try
                catch( InterruptedException e )
                {   SimpleTSSolver.err( e );
                }   // end catch
            }   // end while
        }   // end sync
        
        // Time to start solving.
        // Brains go here.
        
        if( 
        initialSolutions != null 
        && 
        initialSolutions.length >= 1 )
            solve();
        
        //System.out.println( "SimpleTSRunner: done solving" );
        parent.fireSolverFinishedEvent();
    }   // end run
    
    
    private final void solve()
    {
        // Record the first initial solution as the current best
        this.bestSolution = initialSolutions[0];
        parent.fireNewBestSolutionEvent();
        //SimpleTSSolver.out( "SimpleTSRunner.solve: Best solution in TS: " + this.bestSolution.getHSolution().costsToString() );
        
        
        
// TEMP: For kicks, reverse the order of the initial solutions
//System.out.println( "    SOLOMON SOLUTIONS REVERSED IN SimpleTSRUNNER.SOLVE" );
//SimpleTSSolution[]  newOrder = new SimpleTSSolution[ initialSolutions.length ];
//for( int i = 0; i < newOrder.length; i++ )
//    newOrder[i] = initialSolutions[ initialSolutions.length - i - 1 ];
//initialSolutions = newOrder;
        
        // Count orders based on first solution. All solutions
        // should have the same number of orders.
        int countOrders = 0;
        for( int i = 0; i < initialSolutions[0]
        .getHSolution().getHTours().length; i++ )
        {   countOrders += initialSolutions[0]
                .getHSolution().getHTours()[i].size();
        }   // end for
        countOrders += initialSolutions[0]
            .getHSolution().getDummyHTour().size();
        
        // Set up variables that depend on problem size, effort, etc.
        // These hard-coded values can be tweaked at compile time,
        // but mostly it's up to the user to specify a requested effort
        // based on experience with the solver.
        defaultIterationsPerSolution = (int) Math.max( 10, 
            ( countOrders * requestedSolutionEffort * DEF_ITER_N_FRAC ) );
        recencyOfLastBestNeededToGiveMoreIterations = (int) Math.max( 10,
            ( defaultIterationsPerSolution * .30 ) );
        extraIterationsToGiveASolution = (int) Math.max( 10,
            ( defaultIterationsPerSolution * .30 ) );
        int initialTenure = (int) ( countOrders * 3 );
        numBadStartsBeforeQuitting = Math.max( 3, (int)
            ( initialSolutions.length * requestedSolutionEffort * BAD_START_M_FRAC ) );
        //SimpleTSSolver.out( "SimpleTSRunner.solve: numBadStartsBeforeQuitting: " +  numBadStartsBeforeQuitting );       
        totalEstimatedIterations = (int)
            (defaultIterationsPerSolution * initialSolutions.length + 
            defaultIterationsPerSolution * .20); // Little extra so thermometer
                                                // does not hit 100% early
        
        // Display some stats if debugging
        SimpleTSSolver.out( "defaultIterationsPerSolution=" +
            defaultIterationsPerSolution +
            ", recencyOfLastBestNeededToGiveMoreIterations=" +
            recencyOfLastBestNeededToGiveMoreIterations +
            ", extraIterationsToGiveASolution=" +
            extraIterationsToGiveASolution +
            ", initialTenure=" + initialTenure );
            
        
        
        // Set up some objects needed for tabu search engine
        // Functions
        objectiveFunction = new SimpleTSObjectiveFunction( 
            parent.getHEvaluator() );
        penaltyFunction = new SimpleTSPenaltyFunction();
        
        // Move manager
        moveManager = new SimpleTSMoveManager( requestedSolutionEffort );
        
        // Tabu list
//        tabuList = new SimpleTSTabuList( initialTenure );
        tabuList = new SimpleTSTabuListByOrder( initialTenure>>1 );
        


        // Using just one engine
        engine = new TSEngine( 
            initialSolutions[ nextSolutionToTry++ ], 
            tabuList,   
            objectiveFunction, 
            penaltyFunction, 
            moveManager, 
            maximizing, // is false.
            numberOfThreads );  // threads for each engine as well
        
        // Register as engine listener.
        engine.addNewBestSolutionListener( this );
        engine.addNewCurrentSolutionListener( this );
        engine.addUnimprovingMoveListener( this );
        engine.addEngineFinishedListener( this );
        
        // Start the first solution solving
        engine.startSolving( defaultIterationsPerSolution );

        // The rest of the search is run by events. Wait here
        // until something says percent done = 1.0;
        synchronized( this )
        {   while( ! finishedSolving )
            {   this.notifyAll();
                try
                {   this.wait();
                }   // end try
                catch( InterruptedException e )
                {   SimpleTSSolver.err( e );
                }   // end catch
            }   // end while
        }   // end sync
    }   // end solve
    
    
    private final void fillInRestOfPercentage()
    {
        final float originalPercentDone = this.percentDone;
        final float finalPercentDone = 1f;
        final float percentToGo = finalPercentDone - originalPercentDone;
        final int stepsForFillingIn = 20;
        
        for( int i = 0; i <= stepsForFillingIn; i++ )
        {
            final float pd = originalPercentDone 
                + (percentToGo * i)/stepsForFillingIn;
            this.setPercentDone( pd );
            try
            {   final long sleep = (long)
                    ( millisToFillInPercentage 
                      / (float) stepsForFillingIn );
                Thread.currentThread().sleep( sleep );
            }   // end try
            catch( InterruptedException e )
            {   SimpleTSSolver.err( e );
            }   // end catch
        }   // end for: through each step
        
    }   // end fillInRestOfPercentage
    
    
    
/* ********  I N T E R N A L   S E T   M E T H O D S  ******** */
    
    private void setPercentDone( float percentDone )
    {   
        this.percentDone = percentDone;
        parent.setPercentDone( percentDone );
    }   // end setPercentDone
    
    
    
/* ********  C A L L E D   B Y   P A R E N T   E N G I N E  ******** */
    
    
    protected final void startSolving()
    {   synchronized( this )
        {   startSolving = true;
            this.notifyAll();
        }   // end sync
    }   // end startSolving
    
    protected final void stopSolving()
    {   
        engine.stopSolving();
        this.finishedSolving = true;
        synchronized( this )
        {   this.notifyAll();
        }   // end sync
    }   // end stopSolving
    
    protected float getPercentDone()
    {   return percentDone;
    }   // end getPercentDone
    
    protected HSolution getBestHSolution()
    {   if( this.bestSolution != null )
        {   HSolution soln = this.bestSolution.getHSolution();
            if( soln != null )
                if( ! soln.isValid() )
                    if( soln.getLastEvaluatorUsed() != null )
                        soln.validate( soln.getLastEvaluatorUsed() );
            return soln;
        }   // end if: solution not null
        else
            return null;
    }   // end getBestHSolution;
    
    
/* ********  T S N E W B E S T S O L U T I O N   C O D E  ******** */
    
/*
public final static String arrayToString( double[] arr )
{   StringBuffer s = new StringBuffer("[");
    for( int i = 0; i < arr.length; i++ )
        s.append( "" + i + "=" + arr[i] + (i<arr.length-1?", ":"") );
    s.append("]");
    return s.toString();
}   // end arrayToString
*/
    public synchronized void newBestSolutionFound( TSTabuEvent e )
    {
        SimpleTSSolver.out( "SimpleTSRunner.newBestSolutionFound: called." );
        TSEngine engine = e.getTSEngine();
        SimpleTSSolution enginesBest = 
            (SimpleTSSolution) engine.getBestSolution();
        SimpleTSSolver.out( "SimpleTSRunner.newBestSolutionFound: " + enginesBest.getHSolution().costsToString() );
        
        // If this is better than the last best, report it.
        SimpleTSSolver.out( "SimpleTSRunner.newBestSolutionFound: previous bestSolution=" + this.bestSolution.getHSolution().costsToString() );
//        SimpleTSSolver.out( "SimpleTSRunner.newBestSolutionFound: previous bestSolution.getValue()=" + arrayToString( bestSolution.getValue() ) );
        if( enginesBest.isBetterThan( this.bestSolution ) )
        {   this.bestSolution = enginesBest;
            SimpleTSSolver.out( "SimpleTSRunner.newBestSolutionFound: new best is global best." );
            //this.aBestSolutionWasFoundOnThisStartingSolution = true;
            this.numTriedSinceLastNewBest = 0;
            parent.fireNewBestSolutionEvent();
        }   // end if: it was better
        //SimpleTSSolver.out( "SimpleTSRunner.newBestSolutionFound: bestSolution=" + this.bestSolution );        
        
/*        
        // For synchronization concerns, make sure that this new
        // best solution is actually better than what's known.
        // If it's not, it's because two newBestSolutionFound
        // events were fired almost simultaneously from different
        // threads, and the one that was fired barely sooner
        // was better than the second one that was fired.
        if( enginesBest.isBetterThan( this.bestSolution ) )
        {
            // Set this copy of the best solution.
            this.bestSolution = enginesBest;
            
            // Go through the other engines and set their best solutions
            // to this best solution.
            for( int i = 0; i < engines.length; i++ )
            {   
                // Only change the engine's best solution
                // if it's not the engine that just generated
                // the new best.
                if( engines[i] != engine )
                {   if( engines[i] != null )
                        engines[i].trySettingBestSolutionToCopyOf( 
                            enginesBest );
                }   // end if: engine to update is not the one we just heard from
                
            }   // end for: through each engine
            
        }   // end if: new best is better than known best
        
        // Set iteration of last best solution
//        this.iterationOfLastBestSolution = engine.getCurrentIteration();
        
        // Notify listeners that a new best solution was found.
        parent.fireNewBestSolutionEvent();
*/
    }   // end newBestSolutionFound
    
    
/* ********  T S N E W C U R R E N T S O L U T I O N   C O D E  ******** */
    
    public final void newCurrentSolutionFound( TSTabuEvent e )
    {
        TSEngine engine = e.getTSEngine();

/*double[] arr = engine.getCurrentSolution().getValue();
StringBuffer s = new StringBuffer("[");
for( int i = 0; i < arr.length; i++ )
    s.append( "" + i + "=" + arr[i] + (i<arr.length-1?", ":"") );
s.append("]");
System.out.println("SimpleTSRunner.newCurrentSolution:\n   " + s.toString() );
*/




        int itersToGo = engine.getIterationsToGo();
        probableCurrentIteration++;
        
        // Only update the percent every so many iterations
        final int itersBetween = 
            (int) Math.max( 1, (defaultIterationsPerSolution * .10) );
        if( itersToGo % itersBetween == 0 )
        {
            this.setPercentDone( Math.min( 1f,
                (float) probableCurrentIteration 
                / totalEstimatedIterations ) );
        }   // end if: go ahead with updating the percent done        
    }   // end newCurrentSolutionFound
    
    
/* ********  T S U N I M P R O V I N G M O V E   C O D E  ******** */
    
    public final void unimprovingMoveMade( TSTabuEvent e )
    {
        //SimpleTSSolver.out( "SimpleTSRunner: unimproving move made." );
    }   // end unimprovingMoveMade
    
    
/* ********  T S E N G I N E F I N I S H E D   C O D E  ******** */
    
    
    public final synchronized void engineFinished( TSTabuEvent e )
    {
        //SimpleTSSolver.out( "SimpleTSRunner.engineFinished: bestSolution=" + bestSolution );
        TSEngine engine = e.getTSEngine();
        
        // See if this solution deserves more iterations
        if(
        ( engine.getCurrentIteration() - engine.getIterationOfBestSolution() )
        <
        recencyOfLastBestNeededToGiveMoreIterations )
        {   
            // Giving more iterations to this engine.
            totalEstimatedIterations += extraIterationsToGiveASolution;
            engine.startSolving( extraIterationsToGiveASolution );
        }   // end if: there was a recent new best solution
        else    
        
        // See if there are more solutions to try
        if( nextSolutionToTry < initialSolutions.length )
        {
            // Only move on if there has been a new best solution
            // from a recent starting solution.
            if( numTriedSinceLastNewBest < numBadStartsBeforeQuitting )
            {
                SimpleTSSolver.out( "SimpleTSRunner: new starting solution ("
                + (nextSolutionToTry+1) + " of " 
                + (initialSolutions.length) + ")" );
                
                engine.setCurrentSolutionToCopyOf( 
                    initialSolutions[ nextSolutionToTry++ ] );
                engine.setBestSolutionToCopyOf(
                    engine.getCurrentSolution() );
                numTriedSinceLastNewBest++;
                //this.aBestSolutionWasFoundOnThisStartingSolution = false;
                engine.startSolving( defaultIterationsPerSolution );
            }   // end if: okay, keep solving
            else
            {   // Nope, just quit
                fillInRestOfPercentage();
                this.finishedSolving = true;
                synchronized( this )
                {   this.notifyAll();
                }   // end sync
            }   // end else: nope, just quit
        }   // end else if: move on to next solution
        else    
        
        // Must be done.
        {
            fillInRestOfPercentage();
            this.finishedSolving = true;
            synchronized( this )
            {   this.notifyAll();
            }   // end sync
        }   // end else: done.
        
    }   // end engineFinished
    
}   // end class SimpleTSRunner