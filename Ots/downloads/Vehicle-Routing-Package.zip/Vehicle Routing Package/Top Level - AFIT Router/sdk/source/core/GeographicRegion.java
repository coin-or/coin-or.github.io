/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.awt.*;
import java.io.*;
import java.util.*;

/**
 * Used by <code>RestrictedOperatingZone</code> to specify a region
 * on the ground. This uses a <code>java.awt.Polygon</code> to maintain
 * the vertices. The latitudes and longitudes, which are normally stored
 * as doubles, are multiplied by <code>GeographicRegion.DOUBLE_TO_INT_MULTIPLIER</code>
 * since a <code>Polygon</code> only stores ints. A <code>java.awt.geom.GeneralPath</code>
 * would be easier to use, but it's only supported in Java 2 v1.2 and later.
 * I wanted to keep compatibility with Java 1.1.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @since 1.0
 * @version 1.0
 * @see RestrictedOperatingZone
 * @see java.awt.Polygon
 */
public class GeographicRegion 
extends Observable 
implements Serializable
{
    private static int idCounter = 1;
    
    public static final int DOUBLE_TO_INT_MULTIPLIER = 1000000;
    
    //private GeneralPath path = new GeneralPath();
    private transient int id;
    private Polygon polygon;
    private double[][] realVertices = new double[0][];
    
    /**
     * Constructs an empty geographic region.
     *
     * @since 1.0
     */
    public GeographicRegion()
    {   
        this.id = idCounter++;
    }   // end constructor
    
    /**
     * Constructs a region based on the vertices given by the matrix
     * <var>verticeslatLong</var>. Each sub-array should be of length two
     * and contain a latitude in the [][0] position and a longitude in the
     * [][1] position.
     *
     * @since 1.0
     * @param verticesLatLong n x 2 matrix of vertices
     */
    public GeographicRegion( double[][] verticesLatLong )
    {   
        this.id = idCounter++;
        
        this.realVertices = verticesLatLong;
        
        // Polygon
        int[] lat = new int[ verticesLatLong.length ];
        int[] lon = new int[ verticesLatLong.length ];
        
        for( int i = 0; i < verticesLatLong.length; i++ )
        {   lat[i] = (int) (DOUBLE_TO_INT_MULTIPLIER 
                * verticesLatLong[i][0] );
            lon[i] = (int) (DOUBLE_TO_INT_MULTIPLIER 
                * verticesLatLong[i][1] );
        }   // end for: through each vertex
        
        polygon = new Polygon( lon, lat, lat.length );
        
    }   // end constructor
    
    /**
     * Returns the polygon associated with the region.
     *
     * @since 1.0
     * @return polygon associated with the region
     * @see java.awt.Polygon
     */
    public final Polygon getPolygon()
    {   return polygon;
    }   // end getPath
    
    /**
     * Returns the latitudes and longitudes in a matrix of doubles.
     * Unlike the polygon, these points are actual lat/lon values
     * where positive is north and east.
     *
     * @return lat/lon vertices
     * @since 1.0
     */
    public final double[][] getVertices()
    {   return realVertices;
    }   // end getVertices
    
    /** 
     * Returns <code>true</code> if the given latitude and longitude
     * are contained in the region. This accounts for the double to int
     * conversion.
     *
     * @param lat latitude of point
     * @param lon longitude of point
     * @since 1.0
     */
    public final boolean contains( double lat, double lon )
    {   return polygon == null ? false : 
            polygon.contains( 
            (int) ( DOUBLE_TO_INT_MULTIPLIER * lon ), 
            (int) ( DOUBLE_TO_INT_MULTIPLIER * lat ) );
    }   // end contains
    
    /**
     * Return an automatically-assigned id for this region. This id
     * does not persist after serialization. It's probably not a good
     * thing to use.
     *
     * @return id of region
     * @since 1.0
     */
    public final int getID()
    {   return id;
    }   // end getID
    
    
    public String toString()
    {
        StringBuffer s = new StringBuffer("[" + (realVertices.length==0?"]":" ") );
        for( int i = 0; i < realVertices.length; i++ )
        {   for( int j = 0; j < realVertices[i].length; j++ )
                s.append( 
                (j==0 ? "(" : "" ) 
                + realVertices[i][j] 
                + (j<realVertices[i].length-1?", ":")") );
            s.append( i < realVertices.length-1 ? ", " : " ]" );
        }   // end for: through each pair
        return s.toString();
    }   // end toString
    
}   // end class GeographicRegion