/*  AFIT Router for Airframes
    Robert Harder
    rharder@usa.net
    
    This code is public domain. While you are free to use this
    code however you like, I would appreciate a brief mention
    if you used it and a pointer to its web site:
        http://www.crosswinds.net/~rharder/afit/router/
 */
package mil.af.afit.router;

import java.io.*;
import java.util.*;

/**
 * This class saves various preferences for a <code>Kernel</code> and optionally
 * for any application that uses the kernel. Although some methods are available
 * for use by specific components of this software package, any code interested
 * in saving information (for example: window positions or last directory accessed)
 * can use the <code>getProperty</code> and <code>setProperty</code> methods to
 * save strings.
 *
 * @author Robert Harder
 * @author rharder@usa.net
 * @version 1.0
 * @since 1.0
 * @see Kernel
 */
public class Preferences 
extends Observable 
implements Externalizable
{
//    private Hashtable hashtable;
    private Properties properties;
    private final static String PROPERTIES_HEADER = "Preferences";
    
    // Standard keys

    /**
     * Default x position of upper left corner for new windows.
     * @since 1.0
     */
    public final static String WINDOW_DEFAULT_X = "window.default.x";

    /**
     * Default y position of upper left corner of new windows.
     * @since 1.0
     */
    public final static String WINDOW_DEFAULT_Y = "window.default.y";

    /**
     * Default vehicle speed (in knots) for new vehicles.
     * @since 1.0
     */
    public final static String VEHICLE_DEFAULT_SPEED = "vehicle.default.speed";

    /**
     * Default vehicle altitude (in feet) for new vehicles.
     * @since 1.0
     */
    public final static String VEHICLE_DEFAULT_ALTITUDE = "vehicle.default.altitude";

    /**
     * Default vehicle range (in hours) for new vehicles.
     * @since 1.0
     */
    public final static String VEHICLE_DEFAULT_RANGE = "vehicle.default.range";

    /**
     * Default site priority for new sites.
     * @since 1.0
     */
    public final static String SITE_DEFAULT_PRIORITY = "site.default.priority";

    /**
     * Default site service (loiter) time for new sites.
     * @since 1.0
     */
    public final static String SITE_DEFAULT_SERVICE_TIME = "site.default.servicetime";

    /**
     * Name of last solver that was used.
     * @since 1.0
     */
    public final static String SOLVER = "solver.lastused.classname";

    /**
     * Amount of effort specified.
     * @since 1.0
     */
    public final static String EFFORT = "solver.effort";

    /**
     * Whether or not to use the extra post-optimization when solving.
     * @since 1.0
     */
    public final static String USE_POST_OPT = "solver.postoptimization.use";

    /**
     * Number of threads to specify for solvers to use.
     * @since 1.0
     */
    public final static String THREADS = "solver.threads.count";

    /**
     * Header used when saving preferences to a file.
     * @since 1.0
     */
    public final static String HEADER = "AFIT Router Preferences";
        
    
    private final static int defaultX = 5;
    private final static int defaultY = 5;
    private final static String defaultSolver = "";
    private final static double defaultEffort = .25;
    private final static int defaultThreads = 2;
    private final static boolean defaultUsePostOpt = false;
    private final static int defaultServiceTime = 10;
    private final static int defaultPriority = 3;
    
    
    /**
     * Constructs preferences with default values.
     *
     * @since 1.0
     */
    public Preferences()
    {   
        //hashtable = new Hashtable();
        // Try Prefs by using java.util.Properties
        properties = new Properties();
        setDefaultWindowXPosition( defaultX );
        setDefaultWindowYPosition( defaultY );
//        setLastSolverUsed( defaultSolver );
        setUsePostOptimization( defaultUsePostOpt );
        setLastRequestedSolutionEffort( defaultEffort );
        setLastNumberOfThreads( defaultThreads );
        setDefaultServiceTime( defaultServiceTime );
        setDefaultPriority( defaultPriority );
        //setSaveSitesWithKernel( true );
        
    }   // end constructor
    
    
    
/* ********  G E T   M E T H O D S  ******** */
    
   
    /**
     * Returns the default x position to use on new windows.
     *
     * @return default x position for new windows
     * @since 1.0
     */
    public final synchronized int getDefaultWindowX()
    {   try
        {   Integer i = new Integer( properties.getProperty( WINDOW_DEFAULT_X ) );
            return i != null ? i.intValue() : defaultX;
        }   // end try
        catch( Exception e )
        {   return defaultX;
        }   // end catch
    }   // end getDefaultWindowX
    
   
    /**
     * Returns the default y position to use on new windows.
     *
     * @return default y position for new windows
     * @since 1.0
     */
    public final synchronized int getDefaultWindowY()
    {   try
        {   Integer i = new Integer( properties.getProperty( WINDOW_DEFAULT_Y ) );
            return i != null ? i.intValue() : defaultY;
        }   // end try
        catch( Exception e )
        {   return defaultY;
        }   // end catch
    }   // end getDefaultWindowY
    
   
    /**
     * Returns the name of the last solver used.
     *
     * @return name of last solver used
     * @since 1.0
     * @see mil.af.afit.uvr.HSolver
     */
/*    public final synchronized String getLastSolverUsed()
    {   try
        {   String s = properties.getProperty( SOLVER );
            return s != null ? s : defaultSolver;
        }   // end try
        catch( Exception e )
        {   return defaultSolver;
        }   // end catch
    }   // end getLastSolverUsed
    */
   
    /**
     * Returns whether or not to use the extra post-optimization when solving.
     * The post-op uses a tabu search that adds to the solve time but may 
     * yield better answers on complicated problems.
     *
     * @return whether or not to use post-optimization
     * @since 1.0.2
     * @see mil.af.afit.uvr.HSolver
     */
    public final synchronized boolean usePostOptimization()
    {   try
        {   Boolean b = new Boolean( properties.getProperty( USE_POST_OPT ) );
            return b != null ? b.booleanValue() : defaultUsePostOpt;
        }   // end try
        catch( Exception e )
        {   return defaultUsePostOpt;
        }   // end catch
    }   // end usePostOptimization
    
   
    /**
     * Returns the amount of effort (from zero to one) requested by the user.
     *
     * @return effort requested by user
     * @since 1.0
     */
    public final synchronized double getLastRequestedSolutionEffort()
    {   try
        {   Double d = new Double( properties.getProperty( EFFORT ) );
            return d != null ? d.doubleValue() : defaultEffort;
        }   // end try
        catch( Exception e )
        {   return defaultEffort;
        }   // end catch
    }   // end getLastRequestedSolutionEffort
    
   
    /**
     * Returns the number of threads that solvers should try to use. This is
     * sometimes helpful on multiprocessor computers.
     *
     * @return threads to use
     * @since 1.0
     */
    public final synchronized int getLastNumberOfThreads()
    {   try
        {   Integer i = new Integer( properties.getProperty( THREADS ) );
            return i != null ? i.intValue() : defaultThreads;
        }   // end try
        catch( Exception e )
        {   return defaultThreads;
        }   // end catch
    }   // end getLastNumberOfThreads
    
   
    /**
     * Returns the default service (loiter) time (in minutes) for sites.
     *
     * @return default service time for sites
     * @since 1.0
     * @see Site
     */
    public final synchronized int getDefaultServiceTime()
    {   try
        {   Integer i = new Integer( properties.getProperty( SITE_DEFAULT_SERVICE_TIME ) );
            return i != null ? i.intValue() : defaultServiceTime;
        }   // end try
        catch( Exception e )
        {   return defaultServiceTime;
        }   // end catch
    }   // end getDefaultServiceTime
    
   
    /**
     * Returns the default priority for sites.
     *
     * @return default priority for sites
     * @since 1.0
     * @see Site
     */
    public final synchronized int getDefaultPriority()
    {   try
        {   Integer i = new Integer( properties.getProperty( SITE_DEFAULT_PRIORITY ) );
            return i != null ? i.intValue() : defaultPriority;
        }   // end try
        catch( Exception e )
        {   return defaultPriority;
        }   // end catch
    }   // end getDefaultPriority
    
    
   
    /**
     * Returns the property stored by <var>key</var>.
     *
     * @return property stored by <var>key</var>
     * @param key key for property to retrieve
     * @since 1.0
     */
    public final synchronized String getProperty( String key )
    {   try
        {   return properties.getProperty( key );
        }   // end try
        catch( Exception e )
        {   return null;
        }   // end catch
    }   // end getClientProperty
    
    
   
    /**
     * Returns all the properties contained in the preferences.
     *
     * @return all properties
     * @since 1.0
     * @see java.util.Properties
     */
    public final Properties getProperties()
    {   return properties;
    }   // end getProperties
    
    
/* ********  S E T   M E T H O D S  ******** */
    
    
   
    /**
     * Sets the default x position for new windows.
     *
     * @param x default x position for new windows.
     * @since 1.0
     */
    public final synchronized void setDefaultWindowXPosition( int x )
    {   properties.put( WINDOW_DEFAULT_X, ""+x );
        this.setChanged();
        this.notifyObservers();
    }   // end setDefaultWindowXPosition
    
   
    /**
     * Sets the default y position for new windows.
     *
     * @param x default y position for new windows.
     * @since 1.0
     */
    public final synchronized void setDefaultWindowYPosition( int y )
    {   properties.put( WINDOW_DEFAULT_Y, ""+y );
        this.setChanged();
        this.notifyObservers();
    }   // end setDefaultWindowYPosition
    
    
   
    /**
     * Sets whether or not to use post-optimization when solving.
     *
     * @param state whether or not to use post-optimization when solving
     * @since 1.0
     */
    public final synchronized void setUsePostOptimization( boolean state )
    {   properties.put( USE_POST_OPT, ""+state );
        this.setChanged();
        this.notifyObservers();
    }   // end setUsePostOptimization
    
   
    /**
     * Sets the effort to use when solving.
     *
     * @param effort effort to use when solving
     * @since 1.0
     */
    public final synchronized void setLastRequestedSolutionEffort( double effort )
    {   properties.put( EFFORT, ""+effort );
        this.setChanged();
        this.notifyObservers();
    }   // end setLastRequestedSolutionEffort
    
   
    /**
     * Sets the number of threads for solvers to try to use.
     *
     * @param threads the number of threads for solvers to try to use.
     * @since 1.0
     */
    public final synchronized void setLastNumberOfThreads( int threads )
    {   properties.put( THREADS, ""+Math.max(1,threads) );
        this.setChanged();
        this.notifyObservers();
    }   // end setLastNumberOfThreads
    
   
    /**
     * Sets the default service (loiter) time (in minutes) for new sites.
     *
     * @param time the default service (loiter) time (in minutes) for new sites.
     * @since 1.0
     */
    public final synchronized void setDefaultServiceTime( int time )
    {   properties.put( SITE_DEFAULT_SERVICE_TIME, ""+time );
        // Set static value in Site
        Site.setDefaultServiceTime( time );
        this.setChanged();
        this.notifyObservers();
    }   // end setLastNumberOfThreads
    
   
    /**
     * Sets the default priority for new sites.
     *
     * @param time the default priority for new sites.
     * @since 1.0
     */
    public final synchronized void setDefaultPriority( int priority )
    {   properties.put( SITE_DEFAULT_PRIORITY, ""+priority );
        // Set static value in Site
        Site.setDefaultPriority( priority );
        this.setChanged();
        this.notifyObservers();
    }   // end setLastNumberOfThreads
    
    
   
    /**
     * Sets a property stored in <var>key</var>. Works like <code>java.util.Properties</code>.
     *
     * @param key key for storing the property
     * @param thing property to store
     * @since 1.0
     * @see java.util.Properties
     */
    public final synchronized void setProperty( 
    String key, String thing )
    {   properties.put( key, thing );
        this.setChanged();
        this.notifyObservers();
    }   // end setClientProperty
    

/* ********  R E P L A C E   C O D E  ******** */

    /**
     * Replaces these preferences with <var>newPrefs</var>. This is used
     * when loading a new <code>Kernel</code>. <code>Observer</code>s
     * registered with the original preferences will still be registered, but
     * anything registered with <var>newPrefs</var> will not still
     * be registered.
     *
     * @param newPrefs the new preferences to use
     * @since 1.0
     */
    public final void replace( Preferences newPrefs )
    {   //this.hashtable = newPrefs.getHashtable();
        this.properties = newPrefs.getProperties();
        this.setChanged();
        this.notifyObservers();
    }   // end replace
    

    /**
     * Replaces these preferences with the properties stored in
     * <var>props</var>. This is identical in nature to the
     * <code>replace( newPrefs )</code> method.
     *
     * @param props the properties for the new preferences to use
     * @since 1.0
     */
    public final void replace( Properties props )
    {   this.properties = props;
        this.setChanged();
        this.notifyObservers();
    }   // end replace
    

    
/* ********  S E R I A L I Z A B L E   C O D E  ******** */
    
/*    
    private void readObject( ObjectInputStream in )
    throws IOException, ClassNotFoundException
    {   //in.defaultReadObject();
        
        
        try
        {   Site.setDefaultServiceTime( getDefaultServiceTime() );
            Site.setDefaultPriority( getDefaultPriority() );
        }   // end try
        catch( Exception e )
        {   Kernel.err( e );
        }   // end catch
    }   // end readObject
*/    
    
/* ********  E X T E R N A L I Z A B L E   C O D E  ******** */    
    
    /**
     * Needs an InputStream to work properly.
     */
    public void readExternal( ObjectInput oi )
    throws IOException
    {   try
        {   if( oi instanceof InputStream )
            {   InputStream in = (InputStream) oi;
                properties.load( in );
                Site.setDefaultServiceTime( getDefaultServiceTime() );
                Site.setDefaultPriority( getDefaultPriority() );
            }   // end if: oi is an input stream
            else {}
        }   // end try
        catch( Exception e )
        {   Kernel.err( e );
        }   // end catch
    }   // end readExternal
    
    /**
     * Needs an OutputStream to work properly.
     */
    public void writeExternal( ObjectOutput oo )
    throws IOException
    {   try
        {   if( oo instanceof OutputStream )
            {   OutputStream out = (OutputStream) oo;
                properties.save( out, PROPERTIES_HEADER );
            }   // end if: oo is output stream
        }   // end try
        catch( Exception e )
        {   Kernel.err( e );
        }   // end catch
    }   // end writeExternal
    
}   // end class Preferences