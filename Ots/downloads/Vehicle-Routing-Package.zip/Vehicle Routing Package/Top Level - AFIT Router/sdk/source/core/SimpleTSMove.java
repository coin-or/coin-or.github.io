/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.router.simpletabusearch;

import net.usa.rharder.tabusearch22.*;
import mil.af.afit.uvr.*;

class SimpleTSMove implements TSMove
{
    //private HTour fromTour = null;
    //private HTour toTour = null;
    private int fromTourNum = -1;
    private int toTourNum = -1;
    private int fromPosition = -1;
    private int toPosition = -1;
    private HOrder orderToMove = null;
    private SimpleTSMove followUpMove=null;
    
    public SimpleTSMove( int fromTourNum, int fromPosition,
    int toTourNum, int toPosition, HOrder orderToMove,
    SimpleTSMove followUpMove )
    {   this.fromTourNum = fromTourNum;
        this.fromPosition = fromPosition;
        this.toTourNum = toTourNum;
        this.toPosition = toPosition;
        this.orderToMove = orderToMove;
        this.followUpMove = followUpMove;
    }   // end constructor
    
    
    
    
    
/* ********  G E T   M E T H O D S  ******** */
    
    protected int getFromTourNum()
    {   return fromTourNum;
    }   // end getFromTourNum
    
    protected int getToTourNum()
    {   return toTourNum;
    }   // end getToTourNum
    
    protected int getFromPosition()
    {   return fromPosition;
    }   // end getFromPosition
    
    protected int getToPosition()
    {   return toPosition;
    }   // end getToPosition
    
    protected SimpleTSMove getFollowUpMove()
    {   return followUpMove;
    }   // end getFollowUpMove
    
    protected HOrder getHOrderToMove()
    {   return orderToMove;
    }   // end getOrderToMove
    
    
/* ********  S E T   M E T H O D S  ******** */
    
    protected final void setAllParameters( 
    int fromTourNum, int fromPosition,
    int toTourNum, int toPosition, HOrder orderToMove,
    SimpleTSMove followUpMove )
    {   this.fromTourNum = fromTourNum;
        this.fromPosition = fromPosition;
        this.toTourNum = toTourNum;
        this.toPosition = toPosition;
        this.orderToMove = orderToMove;
        this.followUpMove = followUpMove;
    }   // end setAllParameters
    
    protected final void setFromTourNum( int fromTourNum )
    {   this.fromTourNum = fromTourNum;
    }   // end setFromTourNum
    
    protected final void setToTourNum( int toTourNum )
    {   this.toTourNum = toTourNum;
    }   // end setToTourNum
    
    protected final void setFromPosition( int fromPosition )
    {   this.fromPosition = fromPosition;
    }   // end setFromPosition
    
    protected final void setToPosition( int toPosition )
    {   this.toPosition = toPosition;
    }   // end setToPosition
    
    protected final void setFollowUpMove( SimpleTSMove followUpMove )
    {   this.followUpMove = followUpMove;
    }   // end setFollowUpMove
    
    protected final void addFollowUpMove( SimpleTSMove followUpMove )
    {   if( this.followUpMove == null )
            this.followUpMove = followUpMove;
        else
            this.followUpMove.addFollowUpMove( followUpMove );
    }   // end addFollowUpMove
    
    protected final void setHOrderToMove( HOrder orderToMove )
    {   this.orderToMove = orderToMove;
    }   // end setHOrderToMove
    
/* ********  T S M O V E   C O D E  ******** */
    
    public final boolean conflictsWith( TSMove move )
    {   return true;
    }   // end conflictsWith
    
    public final void operateOn( TSSolution solution )
    {
        // If any of the parameters are negative, then treat
        // as a NO-OP move (no operation)
        if( 
        fromTourNum >= 0 && toTourNum >= 0 &&
        fromPosition >= 0 && toPosition >= 0 )
        {
            // Make the swap.
            HSolution soln = ( (SimpleTSSolution) solution ).getHSolution();
            HTour fromTour = fromTourNum < 0 
                ? soln.getDummyHTour()
                : soln.getHTours()[fromTourNum];
            HTour toTour = toTourNum < 0
                ? soln.getDummyHTour()
                : soln.getHTours()[toTourNum];
            HOrder order = fromTour.getHOrderAt(fromPosition);
            fromTour.removeHOrderAt(fromPosition);
            toTour.insertHOrderAt( order, toPosition );
            
            // If there's a follow up move, do it.
            if( followUpMove != null )
                followUpMove.operateOn( solution );

            soln.invalidate();
        }   // end if: not a NO-OP move
    }   // end operateOn
    
    public final void undoOperation( TSSolution solution )
    {
        // If any of the parameters are negative, then treat
        // as a NO-OP move (no operation)
        if( 
        fromTourNum >= 0 && toTourNum >= 0 &&
        fromPosition >= 0 && toPosition >= 0 )
        {
            // To undo properly, try to undo the follow up move first
            if( followUpMove != null )
                followUpMove.undoOperation( solution );
            
            // Make the swap.
            HSolution soln = ( (SimpleTSSolution) solution ).getHSolution();
            HTour fromTour = fromTourNum < 0 
                ? soln.getDummyHTour()
                : soln.getHTours()[fromTourNum];
            HTour toTour = toTourNum < 0
                ? soln.getDummyHTour()
                : soln.getHTours()[toTourNum];
            HOrder order = toTour.getHOrderAt(toPosition);
            toTour.removeHOrderAt(toPosition);
            fromTour.insertHOrderAt( order, fromPosition );
            
            soln.invalidate();
        }   // end if: not a NO-OP move
    }   // end undoOperation
    
    
/* ********  M I S C E L L A N E O U S   M E T H O D S  ******** */
    
    public final int hashCode()
    {
        int hash=1;
        
        hash *= fromTourNum<=0?-30000000:fromTourNum*10;
        hash *= toTourNum<=0?-40000:toTourNum*1000;
        hash *= fromPosition==0?1233445:fromPosition*100000;
        hash *= toPosition==0?-3985024:toPosition*10000000;
        hash *= followUpMove != null ? followUpMove.hashCode() : 1;
        
        return hash;
    }   // end hashCode
    
    
    public String toString()
    {
        StringBuffer s = new StringBuffer();
        s.append( "[fromTourNum=" + fromTourNum +
            ", toTourNum=" + toTourNum + ", fromPosition=" +
            fromPosition + ", toPosition=" + toPosition + "]" );
        return s.toString();
    }   // end toString
    
}   // end class SimpleTSMove