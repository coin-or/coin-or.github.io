/*  This code uses the Java Tabu Search Package written by Robert Harder
    and available at http://www.crosswinds.net/~rharder/tabusearch/
 */
package mil.af.afit.router.simpletabusearch;

import net.usa.rharder.tabusearch22.*;
import mil.af.afit.uvr.*;

class SimpleTSObjectiveFunction implements TSFunction
{
    private HEvaluator evaluator = null;
    
    public SimpleTSObjectiveFunction( HEvaluator evaluator )
    {   this.evaluator = evaluator;
    }   // end constructor
    
    
/* ********  T S F U N C T I O N   C O D E  ******** */
    
    
    public final double[] evaluate( TSSolution solution )
    {
        HSolution soln = ( (SimpleTSSolution) solution ).getHSolution();
        
        // If I need to update the solution, do it here.
        soln.validate( evaluator );

        return soln.getCosts();
    }   // end evaluate
    

}   // end class SimpleTSObjectiveFunction