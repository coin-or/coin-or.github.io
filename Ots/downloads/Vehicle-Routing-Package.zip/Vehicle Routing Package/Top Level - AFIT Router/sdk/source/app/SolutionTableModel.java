package mil.af.afit.router.app;
import mil.af.afit.router.*;
import mil.af.afit.uvr.*;

import com.ibm.sort.SortBean;

import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import java.io.*;

public class SolutionTableModel 
extends AbstractTableModel 
implements ClipboardAccessPanelSource, Observer
{
    private Kernel kernel;
    private Solution solution;
    private Class[] columnClasses;
    private String[] columnNames;
    private int[] columnOrder;
    private JTable hostTable;
    private SolutionRow[] data;
    private SortBean sortBean = new SortBean();
    
    protected final static int 
        NAME = 0,
        LATITUDE = 1,
        LONGITUDE = 2,
        PRIORITY = 3,
        VEHICLE = 4,
        ARRIVAL = 5,
        DEPARTURE = 6,
        ORIGINAL_ORDER = 7,
        WAIT_TIME = 8,
        COMPLETED = 9,
        NUM_OF_COLUMNS = 10;
    
    public SolutionTableModel( Solution solution, Kernel kernel )
    {   super();
        this.solution = solution;
        this.kernel = kernel;
        kernel.getSiteList().addObserver(this);
        setupColumnOrder();
        setupColumnNames();
        setupColumnClasses();
        setupSolutionData();
    }   // end constructor
    
    public final void setHostTable( JTable table )
    {   this.hostTable = table;
    }   // end setHostTable
    
    private final void setupSolutionData()
    {
        HSolution hSoln = solution.getHSolution();
        hSoln.validateTours();
        HTour[] tours = hSoln.getHTours();
        HTour dTour = hSoln.getDummyHTour();
        
        // Count the number of sites in the whole solution
        int count = 0;
        for( int i = 0; i < tours.length; i++ )
            count += tours[i].size();
        count += dTour.size();
        
        // Establish data size
        data = new SolutionRow[ count ];
        
        // Go back through each tour with sites and make data
        int nextSolutionRow = 0;
        for( int i = 0; i < tours.length; i++ )
        {   if( tours[i].size() > 0 )
            {   final HTour tour = tours[i];
                final UVRVehicle uVehicle = (UVRVehicle)tour.getHVehicle();
                for( int j = 0; j < tour.size(); j++ )
                {   final UVRSite uSite = (UVRSite)tour.getHOrderAt(j);
                    final SolutionRow row = createSolutionRow( 
                        tour, j, nextSolutionRow );
                    data[nextSolutionRow] = row;
                    nextSolutionRow++;
                }   // end for: through each site
            }   // end if: tour not empty
        }   // end for: through each tour
        // Dummy tour
        {   final UVRVehicle uVehicle = (UVRVehicle)dTour.getHVehicle();
            for( int j = 0; j < dTour.size(); j++ )
            {   final UVRSite uSite = (UVRSite)dTour.getHOrderAt(j);
                final SolutionRow row = createSolutionRow( 
                    dTour, j, nextSolutionRow );
                data[nextSolutionRow] = row;
                nextSolutionRow++;
            }   // end for: through each site
        }   // end dummy tour
        
    }   // end setupSolutionData
    
    //private final SolutionRow createSolutionRow( 
    //UVRVehicle uVehicle, UVRSite uSite, int originalRowNumber )
    private final SolutionRow createSolutionRow( 
    HTour tour, int orderNum, int originalRowNumber )
    {
        UVRVehicle uVehicle = (UVRVehicle) tour.getHVehicle();
        UVRSite uSite = (UVRSite) tour.getHOrderAt( orderNum );
        
        Object[] row = new Object[ NUM_OF_COLUMNS ];
        
        row[columnOrder[ORIGINAL_ORDER]] = new Integer( originalRowNumber+1  );
        row[columnOrder[VEHICLE]] = uVehicle == null
            ? "NOT VISITED"
            : uVehicle.getParentVehicle().getName();
        row[columnOrder[NAME]] = uSite.getParentSite().getName();
        row[columnOrder[LATITUDE]] = CoreUtilities.doubleLatToString(
            uSite.getParentSite().getLatitude(), kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT) );
        row[columnOrder[LONGITUDE]] = CoreUtilities.doubleLonToString(
            uSite.getParentSite().getLongitude(), kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT) );
        row[columnOrder[PRIORITY]] = new Integer( 
            uSite.getParentSite().getPriority() );
        row[columnOrder[ARRIVAL]] = CoreUtilities.intTimeToString(
            (int)tour.getEstimatedArrivalTime(orderNum) );
        row[columnOrder[DEPARTURE]] = CoreUtilities.intTimeToString(
            (int)tour.getEstimatedDepartureTime(orderNum) );
        int wait = (int)tour.getEstimatedWaitTime(orderNum);
            //Math.max( 0,
            //(int)(uSite.getEarliestArrivalTime() -
            //tour.getEstimatedArrivalTime(orderNum) ) );
        String s = "" + ((int)wait/60) + "h " + ((int)wait%60) + "m";
        row[columnOrder[WAIT_TIME]] = uVehicle == null || wait == 0 ? "" : s;
        //row[columnOrder[COMPLETED]] = new Boolean( !uSite.getParentSite().isEnabled());
        
        return new SolutionRow( row, columnOrder, tour, orderNum );
    }   // end create row
    
    
    private void setupColumnOrder()
    {
        // For now, fixed
        columnOrder = new int[ getColumnCount() ];
        columnOrder[COMPLETED] = 0;
        columnOrder[VEHICLE] = 1;
        columnOrder[NAME] = 2;
        columnOrder[LATITUDE] = 3;
        columnOrder[LONGITUDE] = 4;
        columnOrder[PRIORITY] = 5;
        columnOrder[ARRIVAL] = 6;
        columnOrder[WAIT_TIME] = 7;
        columnOrder[DEPARTURE] = 8;
        columnOrder[ORIGINAL_ORDER] = 9;
    }   // end setupColumnOrder
    
    private void setupColumnNames()
    {
        columnNames = new String[ getColumnCount() ];
        columnNames[NAME] = "Name";
        columnNames[VEHICLE] = "Vehicle";
        columnNames[LATITUDE] = "Latitude";
        columnNames[LONGITUDE] = "Longitude";
        columnNames[PRIORITY] = "Priority";
        columnNames[ARRIVAL] = "Arrival Time";
        columnNames[DEPARTURE] = "Departure Time";
        columnNames[ORIGINAL_ORDER] = "Sequence";
        columnNames[WAIT_TIME] = "Slop time";
        columnNames[COMPLETED] = "Completed";
    }   // end setupColumnNames
    
    private void setupColumnClasses()
    {
        columnClasses = new Class[ getColumnCount() ];
        columnClasses[NAME] = String.class;
        columnClasses[VEHICLE] = String.class;
        columnClasses[LATITUDE] = String.class;
        columnClasses[LONGITUDE] = String.class;
        columnClasses[PRIORITY] = Integer.class;
        columnClasses[ARRIVAL] = String.class;
        columnClasses[DEPARTURE] = String.class;
        columnClasses[ORIGINAL_ORDER] = Integer.class;
        columnClasses[WAIT_TIME] = String.class;
        columnClasses[COMPLETED] = Boolean.class;
    }   // end setupColumnClasses
    
/* ********  ClipboardAccessPanelSource   C O D E  ******** */
    
    
    public String getClipboardText()
    {   try
        {   ByteArrayOutputStream baos = new ByteArrayOutputStream();
            write( baos, true ); // write in the table format
            baos.close();
            return baos.toString();
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
            return null;
        }   // end catch
    }   // end getClipboardText
    
    
/* ********  S O R T I N G   C O D E  ******** */
    
    public final boolean isColumnSortable( int modelColumn )
    {   return true;
    }   // end isColumnSortable
    
    public final void sort( int modelColumn, boolean ascending )
    {
        if( modelColumn == columnOrder[VEHICLE] )
            sortByVehicle( ascending );
        else if( modelColumn == columnOrder[NAME] )
            sortByName( ascending );
        else if( modelColumn == columnOrder[LATITUDE] )
            sortByLatitude( ascending );
        else if( modelColumn == columnOrder[LONGITUDE] )
            sortByLongitude( ascending );
        else if( modelColumn == columnOrder[ARRIVAL] )
            sortByArrival( ascending );
        else if( modelColumn == columnOrder[DEPARTURE] )
            sortByDeparture( ascending );
        else if( modelColumn == columnOrder[PRIORITY] )
            sortByPriority( ascending );
        else if( modelColumn == columnOrder[ORIGINAL_ORDER] )
            sortByOriginalOrder( ascending );
        else if( modelColumn == columnOrder[COMPLETED] )
            sortByCompleted( ascending );
        else if( modelColumn == columnOrder[WAIT_TIME] )
            sortByWaitTime( ascending );
    }   // end sort
    
    private final void sortByVehicle( boolean ascending )
    {   sortByMethod("getVehicle", ascending );
    }   // end sortByVehicle
    
    private final void sortByName( boolean ascending )
    {   sortByMethod("getName", ascending );
    }   // end sortByName
    
    private final void sortByLatitude( boolean ascending )
    {   sortByMethod("getLatitude", ascending );
    }   // end sortByLatitude
    
    private final void sortByLongitude( boolean ascending )
    {   sortByMethod("getLongitude", ascending );
    }   // end sortByLongitude
    
    private final void sortByArrival( boolean ascending )
    {   sortByMethod("getArrival", ascending );
    }   // end sortByArrival
    
    private final void sortByDeparture( boolean ascending )
    {   sortByMethod("getDeparture", ascending );
    }   // end sortByDeparture
    
    private final void sortByPriority( boolean ascending )
    {   sortByMethod("getPriority", ascending );
    }   // end sortByPriority
    
    private final void sortByOriginalOrder( boolean ascending )
    {   sortByMethod("getOriginalOrder", ascending );
    }   // end sortByOriginalOrder
    
    private final void sortByCompleted( boolean ascending )
    {   sortByMethod("getCompletedString", ascending );
    }   // end sortByOriginalOrder
    
    private final void sortByWaitTime( boolean ascending )
    {   sortByMethod("getWaitTime", ascending );
    }   // end sortByOriginalOrder
    
    private final void sortByMethod( String method, boolean ascending )
    {   
        // Determine sort order
        sortBean.setAscending( ascending );

        // Sort
        Object[] sorted = null;
        try
        {   sorted = sortBean.sortObjectArray(
                data, method );
        }   // end try
        catch( Exception e )
        {   Kernel.err( e );
        }   // end catch
        
        // Update only if the sort worked
        if( sorted != null )
        {   for( int i = 0; i < sorted.length; i++ )
                this.data[i] = (SolutionRow)sorted[i];
            fireTableDataChanged();
        }   // end if: sort worked
    }   // end sortByMethod
    
    
    
/* ********  A B S T R A C T T A B L E M O D E L   C O D E  ******** */

    public final int getColumnCount()
    {   return NUM_OF_COLUMNS;
    }   // end getColumnCount
    
    public int getRowCount()
    {   return data != null 
            ? data.length
            : 0;
    }   // end getSolutionRowCount
    
    public boolean isCellEditable( int row, int column )
    {   return column == columnOrder[COMPLETED] ? true : false;
    }   // end isCellEditable   
    
    public String getColumnName( int column )
    {   int i = 0;
        while( columnOrder[i] != column && i < getColumnCount() )
            i++;
        if( i < getColumnCount() )
            return columnNames[ i ];
        else return null;
    }   // end getColumnName
    
    public Class getColumnClass( int column )
    {   int i = 0;
        while( columnOrder[i] != column && i < getColumnCount() )
            i++;
        if( i < getColumnCount() )
            return columnClasses[ i ];
        else return null;
    }   // end getColumnClass
    
    public Object getValueAt( int row, int column )
    {   return data == null
            ? null
            : data[row].dataAt(column);
    }   // end getValueAt
    
    public void setValueAt( Object value, int row, int column )
    {
        // The only editable field is the completed box
        if( column == columnOrder[COMPLETED] )
        {   Boolean state = null;
            if( value instanceof Boolean )
                state = (Boolean)value;
            else if( value instanceof String )
                try{ state = new Boolean((String)value);}
                catch(Exception e){e.printStackTrace();}
            if( state != null )
            {   data[row].setCompleted(state.booleanValue());
                //fireTableRowsUpdated(row,row);
                fireTableDataChanged();
            }   // end if: converted to boolean
        }   // end if: completed column
    }   // end setValueAt
    
    
/* ********  S I M P L E   O U T P U T   C O D E  ******** */
    
    public final void write( OutputStream out )
    {   write( out, true );    // Default is fixed output
    }   // end write
    
    public final void write( OutputStream os, boolean likeHostTable )
    {
        // This method writes the entire table to the stream
        // passed to it. The columns can be outputted in the
        // order in which they appear in the hostTable or
        // in a fixed order that can be read in later to add
        // sites to the project.
        
        // Convert output stream to PrintStream
        // This is marked depracated in Java 1.1 but was
        // reintroduced in Java 1.2
        PrintStream out = new PrintStream( os );
        
        // Set up mapping based on the host table or fixed way.
        // columnOutMapping contains the model column numbers
        // in sequence to output.
        int[] columnOutMapping = new int[0];
        if( likeHostTable && hostTable != null )
        {   // Like host table
            columnOutMapping = new int[ getColumnCount() ];
            for( int i = 0; i < columnOutMapping.length; i++ )
                columnOutMapping[i] = 
                    hostTable.convertColumnIndexToModel(i);
        }   // end if: like host table
        else
        {   // Fixed format
            // SiteName, Lat, Lon, Priority, Arrival, Departure, Vehicle
            columnOutMapping = new int[7];
            columnOutMapping[0] = columnOrder[ NAME ];
            columnOutMapping[1] = columnOrder[ LATITUDE ];
            columnOutMapping[2] = columnOrder[ LONGITUDE ];
            columnOutMapping[3] = columnOrder[ PRIORITY ];
            columnOutMapping[4] = columnOrder[ ARRIVAL ];
            columnOutMapping[5] = columnOrder[ DEPARTURE ];
            columnOutMapping[6] = columnOrder[ VEHICLE ];
        }   // end else: fixed format
        
        // Find a line separator
        //String LINE = System.getProperty( "line.separator" );
        //if( LINE == null || LINE.equals("") )
        //    LINE = "\n";
        String LINE = "\r";
        
        // Start writing data.
        for( int i = 0; i < data.length; i++ )
        {   for( int j = 0; j < columnOutMapping.length; j++ )
            {   out.print( data[i].dataAt(columnOutMapping[j]) + 
                    ( j==columnOutMapping.length-1 ? "" : "\t" ) );
            }   // end for: through each column
            out.print(LINE);
        }   // end for: through each row
        
        out.flush();
    }   // end write
    
    
/* *******  O B S E R V E R   C O D E  ******** */    
    
    public void update( Observable thing, Object arg )
    {   if( thing instanceof SiteList || arg instanceof SiteList )
            fireTableDataChanged();
    }   // end update
    
}   // end class SolutionTableModel