package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.util.*;

/**
 * Split pane for details and summary info
 */
public class SolutionDetailsPanel
extends JPanel
{
    private Kernel kernel = null;
    private Solution solution = null;
    private SolutionsTablePopupMenu tablePopupMenu;
    
	JSplitPane jspMainSplit;// = new JSplitPane();
	    JPanel pnlTopPanel;// = new JPanel();

	    JPanel pnlBottomPanel;// = new JPanel();
	        JScrollPane jscScrollPaneForSolutionsTable;// = new JScrollPane();
	            JTable tblSolutionsTable;// = new JTable();
                    SolutionTableModel mdlSolutionsTableModel;// = new SolutionsTableModel();
    
    
    public SolutionDetailsPanel( 
    Solution solution, Kernel kernel )
    {   super();
        this.solution = solution;
        this.kernel = kernel;
        this.setupLayout();
    }   // end constructor
    
    
    private final void setupLayout()
    {
        // Instantiate
        jspMainSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
	    pnlTopPanel = new JPanel(new BorderLayout());
	    
	    pnlBottomPanel = new JPanel(new BorderLayout());
            mdlSolutionsTableModel = new SolutionTableModel(solution,kernel);
	        tblSolutionsTable = new JTable(mdlSolutionsTableModel);
	        jscScrollPaneForSolutionsTable = new JScrollPane(tblSolutionsTable);
        
        
	    this.setLayout(new BorderLayout());
		this.add("Center",jspMainSplit);
		    jspMainSplit.setOneTouchExpandable(true);
		    jspMainSplit.setTopComponent( pnlTopPanel );
		        pnlTopPanel.add( new SolutionPanel( 
		            solution, kernel, 
		            false/*showDetailsButton*/,
		            mdlSolutionsTableModel), BorderLayout.CENTER );

		    jspMainSplit.setBottomComponent( pnlBottomPanel );
		        pnlBottomPanel.add(jscScrollPaneForSolutionsTable, BorderLayout.CENTER);
                        mdlSolutionsTableModel.setHostTable( tblSolutionsTable );
                        tblSolutionsTable.setCellSelectionEnabled(true);
                        tblSolutionsTable.setSelectionMode(
                            ListSelectionModel.MULTIPLE_INTERVAL_SELECTION );
                        new ExcelAdapter( tblSolutionsTable, ExcelAdapter.COPY );
        
        // Prepare popup menu for table
        tablePopupMenu = new SolutionsTablePopupMenu( mdlSolutionsTableModel );
        tblSolutionsTable.addMouseListener( new MouseAdapter()
        {   public void mousePressed( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    handleTablePopupMenu( e );
            }   // end mousePressed
            public void mouseClicked( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    handleTablePopupMenu( e );
            }   // end mouseClicked
            public void mouseReleased( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    handleTablePopupMenu( e );
            }   // end mouseReleased
        }); // end mouseAdapter,mouseListener
        
        this.validate();
    }   // end setupLayout
    
    
/* ********  P O P U P M E N U   C O D E  ******** */
    
    protected final void handleTablePopupMenu( MouseEvent e )
    {   tablePopupMenu.show( tblSolutionsTable, e.getX(), e.getY() );
    }   // end handleShowPopupMenu
    
    
    
    
}   // end class SolutionDetailsPanel