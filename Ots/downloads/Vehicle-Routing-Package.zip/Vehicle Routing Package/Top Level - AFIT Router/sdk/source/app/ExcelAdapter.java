package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.datatransfer.*;
import java.util.*;

/**
 * ExcelAdapter enables Copy-Paste Clipboard functionality on JTables.
 * The clipboard data format used by the adapter is compatible with
 * the clipboard format used by Excel. This provides for clipboard
 * interoperability between enabled JTables and Excel.
 */
public class ExcelAdapter implements ActionListener
{
    public final static int COPY = 1;
    public final static int PASTE = 2;
    public final static int BOTH = COPY | PASTE;
    public final static int NONE = 0;
    
    private final static String 
        NO_ACCESS_MESSAGE = "Clipboard access is blocked",
        COPY_SUCCEEDED = "Copied",
        COPY_FAILED = "Copy failed",
        PASTE_SUCCEEDED = "Pasted",
        PASTE_FAILED = "Paste failed";
    private final static int MILLIS_TO_DISPLAY_MESSAGE = 250;
    private static int menuShortcutKeyMask;
    
    private String rowstring,value;
    private Clipboard system;
    private StringSelection stsel;
    private JTable jTable1 ;
    boolean clipboardAccessGranted;
   

   /**
    * The Excel Adapter is constructed with a
    * JTable on which it enables Copy-Paste and acts
    * as a Clipboard listener.
    */
    public ExcelAdapter(JTable myJTable, int service )
    {
        menuShortcutKeyMask = myJTable.getToolkit().getMenuShortcutKeyMask();
    
      // If the clipboard is unavailable, don't even continue
      clipboardAccessGranted = false;
      try
      { SecurityManager sm = System.getSecurityManager();
        if( sm != null )
            sm.checkSystemClipboardAccess();
        clipboardAccessGranted = true;
      } // end try
      catch( SecurityException e )
      { clipboardAccessGranted = false;
      } // end catch
      if( clipboardAccessGranted )
      {
        boolean handlePasting = (service & PASTE) > 0;
        boolean handleCopying = (service & COPY) > 0;
          
        jTable1 = myJTable;
        KeyStroke copy = KeyStroke.getKeyStroke(KeyEvent.VK_C,menuShortcutKeyMask,false);

        // Identifying the copy KeyStroke user can modify this
        // to copy on some other Key combination.
        KeyStroke paste = KeyStroke.getKeyStroke(KeyEvent.VK_V,menuShortcutKeyMask,false);

        // Identifying the Paste KeyStroke user can modify this
        //to copy on some other Key combination.
    if( handleCopying )
        jTable1.registerKeyboardAction(this,"Copy",copy,JComponent.WHEN_FOCUSED);

    if( handlePasting )
        jTable1.registerKeyboardAction(this,"Paste",paste,JComponent.WHEN_FOCUSED);

        system = Toolkit.getDefaultToolkit().getSystemClipboard();
      } // end if: clipboard access granted
   }

   /**
    * Public Accessor methods for the Table on which this adapter acts.
    */
public JTable getJTable() {return jTable1;}

public void setJTable(JTable jTable1) {this.jTable1=jTable1;}

   /**
    * This method is activated on the Keystrokes we are listening to
    * in this implementation. Here it listens for Copy and Paste ActionCommands.
    * Selections comprising non-adjacent cells result in invalid selection and

    * then copy action cannot be performed.
    * Paste is done by aligning the upper left corner of the selection with the
    * 1st element in the current selection of the JTable.
    */
    public void actionPerformed(ActionEvent e)
    {
        if (e.getActionCommand().compareTo("Copy")==0)
        {   copy();
        }   // end if: copy
        else if (e.getActionCommand().compareTo("Paste")==0)
        {   paste();
        }   // end if: paste
    }   // end actionPerformed
   
    public void copy()
    {
        // If there's no clipboard access, bail quickly.
        if(  !this.clipboardAccessGranted )
        {   showMessage( NO_ACCESS_MESSAGE );
        }   // end if: no access to clipboard
        else
        {
            try
            {
                StringBuffer sbf=new StringBuffer();

                // Check to ensure we have selected only a contiguous block of
                // cells
                int numcols=jTable1.getSelectedColumnCount();
                int numrows=jTable1.getSelectedRowCount();
                int[] rowsselected=jTable1.getSelectedRows();
                int[] colsselected=jTable1.getSelectedColumns();

                if (!((numrows-1==rowsselected[rowsselected.length-1]-rowsselected[0] &&
                        numrows==rowsselected.length) &&
                        (numcols-1==colsselected[colsselected.length-1]-colsselected[0] &&
                        numcols==colsselected.length)))
                {
                    JOptionPane.showMessageDialog(null, "Invalid Copy Selection",
                                                "Invalid Copy Selection",
                                                JOptionPane.ERROR_MESSAGE);

                    return;
                }

                for (int i=0;i<numrows;i++)
                {
                    for (int j=0;j<numcols;j++)
                    {

                        sbf.append(jTable1.getValueAt(rowsselected[i],colsselected[j]));
                        if (j<numcols-1) sbf.append("\t");
                    }
                    sbf.append("\n");
                }

                stsel = new StringSelection(sbf.toString());
                system = Toolkit.getDefaultToolkit().getSystemClipboard();
                system.setContents(stsel,stsel);
                showMessage( COPY_SUCCEEDED );
            }   // end try
            catch( Exception e )
            {   showMessage( COPY_FAILED );
                AFITRouter.err( e );
            }   // end catch
            }   // end else: clipboard access approved
   }    // end copy
   
   
   public void paste()
   {
        // If there's no clipboard access, bail quickly.
        if( ! this.clipboardAccessGranted )
        {   showMessage( NO_ACCESS_MESSAGE );
        }   // end if: no access to clipboard
        else
        {
            try
            {
                AFITRouter.out("Trying to Paste");
                int startRow=(jTable1.getSelectedRows())[0];
                int startCol=(jTable1.getSelectedColumns())[0];
                String trstring= (String)(system.getContents(this).getTransferData(DataFlavor.stringFlavor));
                
                AFITRouter.out("String is:"+trstring);
                StringTokenizer st1=new StringTokenizer(trstring,"\n");
                int blankLines = 0;
                for(int i=0;st1.hasMoreTokens();i++)
                {
                    rowstring=st1.nextToken();
                    StringTokenizer st2=new StringTokenizer(rowstring,"\t");

                    if( st2.countTokens() == 0 )
                        blankLines++;
                    else
                        for(int j=0;st2.hasMoreTokens();j++)
                        {
                            value=(String)st2.nextToken();
                            if (startRow+i-blankLines< jTable1.getRowCount() &&
                                startCol+j< jTable1.getColumnCount())
                                jTable1.setValueAt(value,startRow+i-blankLines,startCol+j);
                            AFITRouter.out("Putting "+ value+"at row="+startRow+i+"column="+startCol+j);
                        }   //end for: j
                }   // end for: i
                showMessage( PASTE_SUCCEEDED );
            }   // end try
            catch(Exception ex)
            {   showMessage( PASTE_FAILED );
                AFITRouter.err( ex );
            }   // end catch
        }   // end else: access okay
   }    // end paste
   
   
    public void showMessage( String message )
    {
        Graphics g = this.jTable1.getGraphics();
        
        // Center the message in the table.
        g.setFont( new Font( g.getFont().getName(), Font.BOLD, 48 ) );
        int messageWidth = g.getFontMetrics().stringWidth(message);
        int messageHeight = g.getFontMetrics().getAscent();
        int tableWidth = this.jTable1.getVisibleRect().width;
        int tableHeight = this.jTable1.getVisibleRect().height;
        int x = ( tableWidth - messageWidth) / 2;
        int y = (tableHeight - messageHeight) / 2;
        
        // If Java 2 is available, use its more sophisticated
        // drawing techniques. Otherwise just use the Java 1.1 way.
        boolean JAVA2 = false;
        try
        {   Class c = Class.forName( "java.awt.Graphics2D" );
            JAVA2 = true;
        }   // end try
        catch( ClassNotFoundException e )
        {   JAVA2 = false;
        }   // end catch

        if( JAVA2 )
        {
            Graphics2D g2D = (Graphics2D) g;
                
            // Turn on antialiasing if available
            g2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON );
            
            g2D.setPaint( new Color( 20, 200, 20, 100 ) );
            
            g2D.drawString( message, x, y );
        }   // end if: Java 2 available.
        else
        {
            g.setColor( new Color( 20, 200, 20 ) );
            g.drawString( message, x, y );
        }   // end else: doesn't have java 2 available.
        
        
        // Pause and then redraw the table
        try
        {   Thread.sleep( MILLIS_TO_DISPLAY_MESSAGE );
        }   // end try
        catch( InterruptedException e ){}
        
        this.jTable1.repaint();
        
    }   // end showMessage
 
   
    public final boolean hasClipboardAccess()
    {    return clipboardAccessGranted;
    }    // end hasClipboardAccess
    
    public final AbstractAction getCopyAction()
    {   final ExcelAdapter This = this;
        AbstractAction action = new AbstractAction( "Copy" )
        {   public void actionPerformed( ActionEvent e )
            {   This.copy();
            }   // end actionPerformed
        };  // end abstract action
        
        // If there's no clipboard action, disable the action
        if( ! clipboardAccessGranted )
            action.setEnabled( false );
        
        return action;
    }   // end getCopyAction
    
    
    public final AbstractAction getPasteAction()
    {   final ExcelAdapter This = this;
        AbstractAction action = new AbstractAction( "Paste" )
        {   public void actionPerformed( ActionEvent e )
            {   This.paste();
            }   // end actionPerformed
        };  // end abstract action
        
        // If there's no clipboard action, disable the action
        if( ! clipboardAccessGranted )
            action.setEnabled( false );
        
        return action;
    }   // end getPasteAction
    
    
}