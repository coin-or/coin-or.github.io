package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.awt.*;
import javax.swing.*;
import java.util.*;


class StringArrayCellEditor
extends DefaultCellEditor
{
    JTextField txtField = null;
    
    public StringArrayCellEditor()
    {   super( new JTextField() );
        
        if( editorComponent instanceof JTextField )
        {   txtField = (JTextField) editorComponent;
        }   // end if: get text field
    }   // end constructor
    
    
    public Component getTableCellEditorComponent(
    JTable table, Object value, boolean isSelected, int row, int column )
    {
        String text = null;
        if( value instanceof String[] )
        {   StringBuffer s = new StringBuffer();
            String[] ss = (String[]) value;
            for( int i = 0; i < ss.length; i++ )
                s.append( ss[i] + 
                    ( i < ss.length-1
                    ? ", "
                    : "") );
            text = s.toString();
        }   // end if: string array passed
        txtField.setText( text );
        return txtField;
    }   // end getTableCellEditorComponent
 
    
    public Object getCellEditorValue()
    {
        String text = txtField.getText();
        StringTokenizer stoke = new StringTokenizer( text, ",", false );
        String[] ss = new String[ stoke.countTokens() ];
        for( int i = 0; i < ss.length; i++ )
            ss[i] = stoke.nextToken().trim();
        
        return ss;
    }   // end getCellEditorValue
   
    
}   // end class StringArrayCellEditor