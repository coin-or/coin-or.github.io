package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.*;
//import java.awt.geom.*;

public class RegionFrame extends JFrame
{
    Shape shape;
    
    public RegionFrame( Shape shape )
    {   super();
        this.shape = shape;
        
        // Set bounds for this frame.
        this.setBounds( 150, 150, 400, 400 );
        
        this.show();
    }   // end constructor
    
    
    public void paint( Graphics g )
    {   
        //Graphics2D g2D = (Graphics2D) g;
        
        double frameWidth = this.getWidth();
        double frameHeight = this.getHeight();
        
        Rectangle shapeBounds = shape.getBounds();
        double translatex = -shapeBounds.getX() + 10;
        double translatey = -shapeBounds.getY() + 10;
        
        double scalex = frameWidth / shapeBounds.getWidth() * .7;
        double scaley = frameHeight / shapeBounds.getHeight() * .7;
        
        //g2D.scale( Math.min(scalex,scaley), Math.min(scalex,scaley) );
        //g2D.translate( translatex, translatey );
        
        //g2D.setRenderingHints( new RenderingHints(
        //    RenderingHints.KEY_ANTIALIASING,
        //    RenderingHints.VALUE_ANTIALIAS_ON ));
        //g2D.draw( shape );
        
        
        
        
    }   // end paint
    
}   //end class RegionFrame