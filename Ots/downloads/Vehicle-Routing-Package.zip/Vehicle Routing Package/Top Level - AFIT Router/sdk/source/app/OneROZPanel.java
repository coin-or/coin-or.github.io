package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

class OneROZPanel 
extends JPanel
implements Observer
{
    private final static int 
        TIME_TEXT_LENGTH = 10,
        NAME_TEXT_LENGTH = 20;
        
    private Kernel kernel;
    private RestrictedOperatingZone roz;
    private JTextArea txaLatLon;
    private ROZDisplay display;
    
    public OneROZPanel( RestrictedOperatingZone roz, Kernel kernel )
    {   super( new BorderLayout() );
        this.roz = roz;
        this.kernel = kernel;
        setupLayout();
        
        // Setup roz handling
        roz.addObserver( this );
        fillTextAreaFromROZ();
        handleTextAreaUpdate();
    }   // end constructor
    
    
    private final void setupLayout()
    {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Top panel
        JPanel pnlTop = new JPanel( new BorderLayout() );
        pnlTop.add( createHeaderPanel(), BorderLayout.NORTH );
        pnlTop.add( createPanelFor( this.roz), BorderLayout.SOUTH );
        
        // Center panel has table of lat/lons and a simple display of ROZ
        JPanel pnlCenter = new JPanel( new BorderLayout() );
        JPanel pnlLatLon = new JPanel( new BorderLayout() );
            pnlLatLon.setBorder( new TitledBorder( "Enter latitude, longitude pairs" ) );
            pnlLatLon.add( new JScrollPane( txaLatLon = new JTextArea(10,40) ), BorderLayout.CENTER );
        // Panel for ROZ display
        display = new ROZDisplay();
            display.setPreferredSize( new Dimension( 200,200 ) );
            JPanel pnlVisual = new JPanel( new BorderLayout() );
            pnlVisual.setBorder( new BevelBorder( BevelBorder.LOWERED ) );
            pnlVisual.add( display, BorderLayout.CENTER );
        pnlCenter.add( pnlLatLon, BorderLayout.WEST );
        pnlCenter.add( pnlVisual, BorderLayout.CENTER );
        
        
        
        
        
        // Add listener to text area
        txaLatLon.addKeyListener( new KeyListener()
        {   public void keyPressed(KeyEvent e){}
            public void keyReleased(KeyEvent e){}
            public void keyTyped(KeyEvent e)
            {   handleTextAreaUpdate();
            }   // end keyTyped
        }); // end keylistener
        
        panel.add( pnlTop, BorderLayout.NORTH );
        panel.add( pnlCenter, BorderLayout.CENTER );
        this.add( panel, BorderLayout.CENTER );
    }   // end setupLayout
    
    
    
    private final JPanel createHeaderPanel()
    {
                // Make header panel for ROZ stuff
        JPanel pnlHeader1 = new JPanel( new FlowLayout( FlowLayout.LEFT ) );
        JPanel pnlHeader2 = new JPanel( new FlowLayout( FlowLayout.LEFT ) );
        JPanel pnlHeaders = new JPanel( new BorderLayout() );
        pnlHeaders.add( pnlHeader1, BorderLayout.NORTH );
        pnlHeaders.add( pnlHeader2, BorderLayout.SOUTH );
        JTextField tempName = new JTextField("", NAME_TEXT_LENGTH );
        JTextField tempTimes = new JTextField("", TIME_TEXT_LENGTH );
        // Line 1
        JLabel lblBlank1 = new JLabel("");
            lblBlank1.setPreferredSize( tempName.getPreferredSize() );
            pnlHeader1.add( lblBlank1 );
        JLabel lblWindow = new JLabel( "Time Window", JLabel.CENTER );
            lblWindow.setPreferredSize( new Dimension( tempTimes.getPreferredSize().width<<1, tempTimes.getPreferredSize().height ) );
            pnlHeader1.add( lblWindow );
        JLabel lblWall = new JLabel( "Time Wall", JLabel.CENTER );
            lblWall.setPreferredSize( new Dimension( tempTimes.getPreferredSize().width<<1, tempTimes.getPreferredSize().height ) );
            pnlHeader1.add( lblWall );
            
        JLabel lblHeaderName = new JLabel( "Name", JLabel.CENTER );
            lblHeaderName.setPreferredSize( tempName.getPreferredSize() );
            pnlHeader2.add( lblHeaderName );
        JLabel lblHeaderStart1 = new JLabel( "Start", JLabel.CENTER );
            lblHeaderStart1.setPreferredSize( tempTimes.getPreferredSize() );
        JLabel lblHeaderEnd1 = new JLabel( "End", JLabel.CENTER );
            lblHeaderEnd1.setPreferredSize( tempTimes.getPreferredSize() );
        JLabel lblHeaderStart2 = new JLabel( "Start", JLabel.CENTER );
            lblHeaderStart2.setPreferredSize( tempTimes.getPreferredSize() );
        JLabel lblHeaderEnd2 = new JLabel( "End", JLabel.CENTER );
            lblHeaderEnd2.setPreferredSize( tempTimes.getPreferredSize() );
        pnlHeader2.add( lblHeaderStart1 );
        pnlHeader2.add( lblHeaderEnd1 );
        pnlHeader2.add( lblHeaderStart2 );
        pnlHeader2.add( lblHeaderEnd2 );
        
        return pnlHeaders;
    }   // end createHeaderPanel
    
    

    private final JPanel createPanelFor( final RestrictedOperatingZone roz )
    {
        JPanel panel = new JPanel();
        
        // Name textfield
        final JTextField txtName = new JTextField( roz.getName(), NAME_TEXT_LENGTH );
        roz.addObserver( new Observer()
        {   public void update( Observable thing, Object arg )
            {   RestrictedOperatingZone Roz = (RestrictedOperatingZone) thing;
                txtName.setText( Roz.getName() );
            }   // end update
        }); // end observer
        txtName.addFocusListener( new FocusAdapter()
        {   public void focusLost( FocusEvent e )
            {   if( !roz.getName().equals( txtName.getText() ) )
                    roz.setName( txtName.getText() );
            }   // end focusLost
        }); // end focusadapter
        
        
        // Time Window Start textfield
        final JTextField txtWindowStart = new JTextField( 
            CoreUtilities.intTimeToString( roz.getEarliestAllowedTime() ), TIME_TEXT_LENGTH );
        roz.addObserver( new Observer()
        {   public void update( Observable thing, Object arg )
            {   RestrictedOperatingZone Roz = (RestrictedOperatingZone) thing;
                txtWindowStart.setText( CoreUtilities.intTimeToString( Roz.getEarliestAllowedTime() ) );
            }   // end update
        }); // end observer
        txtWindowStart.addFocusListener( new FocusAdapter()
        {   public void focusLost( FocusEvent e )
            {   int t = CoreUtilities.stringTimeToInt( txtWindowStart.getText() );
                if( t <= 0 )
                    t = Integer.MIN_VALUE;
                roz.setEarliestAllowedTime(t);
            }   // end focusLost
        }); // end focusadapter
        
        
        // Time Window End textfield
        final JTextField txtWindowEnd = new JTextField( 
            CoreUtilities.intTimeToString( roz.getLatestAllowedTime() ), TIME_TEXT_LENGTH );
        roz.addObserver( new Observer()
        {   public void update( Observable thing, Object arg )
            {   RestrictedOperatingZone Roz = (RestrictedOperatingZone) thing;
                txtWindowEnd.setText( CoreUtilities.intTimeToString( Roz.getLatestAllowedTime() ) );
            }   // end update
        }); // end observer
        txtWindowEnd.addFocusListener( new FocusAdapter()
        {   public void focusLost( FocusEvent e )
            {   int t = CoreUtilities.stringTimeToInt( txtWindowEnd.getText() );
                if( t <= 0 )
                    t = Integer.MAX_VALUE;
                roz.setLatestAllowedTime(t);
            }   // end focusLost
        }); // end focusadapter
        
        
        // Time Wall Start textfield
        final JTextField txtWallStart = new JTextField( 
            CoreUtilities.intTimeToString( roz.getEarliestRestrictedTime() ), TIME_TEXT_LENGTH );
        roz.addObserver( new Observer()
        {   public void update( Observable thing, Object arg )
            {   RestrictedOperatingZone Roz = (RestrictedOperatingZone) thing;
                txtWallStart.setText( CoreUtilities.intTimeToString( Roz.getEarliestRestrictedTime() ) );
            }   // end update
        }); // end observer
        txtWallStart.addFocusListener( new FocusAdapter()
        {   public void focusLost( FocusEvent e )
            {   int t = CoreUtilities.stringTimeToInt( txtWallStart.getText() );
                if( t <= 0 )
                    t = Integer.MIN_VALUE;
                roz.setEarliestRestrictedTime(t);
            }   // end focusLost
        }); // end focusadapter
        
        
        // Time Wall End textfield
        final JTextField txtWallEnd = new JTextField( 
            CoreUtilities.intTimeToString( roz.getLatestRestrictedTime() ), TIME_TEXT_LENGTH );
        roz.addObserver( new Observer()
        {   public void update( Observable thing, Object arg )
            {   RestrictedOperatingZone Roz = (RestrictedOperatingZone) thing;
                txtWallEnd.setText( CoreUtilities.intTimeToString( Roz.getLatestRestrictedTime() ) );
            }   // end update
        }); // end observer
        txtWallEnd.addFocusListener( new FocusAdapter()
        {   public void focusLost( FocusEvent e )
            {   int t = CoreUtilities.stringTimeToInt( txtWallEnd.getText() );
                if( t <= 0 )
                    t = Integer.MIN_VALUE;
                roz.setLatestRestrictedTime(t);
            }   // end focusLost
        }); // end focusadapter
        
        // Assign to sites
        JButton btnAssign = new JButton( "Assign to sites" );
        btnAssign.setToolTipText( "Copy time windows and walls to all sites in this restricted operating zone" );
        btnAssign.addActionListener( new ActionListener()
        {   public void actionPerformed( ActionEvent e )
            {   new Thread( new Runnable()
                {   public void run()
                    {   CoreUtilities.assignROZTimesToSites( roz, kernel.getSiteList() );
                    }   // end run
                }).start(); // end runnable,thread
                Thread.yield();
            }   // end actionPerformed
        }); // end actionlistener
        
        // Add to panel
        panel.setLayout( new FlowLayout( FlowLayout.LEFT ) );
        panel.add( txtName );
        panel.add( txtWindowStart );
        panel.add( txtWindowEnd );
        panel.add( txtWallStart );
        panel.add( txtWallEnd );
        panel.add( btnAssign );
        
        
        return panel;
    }   // end createPanelFor
    
    
    
    private final void fillTextAreaFromROZ()
    {   double[][] v = roz.getRegion().getVertices();
        for( int i = 0; i < v.length; i++ )
        {   txaLatLon.append( CoreUtilities.doubleLatToString( v[i][0], kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT) ) );
            txaLatLon.append( ", " + CoreUtilities.doubleLonToString( v[i][1], kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT) ) );
            txaLatLon.append( System.getProperty("line.separator") );
        }   // end for: through each pair
    }   // end fillTextAreaFromROZ
    
    
    
    /**
     * Crudely determines lat/lon pairs from the text area. This is called
     * after each keystroke as the user types in data. This could be better.
     */
    protected final void handleTextAreaUpdate()
    {
        // Get text from text area
        txaLatLon.validate();
        String text = txaLatLon.getText();
        StringTokenizer st = new StringTokenizer( text, ","+System.getProperty("line.separator") );
        
        // Store lat/lons in array
        Vector vecVertices = new Vector();
        
        // Go through string and look for pairs of lat/lons
        Double dLat = null;
        Double dLon = null;
        while( st.hasMoreElements() )
        {
            String s = st.nextToken();
            if( dLat == null )
                dLat = new Double( CoreUtilities.stringLatToDouble( s, kernel.getPrefs().getProperty( AFITRouter.LAT_LON_FORMAT ) ) );
            else if( dLon == null )
                dLon = new Double( CoreUtilities.stringLonToDouble( s, kernel.getPrefs().getProperty( AFITRouter.LAT_LON_FORMAT ) ) );
            
            if( dLat != null && dLon != null )
            {   double[] temp = new double[2];
                temp[0] = dLat.doubleValue();
                temp[1] = dLon.doubleValue();
                vecVertices.addElement( temp );
                dLat = dLon = null;
                //System.out.println( "lat=" + temp[0] + ", lon="+ temp[1] );
            }   // end if: lat/lon pair found
            
            //System.out.println( s );
        }   // end while: through string
        
        // Convert vector to matrix
        double[][] vertices = new double[ vecVertices.size() ][];
        for( int i = 0; i < vertices.length; i++ )
        {   vertices[i] = (double[]) vecVertices.elementAt(i);
        }   // end for: through each lat/lon
        
        // Build a geographic region
        GeographicRegion gr = new GeographicRegion( vertices );
        roz.setRegion( gr );
        //System.out.println( "Region: " + gr );
    }   // end handleTextAreaUpdate
    
    
    
    
    public void update( Observable thing, Object arg )
    {
        if( thing instanceof RestrictedOperatingZone )
        {   display.repaint();
        }   // end if
        
    }   // end update
    


    // inner class
    class ROZDisplay extends JPanel
    {
        private double latToYOffset;
        private double lonToXOffset;
        private double latToYScale;
        private double lonToXScale;
        private final Insets forcedInsets =
            new Insets( 10,10,10,10 );
        private Polygon path;
        
        public ROZDisplay()
        {   super();
            setBackground( Color.white );
        }   // end constructor
        
        public void paintComponent( Graphics g )
        {
            super.paintComponent( g );
            setupCoordinateSpace();
            setupPath();
            
            // If Java 2 is available, use its more sophisticated
            // drawing techniques. Otherwise just use the Java 1.1 way.
            boolean JAVA2 = false;
            try
            {   Class c = Class.forName( "java.awt.Graphics2D" );
                JAVA2 = true;
            }   // end try
            catch( ClassNotFoundException e )
            {   JAVA2 = false;
            }   // end catch
            
            if( JAVA2 )
            {
                Graphics2D g2D = (Graphics2D) g;
                
                // Turn on antialiasing if available
                g2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING,
                                      RenderingHints.VALUE_ANTIALIAS_ON );
                
                // Set line width
                //g2D.setStroke( new BasicStroke( STROKE_WIDTH ) );
                
                // Draw path
                //g2D.setPaint( color );
                if( path != null )
                    g2D.draw( path );
                
                // Turn off antialiasing
                //g2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING,
                //                      RenderingHints.VALUE_ANTIALIAS_OFF );
                //g2D.drawString( strVehicle, VEHICLE_X, vehicle_y );
            }   // end if: Java 2 available.
            else
            {
                //g.setColor( color );
                if( path != null )
                    g.drawPolygon( path );
                
                //g.drawString( strVehicle, VEHICLE_X, vehicle_y );
            }   // end else: doesn't have java 2 available.
            
            
            
        }   // end paintComponent
        
        
        private final void setupCoordinateSpace()
        {
            double[][] vertices = roz.getRegion().getVertices();
            
            // Find the smallest and largest latitude and longitude
            double smallestLat = Double.MAX_VALUE;
            double smallestLon = Double.MAX_VALUE;
            double largestLat = -Double.MAX_VALUE;
            double largestLon = -Double.MAX_VALUE;

            for( int i = 0; i < vertices.length; i++ )
            {   
                final double lat = vertices[i][0];
                final double lon = vertices[i][1];
                if( lat < smallestLat )
                    smallestLat = lat;
                if( lon < smallestLon )
                    smallestLon = lon;
                if( lat > largestLat )
                    largestLat = lat;
                if( lon > largestLon )
                    largestLon = lon;
            }   // end for: through each tour
            
            // Find range of latitudes and longitudes
            final double latRange = largestLat - smallestLat;
            final double lonRange = largestLon - smallestLon;
            
            // Find scales
            final int width = this.getWidth() - forcedInsets.left - forcedInsets.right;
            final int height = this.getHeight() - forcedInsets.top - forcedInsets.bottom;
            double scale1 = width / lonRange;
            double scale2 = height / latRange;
            lonToXScale = latToYScale = Math.min( scale1, scale2 );
            
            // Find offsets-Bring it flush right
            lonToXOffset = -smallestLon;
            latToYOffset = -smallestLat;
            
            // Add a little more lonToXOffset to make the drawing
            // flush to the right side.
            double rightMost = (largestLon + lonToXOffset)*lonToXScale;
            double extraOffset = width - rightMost - forcedInsets.right;
            //lonToXOffset += (int)(extraOffset*.75);
        }   // end setupCoordinateSpace
            
        
        
        private final Point latLongToPoint( double lat, double lon )
        {
            final int x = (int) ( (lon + lonToXOffset) 
                * lonToXScale) + forcedInsets.left;
            final int y = this.getHeight() - forcedInsets.top -
                (int)((lat + latToYOffset) * latToYScale);
            
            return new Point( x, y );
        }   // end latLongToPoint
        
        
        private final void setupPath()
        {
            double[][] vertices = roz.getRegion().getVertices();
            
            if( vertices.length > 1 )
            {
                int[] x = new int[ vertices.length ];
                int[] y = new int[ vertices.length ];
                for( int i = 0; i < x.length; i++ )
                {   Point p = latLongToPoint( vertices[i][0], vertices[i][1] );
                    x[i] = p.x;
                    y[i] = p.y;
                }   // end for: through each pair
                path = new Polygon( x, y, x.length );
                
                
/*                // Move to starting location
                Point p =  latLongToPoint( 
                    vertices[0][0], vertices[0][1] );
                int[] startX = new int[1];
                startX[0] = p.x;
                int[] startY = new int[1];
                startY[0] = p.y;
                path = new Polygon( startX, startY, 1 );
                    
                // Draw lines to each target
                for( int j = 1; j < vertices.length; j++ )
                {   
                    p = latLongToPoint(
                        vertices[j][0], vertices[j][1] );
                    path.addPoint( p.x, p.y );
                }   // end for: nodes within tour
                    
                // Draw line back to base
                //p = latLongToPoint( 
                //    vertices[vertices.length-1][0], vertices[vertices.length-1][1] );
                //path.addPoint( p.x, p.y );
*/
            }   // end if: at least two points
        }   // end setupPath
        
        
    }   // end inner class ROZDisplay

}   // end class OneROZPanel