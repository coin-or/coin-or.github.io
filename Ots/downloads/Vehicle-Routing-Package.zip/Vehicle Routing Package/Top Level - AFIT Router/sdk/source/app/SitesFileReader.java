package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.io.*;

public interface SitesFileReader
{
    
    
    public abstract String getFileTypeName();
    
    public abstract String[] getFileExtensions();
    
    public abstract Site[] getSites( InputStream stream, boolean interactive );
    
    
}   // end interface SitesFileReader