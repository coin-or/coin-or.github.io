package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.border.*;

public class PriorityPanel 
extends JPanel
implements Observer, FocusListener
{
    private final static String
        HEADER_COL_1 = "Pairs",
        HEADER_COL_2 = "Worth",
        TOOLTIP_TEXT = "Determines how many lower priority targets are needed to displace a higher priority target.",
        ONE_PRIORITY_MSG = "Only one priority exists";
    
    // Make sure "return" does not get passed to the text fields
    static
    {   JTextField f = new JTextField();
        KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
        Keymap map = f.getKeymap();map.removeKeyStrokeBinding(enter);
    }   // end static
    
    private PriorityModel model = null;
    private JTextField[] txtWorths = new JTextField[0];
    private JLabel[] lblWorths = new JLabel[0];
    
    // Some fixed components
    private JPanel pnlHeader = new JPanel( new BorderLayout() );
    private JLabel lblHeaderCol1 = new JLabel( HEADER_COL_1, JLabel.LEFT );
    private JLabel lblHeaderCol2 = new JLabel( HEADER_COL_2, JLabel.RIGHT );
    
    
    public PriorityPanel( PriorityModel model )
    {   // Set model
        this.model = model;
        
        // Set fixed components
        this.setToolTipText( TOOLTIP_TEXT );
        pnlHeader.add( lblHeaderCol1, BorderLayout.WEST );
        pnlHeader.add( lblHeaderCol2, BorderLayout.EAST );
        this.setLayout( new BorderLayout() );
        this.add( pnlHeader, BorderLayout.NORTH );
        this.setupLayout( model );
        this.model.addObserver( this );
    }   // end constructor
    
    
/* ********  L A Y O U T   C O D E  ******** */
    
    private final void setupLayout( PriorityModel model )
    {
        // Quick access variables
        final boolean isEditable = model.isEditable();
        final boolean enabled = model.isEnabled();
        final int[] worths = model.getRelativeWorths();
        final int[] priorities = model.getPriorities();
        final int numOfPriorities = priorities.length;
        
        // Put everything on a sub-panel and add all at once.
        JPanel main = new JPanel( new BorderLayout() );
        main.setLayout( new GridLayout(Math.max(1,numOfPriorities-1), 1 ) );
        
        if( isEditable )
            txtWorths = new JTextField[ numOfPriorities ];
        else
            lblWorths = new JLabel[ numOfPriorities ];
        
        // Create as many label/input pairs as necessary
        if( numOfPriorities > 1 )
        {
            for( int i = 0; i < numOfPriorities-1; i++ )
            {
                JLabel label = new JLabel( "" + 
                    priorities[i] + " to " + priorities[i+1] + ":" );
                JPanel row = new JPanel( new BorderLayout() );
                row.add( label, BorderLayout.WEST );
                if( isEditable )
                {
                    txtWorths[i] = new JTextField( 
                        PriorityModel.textValue( worths[i] ),5 );
                    row.add( txtWorths[i], BorderLayout.EAST );
                    //txtWorths[i].addActionListener( this );
                    txtWorths[i].addFocusListener( this );
                }   // end if: editable
                else
                {
                    lblWorths[i] = new JLabel( PriorityModel.textValue( 
                        worths[i] ), JLabel.RIGHT );
                    row.add( lblWorths[i], BorderLayout.EAST );
                }   // end else: not editable
                main.add( row );
            }   // end for: through each priority pair
        }   // end if: at least one priority pair
        else
        {   // Add a label stating there are no priority pairs
            main.add( new JLabel( ONE_PRIORITY_MSG, JLabel.CENTER ) );
        }   // end else: no priorities
        this.add( main, BorderLayout.CENTER );        

/*        final JPanel Main = main;
        final PriorityPanel This = this;
//        SwingUtilities.invokeLater( new Runnable()
//        {   public void run()
//          {   
                This.add( Main, BorderLayout.CENTER );
                This.validate();
//            }   // end run
//        }); // end runnable, invokeLater
*/
    }   // end setupLayout
    
    
/* ********  O B S E R V E R   C O D E  ******** */
    
    public void update( Observable thing, Object arg )
    {
        //if( thing instanceof PriorityModel )
        //    setupLayout( (PriorityModel) thing );
    }   // end update
    
    
/* ********  F O C U S L I S T E N E R   C O D E  ******** */
    
    public void focusGained( FocusEvent e ){}
    
    public void focusLost( FocusEvent e )
    {
        // Find which textfield set off the action
        for( int i = 0; i < txtWorths.length; i++ )
        {
            if( txtWorths[i] == e.getSource() )
            {
                int val = PriorityModel.intValue( txtWorths[i].getText() );
                val = val < 1 ? 1 : val;
                model.setRelativeWorthAt( val, i );
                final String Val = PriorityModel.textValue( 
                    model.getRelativeWorthAt(i) );
                final JTextField Txt = txtWorths[i];
                SwingUtilities.invokeLater( new Runnable()
                {   public void run()
                    {   Txt.setText( Val );
                    }   // end run
                }); // end runnable, invokeLater
                i = Integer.MAX_VALUE;
                break;
            }   // end if: found the right one
        }   // end for: through each text field
        
    }   // end focusLost
    
    
/* ********  A C T I O N L I S T E N E R   C O D E  ********* */
    
    public void actionPerformed( ActionEvent e )
    {
    }   // end actionPerformed
    
    
}   // end class PriorityPanel