package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.io.*;
import javax.swing.*;
import java.util.*;

public class SolomonReader implements SitesFileReader
{
    private static final int LAT_COL = 0;
    private static final int LONG_COL = 1;
    private static final int DEMAND = 2;   // Treat as service time
    private static final int TW_START = 3; // Time window start
    private static final int TW_END = 4;   // Time window end
    private static final int SERVICE_TIME = 5;
    private static final int COLUMN_COUNT = 6;
    
    
    public final String getFileTypeName()
    {   return "Tab-delimited text file";
    }   // end getFileTypeName
    
    
    public final String[] getFileExtensions()
    {
        final String[] exts =
            { "sol", "txt" };
        return exts;
    }   // end getFileTypeExtensions
    
    
    public final Site[] getSites( InputStream stream, boolean interactive )
    {
        AFITRouter.out( stream );
        
        int[] columnLocations = getColumnLocations( stream, interactive );
        
        Site[] sites;
        
        sites = loadSites( stream, columnLocations );

        return sites;
    }   // end getSites
    
    
    private final int[] getColumnLocations( InputStream stream, boolean interactive )
    {
        int[] columnLocations = new int[ COLUMN_COUNT ];
        
        // Not really implemented yet.
        
        columnLocations[ LAT_COL ] = 1;
        columnLocations[ LONG_COL ] = 2;
        columnLocations[ TW_START ] = 4;
        columnLocations[ TW_END ] = 5;
        columnLocations[ DEMAND ] = 3;
        columnLocations[ SERVICE_TIME ] = 6;
        
        return columnLocations;
    }   // end getColumnLocations
    
    
    private final Site[] loadSites( InputStream istream, int[] columnLocations )
    {
        // Get stream to read data
        StreamTokenizer stream = getStream( istream, true );
        
        // Ensure that end of line characters are noticed
        stream.eolIsSignificant(true);
        
        // Include some special characters
        stream.wordChars( '_', '_' );
        stream.wordChars( '-', '-' );
        stream.wordChars( '\\', '\\' );
        //stream.wordChars( ' ', ' ' );
        
        Vector sites = new Vector();
        
        int row = 0;
        
        // Begin reading file
        try
        {
            // Try to skip the first line which contains vehicle info.
            while( stream.nextToken() != stream.TT_EOL )
            {}
            
            while( (stream.nextToken() != stream.TT_EOF) )
            {
                // Put token back
                stream.pushBack();
                
                // New row started: setup row variables
                row++;
                int currentColumn = 1;
                Double latitude = null;
                Double longitude = null;
                int demand = -1;
                int service = -1;
                Double twStart = null;
                Double twEnd = null;
                while( ( stream.nextToken() != stream.TT_EOL ) &&
                       ( stream.ttype != stream.TT_EOF ) )
                {
                    if( currentColumn == columnLocations[ LAT_COL ] )
                    {
                        latitude = new Double( stream.nval );
                    }   // end if: latitude
                    else
                    if( currentColumn == columnLocations[ LONG_COL ] )
                    {
                        longitude = new Double( stream.nval );
                    }   // end if: longitude
                    else
                    if( currentColumn == columnLocations[ DEMAND ] )
                    {
                        demand = (int) stream.nval;
                    }   // end if: priority
                    else
                    if( currentColumn == columnLocations[ TW_START ] )
                    {
                        twStart = new Double( stream.nval );
                    }   // end if: priority
                    else
                    if( currentColumn == columnLocations[ TW_END ] )
                    {
                        twEnd = new Double( stream.nval );
                    }   // end if: priority
                    else
                    if( currentColumn == columnLocations[ SERVICE_TIME ] )
                    {
                        service = (int) stream.nval;
                    }   // end if: priority
                    else
                    {
                        ;
                    }   // end else: nothing
                    
                    // Increment column counter
                    currentColumn++;
                }   // end while: until end of line

                // End of line reached. Try to make a site.
                // Make sure enough information was collected
                // to make an entire site before making the site.
                Site tempSite = null;
                tempSite = new Site(
                    "Site_"+row, latitude.doubleValue(),
                    longitude.doubleValue() );
                tempSite.setEarliestArrivalTime(
                    twStart.intValue() );
                tempSite.setLatestDepartureTime(
                    twEnd.intValue() );
                tempSite.setServiceTime( service );
                
                // If site was made, add it to list of sites
                if( tempSite != null )
                    sites.addElement( tempSite );

            }   // end while: until end of file
        }   // end try
        catch( IOException e )
        {
            System.err.println( e );
            return null;
        }   // end catch
        
        // Convert list of sites into an array
        //Site[] arrayOfSites = (Site[]) sites.toArray();
        Site[] arrayOfSites = new Site[ sites.size() ];
        for( int i = 0; i < arrayOfSites.length; i++ )
            arrayOfSites[i] = (Site) sites.elementAt(i);
        
        if( arrayOfSites.length == 0 )
            arrayOfSites = null;
        
        return arrayOfSites;
    }   // end loadSites
    
    
    
    private StreamTokenizer getStream( InputStream stream, boolean useMonitor )
    {
        
        // Make isr based on whether or not a monitor box should come up
        InputStreamReader isr;
        isr = new InputStreamReader( stream );
        
        // Make the stream a reader
        Reader r = new BufferedReader( isr );
        
        // Make the stream a tokenizer
        StreamTokenizer ststream = new StreamTokenizer( r );
        
        return ststream;
    }   // end getStream
    
    
    private void out( String s, double d )
    {   System.out.println( s == null ? "" + d : s );
    }   // end out
    
    
}   // end class SolomonReader