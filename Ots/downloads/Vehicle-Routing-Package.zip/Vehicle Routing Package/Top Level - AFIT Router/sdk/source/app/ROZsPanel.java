package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

class ROZsPanel extends JPanel implements Observer
{
    private final static int 
        TIME_TEXT_LENGTH = 5,
        NAME_TEXT_LENGTH = 10;

    private Kernel kernel;
    private JPanel pnlROZs;
    private Box boxROZs;
    
    public ROZsPanel( Kernel kernel )
    {   super( new BorderLayout() );
        this.kernel = kernel;
        setupLayout();
    }   // end constructor
    
    
    private final void setupLayout()
    {
        JPanel main = new JPanel( new BorderLayout() );
        

        main.add( createHeaderPanel(), BorderLayout.NORTH );
        
        // ROZ stuff
        pnlROZs = new JPanel( new BorderLayout() );
        boxROZs = new Box( BoxLayout.Y_AXIS );
        pnlROZs.add( boxROZs, BorderLayout.CENTER );
        final RestrictedOperatingZoneList list = kernel.getROZList();
        RestrictedOperatingZone[] rozs = list.getROZs();
        for( int i = 0; i < rozs.length; i++ )
            addROZToLayout( rozs[i] );
        main.add( pnlROZs, BorderLayout.CENTER );
        
        // Button to add ROZ
        JPanel pnlButtons = new JPanel( new FlowLayout( FlowLayout.CENTER ) );
        JButton btnAdd = new JButton( "Add ROZ" );
        btnAdd.addActionListener( new ActionListener()
        {   public void actionPerformed( ActionEvent e )
            {   RestrictedOperatingZone roz = new RestrictedOperatingZone();
                list.addROZ( roz );
                addROZToLayout( roz );
            }   // end actionPerformed
        }); // end actionlistener
        pnlButtons.add( btnAdd );
        main.add( pnlButtons, BorderLayout.SOUTH );
        
        this.removeAll();
        this.add( main, BorderLayout.CENTER );
    }   // end setupLayout
    
    
    private final void addROZToLayout( final RestrictedOperatingZone roz )
    {   final JPanel panel = createPanelFor( roz );
        SwingUtilities.invokeLater( new Runnable()
        {   public void run()
            {   //pnlROZs.add( panel );
                boxROZs.add( panel );
                // Try to find parent frame and repack
                Component c = pnlROZs;
                while( c != null && !( c instanceof Window ) )
                    c = c.getParent();
                if( c instanceof Window )
                    ((Window)c).pack();
                else pnlROZs.validate();
            }   // end run
        }); // end runnable,invokeLater
    }   // end addROZToLayout
    
    
    private final JPanel createHeaderPanel()
    {
                // Make header panel for ROZ stuff
        JPanel pnlHeader1 = new JPanel( new FlowLayout( FlowLayout.LEFT ) );
        JPanel pnlHeader2 = new JPanel( new FlowLayout( FlowLayout.LEFT ) );
        JPanel pnlHeaders = new JPanel( new BorderLayout() );
        pnlHeaders.add( pnlHeader1, BorderLayout.NORTH );
        pnlHeaders.add( pnlHeader2, BorderLayout.SOUTH );
        JTextField tempName = new JTextField("", NAME_TEXT_LENGTH );
        JTextField tempTimes = new JTextField("", TIME_TEXT_LENGTH );
        // Line 1
        JLabel lblBlank1 = new JLabel("");
            lblBlank1.setPreferredSize( tempName.getPreferredSize() );
            pnlHeader1.add( lblBlank1 );
        JLabel lblWindow = new JLabel( "Time Window", JLabel.CENTER );
            lblWindow.setPreferredSize( new Dimension( tempTimes.getPreferredSize().width<<1, tempTimes.getPreferredSize().height ) );
            pnlHeader1.add( lblWindow );
        JLabel lblWall = new JLabel( "Time Wall", JLabel.CENTER );
            lblWall.setPreferredSize( new Dimension( tempTimes.getPreferredSize().width<<1, tempTimes.getPreferredSize().height ) );
            pnlHeader1.add( lblWall );
            
        JLabel lblHeaderName = new JLabel( "Name", JLabel.CENTER );
            lblHeaderName.setPreferredSize( tempName.getPreferredSize() );
            pnlHeader2.add( lblHeaderName );
        JLabel lblHeaderStart1 = new JLabel( "Start", JLabel.CENTER );
            lblHeaderStart1.setPreferredSize( tempTimes.getPreferredSize() );
        JLabel lblHeaderEnd1 = new JLabel( "End", JLabel.CENTER );
            lblHeaderEnd1.setPreferredSize( tempTimes.getPreferredSize() );
        JLabel lblHeaderStart2 = new JLabel( "Start", JLabel.CENTER );
            lblHeaderStart2.setPreferredSize( tempTimes.getPreferredSize() );
        JLabel lblHeaderEnd2 = new JLabel( "End", JLabel.CENTER );
            lblHeaderEnd2.setPreferredSize( tempTimes.getPreferredSize() );
        pnlHeader2.add( lblHeaderStart1 );
        pnlHeader2.add( lblHeaderEnd1 );
        pnlHeader2.add( lblHeaderStart2 );
        pnlHeader2.add( lblHeaderEnd2 );
        
        return pnlHeaders;
    }   // end createHeaderPanel
    
    
    private final JPanel createPanelFor( final RestrictedOperatingZone roz )
    {
        JPanel panel = new JPanel();
        
        // Name textfield
        final JTextField txtName = new JTextField( roz.getName(), NAME_TEXT_LENGTH );
        roz.addObserver( new Observer()
        {   public void update( Observable thing, Object arg )
            {   RestrictedOperatingZone Roz = (RestrictedOperatingZone) thing;
                txtName.setText( Roz.getName() );
            }   // end update
        }); // end observer
        txtName.addFocusListener( new FocusAdapter()
        {   public void focusLost( FocusEvent e )
            {   if( !roz.getName().equals( txtName.getText() ) )
                    roz.setName( txtName.getText() );
            }   // end focusLost
        }); // end focusadapter
        
        
        // Time Window Start textfield
        final JTextField txtWindowStart = new JTextField( 
            CoreUtilities.intTimeToString( roz.getEarliestAllowedTime() ), TIME_TEXT_LENGTH );
        roz.addObserver( new Observer()
        {   public void update( Observable thing, Object arg )
            {   RestrictedOperatingZone Roz = (RestrictedOperatingZone) thing;
                txtWindowStart.setText( CoreUtilities.intTimeToString( Roz.getEarliestAllowedTime() ) );
            }   // end update
        }); // end observer
        txtWindowStart.addFocusListener( new FocusAdapter()
        {   public void focusLost( FocusEvent e )
            {   int t = CoreUtilities.stringTimeToInt( txtWindowStart.getText() );
                if( t <= 0 )
                    t = Integer.MIN_VALUE;
                roz.setEarliestAllowedTime(t);
            }   // end focusLost
        }); // end focusadapter
        
        
        // Time Window End textfield
        final JTextField txtWindowEnd = new JTextField( 
            CoreUtilities.intTimeToString( roz.getLatestAllowedTime() ), TIME_TEXT_LENGTH );
        roz.addObserver( new Observer()
        {   public void update( Observable thing, Object arg )
            {   RestrictedOperatingZone Roz = (RestrictedOperatingZone) thing;
                txtWindowEnd.setText( CoreUtilities.intTimeToString( Roz.getLatestAllowedTime() ) );
            }   // end update
        }); // end observer
        txtWindowEnd.addFocusListener( new FocusAdapter()
        {   public void focusLost( FocusEvent e )
            {   int t = CoreUtilities.stringTimeToInt( txtWindowEnd.getText() );
                if( t <= 0 )
                    t = Integer.MAX_VALUE;
                roz.setLatestAllowedTime(t);
            }   // end focusLost
        }); // end focusadapter
        
        
        // Time Wall Start textfield
        final JTextField txtWallStart = new JTextField( 
            CoreUtilities.intTimeToString( roz.getEarliestRestrictedTime() ), TIME_TEXT_LENGTH );
        roz.addObserver( new Observer()
        {   public void update( Observable thing, Object arg )
            {   RestrictedOperatingZone Roz = (RestrictedOperatingZone) thing;
                txtWallStart.setText( CoreUtilities.intTimeToString( Roz.getEarliestRestrictedTime() ) );
            }   // end update
        }); // end observer
        txtWallStart.addFocusListener( new FocusAdapter()
        {   public void focusLost( FocusEvent e )
            {   int t = CoreUtilities.stringTimeToInt( txtWallStart.getText() );
                if( t <= 0 )
                    t = Integer.MIN_VALUE;
                roz.setEarliestRestrictedTime(t);
            }   // end focusLost
        }); // end focusadapter
        
        
        // Time Wall End textfield
        final JTextField txtWallEnd = new JTextField( 
            CoreUtilities.intTimeToString( roz.getLatestRestrictedTime() ), TIME_TEXT_LENGTH );
        roz.addObserver( new Observer()
        {   public void update( Observable thing, Object arg )
            {   RestrictedOperatingZone Roz = (RestrictedOperatingZone) thing;
                txtWallEnd.setText( CoreUtilities.intTimeToString( Roz.getLatestRestrictedTime() ) );
            }   // end update
        }); // end observer
        txtWallEnd.addFocusListener( new FocusAdapter()
        {   public void focusLost( FocusEvent e )
            {   int t = CoreUtilities.stringTimeToInt( txtWallEnd.getText() );
                if( t <= 0 )
                    t = Integer.MIN_VALUE;
                roz.setLatestRestrictedTime(t);
            }   // end focusLost
        }); // end focusadapter
        
        // Edit button
        JButton btnEdit = new JButton( "Edit..." );
        btnEdit.setToolTipText( "Edit the restricted operating zone" );
        btnEdit.addActionListener( new OpenOneROZFrameAction( roz, kernel ) );
        
        // Delete button
        JButton btnDelete = new JButton( "Delete" );
        btnDelete.setToolTipText( "Delete the restricted operating zone" );
        final JPanel This = this;
        btnDelete.addActionListener( new ActionListener()
        {   public void actionPerformed( ActionEvent e )
            {   int result = JOptionPane.showConfirmDialog( This, "Delete ROZ?", "ROZ", JOptionPane.YES_NO_OPTION );
                if( result == JOptionPane.YES_OPTION )
                {   kernel.getROZList().removeRestrictedOperatingZone( roz );
                    setupLayout();
                }   // end if: delete
            }   // end actionPerformed
        }); // end actionlistener
        
        // Assign to sites
        JButton btnAssign = new JButton( "Assign to sites" );
        btnAssign.setToolTipText( "Copy time windows and walls to all sites in this restricted operating zone" );
        btnAssign.addActionListener( new ActionListener()
        {   public void actionPerformed( ActionEvent e )
            {   new Thread( new Runnable()
                {   public void run()
                    {   CoreUtilities.assignROZTimesToSites( roz, kernel.getSiteList() );
                    }   // end run
                }).start(); // end runnable,thread
                Thread.yield();
            }   // end actionPerformed
        }); // end actionlistener
        
        // Add to panel
        panel.setLayout( new FlowLayout( FlowLayout.LEFT ) );
        panel.add( txtName );
        panel.add( txtWindowStart );
        panel.add( txtWindowEnd );
        panel.add( txtWallStart );
        panel.add( txtWallEnd );
        panel.add( btnEdit );
        panel.add( btnDelete );
        panel.add( btnAssign );
        
        
        return panel;
    }   // end createPanelFor
    
    
    
    
/* ********  O B S E R V E R   C O D E  ******** */ 
    
    public void update( Observable thing, Object arg )
    {
        
    }   // end update
    
    
}   // end class ROZsPanel