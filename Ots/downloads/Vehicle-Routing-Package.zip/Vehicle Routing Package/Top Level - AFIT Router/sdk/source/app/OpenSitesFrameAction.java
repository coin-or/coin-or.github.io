package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class OpenSitesFrameAction
extends AbstractAction
{
    private final static String
        SITES_FRAME_BOUNDS = "sites frame bounds",
        FRAME_BOUNDS_X = "window.sites.bounds.x",
        FRAME_BOUNDS_Y = "window.sites.bounds.y",
        FRAME_BOUNDS_WIDTH = "window.sites.bounds.width",
        FRAME_BOUNDS_HEIGHT = "window.sites.bounds.height";
    public final static String
        TOOLTIP = "Open window with sites";
    
    
    private Kernel kernel;
    
    protected OpenSitesFrameAction( Kernel kernel )
    {   super( "Sites..." );
        this.kernel = kernel;
    }   // end constructor
    
    public void actionPerformed( ActionEvent e )
    {
        final Kernel kErnel = this.kernel;
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   
                // Create frame to hold sites panel
                JFrame frame = new JFrame( "Sites" );
                
                // Make a sites panel
                SitesPanel sitesPanel = new SitesPanel( kErnel );
                
                // Make a menu bar
                setupMenu( frame, sitesPanel );
                
                // Add sites panel to frame
                frame.getContentPane().add( sitesPanel, BorderLayout.CENTER );
                
                // Window handler
                final JFrame fRame = frame;
                final Kernel keRnel = kErnel;
                final SitesPanel sItesPanel = sitesPanel;
                frame.addWindowListener( new WindowAdapter()
                {   public void windowClosing( WindowEvent e )
                    {   // Save bounds
                        Rectangle bounds = fRame.getBounds();
                        Preferences prefs = kErnel.getPrefs();
                        prefs.setProperty( FRAME_BOUNDS_X, ""+bounds.x );
                        prefs.setProperty( FRAME_BOUNDS_Y, ""+bounds.y );
                        prefs.setProperty( FRAME_BOUNDS_WIDTH, ""+bounds.width );
                        prefs.setProperty( FRAME_BOUNDS_HEIGHT, ""+bounds.height );
                    }   // end windowClosing
                    public void windowClosed( WindowEvent e )
                    {   sItesPanel.dispose();
                        System.gc();
                    }   // end windowClosed
                }); // end addWindowListener
                
                // Read bounds. If there are errors, use defaults
                Preferences prefs = kernel.getPrefs();
                try
                {   int x = new Integer( prefs.getProperty( FRAME_BOUNDS_X ) ).intValue();
                    int y = new Integer( prefs.getProperty( FRAME_BOUNDS_Y ) ).intValue();
                    int width = new Integer( prefs.getProperty( FRAME_BOUNDS_WIDTH ) ).intValue();
                    int height = new Integer( prefs.getProperty( FRAME_BOUNDS_HEIGHT ) ).intValue();
                    frame.setBounds( new Rectangle( x, y, width, height ) );
                }   // end try
                catch( Exception ex )
                {   frame.pack();
                    frame.setLocation( prefs.getDefaultWindowX(), prefs.getDefaultWindowY() );
                }   // end catch
                
                // Make sure it fits
                Toolkit theKit = frame.getToolkit();
                Dimension screenSize = theKit.getScreenSize();
                if( frame.getLocation().x > screenSize.width 
                || frame.getLocation().y > screenSize.height )
                    frame.setLocation( prefs.getDefaultWindowX(), prefs.getDefaultWindowY() );

                final JFrame frAme = frame;
                SwingUtilities.invokeLater( new Runnable()
                {   public void run()
                    {   frAme.validate();
                        frAme.show();
                    }   // end run
                }); // end runnable, invokeLater

            }   // end run
        }); // end runnable, thread
        t.setDaemon( true );
        t.start();
    }   // end actionPerformed
    
    private final void setupMenu( JFrame frame, SitesPanel sitesPanel )
    {
        // Find the modifier key that is used on this platform
        int menuShortcutKeyMask = frame.getToolkit().getMenuShortcutKeyMask();
        
        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        
        // File Menu
        JMenu fileMenu = new JMenu( "File" );
        fileMenu.setMnemonic( 'F' );
        {   JMenuItem item;
                item = fileMenu.add( new ImportSitesFileAction( frame, kernel ) );
                    item.setMnemonic( 'I' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'I', menuShortcutKeyMask ) );
                //item = fileMenu.add( new ImportSitesURLAction( frame, kernel ) );
                //    item.setMnemonic( 'U' );
                //    item.setAccelerator( KeyStroke.getKeyStroke( 'U', menuShortcutKeyMask ) );
        }   // end file menu
        
        // Edit Menu
        JMenu editMenu = new JMenu( "Edit" );
        editMenu.setMnemonic( 'E' );
        {   JMenuItem item;
                item = editMenu.add( sitesPanel.getExcelAdapter().getCopyAction() );
                    item.setMnemonic( 'C' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'C', menuShortcutKeyMask ) );
                item = editMenu.add( sitesPanel.getExcelAdapter().getPasteAction() );
                    item.setMnemonic( 'P' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'V', menuShortcutKeyMask ) );
        }   // end edit menu
        
        // Add menus to menu bar
        menuBar.add( fileMenu );
        menuBar.add( editMenu );
        
        // Add menu bar to frame
        frame.setJMenuBar( menuBar );
        
    }   // end setupMenu
    
    
}   // end class OpenSitesFrameAction