package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class OpenOtherSettingsDialogAction
extends AbstractAction
{
    
    private final static String DIALOG_TITLE = "Settings...";
    public final static String TOOLTIP = "Change various settings for wind, ROZs, etc";
    private Kernel kernel;
    private Component parentComponent;
    
    public OpenOtherSettingsDialogAction( 
    Kernel kernel, Component parentComponent )
    {   super( DIALOG_TITLE );
        this.parentComponent = parentComponent;
        this.kernel = kernel;
    }   // end constructor
    
    public void actionPerformed( ActionEvent e )
    {
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   
                // Open dialog here.
                OtherSettingsPanel settingsPanel =
                    new OtherSettingsPanel( kernel );
                
                int response = JOptionPane.showConfirmDialog(
                    parentComponent, settingsPanel,
                    DIALOG_TITLE, 
                    JOptionPane.OK_CANCEL_OPTION ) ;
                
                // Only do something if okay was selected
                if( response == JOptionPane.OK_OPTION )
                {   settingsPanel.saveSettings();
                    packParent();
                }   // end if: something changed
                    
            }   // end run
        }); // end runnable, thread
        t.setDaemon( true );
        t.start();
    }   // end actionPerformed
    
    private final void packParent()
    {   Component c = parentComponent;
        while( c != null )
        {   if( c instanceof Window )
            {   ((Window)c).pack();
                break;
            }   // end if: found the window
            else c = c.getParent();
        }   // end while:
    }   // end packParent
    
}   // end class OpenOtherSettingsDialogAction