package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.awt.*;

public class SaveKernelAction
extends AbstractAction
{
    private final static String NAME = "Save kernel...";
    private final static String ERROR_MESSAGE = "Error saving file.";
    public final static String TOOLTIP = "Saves everything (vehicles, sites, ROZs, etc.) in one file";
    private final static String NATIVE_FILE_BOX_KEY = "file.dialog.useNative";
    private static boolean useNativeFileBox = false;
    private Kernel kernel;
    private Component parentComponent;
    
    public SaveKernelAction( Component parentComponent, Kernel kernel )
    {   super( NAME );
        this.parentComponent = parentComponent;
        this.kernel = kernel;
        
        // Determine if native file dialog boxes should be used.
        String result = kernel.getPrefs().getProperty( NATIVE_FILE_BOX_KEY );
        try
        {   useNativeFileBox = new Boolean( result ).booleanValue();
        }   // end try
        catch( Exception e ) {}
        kernel.getPrefs().setProperty( NATIVE_FILE_BOX_KEY, ""+useNativeFileBox );
    }   // end kernel
    
    public void actionPerformed( ActionEvent e )
    {   final Kernel kErnel = kernel;
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   try
                {   
                    // See if a previously used directory is recorded
                    String prevDir = kErnel.getPrefs()
                        .getProperty( AFITRouter.PREV_DIR );
                    
                    // If it's not, default to the user's home
                    File currentDir = null;
                    if( prevDir == null || (! new File( prevDir ).exists() ) )
                        currentDir = new File( System.getProperty( "user.dir" ) );
                    else
                        currentDir = new File( prevDir );
                    
                    File file = null;
                    // Open a file chooser dialog: Swing version
                    if( !useNativeFileBox )
                    {   JFileChooser fileChooser = new JFileChooser( currentDir );
                        int option = fileChooser.showSaveDialog( parentComponent );
                        if( option == JFileChooser.APPROVE_OPTION )
                            file = fileChooser.getSelectedFile();
                    }   // end if: swing version
                    else
                    {
                        // Open a file chooser dialog: Native version
                        // Try to find a frame in the tree
                        Frame frame = null;
                        Component c =parentComponent;
                        while( c != null && ! ( c instanceof Frame ) )
                        {   c = c.getParent();
                        }   // end while
                        frame = (c instanceof Frame) ? (Frame)c : new Frame();

                        FileDialog fd = new FileDialog( frame, "Save kernel file", FileDialog.SAVE );
                        fd.setDirectory( currentDir.getName() );
                        fd.show();
                        String fileName = fd.getFile();
                        String dir = fd.getDirectory();
                        
                        // If a file was selected, try to open it.
                        if( fileName != null )
                            file = new File( dir, fileName );
                    }   // end if: native version

                    if( file != null )
                    {
                        FileOutputStream fos=null;
                        try
                        {   fos = new FileOutputStream( file );
                            ObjectOutputStream oos = new ObjectOutputStream( fos );
                            synchronized( kErnel )
                            {   oos.writeObject( kErnel );
                            }   // end sync
                            oos.flush();
                        }   // end try
                        catch( Exception ex )
                        {   AFITRouter.err( ex );
                            // Show error saving file
                            JOptionPane.showMessageDialog( parentComponent, ERROR_MESSAGE );
                        }   // end catch
                        finally
                        {   try{ fos.close(); }
                            catch( Exception ex ){}
                            kErnel.getPrefs().setProperty(
                                AFITRouter.PREV_DIR, file.getParent() );
                        }   // end finally

                    }   // end if: chose a file
                }   // end try
                catch( Exception err ){}
            }   // end run
        }); // end runnable, thread
        t.start();
        Thread.yield();
    }   // end actionPerformed
    
}   // end SaveKernelAction