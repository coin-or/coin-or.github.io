package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.text.*;

public class ClipboardAccessPanel
extends JPanel
{
    private String LINE;
    
    private final static String[]
        EXPLANATION = 
            { "Because of an applet's high degree of security,",
              "it cannot directly access your clipboard. You will",
              "have to manually select this text and use your",
              "operating system's copy command, e.g., Ctrl-C." };
        
    
    public ClipboardAccessPanel( String s )
    {   super( new BorderLayout() );
        this.setupLayout( s );
    }   // end constructor
    
    private final void setupLayout( String s )
    {   
        // Use a split pane
        JSplitPane splMain = new JSplitPane( JSplitPane.VERTICAL_SPLIT );
        splMain.setOneTouchExpandable( true );
        
        // Top panel has explanation
        JPanel pnlTop = new JPanel( new FlowLayout() );
        pnlTop.setBorder( new TitledBorder( "Explanation" ) );
        Box boxTop = Box.createVerticalBox();
        pnlTop.add( boxTop );
        for( int i = 0; i < EXPLANATION.length; i++ )
            boxTop.add( new JLabel( EXPLANATION[i] ) );
        
        // Bottom panel has text
        JPanel pnlBottom = new JPanel( new BorderLayout() );
        JTextArea txaText = new JTextArea( s );
        txaText.addFocusListener( new FocusListener()
        {   public void focusGained( FocusEvent e )
            {   if( e.getSource() instanceof JTextComponent )
                    ((JTextComponent)e.getSource()).selectAll();
            }   // end focusGained
            public void focusLost( FocusEvent e )
            {   // Do nothing
            }   // end focusLost
        }); // end focusListener
        txaText.addMouseListener( new MouseAdapter()
        {   public void mouseClicked( MouseEvent e )
            {   if( e.getSource() instanceof JTextComponent )
                    ((JTextComponent)e.getSource()).selectAll();
            }   // end mouseClicked
        }); // end mouseAdapter
                
        JScrollPane scrText = new JScrollPane( txaText );
        pnlBottom.add( scrText, BorderLayout.CENTER );
        
        // Add components to split pane
        splMain.setTopComponent( pnlTop );
        splMain.setBottomComponent( pnlBottom );
        
        // Add to main layout
        this.add( splMain, BorderLayout.CENTER );
    }   // end setupLayout
    
    
}   // end class ClipboardAccessPanel