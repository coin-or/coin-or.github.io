package mil.af.afit.router.app;

import java.awt.*;
import java.util.Vector;
import java.awt.event.*;
import javax.swing.*;

/**
 *	   a JPopupMenu that changes the look and feel of an application or applet
 *<BR> to allow the user to sellect his preferred LAF
 *<BR> 
 *<BR> automatically determines the installed Look and Feels and constructs
 *<BR> sub-JRadioButtonMenuItems accordingly
 *<BR>
 *<BR> If boolean property pack=true then if this is in a Window (or subclass) 
 *<BR> when the user changes the LAF the Window will be packed ==> pack() will be called
 *<BR>
 *<BR> if there are other sources of change (unlikely) the user should ensure
 *<BR> that  they call "LAFchangeMenu.updateDisplayedLAF()" to make sure that the 
 *<BR> LAFchangeMenu diplays the correct current LAF
 */

public class LAFPopupMenu extends javax.swing.JPopupMenu
						implements ActionListener {
	
	private JRadioButtonMenuItem LAFPopupMenuItems[];
	private ButtonGroup buttonGroup;
	private Vector updateableVector=null;
	
	public String currentLAF;
	private boolean pack = true;
/**
 * LAFchangeMenu constructor comment.
 */
public LAFPopupMenu() {
	super();
	updateableVector=new Vector();
	initialize();
}
/**
 * 
 * @param event java.awt.event.ActionEvent
 */
public void actionPerformed(ActionEvent event) {
	//get topmost parent
	JRadioButtonMenuItem rbmi=(JRadioButtonMenuItem)event.getSource();
	
	JPopupMenu pm=(JPopupMenu)rbmi.getParent();
	Component c=pm.getInvoker();	// c=LAFchangeMenu
	while (c.getParent() instanceof JPopupMenu) { 
		pm=(JPopupMenu)c.getParent();
		c=pm.getInvoker(); 			// c=the JPopupMenu that holds LAFchangeMenu
	}
	while (c.getParent()!=null) c=c.getParent();
	
	try {
		UIManager.setLookAndFeel(event.getActionCommand());
		SwingUtilities.updateComponentTreeUI(c);
	}
	catch (Exception exc) {}
	
	// pack the frame if requested by user
	if (pack && c instanceof Window ) {
		Window w=(Window)c;
		w.pack();
	}

	// now update all added components
	if (updateableVector.isEmpty()) return;
	int i=0;
	while (i<updateableVector.size()) {
		Object o=updateableVector.elementAt(i);
		if (o instanceof JFrame) {
			try {SwingUtilities.updateComponentTreeUI((JFrame)o);}
			catch (Exception exc) {}
		}
		if (o instanceof JWindow) {
			try {SwingUtilities.updateComponentTreeUI((JWindow)o);}
			catch (Exception exc) {}
		}
		if (o instanceof JApplet) {
			try {SwingUtilities.updateComponentTreeUI((JApplet)o);}
			catch (Exception exc) {}
		}
		if (o instanceof JComponent) {
			try {SwingUtilities.updateComponentTreeUI((JComponent)o);}
			catch (Exception exc) {}
		}
		
		i++;
	}
	
} // end method actionPerformed()
/**
 * 
 * @param updateable com.sun.java.swing.JComponent
 */
public void addUpdateable(Component updateable) {
	
	updateableVector.addElement(updateable);
}
/**
 * Returns the currently selected LAF
 *<BR> as a String like: "Metal" "Windows" or "CDE/Motif"
 *<BR> suitable for storing and later submitting to the method
 *<BR> LAFchangeMenu.setCurrentLAF() to restore the user's preferred LAF
 */
public String getCurrentLAF() {
	return currentLAF;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean getPack() {
	return pack;
}
/**
 * 
 */
private void initialize() {
	//this.setText("Look and Feel");
	buttonGroup=new ButtonGroup();
	this.currentLAF = UIManager.getLookAndFeel().getName();
	
	// Add JRadioButtonMenuItems
	UIManager.LookAndFeelInfo laf[]=UIManager.getInstalledLookAndFeels();
	LAFPopupMenuItems=new JRadioButtonMenuItem[laf.length];
	int select=-1;		// the current LAF
	for (int i=0; i<laf.length; i++) {
		LAFPopupMenuItems[i]=new JRadioButtonMenuItem(laf[i].getName());
		this.add(LAFPopupMenuItems[i]);
		LAFPopupMenuItems[i].setActionCommand(laf[i].getClassName());
		LAFPopupMenuItems[i].addActionListener(this);
		// See if it's supported
		try
		{   LookAndFeel LAF = (LookAndFeel) Class.forName( 
		        laf[i].getClassName() ).getClassLoader()
		        .loadClass( laf[i].getClassName() ).newInstance();
		    LAFPopupMenuItems[i].setEnabled( LAF.isSupportedLookAndFeel() );
		}   // end try
		catch( Exception e ){}
		buttonGroup.add(LAFPopupMenuItems[i]);
		if (laf[i].getName().equals(currentLAF)) select=i;
	} // end for
	if (select>=0) buttonGroup.setSelected(LAFPopupMenuItems[select].getModel(),true);

} // end initialize()
/**
 * 
 * @param updateable java.awt.Component
 */
public void removeUpdateable(java.awt.Component updateable) {
	int i=0;
	while (i<updateableVector.size()) {
		if (updateable==updateableVector.elementAt(i)) {
			updateableVector.removeElementAt(i);
			i=i-1;
		}
		i++;
	}
}
/**
 * Programatically set the LAF
 *<BR> the parameter is a String like:
 *<BR> "Metal" "Windows" or "CDE/Motif"
 * 
 */
public void setCurrentLAF(String newValue) {
	int i=0;
	while (i<LAFPopupMenuItems.length && !LAFPopupMenuItems[i].getText().equals(newValue)){  i++;	}
	if (i==LAFPopupMenuItems.length) return; // no match found

	LAFPopupMenuItems[i].doClick();
	this.currentLAF = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue boolean
 */
public void setPack(boolean newValue) {
	this.pack = newValue;
}
/**
 * Used to update the displayed LAF if the LAF gets changed from elsewhere
 *<BR> (not by this Bean)
 *<BR> does not require any parameters
 */
public void updateDisplayedLAF() {
	this.currentLAF = UIManager.getLookAndFeel().getName();

	int select=-1;		// the current LAF
	for (int i=0; i<LAFPopupMenuItems.length; i++) {
		if (LAFPopupMenuItems[i].getText().equals(currentLAF)) select=i;
	} // end for
	if (select>=0) buttonGroup.setSelected(LAFPopupMenuItems[select].getModel(),true);
}

}