package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.awt.*;
import javax.swing.table.*;
import javax.swing.*;


class VehicleCapabilitiesCellEditor
extends DefaultCellEditor
{
    Kernel kernel;
    String[] items;
    JMenu menu;
    
    public VehicleCapabilitiesCellEditor(Kernel kernel)
    {   super( new JTextField() );
        this.kernel = kernel;
        
        menu = new JMenu();
        menu.add( new JMenuItem( "Item one" ) );
        menu.add( new JMenuItem( "Item two" ) );
        menu.add( new JCheckBoxMenuItem( "Check" ) );
        
    }   // end constructor
    
    public Component getTableCellEditorComponent( 
    JTable table, Object value, boolean isSelected, int row, int column )
    {
        items = (String[]) value;
        return menu;
    }   // end getTableCelLEditorComponent
    
    public Object getCellEditorValue()
    {
        return items;
    }   // end getCellEditorValue
    
    public Component getComponent()
    {   return menu;
    }   // end getComponent
    
    
}   // end class VehicleCapabilitesCellEditor