package mil.af.afit.router.app;
import mil.af.afit.router.*;
import mil.af.afit.uvr.*;

    
public class SolutionRow
{   private Object[] row;
    private int[] columnOrder;
    private UVRSite uSite;
    private HTour tour;
    private int orderNum;
    
    public SolutionRow( Object[] row, int[] columnOrder, 
    HTour tour, int orderNum )
    {   this.row = row;
        this.columnOrder = columnOrder;
        this.uSite = (UVRSite)tour.getHOrderAt(orderNum);
        this.orderNum = orderNum;
        this.tour = tour;
    }   // end constructor
        
    public final String getVehicle()
    {   return (String)row[columnOrder[SolutionTableModel.VEHICLE]];
    }   // end getVehicle
        
    public final String getName()
    {   return (String)row[columnOrder[SolutionTableModel.NAME]];
    }   // end getName
        
    public final String getLatitude()
    {   return (String)row[columnOrder[SolutionTableModel.LATITUDE]];
    }   // end getLatitude
        
    public final String getLongitude()
    {   return (String)row[columnOrder[SolutionTableModel.LONGITUDE]];
    }   // end getLongitude
        
    public final double getArrival()
    {   return tour.getEstimatedArrivalTime(orderNum);//(String)row[columnOrder[SolutionTableModel.ARRIVAL]];
    }   // end getLatitude
        
    public final double getDeparture()
    {   return tour.getEstimatedDepartureTime(orderNum);//(String)row[columnOrder[SolutionTableModel.DEPARTURE]];
    }   // end getLongitude
        
    public final int getPriority()
    {   return ((Integer)row[columnOrder[SolutionTableModel.PRIORITY]]).intValue();
    }   // end getPriority
        
    public final int getOriginalOrder()
    {   return ((Integer)row[columnOrder[SolutionTableModel.ORIGINAL_ORDER]]).intValue();
    }   // end getOriginalOrder
        
    public final double getWaitTime()
    {   return tour.getEstimatedWaitTime(orderNum);//(String)row[columnOrder[SolutionTableModel.WAIT_TIME]];
    }   // end getLongitude
        
    public final Boolean getCompleted()
    {   return new Boolean( !uSite.getParentSite().isEnabled() );
    }   // end getLongitude
    
    public final String getCompletedString()
    {   return getCompleted().toString();
    }   // end getCompletedString
    
    public final void setCompleted( boolean state )
    {   uSite.getParentSite().setEnabled( !state );
    }   // end setCompleted
        
    public final Object dataAt( int column )
    {   if( column == columnOrder[SolutionTableModel.COMPLETED] )
            return getCompleted();
        else return row[column];
    }   // end dataAt
        
}   // end subclass Row