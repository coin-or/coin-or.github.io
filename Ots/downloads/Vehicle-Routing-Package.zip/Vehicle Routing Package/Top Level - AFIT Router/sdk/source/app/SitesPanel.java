package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.util.*;

public class SitesPanel
extends JPanel
implements Observer
{
    private Kernel kernel = null;
    private SitesTablePopupMenu tablePopupMenu;
    private ExcelAdapter excelAdapter;
    
	JSplitPane jspMainSplit;// = new JSplitPane();
	    JPanel pnlTopPanel;// = new JPanel();
	        JPanel pnlInfoPanel;// = new JPanel();
	            JPanel pnlSummary;// = new JPanel();
	                JPanel pnlSummaryLabels;// = new JPanel();
	                    JPanel pnlTotalSitesLabels;// = new JPanel();
	                        JLabel lblTotalSites;// = new JLabel();
	                        JLabel lblTotalSitesValue;// = new JLabel();
	                    JPanel pnlEnabledSitesLabels;// = new JPanel();
	                        JLabel lblEnabledSites;// = new JLabel();
	                        JLabel lblEnabledSitesValue;// = new JLabel();
	                    JPanel pnlEarliestTimeWindowLabels;// = new JPanel();
	                        JLabel lblEarliestTimeWindow;// = new JLabel();
	                        JLabel lblEarliestTimeWindowValue;// = new JLabel();
	                    JPanel pnlLatestTimeWindowLabels;// = new JPanel();
	                        JLabel lblLatestTimeWindow;// = new JLabel();
	                        JLabel lblLatestTimeWindowValue;// = new JLabel();
	            JPanel pnlAdd;// = new JPanel();
	            JPanel pnlHelp;// = new JPanel();
	    JPanel pnlBottomPanel;// = new JPanel();
	        JScrollPane jscScrollPaneForSitesTable;// = new JScrollPane();
	            JTable tblSitesTable;// = new JTable();
                    SitesTableModel mdlSitesTableModel;// = new SitesTableModel();
    
    
    
    
    public SitesPanel( Kernel kernel )
    {   super();
        this.kernel = kernel;
        this.setupLayout();
        this.setupLinksWithKernel();
    }   // end constructor
    
    
    private final void setupLayout()
    {
        // Instantiate
        jspMainSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
	    pnlTopPanel = new JPanel(new BorderLayout());
	        pnlInfoPanel = new JPanel();//new GridBagLayout());
	            pnlSummary = new JPanel(new GridLayout(1,0));
	                pnlSummaryLabels = new JPanel(new GridLayout(4,1));
	                    pnlTotalSitesLabels = new JPanel(new BorderLayout());
	                        lblTotalSites = new JLabel();
	                        lblTotalSitesValue = new JLabel();
	                    pnlEnabledSitesLabels = new JPanel(new BorderLayout());
	                        lblEnabledSites = new JLabel();
	                        lblEnabledSitesValue = new JLabel();
	                    pnlEarliestTimeWindowLabels = new JPanel(new BorderLayout());
	                        lblEarliestTimeWindow = new JLabel();
	                        lblEarliestTimeWindowValue = new JLabel();
	                    pnlLatestTimeWindowLabels = new JPanel(new BorderLayout());
	                        lblLatestTimeWindow = new JLabel();
	                        lblLatestTimeWindowValue = new JLabel();
	            pnlAdd = new JPanel(new BorderLayout());
	            pnlHelp = new JPanel(new BorderLayout());
	    pnlBottomPanel = new JPanel(new BorderLayout());
            mdlSitesTableModel = new SitesTableModel(kernel);
	        tblSitesTable = new JTable(mdlSitesTableModel);
	        jscScrollPaneForSitesTable = new JScrollPane(tblSitesTable);
        
        
        
	    this.setLayout(new BorderLayout());
		this.add("Center",jspMainSplit);
		    jspMainSplit.setOneTouchExpandable(true);
		    jspMainSplit.setTopComponent( pnlTopPanel );
		        pnlTopPanel.add( pnlInfoPanel, BorderLayout.CENTER );
		            GridBagLayout gbl = new GridBagLayout();
		            GridBagConstraints gbc = new GridBagConstraints();
		            gbc.gridx = gbc.gridy = 0;
		            gbl.setConstraints( pnlSummary, gbc );
		            pnlInfoPanel.add(pnlSummary);//, new GridBagConstraints(0,0,1,1,0.05,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
		                pnlSummary.setBorder(new TitledBorder( "Summary" ) );
		                pnlSummary.add( pnlSummaryLabels );
		                    pnlSummaryLabels.add( pnlTotalSitesLabels );
		                        pnlTotalSitesLabels.add("West", lblTotalSites);
		                            lblTotalSites.setText("Total:");
		                            lblTotalSites.setLabelFor(lblTotalSitesValue);
		                        pnlTotalSitesLabels.add("East", lblTotalSitesValue);
		                            lblTotalSitesValue.setHorizontalAlignment(SwingConstants.RIGHT);
		                            lblTotalSitesValue.setText("000");
		                    pnlSummaryLabels.add(pnlEnabledSitesLabels);
		                        pnlEnabledSitesLabels.add("West", lblEnabledSites);
		                            lblEnabledSites.setText("Enabled:");
		                            lblEnabledSites.setLabelFor(lblEnabledSitesValue);
		                        pnlEnabledSitesLabels.add("East", lblEnabledSitesValue);
		                            lblEnabledSitesValue.setHorizontalAlignment(SwingConstants.RIGHT);
		                            lblEnabledSitesValue.setText("000");
		                    pnlSummaryLabels.add(pnlEarliestTimeWindowLabels);
		                        pnlEarliestTimeWindowLabels.setLayout(new BorderLayout(0,0));
		                        pnlEarliestTimeWindowLabels.add("West", lblEarliestTimeWindow);
		                            lblEarliestTimeWindow.setText("Earliest time window:");
		                            lblEarliestTimeWindow.setLabelFor(lblEarliestTimeWindowValue);
		                        pnlEarliestTimeWindowLabels.add("East", lblEarliestTimeWindowValue);
		                            lblEarliestTimeWindowValue.setHorizontalAlignment(SwingConstants.RIGHT);
		                            lblEarliestTimeWindowValue.setText("000");
		            
		                    pnlSummaryLabels.add(pnlLatestTimeWindowLabels);
		                        pnlLatestTimeWindowLabels.setLayout(new BorderLayout(0,0));
		                        pnlLatestTimeWindowLabels.add("West", lblLatestTimeWindow);
		                            lblLatestTimeWindow.setText("Latest time window:");
		                            lblLatestTimeWindow.setLabelFor(lblLatestTimeWindowValue);
		                        pnlLatestTimeWindowLabels.add("East", lblLatestTimeWindowValue);
		                            lblLatestTimeWindowValue.setHorizontalAlignment(SwingConstants.RIGHT);
		                            lblLatestTimeWindowValue.setText("000");
		            
/*		            gbc.gridx = 1;
		            gbc.gridy = 0;
		            gbl.setConstraints(pnlAdd, gbc);
		            pnlInfoPanel.add(pnlAdd );//, new GridBagConstraints(1,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
		                pnlAdd.setBorder(new TitledBorder( "Add" ) );
		                pnlAdd.add( new JLabel( "Blah, blah" ), BorderLayout.CENTER );
		            gbc.gridx = 2;
		            gbc.gridy = 0;
		            gbl.setConstraints( pnlHelp, gbc );
		            pnlInfoPanel.add(pnlHelp );//, new GridBagConstraints(2,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,1),0,0));
		                pnlHelp.setBorder(new TitledBorder( "Help" ) );
		                pnlHelp.add( new JLabel( "Blah, blah, blah" ), BorderLayout.CENTER );
*/
		    jspMainSplit.setBottomComponent( pnlBottomPanel );
		        pnlBottomPanel.add(jscScrollPaneForSitesTable, BorderLayout.CENTER);
                        mdlSitesTableModel.setHostTable( tblSitesTable );
                        tblSitesTable.setCellSelectionEnabled(true);
                        tblSitesTable.setSelectionMode(
                            ListSelectionModel.MULTIPLE_INTERVAL_SELECTION );
                        excelAdapter = new ExcelAdapter( tblSitesTable, ExcelAdapter.NONE );
        
        // Prepare popup menu for table
        tablePopupMenu = new SitesTablePopupMenu( mdlSitesTableModel );
        tblSitesTable.addMouseListener( new MouseAdapter()
        {   public void mousePressed( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    handleTablePopupMenu( e );
            }   // end mousePressed
            public void mouseClicked( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    handleTablePopupMenu( e );
            }   // end mouseClicked
            public void mouseReleased( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    handleTablePopupMenu( e );
            }   // end mouseReleased
        }); // end mouseAdapter,mouseListener
        
        this.validate();
    }   // end setupLayout
    
    public final ExcelAdapter getExcelAdapter()
    {   return excelAdapter;
    }   // end getExcelAdapter
    
    
    
/* ********  P O P U P M E N U   C O D E  ******** */
    
    protected final void handleTablePopupMenu( MouseEvent e )
    {   tablePopupMenu.show( tblSitesTable, e.getX(), e.getY() );
    }   // end handleShowPopupMenu
    
    
/* ********  D I S P O S E   C O D E  ******** */


    public final void dispose()
    {   this.kernel.getSiteList().deleteObserver( this );
    }   // end dispose
    
    
    
    
/* ********  K E R N E L   A C C E S S   C O D E  ******** */
    
    
    private final synchronized void setupLinksWithKernel()
    {
        // Register self to observe the kernel
        kernel.getSiteList().addObserver( this );
        
        // Set kernel in table model
        mdlSitesTableModel.setKernel( kernel );
        
        // Force update of relevant components
        updateSiteStats( kernel.getSiteList() );
        
    }   // end setupLinksWithKernel
    
    public final synchronized void setKernel( Kernel kernel )
    {
        // If we already had a kernel, remove self as observer
        if( this.kernel != null )
            this.kernel.deleteObserver( this );
        this.kernel = kernel;
        setupLinksWithKernel();
    }   // end setKernel
    
    
/* ********  S T A T S   C O D E  ******** */
    
    private final void updateSiteStats( SiteList siteList )
    {   final int total = siteList.getSites().length;
        final int enabled = siteList.countEnabledSites();
        final String earliestTimeWindow = CoreUtilities.intTimeToString(
            siteList.getEarliestTimeWindow() );
        final String latestTimeWindow = CoreUtilities.intTimeToString(
            siteList.getLatestTimeWindow() );
        final JPanel This = this;
        SwingUtilities.invokeLater( new Runnable()
        {   public void run()
            {   lblTotalSitesValue.setText( ""+total );
                lblEnabledSitesValue.setText( ""+enabled );
                lblEarliestTimeWindowValue.setText( earliestTimeWindow );
                lblLatestTimeWindowValue.setText( latestTimeWindow );
                This.validate();
            }   // end run
        }); // end runnable, invokeLater
    }   // end updateSiteStats
    
    
/* ********  O B S E R V E R   C O D E  ******** */    
    
    public void update( Observable thing, Object arg )
    {
        if( thing instanceof SiteList )
            updateSiteStats( (SiteList) thing );
    }   // end update
    
    
}   // end class SitesPanel