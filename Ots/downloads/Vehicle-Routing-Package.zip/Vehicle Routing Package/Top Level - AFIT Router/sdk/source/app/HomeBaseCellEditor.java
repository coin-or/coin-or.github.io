package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.awt.*;
import javax.swing.*;
import java.util.*;


class HomeBaseCellEditor
extends DefaultCellEditor
{
    JComboBox cboBox = null;
    private Kernel kernel;
    
    public HomeBaseCellEditor( Kernel kernel )
    {   super( new JComboBox() );
        if( editorComponent instanceof JComboBox )
        {   cboBox = (JComboBox) editorComponent;
            // Add items to box
            this.kernel = kernel;
            setupComboBox();
        }   // end if: get text field
    }   // end constructor
    
    
    public Component getTableCellEditorComponent(
    JTable table, Object value, boolean isSelected, int row, int column )
    {
        setupComboBox();
        return cboBox;
    }   // end getTableCellEditorComponent
 
    
    public Object getCellEditorValue()
    {
        return cboBox.getSelectedItem();
    }   // end getCellEditorValue
   
    private final void setupComboBox()
    {
        if( kernel != null && cboBox != null )
        {
            cboBox.removeAllItems();
            Base[] bases = kernel.getBaseList().getBases();
            for( int i = 0; i < bases.length; i++ )
                cboBox.addItem( bases[i] );
        }   // end if: not null
    }   // end setupComboBox
    
}   // end class HomeBaseCellEditor