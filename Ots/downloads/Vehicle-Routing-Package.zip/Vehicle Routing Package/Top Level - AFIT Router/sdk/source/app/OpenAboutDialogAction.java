package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class OpenAboutDialogAction
extends AbstractAction
{
    
    private final static String DIALOG_TITLE = "About...";
    public final static String TOOLTIP = "Credits and contact info";
    
    private final static String[] CREDITS = 
    {   "AFIT Router Airframe Routing",
        "by Robert Harder (rharder@usa.net) and Gary Kinney",
        "of the Air Force Institute of Technology (www.afit.af.mil)",
        "in support of the Unmanned Aerial Vehicle Battlelab" };
    
    //private Kernel kernel;
    private Component parentComponent;
    
    public OpenAboutDialogAction( 
    /*Kernel kernel,*/ Component parentComponent )
    {   super( DIALOG_TITLE );
        this.parentComponent = parentComponent;
        //this.kernel = kernel;
    }   // end constructor
    
    public void actionPerformed( ActionEvent e )
    {
        //Thread t = new Thread( 
        SwingUtilities.invokeLater( new Runnable()
        {   public void run()
            {   
                // Open dialog here.
                JPanel panel = new JPanel(new GridLayout(CREDITS.length,1));
                for( int i = 0; i < CREDITS.length; i++ )
                {   JLabel label = new JLabel( CREDITS[i] );
                    if( i == 0 )
                        label.setFont( label.getFont().deriveFont( Font.BOLD ) );
                    panel.add( label );
                }   // end for: each line
                
                
                JOptionPane.showMessageDialog(
                    parentComponent, panel,
                    DIALOG_TITLE, 
                    JOptionPane.PLAIN_MESSAGE ) ;
                
                    
            }   // end run
        }); // end runnable, thread
        //t.start();
    }   // end actionPerformed
    
    
}   // end class OpenAboutDialogAction