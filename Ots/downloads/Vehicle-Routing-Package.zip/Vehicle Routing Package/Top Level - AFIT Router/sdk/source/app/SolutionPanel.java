package mil.af.afit.router.app;
import mil.af.afit.router.*;
import mil.af.afit.uvr.*;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * Summary info for one solution.
 */
public class SolutionPanel
extends JPanel
{
    private int sitesVisited;
    private int sitesSkipped;
    private int vehiclesUsed;
    private int highestPriorityOfASkippedSite;
    private Solution solution;
    private Kernel kernel;
    private boolean showDetailsButton;
    private SolutionTableModel solutionTableModel = null;
    
    public SolutionPanel( Solution soln, Kernel kernel,
    boolean showDetailsButton, SolutionTableModel solutionTableModel )
    {   realConstructor( soln, kernel, showDetailsButton, solutionTableModel );
    }   // end constructor
    
    public SolutionPanel( 
    Solution soln, Kernel kernel, boolean showDetailsButton )
    {   realConstructor( soln, kernel, 
            showDetailsButton, null );
    }   // end constructor
    
    public void realConstructor( 
    Solution soln, Kernel kernel, boolean showDetailsButton,
    SolutionTableModel solutionTableModel )
    {
        AFITRouter.out( "SolutionPanel.constructor: constructing..." );  
        
        this.solutionTableModel = solutionTableModel;
        this.kernel = kernel;
        this.solution = soln;
        this.showDetailsButton = showDetailsButton;
        
        collectStats( soln );
        
        setupLayout( soln, kernel );
    }   // end constructor
    
/* ********  S T A T S   C O D E  ******** */
    
    private final void collectStats( Solution solution )
    {
        sitesVisited = 0;
        sitesSkipped = 0;
        vehiclesUsed = 0;
        highestPriorityOfASkippedSite = -Integer.MAX_VALUE;
        
        // Start going through solution.
        HSolution soln = solution.getHSolution();
        HTour[] tours = soln.getHTours();
        for( int i = 0; i < tours.length; i++ )
        {   if( tours[i].size() > 0 )
            {   vehiclesUsed++;
                sitesVisited += tours[i].size();
//System.out.println("Departure Time (min): " + tours[i].getDepartureTime() );
//System.out.println("Return Time (min): " + tours[i].getReturnTime() );
//System.out.println("Total Travel Time (min): " + tours[i].getTotalTravelTime() );
            }   // end if: vehicle was used.
            
        }   // end for: through each tour
        
        // Dummy tour.
        HTour dTour = soln.getDummyHTour();
        for( int i = 0; i < dTour.size(); i++ )
        {
            sitesSkipped++;
            Site site = ((UVRSite)dTour.getHOrderAt(i)).getParentSite();
            if( site.getPriority() > highestPriorityOfASkippedSite )
                highestPriorityOfASkippedSite = site.getPriority();
            //highestPriorityOfASkippedSite
        }   // end for: through dummy tour.
        
        
    }   // end collectStats
    
    public final void setHostModel( SolutionTableModel solutionTableModel )
    {   this.solutionTableModel = solutionTableModel;
    }   // end setHostModel
    
    
/* ********  L A Y O U T   C O D E  ******** */
    
    
    private final void setupLayout( Solution soln, Kernel kernel )
    {
        // Make a panel to show stats
        GridBagLayout gbl = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = gbc.HORIZONTAL;
        JPanel pnlStats = new JPanel( gbl );
        pnlStats.setBorder( new TitledBorder( "Stats" ) );
            // Visited
            JPanel pnlVisitedLabels = new JPanel( new BorderLayout() );
            pnlVisitedLabels.add( new JLabel( "Sites Visited:" ), BorderLayout.WEST );
            pnlVisitedLabels.add( new JLabel( "" + sitesVisited, JLabel.RIGHT ), BorderLayout.EAST );
            //pnlStats.add( pnlVisitedLabels );
            // Skipped
            JPanel pnlSkippedLabels = new JPanel( new BorderLayout() );
            pnlSkippedLabels.add( new JLabel( "Sites Skipped:" ), BorderLayout.WEST );
            pnlSkippedLabels.add( new JLabel( "" + sitesSkipped, JLabel.RIGHT ), BorderLayout.EAST );
            //pnlStats.add( pnlSkippedLabels );
            // Vehicles used
            JPanel pnlVehiclesUsedLabels = new JPanel( new BorderLayout() );
            pnlVehiclesUsedLabels.add( new JLabel( "Vehicles Used:" ), BorderLayout.WEST );
            pnlVehiclesUsedLabels.add( new JLabel( "" + vehiclesUsed, JLabel.RIGHT ), BorderLayout.EAST );
            //pnlStats.add( pnlVehiclesUsedLabels );
            // Highest skipped priority
            JPanel pnlPriorityLabels = new JPanel( new BorderLayout() );
            pnlPriorityLabels.add( new JLabel( "Highest Skipped Priority:" ), BorderLayout.WEST );
            pnlPriorityLabels.add( new JLabel( "" + (highestPriorityOfASkippedSite<=-(Integer.MAX_VALUE>>1)?"":""+highestPriorityOfASkippedSite), JLabel.RIGHT ), BorderLayout.EAST );
            pnlPriorityLabels.add( Box.createHorizontalStrut(10), BorderLayout.CENTER );
            // Mission Length used
            JPanel pnlMissionLength = new JPanel( new BorderLayout() );
            pnlMissionLength.add( new JLabel( "Est. Mission Length:" ), BorderLayout.WEST );
            pnlMissionLength.add( new JLabel( "" + solution.getMissionLengthString(), JLabel.RIGHT ), BorderLayout.EAST );
            pnlMissionLength.add( Box.createHorizontalStrut(10), BorderLayout.CENTER );
            //pnlStats.add( pnlPriorityLabels );
            // Add labels' panels to stats panel
            //Box boxStats = Box.createVerticalBox();
            gbc.gridx = gbc.gridy = 0;
            gbc.fill = gbc.HORIZONTAL;
                gbl.setConstraints( pnlVisitedLabels, gbc );
                pnlStats.add( pnlVisitedLabels );//, new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0) );
            gbc.gridy = 1;
                gbl.setConstraints( pnlSkippedLabels, gbc );
                pnlStats.add( pnlSkippedLabels );//, new GridBagConstraints(0,1,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0) );
            gbc.gridy = 2;
                gbl.setConstraints( pnlVehiclesUsedLabels, gbc );
                pnlStats.add( pnlVehiclesUsedLabels );//, new GridBagConstraints(0,2,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0) );
            gbc.gridy = 3;
                gbl.setConstraints( pnlPriorityLabels, gbc );
                pnlStats.add( pnlPriorityLabels );//, new GridBagConstraints(0,3,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0) );
            //gbc.gridy = 4;
            //    gbl.setConstraints( pnlMissionLength, gbc );
            //    pnlStats.add( pnlMissionLength );//, new GridBagConstraints(0,3,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0) );
        
            // Add an unknown number of lines for individual vehicle info
            HTour[] tours = soln.getHSolution().getHTours();
            int nextGBCRow = 4;
            for( int i = 0; i < tours.length; i++ )
            {   if( tours[i].size() > 0 )
                {   String strDeparture = CoreUtilities.intTimeToString( (int)
                        tours[i].getDepartureTime() );
                    String strReturn = CoreUtilities.intTimeToString( (int)
                        tours[i].getReturnTime() );
                    int travelT = (int) tours[i].getTotalTravelTime();
                    String strTravel = "" + ((int)travelT/60) + "h " + ((int)travelT%60)+"m";
                    JPanel panel = new JPanel( new BorderLayout() );
                    panel.add( new JLabel( ((UVRVehicle)tours[i].getHVehicle())
                        .getParentVehicle().getName()+":" ), BorderLayout.WEST );
                    panel.add( new JLabel( strDeparture + " to " + strReturn + " ("+strTravel+")", JLabel.RIGHT ), BorderLayout.EAST );
                    panel.add( Box.createHorizontalStrut(10), BorderLayout.CENTER );
                    gbc.gridy = nextGBCRow++;
                        gbl.setConstraints( panel, gbc );
                        pnlStats.add( panel );//, new GridBagConstraints(0,3,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0) );
                }   // end if: vehicle is used
            }   // end for: through each tour
        
        // Panel for buttons
        JPanel pnlButtons = new JPanel( new BorderLayout() );
        GridBagLayout gbl2 = new GridBagLayout();
        GridBagConstraints gbc2 = new GridBagConstraints();
        JPanel pnlSubButtons = new JPanel( gbl2 );
        int nextRow = 0;
        pnlButtons.add( pnlSubButtons, BorderLayout.CENTER );
            // Details button
            if( showDetailsButton )
            {   JButton btnDetails = new JButton( "Details..." );
                btnDetails.addActionListener( 
                    new OpenSolutionDetailsFrameAction( soln, kernel ) );
                gbc2.gridx = 0;
                gbc2.gridy = nextRow++;
                gbl2.setConstraints( btnDetails, gbc2 );
                pnlSubButtons.add( btnDetails );//, new GridBagConstraints(0,nextRow++,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.NONE,new Insets(5,5,5,5),5,5) );
            }   // end if: showDetailsButton
            // Clipboard button
            if( true)//kernel.isRunningAsApplet() )
            {   JButton btnClipboard = new JButton( "Copy to clipboard..." );
                btnClipboard.addActionListener(
                    new OpenClipboardAccessPanelAction(
                    solutionTableModel == null
                    ?   new SolutionTableModel( solution, kernel )
                    :   solutionTableModel, kernel ) );
                gbc2.gridx = 0;
                gbc2.gridy = nextRow++;
                gbl2.setConstraints( btnClipboard, gbc2 );
                pnlSubButtons.add( btnClipboard );//, new GridBagConstraints(0,nextRow++,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.NONE,new Insets(5,5,5,5),5,5) );
            }   // end if: running as applet
            // Enlarge button
            JButton btnEnlarge = new JButton( "Enlarge map..." );
                final Solution sOln = solution;
                final Kernel kErnel = kernel;
                final double FILL_PERC = .9;
                btnEnlarge.addActionListener( new ActionListener()
                {   public void actionPerformed( ActionEvent e )
                    {   JFrame frame = new JFrame( "Solution" );
                        frame.getContentPane().setLayout( new BorderLayout() );
                        Toolkit kit = frame.getToolkit();
                        Dimension screen = kit.getScreenSize();
                        int panelWidth = (int)(screen.width*FILL_PERC);
                        int panelHeight = (int)(screen.height*FILL_PERC);
                        frame.getContentPane().add( new JScrollPane( 
                            new SolutionVisualDisplayPanel(
                            sOln, kErnel, panelWidth, panelHeight) ), BorderLayout.CENTER );
                        //frame.setBounds(
                        //    (int)(screen.width - screen.width*FILL_PERC)/2,
                        //    (int)(screen.height - screen.height*FILL_PERC)/2,
                        //    (int)(screen.width*FILL_PERC),
                        //    (int)(screen.height*FILL_PERC) );
                        final JFrame fRame = frame;
                        frame.addWindowListener( new WindowAdapter()
                        {   public void windowClosed( WindowEvent e )
                            {   fRame.dispose();
                            }   // end windowClosed
                        }); // end windowadapter
                        frame.pack();
                        frame.show();
                    }   // end actionPerformed
                }); // end actionlistener
                gbc2.gridy = nextRow++;
                gbl2.setConstraints(btnEnlarge, gbc2 );
                pnlSubButtons.add( btnEnlarge );
            // Save to disk button
            JButton btnSave = new JButton( "Save..." );
                btnSave.setEnabled( false );
                gbc2.gridy = nextRow++;
                gbl2.setConstraints( btnSave, gbc2 );
                pnlSubButtons.add( btnSave );
        
        
        // Panel for visual solution
        JPanel pnlVisualSolution = new JPanel( new BorderLayout() );
        pnlVisualSolution.setBorder( new BevelBorder( BevelBorder.LOWERED ) );
        pnlVisualSolution.add( new SolutionVisualDisplayPanel( soln, kernel ), BorderLayout.CENTER );
        
        // Add panels to main.
        //GridBagLayout gbl3 = new GridBagLayout();
        //GridBagConstraints gbc3 = new GridBagConstraints();
        JPanel pnlMain = new JPanel( new GridLayout(1,3) );//gbl3 );
        //gbc3.gridx = gbc3.gridy = 0;
        //    gbl3.setConstraints( pnlStats, gbc3 );
            pnlMain.add( pnlStats );//, new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.NONE,new Insets(0,0,0,0),0,0)  );
        //gbc3.gridy = 1;
        //    gbl3.setConstraints( pnlButtons, gbc3 );
            pnlMain.add( pnlButtons );//, new GridBagConstraints(1,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0)  );
        //gbc3.gridy = 2;
        //    gbl3.setConstraints( pnlVisualSolution, gbc3 );
            pnlMain.add( pnlVisualSolution );//, new GridBagConstraints(2,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0)  );
        
        this.add( pnlMain );
        
    }   // end setupLayout
    
    
}   // end class SolutionPanel