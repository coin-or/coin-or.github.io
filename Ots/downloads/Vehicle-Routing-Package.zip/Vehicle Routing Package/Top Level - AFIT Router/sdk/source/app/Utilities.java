package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.io.*;
import java.util.*;
import javax.swing.*;

public class Utilities
{
    
    
    public static void addSitesFromStream( 
    InputStream stream, String fileName, boolean interactive, Kernel kernel )
    {
        // Try to load more sites
        Site[] moreSites = getSitesFromStream( 
            stream, fileName, interactive, kernel );

        // If it worked, add sites to existing list
        if( moreSites != null )
        {   kernel.getSiteList().addSites( moreSites );
        }   // end if: more sites were loaded
    }   // end addSitesFromFile
    
    
    
    private static Site[] getSitesFromStream( 
    InputStream istream, String fileName, boolean interactive, Kernel kernel )
    {
        // So many things could go wrong. If nothing more specific is
        // caught, catch the restovers.
        try
        {
            // Make a monitored input stream
            ProgressMonitorInputStream pmis = new ProgressMonitorInputStream(
                null, "Loading " + fileName, istream );
            
            // Since not all streams can be reset, read the stream in first
            // and then make a ByteArrayInputStream which is resettable.
            byte[] bytes = new byte[ pmis.available() ];
            pmis.read( bytes );
            ByteArrayInputStream stream = new ByteArrayInputStream(bytes);
            
            // Mark stream in case we have to come back to the start
            stream.mark( Integer.MAX_VALUE );
            
            // Get all available file import filters
            SitesFileReader[] readers = getSitesFileReaders( kernel );
            fileName = fileName != null ? fileName : "";
            
            // Find one that works. Start with one that matches
            // the file extension.
            for( int i = 0; i < readers.length; i++ )
            {
                String[] extensions = readers[i].getFileExtensions();
                for( int j = 0; j < extensions.length; j++ )
                {
                    if( fileName.toString().endsWith( extensions[j] ) )
                    {
                        stream.reset();
                        Site[] tempSites = null;
                        tempSites = readers[i].getSites(
                            stream,           // stream to load
                            interactive );  // interactive or not
                        
                        // If this worked, return the sites
                        if( tempSites != null )
                            return tempSites;
                    }   // end if: file matches reader's extension
                }   // end for: through each extension
            }   // end for: through each reader
            
            // If matching extensions did not work, try each reader
            for( int i = 0; i < readers.length; i++ )
            {
                stream.reset();
                Site[] tempSites = null;
                tempSites = readers[i].getSites(
                    stream,           // stream to load
                    interactive );  // interactive or not
                if( tempSites != null )
                    return tempSites;
            }   // end for: through each reader
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
        
        // Must not have found anything.
        return null;
        
    }   // end addSites
    
    
    
    private static SitesFileReader[] getSitesFileReaders( Kernel kernel )
    {
        Vector readers = new Vector();
        
        // Add standard readers
        readers.addElement( new TextSitesFileReader() );
        readers.addElement( new SolomonReader() );
        
        // Check installation directory for readers
        
        
        // Check user directory for readers
        
        
        // Convert Vector to array
        //SitesFileReader[] arrReaders = (SitesFileReader[]) readers.toArray();
        SitesFileReader[] arrReaders = new SitesFileReader[ readers.size() ];
        for( int i = 0; i < arrReaders.length; i++ )
            arrReaders[i] = (SitesFileReader) readers.elementAt(i);
        
        return arrReaders;
    }   // end getSitesFileReaders
    
    
    
    public static File establishUserPrefsDirectory()
    {
        // Point to router directory in user's home directory
        File USERPREFS = new File( System.getProperty( "user.home" ) 
            + "/.afitrouter/" );
        
        // Has it not yet been created?
        if( ! USERPREFS.exists() )
        {
            USERPREFS.mkdir(); // make the directory
        }   // end if: does not yet exist
        
        // If it's not a directory, bail out. Someone's put a file
        // named .afitrouter where the directory should be.
        if( ! USERPREFS.isDirectory() )
        {   AFITRouter.out( "A file called .afitrouter exists where a directory of the same name should be." );
            return null;
        }   // end uh oh.
        
        // If you get this far, everything should be okay.
        return USERPREFS;
        
    }   // end establishUserPrefsDirectory
    
    
    public static File establishRouterDirectory()
    {
        File AFITROUTERHOME = null;
        
        // Point to router installed directory
        String arh = System.getProperty( "user.dir" );
        if( arh == null )
        {
            System.err.println( "No custom features will be loaded." );
            return null;
        }   // end if: variable not defined
        else
        {
            AFITROUTERHOME = new File( arh );
        }
        
        // Has it not yet been created?
        if( ! AFITROUTERHOME.exists() )
        {
            AFITROUTERHOME.mkdir(); // make the directory
        }   // end if: does not yet exist
        
        // If it's not a directory, bail out. There's been a mistake.
        if( ! AFITROUTERHOME.isDirectory() )
        {
            System.err.println( "The variable AFITROUTERHOME points to a file. No custom features will be loaded." );
            return null;
        }   // end uh oh.
        
        // If you get this far, everything should be okay.
        return AFITROUTERHOME;
        
    }   // end establishRouterDirectory
    
    
    
    
}   // end class Utilities