package mil.af.afit.router.app;

import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.net.*;

public class AFITRouterApplet extends JApplet implements Runnable
{
    private final static String
        SAMPLE_DATA_PARAMETER = "sampledata",
        FRAME_BOUNDS_X = "window.main.bounds.x",
        FRAME_BOUNDS_Y = "window.main.bounds.y";
        
    
    private Kernel kernel;
    
    public AFITRouterApplet()
    {   Thread t = new Thread( this );
        t.setDaemon( false );
        t.start();
    }   // end constructor
    
    
    public void run()
    {
        // Create a kernel
        this.kernel = new Kernel();
        this.kernel.setRunningAsApplet();
        
        // Try to set look and feel to coordinate with local computer
	    try 
	    {   Component c = this;
	        while (c.getParent()!=null) c=c.getParent();
	        UIManager.setLookAndFeel(
	            UIManager.getSystemLookAndFeelClassName() );
	        SwingUtilities.updateComponentTreeUI(c);
	    }   //end try
	    catch( Exception e )
	    {   
	    }   // end catch
        
        
        this.getContentPane().add( 
            createAppletPanel( kernel ), 
            BorderLayout.CENTER );
        
        JPanel southPanel = new JPanel( new FlowLayout(FlowLayout.LEFT) );
        this.getContentPane().add(
            southPanel, BorderLayout.SOUTH );
        JButton btnAnotherFrame = new JButton( "Detach" );
        final Kernel kErnel = kernel;
        btnAnotherFrame.addActionListener( new ActionListener()
        {   
            public void actionPerformed( ActionEvent e )
            {   JFrame frame = new JFrame( "AFIT Router" );
                frame.getContentPane().add( 
                    AFITRouterApplet.createAppletPanel(
                    kErnel ), BorderLayout.CENTER );
                
                // Window handler
                final Kernel keRnel = kErnel;
                final JFrame fRame = frame;
                frame.addWindowListener( new WindowAdapter()
                {   public void windowClosing( WindowEvent e )
                    {   keRnel.getPrefs().setProperty( FRAME_BOUNDS_X,
                            ""+fRame.getLocation().x );
                        keRnel.getPrefs().setProperty( FRAME_BOUNDS_Y,
                            ""+fRame.getLocation().y );
                    }   // end windowClosing
                }); // end addWindowListener
                
                // Get window coordinates from prefs
                Preferences prefs = kernel.getPrefs();
                int x,y;
                try
                {   x = new Integer( prefs.getProperty( FRAME_BOUNDS_X ) ).intValue();
                    y = new Integer( prefs.getProperty( FRAME_BOUNDS_Y ) ).intValue();
                }   // end try
                catch( Exception ex )
                {   x = prefs.getDefaultWindowX();
                    y = prefs.getDefaultWindowY();
                }   // end catch
                frame.setLocation( x, y );
                Toolkit theKit = frame.getToolkit();
                Dimension screenSize = theKit.getScreenSize();
                if( x > screenSize.width || y > screenSize.height )
                    frame.setLocation( 20, 20 );
                
                frame.pack();
                //frame.setResizable( false );
                frame.setVisible( true );
            }   // end actionPerformed
        }); // end actionListener
        
        // Make a button for loading sample data
        JButton btnSample = new JButton( "Example" );
//        final Kernel keRnel = kernel;
        final AFITRouterApplet This = this;
        btnSample.addActionListener( new ActionListener()
        {   public void actionPerformed( ActionEvent e )
            {   Thread t = new Thread( new Runnable()
                {   public void run()
                    {   try
                        {   String fileName = This.getParameter( SAMPLE_DATA_PARAMETER );
                            URL sampleURL = new URL( This.getCodeBase(), fileName );
                            This.loadKernel( sampleURL );
                        }   // end try
                        catch( Exception ex )
                        {   ex.printStackTrace();
                        }   // end catch
                    }   // end run
                }); // end runnable, thread
                t.setDaemon(true);
                t.start();
                
            }   // end actionPerformed
        }); // end actionListener
        
        
        // ROZ button
        JButton btnROZ = new JButton( new OpenROZFrameAction(kernel) );
        btnROZ.setText( "ROZ..." );
        
        
        //Memory Button
        // If the MemoryView tool is available, make a spot for it
        Class memoryViewClass = null;
        JButton btnMemory = null;
        try{ memoryViewClass = Class.forName( "MemoryView" ); }
        catch( Exception e ){}
        if( memoryViewClass != null )
        {   btnMemory = new JButton( "Memory..." );
            btnMemory.setToolTipText( "Displays Java memory information" );
            final Class memClass = memoryViewClass;
            btnMemory.addActionListener( new ActionListener()
            {   public void actionPerformed( ActionEvent e )
                {   try{ memClass.newInstance();}
                    catch( Exception ex )
                    {   JOptionPane.showMessageDialog(
                            This,
                            "An error occured: " + ex,
                            "Error",
                            JOptionPane.ERROR_MESSAGE );
                    }   // end catch
                }   // end actionPerformed
            }); // end actionlistener
        }   // end if: memory view available
        
        southPanel.add( btnAnotherFrame );
        if( btnMemory != null )
            southPanel.add( btnMemory );
        southPanel.add( btnSample );
        southPanel.add( btnROZ );
            
            
        this.validate();
        
    }   // end run
    
    public final static JPanel createAppletPanel( Kernel kernel )
    {
        JPanel appletPanel = new JPanel( new BorderLayout() );
        
        // Create and add main panel
        MainPanel mainPanel = new MainPanel( kernel );
        
        // South panel
        JPanel southPanel = new JPanel( new FlowLayout() );
        appletPanel.add( southPanel, BorderLayout.SOUTH );
        
        appletPanel.add( mainPanel, BorderLayout.CENTER );
        return appletPanel;
    }   // end createAppletPanel
    
    
    protected void loadKernel( URL url )
    {   InputStream is = null;
        try
        {   is = new ProgressMonitorInputStream(
                this, // parent component
                "Loading sample data...", // message
                url.openStream() );
            ObjectInputStream ois = new ObjectInputStream( is );
            Kernel k = (Kernel) ois.readObject();
            this.kernel.replace( k );
            this.kernel.setRunningAsApplet();
        }   // end try
        catch( Exception e )
        {   this.kernel = new Kernel();
            this.kernel.setRunningAsApplet();
            e.printStackTrace();
        }   // end catch
        finally
        {   try{ is.close(); } catch(Exception e){}
        }   // end finally
    }   // end loadKernel
    
    
}   // end class AFITRouterApplet