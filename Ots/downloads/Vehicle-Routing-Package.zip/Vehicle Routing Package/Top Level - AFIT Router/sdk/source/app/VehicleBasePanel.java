package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.util.*;

public class VehicleBasePanel
extends JPanel
implements Observer
{
    private Kernel kernel = null;
    private VehiclesTablePopupMenu tablePopupMenu;
    
	JSplitPane jspMainSplit;// = new JSplitPane();
	    JPanel pnlVehiclePanel;// = new JPanel();
	        JScrollPane jscScrollPaneForVehicleTable;// = new JScrollPane();
	            JTable jtbVehicleTable;// = new JTable();
                    VehiclesTableModel mdlVehicleTableModel;// = new VehiclesTableModel();
	    JPanel pnlBasesPanel;// = new JPanel();
	        JScrollPane jscScrollPaneForBaseTable;// = new JScrollPane();
	            JTable jtbBaseTable;// = new JTable();
                    BasesTableModel mdlBaseTableModel;// = new BasesTableModel();
    
    
    
    public VehicleBasePanel( Kernel kernel )
    {   super();
        this.kernel = kernel;
        mdlVehicleTableModel = new VehiclesTableModel( kernel );
        mdlBaseTableModel = new BasesTableModel( kernel );
        this.setupLayout();
        //this.kernel.addObserver( this );
    }   // end constructor
    
    
    private final void setupLayout()
    {
        // Instantiate
	    jspMainSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
	        pnlVehiclePanel = new JPanel(new BorderLayout());
                mdlVehicleTableModel = new VehiclesTableModel( kernel );
	            jtbVehicleTable = new JTable(mdlVehicleTableModel);
	                jtbVehicleTable.setDefaultRenderer( String[].class,
	                    new StringArrayCellRenderer() );
	                jtbVehicleTable.setDefaultEditor( String[].class,
	                    new StringArrayCellEditor() );
	                jtbVehicleTable.setDefaultEditor( Base.class,
	                    new HomeBaseCellEditor(kernel) );
	            jscScrollPaneForVehicleTable = new JScrollPane(jtbVehicleTable);
	        pnlBasesPanel = new JPanel(new BorderLayout());
                mdlBaseTableModel = new BasesTableModel(kernel);
	            jtbBaseTable = new JTable(mdlBaseTableModel);
	            jscScrollPaneForBaseTable = new JScrollPane(jtbBaseTable);
        
        
	    this.setLayout(new BorderLayout());
		this.add(jspMainSplit, BorderLayout.CENTER);
		    jspMainSplit.setOneTouchExpandable(true);
		    jspMainSplit.setTopComponent( pnlVehiclePanel );
		        pnlVehiclePanel.setMinimumSize( new Dimension(100,50) );
		        pnlVehiclePanel.add(jscScrollPaneForVehicleTable, BorderLayout.CENTER);
                    jtbVehicleTable.setSelectionMode(
                        ListSelectionModel.MULTIPLE_INTERVAL_SELECTION );
                    jtbVehicleTable.setCellSelectionEnabled(true);
                    new ExcelAdapter( jtbVehicleTable, ExcelAdapter.BOTH );
		    
		    jspMainSplit.setBottomComponent( pnlBasesPanel );
		        pnlBasesPanel.setMinimumSize( new Dimension(100,50) );
		        pnlBasesPanel.add(jscScrollPaneForBaseTable, BorderLayout.CENTER);
                    jtbBaseTable.setCellSelectionEnabled(true);
                    new ExcelAdapter( jtbBaseTable, ExcelAdapter.BOTH );
        
        
        // Prepare popup menu for vehicle table
        final VehiclesTablePopupMenu popVehicles = 
            new VehiclesTablePopupMenu( mdlVehicleTableModel );
        jtbVehicleTable.addMouseListener( new MouseAdapter()
        {   public void mousePressed( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    popVehicles.show( jtbVehicleTable, e.getX(), e.getY() );
            }   // end mousePressed
            public void mouseClicked( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    popVehicles.show( jtbVehicleTable, e.getX(), e.getY() );
            }   // end mouseClicked
            public void mouseReleased( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    popVehicles.show( jtbVehicleTable, e.getX(), e.getY() );
            }   // end mouseReleased
        }); // end mouseAdapter,mouseListener
        
        
        // Prepare popup menu for base table
        final BasesTablePopupMenu popBases = 
            new BasesTablePopupMenu( mdlBaseTableModel );
        jtbBaseTable.addMouseListener( new MouseAdapter()
        {   public void mousePressed( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    popBases.show( jtbBaseTable, e.getX(), e.getY() );
            }   // end mousePressed
            public void mouseClicked( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    popBases.show( jtbBaseTable, e.getX(), e.getY() );
            }   // end mouseClicked
            public void mouseReleased( MouseEvent e )
            {   if( e.isPopupTrigger() )
                    popBases.show( jtbBaseTable, e.getX(), e.getY() );
            }   // end mouseReleased
        }); // end mouseAdapter,mouseListener
		
        this.validate();
    }   // end setupLayout
      
    
    
    
/* ********  D I V I D E R   L O C A T I O N   C O D E  ******** */    
    
    public final int getDividerLocation()
    {   return jspMainSplit.getDividerLocation();
    }   // end getLastDividerLocation
    
    public final void setDividerLocation( int loc)
    {   jspMainSplit.setDividerLocation( loc );
    }   // end setDividerLocation
    
    
/* ********  O B S E R V E R   C O D E  ******** */    
    
    public void update( Observable thing, Object arg )
    {
        //setupLayout();
    }   // end update
    
    
/* ********  D I S P O S E   C O D E  ******** */


    public final void dispose()
    {   this.kernel.deleteObserver( this );
    }   // end dispose
    
    
}   // end class VehicleBasePanel