package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.net.*;

public class ImportSitesURLAction
extends AbstractAction
{
    private final static String NAME = "Import sites from URL...";
    private Kernel kernel;
    private Component parentComponent;
    
    public ImportSitesURLAction( Component parentComponent, Kernel kernel )
    {   super( NAME );
        this.parentComponent = parentComponent;
        this.kernel = kernel;
    }   // end kernel
    
    public void actionPerformed( ActionEvent e )
    {   final Kernel kErnel = kernel;
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   try
                {   
                    String result = JOptionPane.showInputDialog( "Enter URL of sites file" );
                    AFITRouter.out( result );
                    
                    if( result != null )
                    {
                        URL url = new URL( result );
                        InputStream ustream = url.openStream();
                        InputStream stream = prepareURLStream( ustream );
                        Utilities.addSitesFromStream( stream, result, true, kErnel );
                    }   // end if: result not null                    
                }   // end try
                catch( Exception err )
                {}
            }   // end run
        }); // end runnable, thread
        t.setDaemon( true );
        t.start();
    }   // end actionPerformed
    
    private final InputStream prepareURLStream( InputStream ustream )
    {
        try
        {
            ProgressMonitorInputStream pmis = new 
                ProgressMonitorInputStream( parentComponent, "Loading...", ustream );
            
            byte[] bytes = new byte[ pmis.available() ];
            pmis.read( bytes );
            ByteArrayInputStream bais = new ByteArrayInputStream( bytes );
            bais.mark(Integer.MAX_VALUE);
            
            // Try to figure a way to strip the HTTP header information.
            ObjectInputStream ois = new ObjectInputStream( bais );
            
            
            
            // Until then, just pass the stream on.
            return bais;
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
            return null;
        }   // end e
    }   // end prepareURLStream
    
}   // end ImportSitesURLAction