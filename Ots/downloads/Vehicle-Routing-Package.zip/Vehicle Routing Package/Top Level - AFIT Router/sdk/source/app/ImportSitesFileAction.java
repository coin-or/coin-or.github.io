package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.awt.*;

public class ImportSitesFileAction
extends AbstractAction
{
    private final static String NAME = "Import sites from file...";
    public final static String TOOLTIP = "Import site information from a file";
    private final static String NATIVE_FILE_BOX_KEY = "file.dialog.useNative";
    private static boolean useNativeFileBox = false;
    private Kernel kernel;
    private Component parentComponent;
    
    public ImportSitesFileAction( Component parentComponent, Kernel kernel )
    {   super( NAME );
        this.parentComponent = parentComponent;
        this.kernel = kernel;
        
        // Determine if native file dialog boxes should be used.
        String result = kernel.getPrefs().getProperty( NATIVE_FILE_BOX_KEY );
        try
        {   useNativeFileBox = new Boolean( result ).booleanValue();
        }   // end try
        catch( Exception e ) {}
        kernel.getPrefs().setProperty( NATIVE_FILE_BOX_KEY, ""+useNativeFileBox );
    }   // end kernel
    
    public void actionPerformed( ActionEvent e )
    {   final Kernel kErnel = kernel;
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   try
                {   // See if a previously used directory is recorded
                    String prevDir = kErnel.getPrefs()
                        .getProperty( AFITRouter.PREV_DIR );
                    
                    // If it's not, default to the user's home
                    File currentDir = null;
                    if( prevDir == null || (! new File( prevDir ).exists() ) )
                        currentDir = new File( System.getProperty( "user.dir" ) );
                    else
                        currentDir = new File( prevDir );
                    
                    File file = null;
                    // Open a file chooser dialog: Swing version
                    if( !useNativeFileBox )
                    {   JFileChooser fileChooser = new JFileChooser( currentDir );
                        int option = fileChooser.showOpenDialog( parentComponent );
                        if( option == JFileChooser.APPROVE_OPTION )
                            file = fileChooser.getSelectedFile();
                    }   // end if: swing version
                    else
                    {
                        // Open a file chooser dialog: Native version
                        // Try to find a frame in the tree
                        Frame frame = null;
                        Component c =parentComponent;
                        while( c != null && ! ( c instanceof Frame ) )
                        {   c = c.getParent();
                        }   // end while
                        frame = (c instanceof Frame) ? (Frame)c : new Frame();

                        FileDialog fd = new FileDialog( frame, "Select sites file", FileDialog.LOAD );
                        fd.setDirectory( currentDir.getName() );
                        fd.show();
                        String fileName = fd.getFile();
                        String dir = fd.getDirectory();
                        
                        // If a file was selected, try to open it.
                        if( fileName != null )
                            file = new File( dir, fileName );
                    }   // end if: native version
                    
                        // Get data if file was available
                        if( file != null )
                        {   FileInputStream fis = new FileInputStream( file );
                            Utilities.addSitesFromStream( fis, file.getName(), true, kErnel );
                            kErnel.getPrefs().setProperty(
                                AFITRouter.PREV_DIR, file.getParent() );
                        }   // end if: file not null
                }   // end try
                catch( Exception err )
                {}
            }   // end run
        }); // end runnable, thread
        t.setDaemon( true );
        t.start();
    }   // end actionPerformed
    
}   // end ImportSitesFileAction