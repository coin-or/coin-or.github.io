package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.datatransfer.*;

class OpenClipboardAccessPanelAction
extends AbstractAction
{
    private String LINE;
    private final static int MILLIS_TO_DISPLAY_MESSAGE = 250;
    
    private final static String 
        NO_ACCESS_MESSAGE = "Clipboard access is blocked",
        COPY_SUCCEEDED = "Copied",
        COPY_FAILED = "Copy failed";

    private final static String
        CLIPBOARD_ACCESS_FRAME_BOUNDS = "clipboard access frame bounds",
        FRAME_BOUNDS_X = "window.clipboardaccess.bounds.x",
        FRAME_BOUNDS_Y = "window.clipboardaccess.bounds.y",
        FRAME_BOUNDS_WIDTH = "window.clipboardaccess.bounds.width",
        FRAME_BOUNDS_HEIGHT = "window.clipboardaccess.bounds.height";
        
        
    private ClipboardAccessPanelSource source;
    private Kernel kernel;
    
    protected OpenClipboardAccessPanelAction(
    ClipboardAccessPanelSource source, Kernel kernel )
    {   super( "Clipboard Access..." );
        this.kernel = kernel;
        this.source = source;
    }   // end constructor
    
    public void actionPerformed( ActionEvent e )
    {
        final String Text = source.getClipboardText();
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   
                // If there's access to the clipboard, just copy it directly
                boolean clipboardAccessGranted = false;
                try
                { SecurityManager sm = System.getSecurityManager();
                    if( sm != null )
                        sm.checkSystemClipboardAccess();
                    clipboardAccessGranted = true;
                } // end try
                catch( SecurityException ex )
                { clipboardAccessGranted = false;
                } // end catch
                
                if( clipboardAccessGranted )
                {
                    StringSelection stsel = new StringSelection( Text );
                    Clipboard system = Toolkit.getDefaultToolkit().getSystemClipboard();
                    system.setContents(stsel,stsel);
                    showMessage( COPY_SUCCEEDED );
                }   // end if: clipboard access granted
                else
                {
                    // Create frame to hold access panel
                    JFrame frame = new JFrame( "Clipboard Access" );
                    
                    // Make an access panel
                    ClipboardAccessPanel accessPanel = 
                        new ClipboardAccessPanel( Text );
                    
                    // Add access panel to frame
                    frame.getContentPane().add( 
                        accessPanel, BorderLayout.CENTER );
                    
                    // Window handler
                    final JFrame fRame = frame;
                    final Kernel kErnel = kernel;
                    final ClipboardAccessPanel AccessPanel = accessPanel;
                    frame.addWindowListener( new WindowAdapter()
                    {   public void windowClosing( WindowEvent e )
                        {   // Save bounds
                            Rectangle bounds = fRame.getBounds();
                            Preferences prefs = kErnel.getPrefs();
                            prefs.setProperty( FRAME_BOUNDS_X, ""+bounds.x );
                            prefs.setProperty( FRAME_BOUNDS_Y, ""+bounds.y );
                            prefs.setProperty( FRAME_BOUNDS_WIDTH, ""+bounds.width );
                            prefs.setProperty( FRAME_BOUNDS_HEIGHT, ""+bounds.height );
                        }   // end windowClosing
                        public void windowClosed( WindowEvent e )
                        {   System.gc();
                        }   // end windowClosed
                    }); // end addWindowListener
                    
                    // Read bounds. If there are errors, use defaults
                    Preferences prefs = kernel.getPrefs();
                    try
                    {   int x = new Integer( prefs.getProperty( FRAME_BOUNDS_X ) ).intValue();
                        int y = new Integer( prefs.getProperty( FRAME_BOUNDS_Y ) ).intValue();
                        int width = new Integer( prefs.getProperty( FRAME_BOUNDS_WIDTH ) ).intValue();
                        int height = new Integer( prefs.getProperty( FRAME_BOUNDS_HEIGHT ) ).intValue();
                        frame.setBounds( new Rectangle( x, y, width, height ) );
                    }   // end try
                    catch( Exception ex )
                    {   frame.pack();
                        frame.setLocation( prefs.getDefaultWindowX(), prefs.getDefaultWindowY() );
                    }   // end catch
                    
                    // Make sure it fits
                    Toolkit theKit = frame.getToolkit();
                    Dimension screenSize = theKit.getScreenSize();
                    if( frame.getLocation().x > screenSize.width 
                    || frame.getLocation().y > screenSize.height )
                        frame.setLocation( prefs.getDefaultWindowX(), prefs.getDefaultWindowY() );

                    final JFrame frAme = frame;
                    SwingUtilities.invokeLater( new Runnable()
                    {   public void run()
                        {   frAme.validate();
                            frAme.show();
                        }   // end run
                    }); // end runnable, invokeLater
                }   // end else: no clipboard access
            }   // end run
        }); // end runnable, thread
        t.setDaemon( true );
        t.start();
    }   // end actionPerformed
    
    
    public void showMessage( String message )
    {
        if( source instanceof JComponent )
        {
            JComponent c = (JComponent) source;
            Graphics g = c.getGraphics();
            
            // Center the message in the table.
            g.setFont( new Font( g.getFont().getName(), Font.BOLD, 48 ) );
            int messageWidth = g.getFontMetrics().stringWidth(message);
            int messageHeight = g.getFontMetrics().getAscent();
            int cWidth = c.getVisibleRect().width;
            int cHeight = c.getVisibleRect().height;
            int x = ( cWidth - messageWidth) / 2;
            int y = (cHeight - messageHeight) / 2;
            
            // If Java 2 is available, use its more sophisticated
            // drawing techniques. Otherwise just use the Java 1.1 way.
            boolean JAVA2 = false;
            try
            {   Class.forName( "java.awt.Graphics2D" );
                JAVA2 = true;
            }   // end try
            catch( ClassNotFoundException e )
            {   JAVA2 = false;
            }   // end catch

            if( JAVA2 )
            {
                Graphics2D g2D = (Graphics2D) g;
                    
                // Turn on antialiasing if available
                g2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING,
                                        RenderingHints.VALUE_ANTIALIAS_ON );
                
                g2D.setPaint( new Color( 20, 200, 20, 100 ) );
                
                g2D.drawString( message, x, y );
            }   // end if: Java 2 available.
            else
            {
                g.setColor( new Color( 20, 200, 20 ) );
                g.drawString( message, x, y );
            }   // end else: doesn't have java 2 available.
            
            
            // Pause and then redraw the table
            try
            {   Thread.sleep( MILLIS_TO_DISPLAY_MESSAGE );
            }   // end try
            catch( InterruptedException e ){}
            
            c.repaint();
        }   // end if: source is a component
    }   // end showMessage
    
    
    
    
}   // end class OpenClipboardAccessPanelAction