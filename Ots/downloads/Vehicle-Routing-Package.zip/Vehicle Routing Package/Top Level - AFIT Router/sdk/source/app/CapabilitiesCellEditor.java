package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;
import java.util.*;

class CapabilitiesCellEditor
implements TableCellEditor
{
    private static Kernel kernel;
    protected transient Vector listeners;
    protected transient String[] originalValue;
    protected transient String[] value;
    
    public CapabilitiesCellEditor( Kernel kernel )
    {   super();
        CapabilitiesCellEditor.kernel = kernel;
    }   // end constructor
    
    public CapabilitiesCellEditor()
    {   super();
    }   // end constructor
    
    
/* ********  T A B L E C E L L E D I T O R   C O D E  ******** */    
    
    public Component getTableCellEditorComponent(
    JTable table, Object value, boolean isSelected,
    int row, int column )
    {
        if( value == null )
            return null;
        else if( value instanceof String[] )
        {
            return null;
        }   // end else if: string array
        else return null;
    }   // end getTableCellEditorComponent
    
    public void cancelCellEditing()
    {   fireEditingCanceled();
    }   // end cancelCellEditing
    
    public Object getCellEditorValue()
    {
        return null;
    }   // end getCellEditorValue
    
    public boolean isCellEditable( EventObject eo )
    {   return true;
    }   // end isCellEditable
    
    public boolean shouldSelectCell( EventObject eo )
    {   return true;
    }   // end shouldSelectCell
    
    public boolean stopCellEditing()
    {   fireEditingStopped();
        return true;
    }   // end stopCellEditing
    
    public void addCellEditorListener( CellEditorListener listener )
    {   listeners.addElement( listener );
    }   // end addCellEditorListener
    
    public void removeCellEditorListener( CellEditorListener listener )
    {   listeners.removeElement( listener );
    }   // end removeCellEditorListener
    
    protected void fireEditingCanceled()
    {   this.value = originalValue;
        ChangeEvent ce = new ChangeEvent( this );
        for( int i = 0; i < listeners.size(); i++ )
            ((CellEditorListener)listeners.elementAt(i))
            .editingCanceled(ce);
    }   // end fireEditingCanceled
    
    protected void fireEditingStopped()
    {   ChangeEvent ce = new ChangeEvent( this );
        for( int i = 0; i < listeners.size(); i++ )
            ((CellEditorListener)listeners.elementAt(i))
            .editingStopped(ce);
    }   // end fireEditingStopped
    
    
}   // end class CapabilitiesCellEditor