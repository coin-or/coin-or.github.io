package mil.af.afit.router.app;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class SolutionsTablePopupMenu
extends JPopupMenu
implements ActionListener
{
    SolutionTableModel tableModel;
    
    private int modelColumn;
    private int modelRow;
    private int[] selectedRows;
    private int[] selectedColumns;
    
    JMenuItem sortAscending;
    JMenuItem sortDescending;
    
    public SolutionsTablePopupMenu( SolutionTableModel tableModel )
    {   
        super();
        
        this.tableModel = tableModel;
        
        sortAscending = new JMenuItem( "Sort ascending" );
        sortDescending = new JMenuItem( "Sort descending" );
        
        // Action listeners
        sortAscending.addActionListener( this );
        sortDescending.addActionListener( this );
        
        // Build popup menu
        this.add( sortAscending );
        this.add( sortDescending );
        
    }   // end constructor
    
    
    public final void handleSortableSetup( boolean state )
    {   sortAscending.setEnabled( state );
        sortDescending.setEnabled( state );
    }   // end setSortable
    
    
/* ********  S H O W   C O D E  ******** */
    
    public void show( JTable hostTable, int x, int y )
    {
        this.modelColumn = hostTable.convertColumnIndexToModel(
            hostTable.columnAtPoint( new Point(x,y) ) );
        this.modelRow = hostTable.rowAtPoint( new Point(x,y) );
            
        handleSortableSetup( tableModel.isColumnSortable( modelColumn ) );

        super.show( hostTable, x, y );
    }   // end show

        
        
/* ********  A C T I O N L I S T E N E R   C O D E  ******** */
        
    public void actionPerformed( ActionEvent e )
    {
        // Sort?
        if( e.getSource() == sortAscending )
            tableModel.sort( modelColumn, true );
        else if( e.getSource() == sortDescending )
            tableModel.sort( modelColumn, false );
    }   // end actionPerformed
        
}   // end class SolutionsTablePopupMenu