package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.util.*;
import javax.swing.table.*;


public class BasesTableModel 
extends AbstractTableModel 
implements Observer
{
    BaseList baseList=null;
    Kernel kernel;
    Base emptyBase;
    private String[] columnNames;
    private int[] columnOrder;
    private final static int NAME = 0;
    private final static int LATITUDE = 1;
    private final static int LONGITUDE = 2;
    private final static int NUM_OF_COLUMNS = 3;
    
    
    public BasesTableModel( Kernel kernel )
    {
        this.kernel = kernel;
        this.emptyBase = new Base();
        this.baseList = kernel.getBaseList();
        setupColumnOrder();
        setupColumnNames();
        baseList.addObserver( this );
        this.update( baseList, null );
    }   // end constructor
    
    
    public final void setKernel( Kernel kernel )
    {   this.baseList = kernel.getBaseList();
        this.baseList.addObserver( this );
        this.update( baseList, null );
    }   // end setKernel
    
    private void setupColumnOrder()
    {
        // For now, fixed
        columnOrder = new int[ getColumnCount() ];
        columnOrder[NAME] = 0;
        columnOrder[LATITUDE] = 1;
        columnOrder[LONGITUDE] = 2;
    }   // end setupColumnOrder
    
    private void setupColumnNames()
    {
        columnNames = new String[ getColumnCount() ];
        columnNames[NAME] = "Name";
        columnNames[LATITUDE] = "Latitude";
        columnNames[LONGITUDE] = "Longitude";
    }   // end setupColumnNames
    
    public final void removeBaseAt( int index )
    {   baseList.removeBaseAt( index );
    }   // end removeBaseAt
    
    public final void removeBasesAt( int[] indeces )
    {   // if the last index points to the empty entry, remake the list
        // without that entry (which doesn't exist anyway)
        if( indeces[indeces.length-1] == baseList.getBases().length )
        {   int[] temp = new int[ indeces.length-1 ];
            System.arraycopy(indeces,0,temp,0,temp.length);
            indeces = temp;
        }   // end if: strip off fake vehicle at end
        baseList.removeBasesAt( indeces );
    }   // end removeBasesAt
    
    

/* ********  O B S E R V E R   C O D E  ******** */
    
    public void update( Observable thing, Object obj )
    {   fireTableDataChanged();
    }   // end update

    
/* ********  A B S T R A C T T A B L E M O D E L   C O D E  ******** */

    public final int getColumnCount()
    {
        return NUM_OF_COLUMNS;
    }   // end getColumnCount
    
    public int getRowCount()
    {   return baseList.getBases().length + 1;
    }   // end getRowCount
    
    public String getColumnName( int column )
    {   int i = 0;
        while( columnOrder[i] != column && i < getColumnCount() )
            i++;
        if( i < getColumnCount() )
            return columnNames[ i ];
        else return null;
    }   // end getColumnName
    
    public Object getValueAt( int row, int column )
    {
        
        final boolean isEmptyBase = 
            row == baseList.getBases().length;
        final Base base = isEmptyBase ?
                emptyBase : baseList.getBases()[row];
        
        
        if( base != null )
        {
            if( column == columnOrder[NAME] )
                return base.getName();
            else
            if( column == columnOrder[LATITUDE] )
                return CoreUtilities.doubleLatToString( base.getLatitude(), kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT) );
            else
            if( column == columnOrder[LONGITUDE] )
                return CoreUtilities.doubleLonToString( base.getLongitude(), kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT) );
            else return null;
        }   // end if: base not null
        else return null;
    }   // end getValueAt
    
    public boolean isCellEditable( int row, int column )
    {   return true;
    }   // end isCellEditable
    
    public void setValueAt( Object value, int row, int column )
    {
        
        final boolean isEmptyBase = 
            row == baseList.getBases().length;
        final Base base = isEmptyBase ?
                emptyBase : baseList.getBases()[row];
        
        if( base != null )
        {
            if( column == columnOrder[NAME] )
                base.setName( (String) value );
            else
                    if( column == columnOrder[LATITUDE] )
                    {   String lat = value.toString().toUpperCase();
                        if( lat.indexOf('N')<0 && lat.indexOf('S')<0 )
                        {   String def = kernel.getPrefs().getProperty( AFITRouter.DEFAULT_LAT_DIRECTION );
                            def = def == null ? "N" : def.substring(0,1);
                            lat = lat+def;
                        }   // end if: no north/south specified
                        base.setLatitude( 
                            CoreUtilities.stringLatToDouble( lat, kernel.getPrefs().getProperty( AFITRouter.LAT_LON_FORMAT ) ) );
                    }   // end if: latitude
                    else
                    if( column == columnOrder[LONGITUDE] )
                    {   String lon = value.toString().toUpperCase();
                        if( lon.indexOf('E')<0 && lon.indexOf('W')<0 )
                        {   String def = kernel.getPrefs().getProperty( AFITRouter.DEFAULT_LON_DIRECTION );
                            def = def == null ? "E" : def.substring(0,1);
                            lon = lon+def;
                        }   // end if: no north/south specified
                        base.setLongitude( 
                            CoreUtilities.stringLonToDouble( lon, kernel.getPrefs().getProperty( AFITRouter.LAT_LON_FORMAT ) ) );
                    }   // end if: latitude
                
            // If it was the empty base being edited, then actually
            // a base was being added.
            if( isEmptyBase )
            {
                Base temp = emptyBase;
                emptyBase = new Base();
                baseList.addBase( temp );
            }   // end if: is empty base
        
        }   // end if: base not null
            
    }   // end setValueAt
    
    
}   // end class BasesTableModel