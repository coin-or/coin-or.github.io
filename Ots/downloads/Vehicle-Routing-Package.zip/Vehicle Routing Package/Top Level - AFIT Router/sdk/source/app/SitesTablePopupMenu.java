package mil.af.afit.router.app;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class SitesTablePopupMenu
extends JPopupMenu
implements ActionListener
{
    private final static String
        DELETE_SINGLE = "Delete site",
        DELETE_MULTIPLE = "Delete selected sites";
    
    SitesTableModel tableModel;
    
    private int modelColumn;
    private int modelRow;
    private int[] selectedRows;
    private int[] selectedColumns;
    
    JMenuItem sortAscending;
    JMenuItem sortDescending;
    JMenuItem deleteSelected;
    
    public SitesTablePopupMenu( SitesTableModel tableModel )
    {   
        super();
        
        this.tableModel = tableModel;
        
        sortAscending = new JMenuItem( "Sort ascending" );
        sortDescending = new JMenuItem( "Sort descending" );
        deleteSelected = new JMenuItem( DELETE_SINGLE );
        
        // Action listeners
        sortAscending.addActionListener( this );
        sortDescending.addActionListener( this );
        deleteSelected.addActionListener( this );
        
        // Build popup menu
        this.add( sortAscending );
        this.add( sortDescending );
        this.addSeparator();
        this.add( deleteSelected );
        
    }   // end constructor
    
    
    public final void handleSortableSetup( boolean state )
    {   sortAscending.setEnabled( state );
        sortDescending.setEnabled( state );
    }   // end setSortable
    
    
    public final void handleDeleteSetup( JTable hostTable )
    {
        // If there's only one row selected, or no rows,
        // then change the label on the menu item.
        this.selectedRows = hostTable.getSelectedRows();
        this.selectedColumns = hostTable.getSelectedRows();
        
        // If now rows were selected or a leftover cell is
        // technically selected, but not such that a user would
        // recognize it, set selected to the
        // row where the user clicked.
        if( selectedRows.length == 0
        || (selectedRows.length==1 && selectedColumns.length==1) )
        {   selectedRows = new int[1];
            selectedRows[0] = modelRow;
        }   // end if: zero rows selected

        
        if( selectedRows.length > 1 )
            deleteSelected.setText( DELETE_MULTIPLE );
        else deleteSelected.setText( DELETE_SINGLE );
    }   // end handleDeleteSetup

    
/* ********  S H O W   C O D E  ******** */
    
    public void show( JTable hostTable, int x, int y )
    {
        this.modelColumn = hostTable.convertColumnIndexToModel(
            hostTable.columnAtPoint( new Point(x,y) ) );
        this.modelRow = hostTable.rowAtPoint( new Point(x,y) );
            
        handleSortableSetup( tableModel.isColumnSortable( modelColumn ) );
        handleDeleteSetup( hostTable );

        super.show( hostTable, x, y );
    }   // end show

        
        
/* ********  A C T I O N L I S T E N E R   C O D E  ******** */
        
    public void actionPerformed( ActionEvent e )
    {
        // Sort?
        if( e.getSource() == sortAscending )
            tableModel.sort( modelColumn, true );
        else if( e.getSource() == sortDescending )
            tableModel.sort( modelColumn, false );
        else if( e.getSource() == deleteSelected )
            tableModel.removeSitesAt( selectedRows );
    }   // end actionPerformed
        
}   // end class SitesTablePopupMenu