package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;

class OtherSettingsPanel 
extends JPanel
{
    private final static int FIELD_LENGTH = 8;
    
    private final static String
        PRIORITY_TOOLTIP = "Default priority for sites",
        SERVICE_TIME_TOOLTIP = "Default service time for sites (in minutes)",
        WIND_SPEED_TOOLTIP = "Wind speed (in knots)",
        WIND_BEARING_TOOLTIP = "Wind direction--'from' not 'bearing'--in degrees clockwise from North)";
    
    private JTextField txtDefaultPriority;
    private JTextField txtDefaultServiceTime;
    private JTextField txtWindSpeed;
    private JTextField txtWindFrom;
    
    private ButtonGroup bgDefaultLat;
    private ButtonGroup bgDefaultLon;
    private JRadioButton rbNorth;
    private JRadioButton rbSouth;
    private JRadioButton rbEast;
    private JRadioButton rbWest;
    
    private ButtonGroup bgLatLonFormat;
    private String[] strLatLonFormats = { "dddmmss", "dddmmhh", "ddd.hh" };
    private JRadioButton[] rbLatLonFormats =
        { new JRadioButton( strLatLonFormats[0] ),
          new JRadioButton( strLatLonFormats[1] ),
          new JRadioButton( strLatLonFormats[2] ) };
    private String[] strLatLonFormatToolTips = 
        { "degrees, minutes, seconds",
          "degrees, minutes, hundredths",
          "degrees.hundredths of degrees" };
    
    private int previousDefaultPriority;
    private int previousDefaultServiceTime;
    private int previousWindSpeed;
    private int previousWindBearing;
    private String previousDefaultLat;
    private String previousDefaultLon;
    private String previousLatLonFormat;
    
    private Kernel kernel;
    private Wind previousWind;
    
    public OtherSettingsPanel( Kernel kernel )
    {
        super();
        
        this.kernel = kernel;
        
        // Get existing values
        previousDefaultPriority = kernel.getPrefs().getDefaultPriority();
        previousDefaultServiceTime = kernel.getPrefs().getDefaultServiceTime();
        previousDefaultLat = kernel.getPrefs().getProperty( AFITRouter.DEFAULT_LAT_DIRECTION );
        previousDefaultLon = kernel.getPrefs().getProperty( AFITRouter.DEFAULT_LON_DIRECTION );
        previousLatLonFormat = kernel.getPrefs().getProperty( AFITRouter.LAT_LON_FORMAT );
        
        // The core AFIT router supports multiple winds, but
        // I'm only displaying one at a time for now.
        Wind[] winds = kernel.getWindList().getWinds();
        Wind wind = winds.length > 0 ? winds[0] : new Wind();
        previousWindSpeed = wind.getSpeed();
        previousWindBearing = wind.getBearing();
        previousWind = wind;
        
        setupLayout( kernel );
    }   // end constructor
    
    
    private final void setupLayout( Kernel kernel )
    {
        // Setup text fields
        txtDefaultPriority = new JTextField( "" +
            previousDefaultPriority, FIELD_LENGTH );
        txtDefaultPriority.setToolTipText( PRIORITY_TOOLTIP );
        txtDefaultServiceTime = new JTextField( "" +
            previousDefaultServiceTime, FIELD_LENGTH );
        txtDefaultServiceTime.setToolTipText( SERVICE_TIME_TOOLTIP );
            
        txtWindSpeed = new JTextField( "" +
            previousWindSpeed, FIELD_LENGTH );
        txtWindSpeed.setToolTipText( WIND_SPEED_TOOLTIP );
        txtWindFrom = new JTextField( "" +
            CoreUtilities.reverseDirection(previousWindBearing), FIELD_LENGTH );
        txtWindFrom.setToolTipText( WIND_BEARING_TOOLTIP );
        
        // Set up button groups for lat/lon direction defaults
        rbNorth = new JRadioButton( "North" );
        rbSouth = new JRadioButton( "South" );
        rbEast =  new JRadioButton( "East" );
        rbWest =  new JRadioButton( "West" );
        if( previousDefaultLat != null && previousDefaultLat.toUpperCase().indexOf("S")>=0 )
            rbSouth.setSelected( true );
        else rbNorth.setSelected(true);
        if( previousDefaultLon != null && previousDefaultLon.toUpperCase().indexOf("W")>=0 )
            rbWest.setSelected( true );
        else rbEast.setSelected(true);
        bgDefaultLat = new ButtonGroup();
        bgDefaultLon = new ButtonGroup();
        bgDefaultLat.add( rbNorth );
        bgDefaultLat.add( rbSouth );
        bgDefaultLon.add( rbEast );
        bgDefaultLon.add( rbWest );
        
        // Set up button groups for lat/lon formats
        bgLatLonFormat = new ButtonGroup();
        for( int i = 0; i < rbLatLonFormats.length; i++ )
        {   bgLatLonFormat.add( rbLatLonFormats[i] );
            rbLatLonFormats[i].setToolTipText(strLatLonFormatToolTips[i]);
            if( strLatLonFormats[i].equals( previousLatLonFormat ) )
                rbLatLonFormats[i].setSelected(true);
        }   // end for: each format type
        if( bgLatLonFormat.getSelection() == null )
            rbLatLonFormats[0].setSelected(true);
        
        
        // Make a wind panel
        JPanel pnlWind = new JPanel( new GridLayout(2,1) );
        pnlWind.setBorder( new TitledBorder( "Wind" ) );
            JPanel pnlLabels1 = new JPanel( new BorderLayout() );
                JLabel label1 = new JLabel( "Speed:" );
                label1.setToolTipText( WIND_SPEED_TOOLTIP );
                label1.setLabelFor( txtWindSpeed );
                pnlLabels1.add( label1, BorderLayout.WEST );
                pnlLabels1.add( txtWindSpeed, BorderLayout.EAST );
            JPanel pnlLabels2 = new JPanel( new BorderLayout() );
                JLabel label2 = new JLabel( "From:" );
                label2.setToolTipText( WIND_BEARING_TOOLTIP );
                label2.setLabelFor( txtWindFrom );
                pnlLabels2.add( label2, BorderLayout.WEST );
                pnlLabels2.add( txtWindFrom, BorderLayout.EAST );
        pnlWind.add( pnlLabels1 );
        pnlWind.add( pnlLabels2 );
        
        // Make a site panel
        JPanel pnlSites = new JPanel( new GridLayout(2,1) );
        pnlSites.setBorder( new TitledBorder( "Site Defaults" ) );
            JPanel pnlLabels3 = new JPanel( new BorderLayout() );
                JLabel label3 = new JLabel( "Priority:" );
                label3.setToolTipText( PRIORITY_TOOLTIP );
                label3.setLabelFor( txtDefaultPriority );
                pnlLabels3.add( label3, BorderLayout.WEST );
                pnlLabels3.add( txtDefaultPriority, BorderLayout.EAST );
            JPanel pnlLabels4 = new JPanel( new BorderLayout() );
                JLabel label4 = new JLabel( "Service Time:" );
                label4.setLabelFor( txtDefaultServiceTime );
                label4.setToolTipText( SERVICE_TIME_TOOLTIP );
                pnlLabels4.add( label4, BorderLayout.WEST );
                pnlLabels4.add( txtDefaultServiceTime, BorderLayout.EAST );
        pnlSites.add( pnlLabels3 );
        pnlSites.add( pnlLabels4 );
        
        // Make a default lat/lon directions panel
        JPanel pnlLatLonDirs = new JPanel( new GridLayout(1,2) );
            pnlLatLonDirs.setBorder( new TitledBorder( "Lat/Lon Directions" ) );
            JPanel pnlLat = new JPanel( new GridLayout(2,1) );
                pnlLat.add( rbNorth );
                pnlLat.add( rbSouth );
            JPanel pnlLon = new JPanel( new GridLayout(2,1) );
                pnlLon.add( rbEast );
                pnlLon.add( rbWest );
            pnlLatLonDirs.add( pnlLat );
            pnlLatLonDirs.add( pnlLon );
            
        // Lat/Lon formats panel
        JPanel pnlLatLonFormats = new JPanel( new GridLayout( rbLatLonFormats.length, 1 ) );
            pnlLatLonFormats.setBorder( new TitledBorder( "Lat/Lon Formats" ) );
            for( int i = 0; i < rbLatLonFormats.length; i++ )
                pnlLatLonFormats.add( rbLatLonFormats[i] );
        
        
        // Put stuff on main panel
        JPanel pnlMain = new JPanel( new BorderLayout() );
            JPanel pnlTop = new JPanel( new GridLayout(1,2) );
                pnlTop.add( pnlSites );
                pnlTop.add( pnlWind );
            JPanel pnlBottom = new JPanel( new GridLayout(1,2) );
                pnlBottom.add( pnlLatLonDirs );
                pnlBottom.add( pnlLatLonFormats );
            pnlMain.add( pnlTop, BorderLayout.NORTH );
            pnlMain.add( pnlBottom, BorderLayout.SOUTH );
        
        // Add main to this
        this.setLayout( new BorderLayout() );
        this.add( pnlMain, BorderLayout.CENTER );
    }   // end setupLayout
    
    
/* ********  G E T   M E T H O D S  ******** */
    
    
    public final int getDefaultPriority()
    {   try
        {   return Integer.parseInt( txtDefaultPriority.getText() );
        }   // end try
        catch( Exception e )
        {   return previousDefaultPriority;
        }   // end catch
    }   // end getDefaultPriority
    
    public final int getDefaultServiceTime()
    {   try
        {   return Integer.parseInt( txtDefaultServiceTime.getText() );
        }   // end try
        catch( Exception e )
        {   return previousDefaultServiceTime;
        }   // end catch
    }   // end getDefaultServiceTime
    
    public final int getWindSpeed()
    {   try
        {   return Integer.parseInt( txtWindSpeed.getText() );
        }   // end try
        catch( Exception e )
        {   return previousWindSpeed;
        }   // end catch
    }   // end getWindSpeed
    
    
    public final int getWindFrom()
    {   try
        {   return CoreUtilities.reverseDirection( 
                Integer.parseInt( txtWindFrom.getText() ) );
        }   // end try
        catch( Exception e )
        {   return previousWindBearing;
        }   // end catch
    }   // end getWindBearing
    
    
    public final String getDefaultLatDirection()
    {   if( rbSouth.isSelected() )
            return "South";
        else return "North";
    }   // end getDefaultLatDirection
    
    public final String getDefaultLonDirection()
    {   if( rbWest.isSelected() )
            return "West";
        else return "East";
    }   // end getDefaultLonDirection
    
    public final String getLatLonFormat()
    {   String s = "";
        for( int i = 0; i < rbLatLonFormats.length; i++ )
            if( rbLatLonFormats[i].isSelected() )
            {   s = strLatLonFormats[i];
                break;
            }   // end if: found match
        return s;
    }   // end getDefaultLatDirection
    
/* ********  S A V E   M E T H O D  ********* */
    
    public final void saveSettings()
    {
                    
        // Get settings
        int defaultPriority = getDefaultPriority();
        int defaultServiceTime = getDefaultServiceTime();
        int windSpeed = getWindSpeed();
        int windBearing = getWindFrom();
        String defaultLat = getDefaultLatDirection();
        String defaultLon = getDefaultLonDirection();
        String latLonFormat = getLatLonFormat();
                    
        // Set prefs
        Preferences prefs = kernel.getPrefs();
        prefs.setDefaultPriority( defaultPriority );
        prefs.setDefaultServiceTime( defaultServiceTime );
        prefs.setProperty( AFITRouter.DEFAULT_LAT_DIRECTION, defaultLat );
        prefs.setProperty( AFITRouter.DEFAULT_LON_DIRECTION, defaultLon );
        prefs.setProperty( AFITRouter.LAT_LON_FORMAT, latLonFormat );
                    
        // Set wind speed
        previousWind.setSpeed( windSpeed );
        previousWind.setBearing( windBearing );
                    
    }   // end saveSettings
    
}   // end class OtherSettingsPanel