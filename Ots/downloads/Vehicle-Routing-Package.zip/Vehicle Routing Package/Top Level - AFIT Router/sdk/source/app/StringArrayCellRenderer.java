package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

public class StringArrayCellRenderer 
extends DefaultTableCellRenderer
{
    public StringArrayCellRenderer()
    {   super();
    }   // end constructor
    
    public Component getTableCellRendererComponent(
    JTable table, Object value, boolean isSelected,
    boolean hasFocus, int row, int column )
    {
        Object newValue = value;
        if( value instanceof String[] )
        {   StringBuffer s = new StringBuffer();
            String[] ss = (String[]) value;
            for( int i = 0; i < ss.length; i++ )
                s.append( ss[i] + 
                    ( i < ss.length-1
                    ? ", "
                    : "") );
            newValue = s.toString();
        }   // end if: string array passed
        return super.getTableCellRendererComponent( 
            table, newValue, isSelected, hasFocus, row, column );
    }   // end getTableCellRendererComponent
    
    
}   // end class CapabilitiesCellRenderer