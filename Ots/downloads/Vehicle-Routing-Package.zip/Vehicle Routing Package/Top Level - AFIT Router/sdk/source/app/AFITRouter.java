package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.io.*;
import java.util.*;

public class AFITRouter implements Runnable
{
    public final static String 
        KEY_AFITROUTER = "Parent AFITRouter object",
        KEY_SAVE_KERNEL = "Save the kernel to disk",
        KEY_KERNEL_WAS_SAVED = "Kernel was loaded from saved version on disk",
        KEY_LAST_LAF = "laf.lastused",
        PREV_DIR = "file.dir.last",
        FRAME_BOUNDS_X = "window.main.bounds.x",
        FRAME_BOUNDS_Y = "window.main.bounds.y",
        DEFAULT_LAT_DIRECTION = "coordinate.latitude.direction.default",
        DEFAULT_LON_DIRECTION = "coordinate.longitude.direction.default",
        LAT_LON_FORMAT = "coordinate.format";
    
    private final static String[] NO_SWING = 
        { "Error loading Swing",
          "Java's Swing components do not seem to",
          "be installed correctly. Depending on your",
          "computer platform, you may need to reinstall",
          "Java or download Swing from java.sun.com and",
          "put the swingall.jar file in your CLASSPATH or",
          "Extensions:MRJ Libraries:MRJClasses folder."
        };
        
    private boolean runWindowed = true;
    
    private static boolean DEBUGGING = false;
    private static boolean doneLoading = false;
    private static String[] args;
    
    private File AFITROUTERHOME = null;
    private File USERPREFSDIR = null;
    private final static String
        KERNEL_FILE_NAME = "kernel",
        BASELIST_FILE_NAME = "bases",
        VEHICLELIST_FILE_NAME = "vehicles",
        ROZLIST_FILE_NAME = "roz",
        PREF_FILE_NAME = "prefs",
        PRIORITYMODELLIST_FILE_NAME = "priorities",
        WIND_FILE_NAME = "wind";
    
    private boolean quitAndSave = false;

    private Kernel kernel;


private static void muckAbout()
{   String[] times = {"1030h", "1030 h", " 1030 h", " 1030h", "125", "125h",
        "1030h +1", "1030h + 1", "1030h + 1 day", "1030+3days"};
    for( int i = 0; i < times.length; i++ )
    {   System.out.println( times[i] + ":" );
        int time = CoreUtilities.stringTimeToInt( times[i] );
        System.out.println( "  Time=" + time );
    }   // end for
}   // end muckabout


    public static void main( String[] args )
    {
        //muckAbout();         // Debugging
        
        // If Swing is not loaded, say so and bail.
        try
        {   Class c = Class.forName( "javax.swing.JLabel" ); // Any swing component would work
        }   // end try
        catch( ClassNotFoundException e )
        {   try
            {   java.awt.Frame f = new java.awt.Frame( NO_SWING[0] );
                f.setLayout( new java.awt.GridLayout(NO_SWING.length,1) );
                for( int i = 0; i < NO_SWING.length; i++ )
                    f.add( new java.awt.Label( NO_SWING[i], java.awt.Label.CENTER ) );
                f.pack();
                java.awt.Toolkit t = f.getToolkit();
                f.setLocation( (t.getScreenSize().width-f.getSize().width)/2, (t.getScreenSize().height-f.getSize().height)/2 );
                f.addWindowListener( new java.awt.event.WindowAdapter()
                {   public void windowClosing( java.awt.event.WindowEvent e )
                    {   System.exit(0);
                    }   // end windowClosed
                }); // end WindowAdapter
                f.show();
            }   // end try
            catch( Exception ex ){System.exit(0);}
        }   // end catch
        
        // Show something right away to make the program seem
        // to respond faster.
        Window infoFrame = new Window(new Frame());
        infoFrame/*.getContentPane()*/.setLayout( new BorderLayout() );
        Panel p = new Panel( new BorderLayout() );
        //p.setBorder( new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED) );
        p.add(  new Label( "Loading AFIT Router v1.0.1...", Label.CENTER ), BorderLayout.CENTER );
        infoFrame/*.getContentPane()*/.add( p, BorderLayout.CENTER );
        Toolkit theKit = infoFrame.getToolkit();
        Dimension screenSize = theKit.getScreenSize();
        int width = 170; 
        int height = 70;
        infoFrame.setBounds( new Rectangle( 
            (screenSize.width-width)/2,
            (screenSize.height-height)/2,
            width, height ) );
        infoFrame.show();
        
        
        // Get the complicated things loading going in another thread
        AFITRouter.args = args;
        AFITRouter arouter = new AFITRouter();
        Thread t = new Thread( arouter );
        t.setDaemon( false );
        t.start();
        
        
        // Wait for word to close
        synchronized( arouter )
        {   while( ! doneLoading )
            {   arouter.notifyAll();
                try
                {   arouter.wait();
                }   // end try
                catch( InterruptedException e )
                {   AFITRouter.err( e );
                }   // end catch
            }   // end while: not done loading
        }   // end sync: doneLoading
        infoFrame.dispose();
        
    }   // end main
    
    
    public AFITRouter()
    {
    }   // end AFITRouter constructor
    
    
    public void run()
    {
        // Establish relevant directories
        establishDirectories();
        
        // Load kernel
        loadKernel();
        
/*        // If the kernel was loaded from disk, don't bother
        // also loading all these other things.
        Boolean kernelCameFromDisk = (Boolean) kernel
            .getClientProperty( KEY_KERNEL_WAS_SAVED );
        if( kernelCameFromDisk == null
        || 
            ( kernelCameFromDisk != null 
            && !kernelCameFromDisk.booleanValue() ) )
        {
*/            // Try to load preferences
            loadPreferences();
            
            // Load base list
            loadBaseList();
            
            // Load vehicle list
            loadVehicleList();
            kernel.getVehicleList().initializeAfterDeserialization(kernel);
            
            // Load priority models
            loadPriorityModelList();
            kernel.getPriorityModelList().initializeAfterDeserialization(kernel);
            
            // Load Restricted Operating Zone (ROZ) list
            loadROZList();
            
            // Load wind list
            loadWindList();
//        }   // end if: kernel didn't come from the disk               

        
        processArgs( args );
        
        
        
        // See if this should be run entirely from the
        // command prompt or open up the GUI window
        if( runWindowed )
        {
            // Show main frame, but get it going in another thread
            final Kernel kErnel = this.kernel;
            final AFITRouter This = this;
            Thread t = new Thread( new Runnable()
            {   public void run()
                {   This.openMainFrame( kErnel );
                }   // end run
            }); // end runnable, thread
            t.setDaemon( true );
            t.start();
        }   // end if: run as a window
        else
        {
            // NOT CURRENTLY SUPPORTED
            quitAndSave = true;
            // Put code here for when an automatic answer is requested,
            // i.e., there's to be no window, just an answer outputed
            // somehow.
            /* code here */
        }   // end else: run without interaction
        
        
        // Program will wait here until it's time to quit.
        synchronized( this )
        {   while( ! quitAndSave )
            {   this.notifyAll();
                try
                {   this.wait();
                }   // end try
                catch( Exception e )
                {   AFITRouter.err( e );
                }   // end catch
            }   // end while: not time to quit
        }   // end sync: this
        
        // Quit
        quit();
        
    }   // end run
    
    private final void quit()
    {
        // Quit
        //saveLAFToPrefs();
        savePreferences();
        saveBaseList();
        saveVehicleList();
        saveROZList();
        savePriorityModelList();
        saveWindList();
        System.exit(0);
    }   // end quit
    
    
    private void processArgs( String[] args )
    {
        AFITRouter.out( "AFITRouter.processArgs: calling" );
        
        int i = 0;
        while( i < args.length )
        {
            // Was it requested to open with no window?
            if( args[i].equals( "-nowindow" ) )
            {   this.runWindowed = false;
                i++;
                continue;
            }   // end if: nowindow
                        
            // Was an effort specified?
            else
            if( args[i].equals( "-effort" ) )
            {   try
                {   kernel.getPrefs().setLastRequestedSolutionEffort(
                        i < args.length-1 
                        ? new Double( args[i+1] ).doubleValue()
                        : .2 );
                }   // end try
                catch( Exception e )
                {}  // end catch: just press on.
                i += 2;
            }   // end if: solver specified
            
            // Was a sites file specified?
            else
            if( args[i].equals( "-sites" ) )
            {
                i++;    // Increment argument counter
                if( i < args.length )
                {   try
                    {   final File sitesFile = new File( args[i] );
                        Thread t = new Thread( new Runnable()
                        {   public void run()
                            {   long start = System.currentTimeMillis();
                                addSitesFromFile( sitesFile );
                                double secs = (System.currentTimeMillis()-start)/1000.;
                                AFITRouter.out( "Seconds to load file: " + secs );
                            }   // end run
                        }); // end thread
                        t.start();
                    }   // end try: get sites files
                    catch( Exception e )
                    {   AFITRouter.err( e );
                    }   // end catch: error getting file
                    i++;    // increment argument counter
                }   // end if: at least one argument following
            }   // end if: sites file
            
            
            else
            {
                i++;
            }   // end else: argument not meaningful
        }   // end while: through each argument
    }   // end processArgs
    
    protected void addSitesFromFile( File file )
    {
        try
        {
            FileInputStream fis = new FileInputStream( file );
            Utilities.addSitesFromStream( 
                fis, file.getName(), runWindowed, kernel );
        }   // end try
        catch( FileNotFoundException e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end addSitesFromFile
    

    private void establishDirectories()
    {   USERPREFSDIR = Utilities.establishUserPrefsDirectory();
        AFITROUTERHOME = Utilities.establishRouterDirectory();
    }   // end establishDirectories


    
    private void saveBaseList()
    {
        // Make a stream to save other information
        try
        {   File file = new File( USERPREFSDIR, BASELIST_FILE_NAME );
            FileOutputStream fos = new FileOutputStream( file );
            ObjectOutputStream oos = new ObjectOutputStream( fos );
            oos.writeObject( kernel.getBaseList() );
            oos.flush();
            fos.close();
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end saveBaseList
    
    
    private void saveVehicleList()
    {
        // Make a stream to save other information
        try
        {   File file = new File( USERPREFSDIR, VEHICLELIST_FILE_NAME );
            FileOutputStream fos = new FileOutputStream( file );
            ObjectOutputStream oos = new ObjectOutputStream( fos );
            oos.writeObject( kernel.getVehicleList() );
            oos.flush();
            fos.close();
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end saveVehicleList
    
    private void savePriorityModelList()
    {
        // Make a stream to save other information
        try
        {   File file = new File( USERPREFSDIR, PRIORITYMODELLIST_FILE_NAME );
            FileOutputStream fos = new FileOutputStream( file );
            ObjectOutputStream oos = new ObjectOutputStream( fos );
            oos.writeObject( kernel.getPriorityModelList() );
            oos.flush();
            fos.close();
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end savePriorityModelList
    
    
    private void saveROZList()
    {
        // Make a stream to save other information
        try
        {   File file = new File( USERPREFSDIR, ROZLIST_FILE_NAME );
            FileOutputStream fos = new FileOutputStream( file );
            ObjectOutputStream oos = new ObjectOutputStream( fos );
            oos.writeObject( kernel.getROZList() );
            oos.flush();
            fos.close();
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end saveROZList
    
    private void saveWindList()
    {
        // Make a stream to save other information
        try
        {   File file = new File( USERPREFSDIR, WIND_FILE_NAME );
            FileOutputStream fos = new FileOutputStream( file );
            ObjectOutputStream oos = new ObjectOutputStream( fos );
            oos.writeObject( kernel.getWindList() );
            oos.flush();
            fos.close();
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end saveWindList
    
    
    private final void loadBaseList()
    {
        try
        {   File file = new File( USERPREFSDIR, BASELIST_FILE_NAME );
            FileInputStream fis = new FileInputStream( file );
            ObjectInputStream ois = new ObjectInputStream( fis );
            BaseList bl = (BaseList) ois.readObject();
            fis.close();
            kernel.getBaseList().replace( bl );
//            kernel.getBaseList().addBases( bl.getBases() );
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end loadBaseList
    
    private final void loadVehicleList()
    {   try
        {   File file = new File( USERPREFSDIR, VEHICLELIST_FILE_NAME );
            FileInputStream fis = new FileInputStream( file );
            ObjectInputStream ois = new ObjectInputStream( fis );
            VehicleList vl = (VehicleList) ois.readObject();
            fis.close();
            kernel.getVehicleList().replace( vl, kernel.getBaseList() );
//            kernel.getVehicleList().addVehicles( vl.getVehicles() );
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end loadVehicleList
    
    private final void loadPriorityModelList()
    {   try
        {   File file = new File( USERPREFSDIR, PRIORITYMODELLIST_FILE_NAME );
            FileInputStream fis = new FileInputStream( file );
            ObjectInputStream ois = new ObjectInputStream( fis );
            PriorityModelList pl = (PriorityModelList) ois.readObject();
            fis.close();
            kernel.getPriorityModelList().replace( pl );
//            kernel.getPriorityModelList().addPriorityModels( pl.getPriorityModels() );
        }   // end try
        catch( Exception e )
        {   kernel.getPriorityModelList().makeStandardModels(kernel);
            AFITRouter.err( e );
        }   // end catch
    }   // end loadPriorityModelList
    
    
    private final void loadROZList()
    {   try
        {   File file = new File( USERPREFSDIR, ROZLIST_FILE_NAME );
            FileInputStream fis = new FileInputStream( file );
            ObjectInputStream ois = new ObjectInputStream( fis );
            RestrictedOperatingZoneList rl = 
                (RestrictedOperatingZoneList) ois.readObject();
            fis.close();
            kernel.getROZList().replace( rl );
//            kernel.getROZList().addROZs( rl.getROZs() );
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end loadROZList
    
    
    private final void loadWindList()
    {   try
        {   File file = new File( USERPREFSDIR, WIND_FILE_NAME );
            FileInputStream fis = new FileInputStream( file );
            ObjectInputStream ois = new ObjectInputStream( fis );
            WindList wl = (WindList) ois.readObject();
            fis.close();
            kernel.getWindList().replace( wl );
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end loadWindList
    
    public final Kernel getKernel()
    {   return kernel;
    }   // end getKernel
    
    
    protected synchronized final void windowClosing( WindowEvent e )
    {   this.quitAndSave = true;
        this.notifyAll();
    }   // end windowClosing
        

    
/* ********  M A I N   P A N E L   C O D E  ******** */
    
    private final void openMainFrame( Kernel kernel )
    {
        // Create frame
        JFrame mainFrame = new JFrame( "AFIT Router" );
        
        // Setup meu
        setupMenuForFrame( mainFrame, kernel );
        
        // Create and add the main panel
        MainPanel mainPanel = new MainPanel( kernel );
        mainFrame.getContentPane().setLayout( new BorderLayout() );
        mainFrame.getContentPane().add( mainPanel, BorderLayout.CENTER );
        
        // Add appropriate actions to buttons
/*        mainPanel.addActionListenerToSitesButton(
            new OpenSitesFrameAction( kernel ) );
        mainPanel.addActionListenerToVehiclesButton(
            new OpenVehicleBaseFrameAction( kernel ) );
        mainPanel.addActionListenerToSolveButton( 
            new OpenSolveDialogAction( kernel, mainFrame ) );
        mainPanel.addActionListenerToSolutionsMoreButton(
            new OpenSolutionsFrameAction( kernel ) );
        mainPanel.addActionListenerToOtherButton( 
            new OpenOtherSettingsDialogAction( kernel, mainFrame ) );
*/        
        
        // Window handler
        final Kernel kErnel = kernel;
        final JFrame fRame = mainFrame;
        mainFrame.addWindowListener( new WindowAdapter()
        {   public void windowClosing( WindowEvent e )
            {   kErnel.getPrefs().setProperty( FRAME_BOUNDS_X,
                    ""+fRame.getLocation().x );
                kErnel.getPrefs().setProperty( FRAME_BOUNDS_Y,
                    ""+fRame.getLocation().y );
                ((AFITRouter)kErnel.getClientProperty( 
                    AFITRouter.KEY_AFITROUTER )).windowClosing( e );
            }   // end windowClosing
        }); // end addWindowListener
        
        // Get window coordinates from prefs
        Preferences prefs = kernel.getPrefs();
        int x,y;
        try
        {   x = new Integer( prefs.getProperty( FRAME_BOUNDS_X ) ).intValue();
            y = new Integer( prefs.getProperty( FRAME_BOUNDS_Y ) ).intValue();
        }   // end try
        catch( Exception e )
        {   x = prefs.getDefaultWindowX();
            y = prefs.getDefaultWindowY();
        }   // end catch
        //int x = prefs.getLastWindowXPosition();
        //int y = prefs.getLastWindowYPosition();
        mainFrame.setLocation( x, y );
        Toolkit theKit = mainFrame.getToolkit();
        Dimension screenSize = theKit.getScreenSize();
        if( x > screenSize.width || y > screenSize.height )
            mainFrame.setLocation( 20, 20 );
        
        setupLAF( mainFrame );
        
        mainFrame.pack();
        //mainFrame.setResizable( false );
        mainFrame.setVisible( true );
        
        // Close splash screen
        synchronized( this )
        {   AFITRouter.doneLoading = true;
            this.notifyAll();
        }   // end sync: this
        
    }   // end createMainFrame
        

        
    private final void setupMenuForFrame( final JFrame frame, final Kernel kernel )
    {
        // Find the modifier key that is used on this platform
        int menuShortcutKeyMask = frame.getToolkit().getMenuShortcutKeyMask();
        
        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        
        // File Menu
        JMenu fileMenu = new JMenu( "File" );
        fileMenu.setMnemonic( 'F' );
        {   JMenuItem item;
                item = fileMenu.add( new ImportSitesFileAction( frame, kernel ) );
                    item.setMnemonic( 'I' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'I', menuShortcutKeyMask ) );
                //item = fileMenu.add( new ImportSitesURLAction( frame, kernel ) );
                //    item.setMnemonic( 'U' );
                //    item.setAccelerator( KeyStroke.getKeyStroke( 'U', menuShortcutKeyMask ) );
                
                fileMenu.addSeparator();
                
                item = fileMenu.add( new LoadKernelAction( frame, kernel ) );
                    item.setMnemonic( 'L' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'L', menuShortcutKeyMask ) );
                    item.setToolTipText( LoadKernelAction.TOOLTIP );
                item = fileMenu.add( new SaveKernelAction( frame, kernel ) );
                    item.setMnemonic( 'S' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'S', menuShortcutKeyMask ) );
                    item.setToolTipText( SaveKernelAction.TOOLTIP );
                
        }   // end file menu
        
        // Edit Menu
        /*
        JMenu editMenu = new JMenu( "Edit" );
        fileMenu.setMnemonic( 'E' );
        {   JMenuItem item;
                item = editMenu.add( new OpenOtherSettingsDialogAction( kernel, frame ) );
                    item.setMnemonic( 'E' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'E', menuShortcutKeyMask ) );
                    item.setToolTipText( OpenOtherSettingsDialogAction.TOOLTIP );
                
        }   // end edit menu
        */
        
        // View Menu
        JMenu viewMenu = new JMenu( "View" );
        fileMenu.setMnemonic( 'V' );
        {   JMenuItem item;
                item = viewMenu.add( new OpenSitesFrameAction( kernel ) );
                    item.setMnemonic( 'T' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'T', menuShortcutKeyMask ) );
                    item.setToolTipText( OpenSitesFrameAction.TOOLTIP );
                item = viewMenu.add( new OpenVehicleBaseFrameAction( kernel ) );
                    item.setMnemonic( 'H' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'H', menuShortcutKeyMask ) );
                    item.setToolTipText( OpenVehicleBaseFrameAction.TOOLTIP );
                item = viewMenu.add( new OpenROZFrameAction( kernel ) );
                    item.setMnemonic( 'R' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'R', menuShortcutKeyMask ) );
                    item.setToolTipText( OpenROZFrameAction.TOOLTIP );
                item = viewMenu.add( new OpenOtherSettingsDialogAction( kernel, frame ) );
                    item.setMnemonic( 'E' );
                    item.setAccelerator( KeyStroke.getKeyStroke( 'E', menuShortcutKeyMask ) );
                    item.setToolTipText( OpenOtherSettingsDialogAction.TOOLTIP );
                
                
                // If the MemoryView tool is available, make a spot for it
                Class memoryViewClass = null;
                try{ memoryViewClass = Class.forName( "MemoryView" ); }
                catch( Exception e ){}
                if( memoryViewClass != null )
                {   viewMenu.addSeparator();
                    item = viewMenu.add( new JMenuItem( "Memory..." ) );
                        item.setMnemonic( 'M' );
                        //item.setAccelerator( KeyStroke.getKeyStroke( 'M', menuShortcutKeyMask ) );
                        //item.setToolTipText( "Displays Java memory information" );
                    final Class memClass = memoryViewClass;
                    item.addActionListener( new ActionListener()
                    {   public void actionPerformed( ActionEvent e )
                        {   try{ memClass.newInstance();}
                            catch( Exception ex )
                            {   JOptionPane.showMessageDialog(
                                    frame,
                                    "An error occured: " + ex,
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE );
                            }   // end catch
                        }   // end actionPerformed
                    }); // end actionlistener
                }   // end if: memory view available
                
                // About dialog
                item = viewMenu.add( new OpenAboutDialogAction(frame) );
                item.setMnemonic( 'A' );
                
        }   // end view menu
        

        
        // Add menus to menu bar
        menuBar.add( fileMenu );
        //.add( editMenu );
        menuBar.add( viewMenu );
        
        // Add menu bar to frame
        final JMenuBar mEnuBar = menuBar;
        final JFrame fRame = frame;
        SwingUtilities.invokeLater( new Runnable()
        {   public void run()
            {   fRame.setJMenuBar( mEnuBar );
            }   // end run
        }); // end runnable,invokeLater
    }   // end setupMenuForFrame
        




    private final void setupLAF( Component parent )
    {   try
        {   String lastLAF = kernel.getPrefs().getProperty( KEY_LAST_LAF );
            UIManager.setLookAndFeel( lastLAF );
            SwingUtilities.updateComponentTreeUI( parent );
        }   // end try
        catch( Exception e )
        {   // If anything goes wrong, just setup the native L&F
	        try 
	        {   Component c = parent;
	            while (c.getParent()!=null) c=c.getParent();
	            UIManager.setLookAndFeel(
	                UIManager.getSystemLookAndFeelClassName() );
	            SwingUtilities.updateComponentTreeUI(c);
	        }   //end try
	        catch( Exception ex )
	        {   AFITRouter.err( ex );
	        }   // end catch
        }   // end catch
    }   // end setupLAF

    
    private final void saveLAFToPrefs()
    {   kernel.getPrefs().setProperty( KEY_LAST_LAF, 
            UIManager.getLookAndFeel().getClass().getName() );
    }   // end saveLAFToPrefs
    
    
/* ********  S O L V I N G   C O D E  ******** */
    
    public final void startSolving( java.awt.Window window )
    {   SolverRunner runner = new SolverRunner( kernel, window );
        runner.startSolving();
    }   // end startSolving
    
    
    
/* ********  F I L E   I / O   M E T H O D S  ******** */
    
    public final void loadKernel()
    {
        // See if a kernel was saved to disk. If so, load it.
    /*    try
        {   File file = new File( USERPREFSDIR, KERNEL_FILE_NAME );
            FileInputStream fis = new FileInputStream( file );
            ObjectInputStream ois = new ObjectInputStream( fis );
            this.kernel = (Kernel) ois.readObject();
            fis.close();
            this.kernel.putClientProperty( KEY_KERNEL_WAS_SAVED,
                new Boolean(true) );
        }   // end try
        catch( Exception e )
        {   this.kernel = new Kernel();
        }   // end catch
   */
        this.kernel = new Kernel();
        this.kernel.putClientProperty( KEY_AFITROUTER, this );
        this.kernel.setRunningAsApplication();
    }   // end loadKernel
    
    public final void loadKernel( File file )
    {   try
        {   FileInputStream fis = new FileInputStream( file );
            ObjectInputStream ois = new ObjectInputStream( fis );
            Kernel k = (Kernel) ois.readObject();
            this.kernel.replace( k );
            fis.close();
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
        
        this.kernel.putClientProperty( KEY_AFITROUTER, this );
        this.kernel.setRunningAsApplication();
    }   // end loadKernel
    
    public final synchronized void saveObject( File file, Object obj )
    {   try
        {   FileOutputStream fos = new FileOutputStream( file );
            ObjectOutputStream oos = new ObjectOutputStream( fos );
            oos.writeObject( obj );
            oos.flush();
            fos.close();
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end saveObject
    
    
    private final void deleteKernelFile()
    {
        try
        {   File file = new File( USERPREFSDIR, KERNEL_FILE_NAME );
            file.delete();
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end deleteKernelFile
    
    public final void loadPreferences()
    {
        try
        {   File prefsFile = new File( USERPREFSDIR, PREF_FILE_NAME );
            FileInputStream fis = new FileInputStream( prefsFile );
            Properties prop = new Properties();
            prop.load( fis );
            fis.close();
            kernel.getPrefs().replace( prop );
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end loadPreferences
    
    public final synchronized void savePreferences()
    {
        try
        {   File prefsFile = new File( USERPREFSDIR, PREF_FILE_NAME );
            FileOutputStream fos = new FileOutputStream( prefsFile );
            // save() is deprecated, but keep it for compatibility with Java 1.1
            kernel.getPrefs().getProperties().save( fos, Preferences.HEADER );
//            ObjectOutputStream oos = new ObjectOutputStream( fos );
//            oos.writeObject( kernel.getPrefs() );
//            oos.flush();
            fos.close();
        }   // end try
        catch( Exception e )
        {   AFITRouter.err( e );
        }   // end catch
    }   // end savePreferences
    
    
    
    
    
/* ********  D E B U G G I N G   C O D E  ******** */
    
    public final static void out( Object obj )
    {   if( DEBUGGING )
            System.out.println( obj );
    }   // end out
    
    public final static void err( Exception e )
    {   if( DEBUGGING )
        {   System.err.println( e );
            e.printStackTrace();
        }   // end if
    }   // end err
    
}   // end class AFITRouter