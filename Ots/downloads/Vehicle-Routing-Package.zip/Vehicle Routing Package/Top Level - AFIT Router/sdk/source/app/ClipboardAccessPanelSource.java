package mil.af.afit.router.app;

public interface ClipboardAccessPanelSource
{
    public abstract String getClipboardText();
}   // end interface ClipboardAccessPanelSource