package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.awt.*;

public class LoadKernelAction
extends AbstractAction
{
    private final static String NAME = "Load kernel...";
    public final static String TOOLTIP = "Loads everything (vehicles, sites, ROZs, etc.) from one file";
    private final static String NATIVE_FILE_BOX_KEY = "file.dialog.useNative";
    private static boolean useNativeFileBox = false;
    private Kernel kernel;
    private Component parentComponent;
    
    public LoadKernelAction( Component parentComponent, Kernel kernel )
    {   super( NAME );
        this.parentComponent = parentComponent;
        this.kernel = kernel;
        
        // Determine if native file dialog boxes should be used.
        String result = kernel.getPrefs().getProperty( NATIVE_FILE_BOX_KEY );
        try
        {   useNativeFileBox = new Boolean( result ).booleanValue();
        }   // end try
        catch( Exception e ) {}
        kernel.getPrefs().setProperty( NATIVE_FILE_BOX_KEY, ""+ useNativeFileBox );
    }   // end kernel
    
    public void actionPerformed( ActionEvent e )
    {   final Kernel kErnel = kernel;
        Thread t = new Thread( new Runnable()
        //SwingUtilities.invokeLater( new Runnable()
        {   public void run()
            {   
                FileInputStream fis = null;
                try
                {   
                    // See if a previously used directory is recorded
                    String prevDir = kErnel.getPrefs()
                        .getProperty( AFITRouter.PREV_DIR );
                    
                    // If it's not, default to the user's home
                    File currentDir = null;
                    if( prevDir == null || (! new File( prevDir ).exists() ) )
                        currentDir = new File( System.getProperty( "user.dir" ) );
                    else
                        currentDir = new File( prevDir );
                    
                    File file = null;
                    // Open a file chooser dialog: Swing version
                    if( !useNativeFileBox )
                    {   JFileChooser fileChooser = new JFileChooser( currentDir );
                        int option = fileChooser.showOpenDialog( parentComponent );
                        if( option == JFileChooser.APPROVE_OPTION )
                            file = fileChooser.getSelectedFile();
                    }   // end if: swing version
                    else
                    {
                        // Open a file chooser dialog: Native version
                        // Try to find a frame in the tree
                        Frame frame = null;
                        Component c =parentComponent;
                        while( c != null && ! ( c instanceof Frame ) )
                        {   c = c.getParent();
                        }   // end while
                        frame = (c instanceof Frame) ? (Frame)c : new Frame();

                        FileDialog fd = new FileDialog( frame, "Select kernel file", FileDialog.LOAD );
                        fd.setDirectory( currentDir.getName() );
                        fd.show();
                        String fileName = fd.getFile();
                        String dir = fd.getDirectory();
                        
                        // If a file was selected, try to open it.
                        if( fileName != null )
                            file = new File( dir, fileName );
                    }   // end if: native version

                    // Get the file's data
                    if( file != null )
                    {   fis = new FileInputStream( file );
                        ObjectInputStream ois = new ObjectInputStream( fis );
                        Kernel k = (Kernel) ois.readObject();
                        kErnel.replace( k );
                        fis.close();

                        kErnel.getPrefs().setProperty(
                            AFITRouter.PREV_DIR, file.getParent() );
                    }   // end if: file not null
                }   // end try
                catch( Exception err ){}
                finally
                {   try{ fis.close(); }
                    catch( Exception ex ){}
                }   // end finally
            }   // end run
        }); // end runnable, thread
        t.start();
    }   // end actionPerformed
    
}   // end LoadKernelAction