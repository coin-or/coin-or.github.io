package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.io.*;
import javax.swing.*;
import java.util.*;

public class TextSitesFileReader implements SitesFileReader
{
    private static final int NAME_COL = 0;
    private static final int LAT_COL = 1;
    private static final int LONG_COL = 2;
    private static final int PRIOR_COL = 3;
    private static final int TW_START = 4; // Time window start
    private static final int TW_END = 5;   // Time window end
    private static final int COLUMN_COUNT = 6;
    
    
    public final String getFileTypeName()
    {   return "Tab-delimited text file";
    }   // end getFileTypeName
    
    
    public final String[] getFileExtensions()
    {
        final String[] exts =
            { "txt", "tab" };
        return exts;
    }   // end getFileTypeExtensions
    
    
    public final Site[] getSites( InputStream stream, boolean interactive )
    {
        int[] columnLocations = getColumnLocations( stream, interactive );
        
        Site[] sites;
        
        sites = loadSites( stream, columnLocations );

        return sites;
    }   // end getSites
    
    
    private final int[] getColumnLocations( InputStream stream, boolean interactive )
    {
        int[] columnLocations = new int[ COLUMN_COUNT ];
        
        if( ! interactive )
        {
            columnLocations[ NAME_COL ] = 1;
            columnLocations[ LAT_COL ] = 2;
            columnLocations[ LONG_COL ] = 3;
            columnLocations[ PRIOR_COL ] = 4;
            columnLocations[ TW_START ] = 5;
            columnLocations[ TW_END ] = 6;
        }   // end if: not interactive
        else
        {
            columnLocations = getInteractiveColumnLocations( stream );
        }   // end else: interactive
        
        return columnLocations;
    }   // end getColumnLocations
    
    
    private final int[] getInteractiveColumnLocations( InputStream istream )
    {
        int[] columnLocations = new int[ COLUMN_COUNT ];
        
        // Get a stream for pulling sample data (use no monitor box)
        StreamTokenizer stream = getStream( istream, false );
        
        // Start building self-contained frame for interactivity
        JFrame frame = new JFrame( "Map columns" );
        
        
        // For now make columns static
        columnLocations[ NAME_COL ] = 1;
        columnLocations[ LAT_COL ] = 2;
        columnLocations[ LONG_COL ] = 3;
        columnLocations[ PRIOR_COL ] = 4;
        columnLocations[ TW_START ] = 5;
        columnLocations[ TW_END ] = 6;
        
        return columnLocations;
    }   // end getInteractiveColumnLocations
    
    
    private final Site[] loadSites( InputStream istream, int[] columnLocations )
    {

        // Get stream to read data
        StreamTokenizer stream = getStream( istream, true );
        
        // Ensure that end of line characters are noticed
        stream.eolIsSignificant(true);
        
        // Include some special characters
        stream.wordChars( '_', '_' );
        stream.wordChars( '-', '-' );
        stream.wordChars( '\\', '\\' );
        //stream.wordChars( ' ', ' ' );
        
        // Use an ArrayList to read in sites. ArrayList is like
        // Vector except ArrayList is unsynchronized so it's faster
        Vector sites = new Vector();
        
        
        // Begin reading file
        try
        {
            while( (stream.nextToken() != stream.TT_EOF) )
            {
                // Put token back
                stream.pushBack();
                
                // New row started: setup row variables
                int currentColumn = 1;
                String name = null;
                Double latitude = null;
                Double longitude = null;
                int priority = -1;
                Double twStart = null;
                Double twEnd = null;
                while( ( stream.nextToken() != stream.TT_EOL ) &&
                       ( stream.ttype != stream.TT_EOF ) )
                {
                    // If the current column is a significant one,
                    // get that piece of data
                    if( currentColumn == columnLocations[ NAME_COL ] )
                    {
                        name = stream.sval;
                    }   // end if: name
                    else
                    if( currentColumn == columnLocations[ LAT_COL ] )
                    {
                        latitude = new Double( stream.nval );
                    }   // end if: latitude
                    else
                    if( currentColumn == columnLocations[ LONG_COL ] )
                    {
                        longitude = new Double( stream.nval );
                    }   // end if: longitude
                    else
                    if( currentColumn == columnLocations[ PRIOR_COL ] )
                    {
                        priority = (int) stream.nval;
                    }   // end if: priority
                    else
                    if( currentColumn == columnLocations[ TW_START ] )
                    {
                        twStart = new Double( stream.nval );
                    }   // end if: priority
                    else
                    if( currentColumn == columnLocations[ TW_END ] )
                    {
                        twEnd = new Double( stream.nval );
                    }   // end if: priority
                    else
                    {
                        ;
                    }   // end else: nothing
                    
                    // Increment column counter
                    currentColumn++;
                }   // end while: until end of line

                // End of line reached. Try to make a site.
                // Make sure enough information was collected
                // to make an entire site before making the site.
                Site tempSite = null;
                if( name != null )
                    if( latitude != null )
                        if( longitude != null )
                        {   if( priority >= 0 )
                            {   tempSite = new Site(
                                name, latitude.doubleValue(),
                                longitude.doubleValue(), priority );
                            }   // end if: priority was specified
                            else
                            {
                                tempSite = new Site(
                                name, latitude.doubleValue(),
                                longitude.doubleValue() );
                            }   // end else: priority not specified
                            
                            if( twStart != null )
                                tempSite.setEarliestArrivalTime(
                                    twStart.intValue() );
                            if( twEnd != null )
                                tempSite.setLatestDepartureTime(
                                    twEnd.intValue() );
                        }   // end if: enough info for a site
                            
                // If site was made, add it to list of sites
                if( tempSite != null )
                    sites.addElement( tempSite );
                
            }   // end while: until end of file
        }   // end try
        catch( IOException e )
        {   System.err.println( e );
            return null;
        }   // end catch
        
        // Convert list of sites into an array
        //Site[] arrayOfSites = (Site[]) sites.toArray();
        Site[] arrayOfSites = new Site[ sites.size() ];
        for( int i = 0; i < arrayOfSites.length; i++ )
            arrayOfSites[i] = (Site) sites.elementAt(i);
        
        if( arrayOfSites.length == 0 )
            arrayOfSites = null;
        
        return arrayOfSites;
    }   // end loadSites
    
    
    
    private StreamTokenizer getStream( InputStream istream, boolean useMonitor )
    {
        
        // Make isr based on whether or not a monitor box should come up
        InputStreamReader isr;
        isr = new InputStreamReader( istream );
        
        // Make the stream a reader
        Reader r = new BufferedReader( isr );
        
        // Make the stream a tokenizer
        StreamTokenizer stream = new StreamTokenizer( r );
        
        return stream;
    }   // end getStream
    
    
    private void out( String s, double d )
    {   System.out.println( s == null ? "" + d : s );
    }   // end out
    
    
}   // end class TextSitesFileReader