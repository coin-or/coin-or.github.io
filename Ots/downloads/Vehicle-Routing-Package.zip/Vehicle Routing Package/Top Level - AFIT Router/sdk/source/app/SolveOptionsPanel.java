package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import mil.af.afit.uvr.*;
import java.util.*;

public class SolveOptionsPanel extends JPanel
{
    private final static String
        EFFORT_TOOLTIP = "Longer solve times tend to give better answers.",
        SOLVER_TOOLTIP = "Selects which solver to use.",
        EFFORT_BORDER_TITLE = "Solve Time",
        CHECKBOX_TITLE = "Use these priorities",
        USE_POST_OPT_LABEL = "Use post-optimization",
        USE_POST_OPT_TOOLTIP = "Increases solve time but improves answers.";
    
    private final static int MIN = 0, MAX = 100;
    private final static String
        MIN_LABEL = "Shorter",
        MIN_LABEL2 = "(Lower quality)",
        MAX_LABEL = "Longer",
        MAX_LABEL2 = "(Higher quality)";
    
    private Kernel kernel;
    private JSlider effortSlider;
    private JComboBox solversBox;
    private JCheckBox chkUsePostOptimization;
    private PriorityModel[] priorityModels;
    private JCheckBox[] chkModelsToUse;
    
    public SolveOptionsPanel( Kernel kernel )
    {   
        super();
        this.setOpaque( false );
        
        // Start this to collect available solvers
//        HEngine engine = new HEngine();
        
        // Set kernel variable
        this.kernel = kernel;
        
        // Get prefs
//        final String lastSolverUsed = 
//            kernel.getPrefs().getLastSolverUsed();
        final double effort = 
            kernel.getPrefs().getLastRequestedSolutionEffort();

        // Setup effort slider
        effortSlider = new JSlider( MIN, MAX, (int) (effort*(MAX-MIN)) );
        effortSlider.setToolTipText( EFFORT_TOOLTIP );
        JPanel effortPanel = new JPanel( new GridLayout(2,1) );
        effortPanel.setBorder( new TitledBorder( EFFORT_BORDER_TITLE ) );
        Hashtable labelTable = new Hashtable();
        labelTable.put( new Integer(MIN), new JLabel(MIN_LABEL) );
        labelTable.put( new Integer(MAX), new JLabel(MAX_LABEL) );
        effortSlider.setLabelTable( labelTable );
        effortSlider.setPaintLabels( true );
        effortPanel.add( effortSlider );
//JPanel secondRowLabels = new JPanel( new BorderLayout() );
//secondRowLabels.add( new JLabel( MIN_LABEL2, JLabel.LEFT ), BorderLayout.WEST );
//secondRowLabels.add( new JLabel( MAX_LABEL2, JLabel.RIGHT ), BorderLayout.EAST );
//effortPanel.add( secondRowLabels );
        chkUsePostOptimization = new JCheckBox( USE_POST_OPT_LABEL, 
            kernel.getPrefs().usePostOptimization() );
        chkUsePostOptimization.setToolTipText( USE_POST_OPT_TOOLTIP );
        effortPanel.add( chkUsePostOptimization );
        
/*            
        // Get available solvers
        final HSolver[] solvers = engine.getAvailableSolvers();
        
        // Put them in a combo box and select appropriate default
        final String[] solverNames = new String[ solvers.length ];
        for( int i = 0; i < solvers.length; i++ )
            solverNames[i] = solvers[i].getName();
        solversBox = new JComboBox( solverNames );
        for( int i = 0; i < solvers.length; i++ )
            if( solvers[i].getName().equals( lastSolverUsed ) )
                solversBox.setSelectedIndex( i );
        JPanel solversPanel = new JPanel();
        solversPanel.setBorder( new TitledBorder( "Solver" ) );
        solversBox.setToolTipText( SOLVER_TOOLTIP );
        solversPanel.add( solversBox );
*/        
        // Add components to bottom panel
        JPanel bottomPanel = new JPanel( new BorderLayout() );
//        bottomPanel.add( solversPanel );
        bottomPanel.add( effortPanel, BorderLayout.CENTER );
        
        // Start top panel with priorities
        JPanel topPanel = new JPanel();
        priorityModels = kernel.getPriorityModelList().getPriorityModels();
        
        // Figure out how to lay out the panel based on how many
        // models were returned. Some numbers have a prescribed
        // layout. Others are just estimated.
        final int numModels = priorityModels.length;
        topPanel.setLayout( new GridLayout((numModels-1)/3,3) );
        
        // Add priority panels to panel.
        chkModelsToUse = new JCheckBox[numModels];
        for( int i = 0; i < numModels; i++ )
        {
            // Use the old-fashioned (Java 1.1) way of using the GridBagLayout
            GridBagLayout gbl = new GridBagLayout();
            GridBagConstraints gbc = new GridBagConstraints();
            JPanel panel = new JPanel( gbl );
            panel.setBorder( new TitledBorder( priorityModels[i].getName() ) );
            chkModelsToUse[i] = new JCheckBox( CHECKBOX_TITLE, priorityModels[i].isEnabled() );
            final PriorityModel Model = priorityModels[i];
            chkModelsToUse[i].addActionListener( new ActionListener()
            {   public void actionPerformed( ActionEvent e )
                {   Model.setEnabled( ((JCheckBox)e.getSource()).isSelected() );
                }   // end actionPerformed
            }); // end actionPerformed,ActionListener
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbl.setConstraints( chkModelsToUse[i], gbc );
            panel.add( chkModelsToUse[i] );//, new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.NORTHWEST,GridBagConstraints.NONE,new Insets(0,0,0,0),0,0) );
            gbc.gridy = 1;
            Component c = new PriorityPanel( priorityModels[i] );
            gbl.setConstraints( c, gbc );
            panel.add( c );//, new GridBagConstraints(0,1,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0) );
            topPanel.add( panel );
        }   // end for: through each priority model
        
        // Add all to main panel
        GridBagLayout gbl = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        this.setLayout( gbl );
        gbc.gridx = gbc.gridy = 0;
        gbl.setConstraints( topPanel, gbc );
        this.add( topPanel );//, new GridBagConstraints(0,0,1,1,1.0,1.0,GridBagConstraints.NORTHWEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0) );
        gbc.gridy = 1;
        gbc.fill = gbc.BOTH;
        gbl.setConstraints( bottomPanel, gbc );
        this.add( bottomPanel );//, new GridBagConstraints(0,1,1,1,1.0,1.0,GridBagConstraints.NORTHWEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0) );
    }   // end constructor
    
    
//    public final String getSelectedSolverName()
//    {   return (String) solversBox.getSelectedItem();
//    }   // end getSelectedSolverName
    
    public final boolean usePostOptimization()
    {   return chkUsePostOptimization.isSelected();
    }   // end usePostOptimizationSearch
    
    public final double getRequestedEffort()
    {   return (double) effortSlider.getValue() 
            / ( effortSlider.getMaximum() 
              - effortSlider.getMinimum() );
    }   // end getRequestedEffort
    
}   // end class SolveOptionsPanel