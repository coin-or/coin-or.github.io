package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.util.*;
import javax.swing.JComboBox;
import javax.swing.table.*;


public class VehiclesTableModel 
extends AbstractTableModel 
implements Observer
{
    VehicleList vehicleList=null;
    Vehicle emptyVehicle;
    private Kernel kernel;
    private String[] columnNames;
    private int[] columnOrder;
    private Class[] columnClasses;
    private final static int NAME = 0;
    private final static int ENABLED = 1;
    private final static int HOME_BASE = 2;
    private final static int ALT_LOCATION = 3;
    private final static int START_TIME = 4;
    private final static int RANGE = 5;
    private final static int ALT_LAT = 6;
    private final static int ALT_LONG = 7;
    private final static int SUPPORTED_REQUIREMENTS = 8;
    private final static int SPEED_KNOTS = 9;
    private final static int ALTITUDE = 10;
    private final static int NUM_OF_COLUMNS = 11;
    
    
    
    public VehiclesTableModel( Kernel kernel )
    {   this.kernel = kernel;
        this.vehicleList = kernel.getVehicleList();
        this.emptyVehicle = new Vehicle();
        this.emptyVehicle.setEnabled( false );
        setupColumnOrder();
        setupColumnNames();
        setupColumnClasses();
        vehicleList.addObserver( this );
        this.update( vehicleList, null );
    }   // end constructor
    
    
    
    private void setupColumnOrder()
    {
        // For now, fixed
        columnOrder = new int[ getColumnCount() ];
        columnOrder[ENABLED] = 0;
        columnOrder[NAME] = 1;
        columnOrder[HOME_BASE] = 2;
        columnOrder[SUPPORTED_REQUIREMENTS] = 3;
        columnOrder[SPEED_KNOTS] = 4;
        columnOrder[RANGE] = 5;
        columnOrder[ALTITUDE] = 6;
        columnOrder[START_TIME] = 7;
        columnOrder[ALT_LOCATION] = 8;
        columnOrder[ALT_LAT] = 9;
        columnOrder[ALT_LONG] = 10;
    }   // end setupColumnOrder
    
    private void setupColumnNames()
    {
        columnNames = new String[ getColumnCount() ];
        columnNames[ENABLED] = "Enabled";
        columnNames[NAME] = "Name";
        columnNames[SUPPORTED_REQUIREMENTS] = "Capabilities";
        columnNames[HOME_BASE] = "Home";
        columnNames[START_TIME] = "Start Time";
        columnNames[ALT_LOCATION] = "Use Alt. Location";
        columnNames[ALT_LAT] = "Alt. Latitude";
        columnNames[ALT_LONG] = "Alt. Longitude";
        columnNames[SPEED_KNOTS] = "Speed (knots)";
        columnNames[RANGE] = "Range (hrs)";
        columnNames[ALTITUDE] = "Altitude (feet)";
    }   // end setupColumnNames
    
    private void setupColumnClasses()
    {
        columnClasses = new Class[ getColumnCount() ];
        columnClasses[NAME] = String.class;
        columnClasses[SUPPORTED_REQUIREMENTS] = String[].class;
        columnClasses[ENABLED] = Boolean.class;
        columnClasses[HOME_BASE] = Base.class;
        columnClasses[START_TIME] = String.class;
        columnClasses[ALT_LOCATION] = Boolean.class;
        columnClasses[ALT_LAT] = String.class;
        columnClasses[ALT_LONG] = String.class;
        columnClasses[SPEED_KNOTS] = Integer.class;
        columnClasses[RANGE] = Integer.class;
        columnClasses[ALTITUDE] = Integer.class;
    }   // end setupColumnClasses
    
/* ********  R E M O V E   C O D E  ******** */
    
    public final void removeVehicle( Vehicle vehicle )
    {   vehicleList.removeVehicle( vehicle );
    }   // end removeVehicle
    
    public final void removeVehicleAt( int index )
    {   vehicleList.removeVehicleAt( index );
    }   // end removeVehicleAt
    
    public final void removeVehiclesAt( int[] indeces )
    {   // if the last index points to the empty entry, remake the list
        // without that entry (which doesn't exist anyway)
        if( indeces[indeces.length-1] == vehicleList.getVehicles().length )
        {   int[] temp = new int[ indeces.length-1 ];
            System.arraycopy(indeces,0,temp,0,temp.length);
            indeces = temp;
        }   // end if: strip off fake vehicle at end
        vehicleList.removeVehiclesAt( indeces );
    }   // end removeVehiclesAt
    
    

/* ********  O B S E R V E R   C O D E  ******** */
    
    public void update( Observable thing, Object obj )
    {   fireTableDataChanged();
    }   // end update

    
/* ********  A B S T R A C T T A B L E M O D E L   C O D E  ******** */

    public final int getColumnCount()
    {   return NUM_OF_COLUMNS;
    }   // end getColumnCount
    
    public int getRowCount()
    {   return vehicleList.getVehicles().length + 1;
    }   // end getRowCount
    
    public String getColumnName( int column )
    {   int i = 0;
        while( columnOrder[i] != column && i < getColumnCount() )
            i++;
        if( i < getColumnCount() )
            return columnNames[ i ];
        else return null;
    }   // end getColumnName
    
    public Object getValueAt( int row, int column )
    {
        final boolean isEmptyVehicle = 
            row == vehicleList.getVehicles().length;
        final Vehicle vehicle = isEmptyVehicle ?
                emptyVehicle : vehicleList.getVehicles()[row];
        
        if( vehicle != null )
        {
            if( column == columnOrder[NAME] )
                return vehicle.getName();
            else
            if( column == columnOrder[ENABLED] )
                return new Boolean( vehicle.isEnabled() );
            else
            if( column == columnOrder[SUPPORTED_REQUIREMENTS] )
                return vehicle.getSupportedRequirementTypes();
            else
            if( column == columnOrder[HOME_BASE] )
                if( vehicle.getHomeBase() != null )
                    return vehicle.getHomeBase().getName();
                else
                    return null;
            else
            if( column == columnOrder[START_TIME] )
                return CoreUtilities.intTimeToString( 
                vehicle.getEarliestStartTime() );
            else
            if( column == columnOrder[ALT_LOCATION] )
                return new Boolean( !vehicle.isAtHome() );
            else
            if( column == columnOrder[ALT_LAT] )
                return CoreUtilities.doubleLatToString( vehicle.getAlternateLatitude(), kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT) );
            else
            if( column == columnOrder[ALT_LONG] )
                return CoreUtilities.doubleLonToString( vehicle.getAlternateLongitude(), kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT) );
            else
            if( column == columnOrder[SPEED_KNOTS] )
                return new Integer( vehicle.getSpeed() );
            else
            if( column == columnOrder[RANGE] )
                return new Integer( vehicle.getRange() / 60 );
            else
            if( column == columnOrder[ALTITUDE] )
                return new Integer( vehicle.getAltitude() );
            else return null;
        }   // end if: vehicle not null
        else return null;
    }   // end getValueAt
    
    public Class getColumnClass( int column )
    {   int i = 0;
        while( columnOrder[i] != column && i < getColumnCount() )
            i++;
        if( i < getColumnCount() )
            return columnClasses[ i ];
        else return null;
    }   // end getColumnClass
    
    public boolean isCellEditable( int row, int column )
    {   return true;
    }   // end isCellEditable
    
    public void setValueAt( Object value, int row, int column )
    {
        Vehicle[] vehicles = vehicleList.getVehicles();
        
        final boolean isEmptyVehicle = 
            row == vehicleList.getVehicles().length;
        final Vehicle vehicle = isEmptyVehicle ?
                emptyVehicle : vehicleList.getVehicles()[row];
        
        if( vehicle != null )
        {
            if( column == columnOrder[NAME] )
                vehicle.setName( (String) value );
            else
            if( column == columnOrder[ENABLED] )
                vehicle.setEnabled( 
                value instanceof Boolean
                ? ((Boolean)value).booleanValue() 
                : ( new Boolean(
                    value instanceof String
                    ? (String)value
                    : null )).booleanValue()
                );
            else
            if( column == columnOrder[HOME_BASE] )
                vehicle.setHomeBase( (Base) value );
            else
            if( column == columnOrder[SUPPORTED_REQUIREMENTS] )
                vehicle.setSupportedRequirementTypes( 
                value instanceof String[]
                ? (String[]) value
                : new String[0]
                );
            else
            if( column == columnOrder[START_TIME] )
                vehicle.setEarliestStartTime( 
                    CoreUtilities.stringTimeToInt( (String) value ) );
            else
            if( column == columnOrder[ALT_LOCATION] )
                vehicle.setAtHome( ! (
                value instanceof Boolean
                ? ((Boolean)value).booleanValue() 
                : ( new Boolean(
                    value instanceof String
                    ? (String)value
                    : null )).booleanValue()
                ));
            else
            if( column == columnOrder[ALT_LAT] )
            {   String lat = value.toString().toUpperCase();
                if( lat.indexOf('N')<0 && lat.indexOf('S')<0 )
                {   String def = kernel.getPrefs().getProperty( AFITRouter.DEFAULT_LAT_DIRECTION );
                    def = def == null ? "N" : def.substring(0,1);
                    lat = lat+def;
                }   // end if: no north/south specified
                vehicle.setAlternateLatitude( 
                    CoreUtilities.stringLatToDouble( lat, kernel.getPrefs().getProperty( AFITRouter.LAT_LON_FORMAT ) ) );
            }   // end if: latitude
            else
            if( column == columnOrder[ALT_LONG] )
            {   String lon = value.toString().toUpperCase();
                if( lon.indexOf('E')<0 && lon.indexOf('W')<0 )
                {   String def = kernel.getPrefs().getProperty( AFITRouter.DEFAULT_LON_DIRECTION );
                    def = def == null ? "E" : def.substring(0,1);
                    lon = lon+def;
                }   // end if: no north/south specified
                vehicle.setAlternateLongitude( 
                    CoreUtilities.stringLonToDouble( lon, kernel.getPrefs().getProperty( AFITRouter.LAT_LON_FORMAT ) ) );
            }   // end if: latitude
            else
            if( column == columnOrder[SPEED_KNOTS] )
                vehicle.setSpeed( 
                value instanceof Integer
                ? ((Integer)value).intValue() 
                : ( new Integer(
                    value instanceof String
                    ? (String)value
                    : null )).intValue()
                );
            else
            if( column == columnOrder[RANGE] )
                vehicle.setRange( 60 * (
                value instanceof Integer
                ? ((Integer)value).intValue() 
                : ( new Integer(
                    value instanceof String
                    ? (String)value
                    : null )).intValue()
                ));
            else
            if( column == columnOrder[ALTITUDE] )
                vehicle.setAltitude(/*multiplier if needed*/ (
                value instanceof Integer
                ? ((Integer)value).intValue() 
                : ( new Integer(
                    value instanceof String
                    ? (String)value
                    : null )).intValue()
                ));
            
            
            // If it was the empty vehicle being edited, then actually
            // a vehicle was being added.
            if( isEmptyVehicle )
            {
                emptyVehicle.setEnabled( true );
                Vehicle temp = emptyVehicle;
                emptyVehicle = new Vehicle();
                emptyVehicle.setEnabled( false );
                vehicleList.addVehicle( temp );
            }   // end if: is empty vehicle
        }   // end if: vehicle is not null
    }   // end setValueAt
    
    
}   // end class VehiclesTableModel