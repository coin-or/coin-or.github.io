package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class OpenVehicleBaseFrameAction
extends AbstractAction
{
    private final static String
        VEHICLE_BASE_FRAME_BOUNDS = "vehicle/base frame bounds",
        VEHICLE_BASE_DIVIDER_LOCATION = "vehicle/base divider location",
        FRAME_BOUNDS_X = "window.vehicle.bounds.x",
        FRAME_BOUNDS_Y = "window.vehicle.bounds.y",
        FRAME_BOUNDS_WIDTH = "window.vehicle.bounds.width",
        FRAME_BOUNDS_HEIGHT = "window.vehicles.bounds.height",
        DIVIDER_LOCATION = "window.vehicles.divider.location";
    public final static String
        TOOLTIP = "Open window with vehicles and bases";
    
    private Kernel kernel;
    
    protected OpenVehicleBaseFrameAction( Kernel kernel )
    {   super( "Vehicles & Bases..." );
        this.kernel = kernel;
    }   // end constructor
    
    public void actionPerformed( ActionEvent e )
    {
        final Kernel kErnel = this.kernel;
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   
                // Create frame to hold sites panel
                JFrame frame = new JFrame( "Vehicles & Bases" );
                
                // Make a vehicleBase panel
                VehicleBasePanel vehicleBasePanel = 
                    new VehicleBasePanel( kErnel );
                
                // Add vehicleBase panel to frame
                frame.getContentPane().add( vehicleBasePanel, BorderLayout.CENTER );
                
                // Window handler
                final JFrame fRame = frame;
                final VehicleBasePanel VBPanel = vehicleBasePanel;
                final Kernel keRnel = kErnel;
                frame.addWindowListener( new WindowAdapter()
                {   public void windowClosing( WindowEvent e )
                    {   // Save bounds
                        Rectangle bounds = fRame.getBounds();
                        Preferences prefs = kErnel.getPrefs();
                        prefs.setProperty( FRAME_BOUNDS_X, ""+bounds.x );
                        prefs.setProperty( FRAME_BOUNDS_Y, ""+bounds.y );
                        prefs.setProperty( FRAME_BOUNDS_WIDTH, ""+bounds.width );
                        prefs.setProperty( FRAME_BOUNDS_HEIGHT, ""+bounds.height );
                        
                        // Save dividier position
                        prefs.setProperty( DIVIDER_LOCATION,
                            ""+ VBPanel.getDividerLocation() );
                    }   // end windowClosing
                    public void windowClosed( WindowEvent e )
                    {   VBPanel.dispose();
                        System.gc();
                    }   // end windowClosed
                }); // end addWindowListener
                
                // Read bounds. If there are errors, use defaults
                Preferences prefs = kernel.getPrefs();
                try
                {   int x = new Integer( prefs.getProperty( FRAME_BOUNDS_X ) ).intValue();
                    int y = new Integer( prefs.getProperty( FRAME_BOUNDS_Y ) ).intValue();
                    int width = new Integer( prefs.getProperty( FRAME_BOUNDS_WIDTH ) ).intValue();
                    int height = new Integer( prefs.getProperty( FRAME_BOUNDS_HEIGHT ) ).intValue();
                    frame.setBounds( new Rectangle( x, y, width, height ) );
                }   // end try
                catch( Exception ex )
                {   frame.setSize( new Dimension(500,400) );
                    frame.setLocation( prefs.getDefaultWindowX(), prefs.getDefaultWindowY() );
                }   // end catch
                
                // Make sure it fits
                Toolkit theKit = frame.getToolkit();
                Dimension screenSize = theKit.getScreenSize();
                if( frame.getLocation().x > screenSize.width 
                || frame.getLocation().y > screenSize.height )
                    frame.setLocation( prefs.getDefaultWindowX(), prefs.getDefaultWindowY() );

                // Read divider location
                Integer divLoc = null;
                try
                {   divLoc = new Integer( kernel.getPrefs()
                        .getProperty( DIVIDER_LOCATION ) );
                }   // end try
                catch( Exception ex ){}
                if( divLoc != null )
                    VBPanel.setDividerLocation( divLoc.intValue() );
                
                final JFrame frAme = frame;
                SwingUtilities.invokeLater( new Runnable()
                {   public void run()
                    {   frAme.validate();
                        frAme.show();
                    }   // end run
                }); // end runnable, invokeLater

            }   // end run
        }); // end runnable, thread
        t.setDaemon( true );
        t.start();
    }   // end actionPerformed
    
}   // end class OpenVehicleBaseFrameAction