package mil.af.afit.router.app;

import mil.af.afit.router.*;
import mil.af.afit.uvr.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.*;

/**
 * Displays lots of solutions.
 */
public class SolutionsPanel 
extends JPanel
implements Observer
{
    private SolutionList solutionList;
    private Kernel kernel;
    
    public SolutionsPanel( Kernel kernel )
    {   
        super( new BorderLayout() );
        this.solutionList = kernel.getSolutionList();
        this.kernel = kernel;
        this.setupLayout();
        solutionList.addObserver( this );
        AFITRouter.out( "SolutionsPanel.constructor: done." );
    }   // end constructor
    
    
    private final void setupLayout()
    {   
        // Panel for solutions
        JPanel pnlSolutions = new JPanel( new BorderLayout() );
        Box boxSolutions = Box.createVerticalBox();
        JScrollPane scrSolutions = new JScrollPane( boxSolutions );
        pnlSolutions.add( scrSolutions, BorderLayout.CENTER );
        Solution[] solns = solutionList.getSolutions();
        for( int i = solns.length-1; i >= 0; i-- ) // LIFO
        {   boxSolutions.add( new SolutionPanel( 
                solns[i], kernel, true/*showDetailsButton*/ ) );
            if( i < solns.length -1 )
            {   boxSolutions.add( new JToolBar.Separator() );
            }   // end if: add separator
        }   // end for: through each solution
        
        // Add to main
        JPanel pnlMain = new JPanel( new BorderLayout() );
        pnlMain.add( pnlSolutions, BorderLayout.CENTER );
        this.add( pnlMain, BorderLayout.CENTER );
    }   // end setupLayout
    
    public final void dispose()
    {   this.solutionList.deleteObserver( this );
        AFITRouter.out( "SolutionsPanel.dispose: done." );
    }   // end dispose
    
    
/* ********  O B S E R V E R   C O D E  ******** */
    
    public void update( Observable thing, Object arg )
    {
        AFITRouter.out( "SolutionsPanel.update: updating..." );
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   setupLayout();// Do something more suave later
            }   // end run
        }); // end runnable,thread
        t.setDaemon(true);
        t.start();
    }   // end update
    
}   // end class SolutionsPanel