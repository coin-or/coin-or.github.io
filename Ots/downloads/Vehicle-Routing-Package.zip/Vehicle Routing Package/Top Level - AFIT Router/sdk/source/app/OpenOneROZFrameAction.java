package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class OpenOneROZFrameAction
extends AbstractAction
{
    private final static String
        //ROZS_FRAME_BOUNDS = "ROZs frame bounds",
        FRAME_BOUNDS_X = "window.roz.single.bounds.x",
        FRAME_BOUNDS_Y = "window.roz.single.bounds.y",
        FRAME_BOUNDS_WIDTH = "window.single.roz.bounds.width",
        FRAME_BOUNDS_HEIGHT = "window.single.roz.bounds.height";
        
    public final static String TOOLTIP = "Edit the Restricted Operating Zone";
    
    private RestrictedOperatingZone roz;
    private Kernel kernel;
    
    protected OpenOneROZFrameAction( RestrictedOperatingZone roz, Kernel kernel )
    {   super( "..." );
        this.roz = roz;
        this.kernel = kernel;
    }   // end constructor
    
    public void actionPerformed( ActionEvent e )
    {
        final Kernel kErnel = this.kernel;
        final RestrictedOperatingZone Roz = this.roz;
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   
                // Create frame to hold ROZs panel
                JFrame frame = new JFrame( "Restricted Operating Zone" );
                
                // Make a ROZs panel
                OneROZPanel panel = new OneROZPanel( Roz, kernel );
                
                // Add ROZs panel to frame
                frame.getContentPane().add( panel, BorderLayout.CENTER );
                
                // Window handler
                final JFrame fRame = frame;
//                final Kernel keRnel = kErnel;
//                final OneROZPanel pAnel = panel;
                frame.addWindowListener( new WindowAdapter()
                {   public void windowClosing( WindowEvent e )
                    {   // Save bounds
                        Rectangle bounds = fRame.getBounds();
                        Preferences prefs = kErnel.getPrefs();
                        prefs.setProperty( FRAME_BOUNDS_X, ""+bounds.x );
                        prefs.setProperty( FRAME_BOUNDS_Y, ""+bounds.y );
                        prefs.setProperty( FRAME_BOUNDS_WIDTH, ""+bounds.width );
                        prefs.setProperty( FRAME_BOUNDS_HEIGHT, ""+bounds.height );
                    }   // end windowClosing
                    public void windowClosed( WindowEvent e )
                    {   //pAnel.dispose();
                        System.gc();
                    }   // end windowClosed
                }); // end addWindowListener
                
                // Read bounds. If there are errors, use defaults
                Preferences prefs = kernel.getPrefs();
                try
                {   int x = new Integer( prefs.getProperty( FRAME_BOUNDS_X ) ).intValue();
                    int y = new Integer( prefs.getProperty( FRAME_BOUNDS_Y ) ).intValue();
                    int width = new Integer( prefs.getProperty( FRAME_BOUNDS_WIDTH ) ).intValue();
                    int height = new Integer( prefs.getProperty( FRAME_BOUNDS_HEIGHT ) ).intValue();
                    frame.setBounds( new Rectangle( x, y, width, height ) );
                }   // end try
                catch( Exception ex )
                {   frame.pack();
                    frame.setLocation( prefs.getDefaultWindowX(), prefs.getDefaultWindowY() );
                }   // end catch
                
                // Make sure it fits
                Toolkit theKit = frame.getToolkit();
                Dimension screenSize = theKit.getScreenSize();
                if( frame.getLocation().x > screenSize.width 
                || frame.getLocation().y > screenSize.height )
                    frame.setLocation( prefs.getDefaultWindowX(), prefs.getDefaultWindowY() );

                final JFrame frAme = frame;
                SwingUtilities.invokeLater( new Runnable()
                {   public void run()
                    {   frAme.validate();
                        frAme.show();
                    }   // end run
                }); // end runnable, invokeLater

            }   // end run
        }); // end runnable, thread
        t.start();
    }   // end actionPerformed
    
    
    
}   // end class OpenOneROZFrameAction