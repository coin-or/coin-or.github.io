package mil.af.afit.router.app;
import mil.af.afit.router.*;

import java.util.*;
import javax.swing.*;
import javax.swing.table.*;

public class SitesTableModel 
extends AbstractTableModel 
implements Observer
{
    SiteList siteList=null;
    private Kernel kernel;
    private Site emptySite = new Site();
    private Class[] columnClasses;
    private String[] columnNames;
    private int[] columnOrder;
    private JTable hostTable;
    
    private final static int NAME = 0;
    private final static int ENABLED = 1;
    private final static int LATITUDE = 2;
    private final static int LONGITUDE = 3;
    private final static int PRIORITY = 4;
    private final static int EARLIEST_ARRIVAL = 5;
    private final static int LATEST_DEPARTURE = 6;
    private final static int EARLIEST_RESTRICTED = 7;
    private final static int LATEST_RESTRICTED = 8;
    private final static int REQUIREMENT = 9;
    private final static int SERVICE_TIME = 10;
    private final static int NUM_OF_COLUMNS = 11;
    
    public SitesTableModel( Kernel kernel )
    {   super();
        this.kernel = kernel;
        this.emptySite.setEnabled( false );
        setupColumnOrder();
        setupColumnNames();
        setupColumnClasses();
        setupLinksWithKernel(kernel);
    }   // end constructor
    
    public final void setHostTable( JTable table )
    {   this.hostTable = table;
    }   // end setHostTable
    
    private void setupColumnOrder()
    {
        // For now, fixed
        columnOrder = new int[ getColumnCount() ];
        columnOrder[ENABLED] = 0;
        columnOrder[NAME] = 1;
        columnOrder[LATITUDE] = 2;
        columnOrder[LONGITUDE] = 3;
        columnOrder[SERVICE_TIME] = 4;
        columnOrder[PRIORITY] = 5;
        columnOrder[REQUIREMENT] = 6;
        columnOrder[EARLIEST_ARRIVAL] = 7;
        columnOrder[LATEST_DEPARTURE] = 8;
        columnOrder[EARLIEST_RESTRICTED] = 9;
        columnOrder[LATEST_RESTRICTED] = 10;
    }   // end setupColumnOrder
    
    private void setupColumnNames()
    {
        columnNames = new String[ getColumnCount() ];
        columnNames[NAME] = "Name";
        columnNames[REQUIREMENT] = "Requirement";
        columnNames[ENABLED] = "Enabled";
        columnNames[LATITUDE] = "Latitude";
        columnNames[LONGITUDE] = "Longitude";
        columnNames[SERVICE_TIME] = "Loiter Time (minutes)";
        columnNames[PRIORITY] = "Priority";
        columnNames[EARLIEST_ARRIVAL] = "Earliest Allowed";
        columnNames[LATEST_DEPARTURE] = "Latest Allowed";
        columnNames[EARLIEST_RESTRICTED] = "Earliest Restricted";
        columnNames[LATEST_RESTRICTED] = "Latest Restricted";
    }   // end setupColumnNames
    
    private void setupColumnClasses()
    {
        columnClasses = new Class[ getColumnCount() ];
        columnClasses[NAME] = String.class;
        columnClasses[REQUIREMENT] = String.class;
        columnClasses[ENABLED] = Boolean.class;
        columnClasses[LATITUDE] = String.class;
        columnClasses[LONGITUDE] = String.class;
        columnClasses[SERVICE_TIME] = Integer.class;
        columnClasses[PRIORITY] = Integer.class;
        columnClasses[EARLIEST_ARRIVAL] = String.class;
        columnClasses[LATEST_DEPARTURE] = String.class;
        columnClasses[EARLIEST_RESTRICTED] = String.class;
        columnClasses[LATEST_RESTRICTED] = String.class;
    }   // end setupColumnClasses
    
    
/* ********  R E M O V E   C O D E  ******** */
    
    public final void removeSite( Site site )
    {   siteList.removeSite( site );
    }   // end removeSite
    
    public final void removeSiteAt( int index )
    {   siteList.removeSiteAt( index );
    }   // end removeSiteAt
    
    public final void removeSitesAt( int[] indeces )
    {   // if the last index points to the empty entry, remake the list
        // without that entry (which doesn't exist anyway)
        if( indeces[indeces.length-1] == siteList.getSites().length )
        {   int[] temp = new int[ indeces.length-1 ];
            System.arraycopy(indeces,0,temp,0,temp.length);
            indeces = temp;
        }   // end if: strip off fake site at end
        siteList.removeSitesAt( indeces );
    }   // end removeSitesAt
    
/* ********  S O R T I N G   C O D E  ******** */
    
    public final boolean isColumnSortable( int modelColumn )
    {   return true;
    }   // end isColumnSortable
    
    public final void sort( int modelColumn, boolean ascending )
    {
        if( modelColumn == columnOrder[ENABLED] )
            siteList.sortByEnabled( ascending );
        else if( modelColumn == columnOrder[NAME] )
            siteList.sortByName( ascending );
        else if( modelColumn == columnOrder[LATITUDE] )
            siteList.sortByLatitude( ascending );
        else if( modelColumn == columnOrder[LONGITUDE] )
            siteList.sortByLongitude( ascending );
        else if( modelColumn == columnOrder[REQUIREMENT] )
            siteList.sortByRequirementType( ascending );
        else if( modelColumn == columnOrder[EARLIEST_ARRIVAL] )
            siteList.sortByEarliestArrivalTime( ascending );
        else if( modelColumn == columnOrder[LATEST_DEPARTURE] )
            siteList.sortByLatestDepartureTime( ascending );
        else if( modelColumn == columnOrder[EARLIEST_RESTRICTED] )
            siteList.sortByEarliestRestrictedTime( ascending );
        else if( modelColumn == columnOrder[LATEST_RESTRICTED] )
            siteList.sortByLatestRestrictedTime( ascending );
        else if( modelColumn == columnOrder[SERVICE_TIME] )
            siteList.sortByServiceTime( ascending );
        
    }   // end sort
    
/* ********  K E R N E L   A C C E S S   C O D E  ******** */
    
    
    private final synchronized void setupLinksWithKernel(Kernel kernel)
    {
        // Save site list reference
        siteList = kernel.getSiteList();
        
        // Register self to observe the kernel
        siteList.addObserver( this );
        
        // Force an update of relevant components
        fireTableDataChanged();
    }   // end setupLinksWithKernel
    
    public final synchronized void setKernel( Kernel kernel )
    {
        // If we already had a kernel, remove self as observer
        if( this.kernel != null )
            this.kernel.deleteObserver( this );
        this.kernel = kernel;
        setupLinksWithKernel(kernel);
    }   // end setKernel
    
    
    
    
    
    

/* ********  O B S E R V E R   C O D E  ******** */
    
    public void update( Observable thing, Object obj )
    {   fireTableDataChanged();
    }   // end update

    
/* ********  A B S T R A C T T A B L E M O D E L   C O D E  ******** */

    public final int getColumnCount()
    {   return NUM_OF_COLUMNS;
    }   // end getColumnCount
    
    public int getRowCount()
    {   return siteList != null 
            ? siteList.getSites().length + 1
            : 0;
    }   // end getRowCount
    
    public String getColumnName( int column )
    {   int i = 0;
        while( columnOrder[i] != column && i < getColumnCount() )
            i++;
        if( i < getColumnCount() )
            return columnNames[ i ];
        else return null;
    }   // end getColumnName
    
    public Class getColumnClass( int column )
    {   int i = 0;
        while( columnOrder[i] != column && i < getColumnCount() )
            i++;
        if( i < getColumnCount() )
            return columnClasses[ i ];
        else return null;
    }   // end getColumnClass
    
    public Object getValueAt( int row, int column )
    {
        if( siteList != null )
        {
            final boolean isEmptySite = 
                row == siteList.getSites().length;
            final Site site = isEmptySite ?
                    emptySite : siteList.getSites()[row];
            if( site != null )
            {
                if( column == columnOrder[NAME] )
                    return site.getName();
                else
                if( column == columnOrder[REQUIREMENT] )
                    return site.getRequirementType();
                else
                if( column == columnOrder[ENABLED] )
                    return new Boolean( site.isEnabled() );
                else
                if( column == columnOrder[LATITUDE] )
                    return CoreUtilities.doubleLatToString( site.getLatitude(), kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT) );
                    //new Double( site.getLatitude() );
                else
                if( column == columnOrder[LONGITUDE] )
                    return CoreUtilities.doubleLonToString( site.getLongitude(), kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT) );
                    //new Double( site.getLongitude() );
                else
                if( column == columnOrder[PRIORITY] )
                    return new Integer( site.getPriority() );
                else
                if( column == columnOrder[SERVICE_TIME] )
                    return new Integer( site.getServiceTime() );
                else
                if( column == columnOrder[EARLIEST_ARRIVAL] )
                    return CoreUtilities.intTimeToString( 
                        site.getEarliestArrivalTime() );
                else
                if( column == columnOrder[LATEST_DEPARTURE] )
                    return CoreUtilities.intTimeToString( 
                        site.getLatestDepartureTime() );
                else
                if( column == columnOrder[EARLIEST_RESTRICTED] )
                    return CoreUtilities.intTimeToString( 
                        site.getEarliestRestrictedTime() );
                else
                if( column == columnOrder[LATEST_RESTRICTED] )
                    return CoreUtilities.intTimeToString( 
                        site.getLatestRestrictedTime() );
                else
                    return null;
            }   // end if: if site was not null
            else return null;
        }   // end if: siteList not null
        else return null;
    }   // end getValueAt
    
    public boolean isCellEditable( int row, int column )
    {   return true;
    }   // end isCellEditable
    
    
    public void setValueAt( Object value, int row, int column )
    {
        // value may be of the proper natural type, e.g., Boolean,
        // or it may be of type String--particularly if the data
        // is being pasted from Excel. Handling this makes it a little
        // messy.
        if( siteList != null )
        {
            // If the value is a string and contains tabs or
            // new line characters, then hand the data off
            // to the setTabulatedValue method. The data is
            // probably being pasted in.
            if( 
            value instanceof String
            && (
                ((String)value).indexOf('\t')>=0
                || ((String)value).indexOf('\n')>=0 ) )
            {   
                setTabulatedValue( value, row, column );
                /* try to terminate cell edit here. */
            }   // end if: value had tabs or newline characters
            else
            {
                
                final boolean isEmptySite = 
                    row == siteList.getSites().length;
                final Site site = isEmptySite ?
                        emptySite : siteList.getSites()[row];
                
                if( site != null )
                {
                    if( column == columnOrder[NAME] )
                        site.setName( (String) value );
                    else
                    if( column == columnOrder[REQUIREMENT] )
                        site.setRequirementType( (String) value );
                    else
                    if( column == columnOrder[ENABLED] )
                        site.setEnabled( 
                        value instanceof Boolean
                        ? ((Boolean)value).booleanValue() 
                        : ( new Boolean(
                            value instanceof String
                            ? (String)value
                            : null )).booleanValue()
                        );
                    else
                    if( column == columnOrder[LATITUDE] )
                    {   String lat = value.toString().toUpperCase();
                        if( lat.indexOf('N')<0 && lat.indexOf('S')<0 )
                        {   String def = kernel.getPrefs().getProperty( AFITRouter.DEFAULT_LAT_DIRECTION );
                            def = def == null ? "N" : def.substring(0,1);
                            lat = lat+def;
                        }   // end if: no north/south specified
                        site.setLatitude( 
                            CoreUtilities.stringLatToDouble( lat, kernel.getPrefs().getProperty( AFITRouter.LAT_LON_FORMAT ) ) );
                    }   // end if: latitude
                    else
                    if( column == columnOrder[LONGITUDE] )
                    {   String lon = value.toString().toUpperCase();
                        if( lon.indexOf('E')<0 && lon.indexOf('W')<0 )
                        {   String def = kernel.getPrefs().getProperty( AFITRouter.DEFAULT_LON_DIRECTION );
                            def = def == null ? "E" : def.substring(0,1);
                            lon = lon+def;
                        }   // end if: no north/south specified
                        site.setLongitude( 
                            CoreUtilities.stringLonToDouble( lon, kernel.getPrefs().getProperty( AFITRouter.LAT_LON_FORMAT ) ) );
                    }   // end if: latitude
                    else
                    if( column == columnOrder[PRIORITY] )
                        site.setPriority( 
                        value instanceof Number
                        ? ((Number)value).intValue() 
                        : ( new Integer(
                            value instanceof String
                            ? (String)value
                            : null )).intValue()
                        );
                    else
                    if( column == columnOrder[SERVICE_TIME] )
                        site.setServiceTime( 
                        value instanceof Number
                        ? ((Number)value).intValue() 
                        : ( new Integer(
                            value instanceof String
                            ? (String)value
                            : null )).intValue()
                        );
                    else
                    if( column == columnOrder[EARLIEST_ARRIVAL] )
                    {   int t = CoreUtilities.stringTimeToInt( (String) value );
                        if( t <= 0 )
                            t = Integer.MIN_VALUE;
                        site.setEarliestArrivalTime(t);
                    }   // end if: EA
                    else
                    if( column == columnOrder[LATEST_DEPARTURE] )
                    {   int t = CoreUtilities.stringTimeToInt( (String) value );
                        if( t <= 0 )
                            t = Integer.MAX_VALUE;
                        site.setLatestDepartureTime(t);
                    }   // end if: LD
                    else
                    if( column == columnOrder[EARLIEST_RESTRICTED] )
                    {   int t = CoreUtilities.stringTimeToInt( (String) value );
                        if( t <= 0 )
                            t = Integer.MIN_VALUE;
                        site.setEarliestRestrictedTime(t);
                    }   // end if: ER
                    else
                    if( column == columnOrder[LATEST_RESTRICTED] )
                    {   int t = CoreUtilities.stringTimeToInt( (String) value );
                        if( t <= 0 )
                            t = Integer.MIN_VALUE;
                        site.setLatestRestrictedTime(t);
                    }   // end if: LR
                    
                    
                    // If it was the empty site being edited, then actually
                    // a site was being added.
                    if( isEmptySite )
                    {   emptySite.setEnabled( true );
                        Site temp = emptySite;
                        emptySite = new Site();
                        emptySite.setEnabled( false );
                        siteList.addSite( temp );
                    }   // end if: is empty site
                }   // end if: site was not null
            }   // end else: wasn't tabulated
        }   // end if: site list not null
        
    }   // end setValueAt
    
    
/* ********  C O M P L E X   P A S T I N G   C O D E  ******** */
    
    
    private void setTabulatedValue(Object value, int row, int column)
    {
        // If a host table is known, then get a more accurate mapping
        // of columns.
        boolean hasHost = hostTable == null ? false : true;
        int startRow=row;
        int startCol = hasHost 
            ? hostTable.convertColumnIndexToView( column ) 
            : column;
        try
        {
            String trstring= (String)value;//(system.getContents(this).getTransferData(DataFlavor.stringFlavor));

            //System.out.println("String is:"+trstring);
            StringTokenizer st1=new StringTokenizer(trstring,"\n");
            int blankLines = 0;
            for(int i=0;st1.hasMoreTokens();i++)
            {
                String rowstring=st1.nextToken();
                StringTokenizer st2=new StringTokenizer(rowstring,"\t");
                
                if( st2.countTokens() == 0 )
                    blankLines++;
                else
                    for(int j=0;st2.hasMoreTokens();j++)
                    {
                        String valueToSet=(String)st2.nextToken();
                        if (startRow+i-blankLines< getRowCount() &&
                            startCol+j< getColumnCount())
                            setValueAt(valueToSet,startRow+i-blankLines,
                                hasHost
                                ? hostTable.convertColumnIndexToModel(startCol+j)
                                : startCol + j );
                        //System.out.println("Putting "+ value+"at row="+startRow+i+"column="+startCol+j);
                    }
            }
        }
        catch(Exception ex){AFITRouter.err(ex);}
    }   // end setTabulatedValue
    
    
}   // end class SitesTableModel