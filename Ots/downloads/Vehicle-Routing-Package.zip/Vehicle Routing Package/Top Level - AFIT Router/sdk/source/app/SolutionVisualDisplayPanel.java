package mil.af.afit.router.app;
import mil.af.afit.router.*;
import mil.af.afit.uvr.*;

import javax.swing.*;
//import java.awt.geom.*;
import java.awt.*;

public class SolutionVisualDisplayPanel 
extends JPanel
{
    //private final static Color 
    //    VISITED_COLOR = new Color( 0,200,0 ),   // alpha used in Java2 only ->, 200 ),
    //    NOT_VISITED_COLOR = new Color( 200,0,0 ),//, 200 ),
    //    BACKGROUND_COLOR = new Color( 245, 245, 245 ),
    //    BASE_COLOR = new Color( 20, 50, 200 );//, 150 );
    private final int
        J1 = 0, // Indeces used with color arrays for Java 1.1
        J2 = 1; // and Java 1.2
    private int JI = -1;
    private final static Color[]
        VISITED_COLOR = {new Color( 0,200,0 ), new Color( 0,200,0, 200 ) },
        NOT_VISITED_COLOR = {new Color( 200,0,0 ), new Color( 200,0,0, 200)},
        BACKGROUND_COLOR = {new Color( 245,245,245),new Color( 245,245,245)},
        BASE_COLOR = {new Color( 20, 50, 200 ), new Color( 20, 50, 200,150)},
        ALT_START_COLOR = {new Color(10,10,200),new Color(10,10,200,200)};
   
    private boolean JAVA2;
   
    private final static int 
        SITE_WIDTH = 4,
        SITE_HEIGHT = 4,
        BASE_WIDTH = 6,
        BASE_HEIGHT = 6,
        PREFERRED_WIDTH = 200,
        PREFERRED_HEIGHT = 150;
    private final static Color[][] ROUTE_COLORS =
        { 
     //       {new Color( 0, 150, 0 ),new Color( 0, 150, 0, 200 )},
            {new Color( 0, 0, 200 ),new Color( 0, 0, 200, 200 )},
     //       {new Color( 200, 0, 0 ),new Color( 200, 0, 0, 200 )},
            {new Color( 200, 150, 0 ),new Color( 200, 150, 0, 200 )},
            {new Color( 200, 0, 200 ),new Color( 200, 0, 200, 200 )},
            {new Color( 0, 150, 200 ),new Color( 0, 150, 200, 200 )} };
    
    private final static Insets forcedInsets =
        new Insets( 10,10,10,10 );
        
    private final static int VEHICLE_X = forcedInsets.left;
    private final static int Y_STEP = 15;
    private int VEHICLE_Y = forcedInsets.top + Y_STEP;
    
    private final static Integer
        VISITED_SITE_LAYER = new Integer( 150 ),
        NOT_VISITED_SITE_LAYER = new Integer( 200 ),
        ROUTE_LAYER = new Integer( 50 ),
        BASE_LAYER = new Integer( 100 ),
        ALT_START_LAYER = new Integer( 110 );
    
    private double latToYOffset;
    private double lonToXOffset;
    private double latToYScale;
    private double lonToXScale;
    private int extraXOffset;
    
    private Rectangle bounds;
    private Solution solution;
    Kernel kernel;
    
    public SolutionVisualDisplayPanel( Solution soln, Kernel kernel )
    {
        this( soln, kernel, PREFERRED_WIDTH, PREFERRED_HEIGHT );
        
/*        try
        {   Class c = Class.forName( "java.awt.Graphics2D" );
            JAVA2 = true;
        }   // end try
        catch( ClassNotFoundException e )
        {   JAVA2 = false;
        }   // end catch
        JI = JAVA2 ? J2 : J1;
        
        this.setLayout( null );
        this.kernel = kernel;
        this.setBackground( BACKGROUND_COLOR[JI] );
        this.solution = soln;
        final Dimension dim = new Dimension( 
            PREFERRED_WIDTH, PREFERRED_HEIGHT );
        this.setPreferredSize( dim );
        this.setMinimumSize( dim );
        this.setMaximumSize( dim );
        this.setSize( dim );
        this.bounds = this.getBounds();
        this.setupCoordinateSpace( soln );
        
        addSites( soln );
        addTours( soln );
        addBases( kernel.getBaseList() );*/
    }   // end constructor
    
    public SolutionVisualDisplayPanel( Solution soln, Kernel kernel, int width, int height )
    {
        super();
        try
        {   Class c = Class.forName( "java.awt.Graphics2D" );
            JAVA2 = true;
        }   // end try
        catch( ClassNotFoundException e )
        {   JAVA2 = false;
        }   // end catch
        JI = JAVA2 ? J2 : J1;
        
        this.setLayout( null );
        this.kernel = kernel;
        this.setBackground( BACKGROUND_COLOR[JI] );
        this.solution = soln;
        final Dimension dim = new Dimension( 
            width, height );
        this.setPreferredSize( dim );
        this.setMinimumSize( dim );
        this.setMaximumSize( dim );
        this.setSize( dim );
        this.bounds = this.getBounds();
        this.setupCoordinateSpace( soln );
        
        addSites( soln );
        addTours( soln );
        addBases( kernel.getBaseList() );
    }   // end constructor
    
    
    
/* ********  B U I L D   L A Y O U T   C O D E  ******** */
    
    private final void addSites( Solution soln )
    {
        HTour[] tours = soln.getHSolution().getHTours();
        for( int i = 0; i < tours.length; i++ )
        {   final HTour tour = tours[i];
            for( int j = 0; j < tour.size(); j++ )
            {   final Site site = ((UVRSite) 
                    tour.getHOrderAt(j)).getParentSite();
                this.add( makeJSite( site, true, site.getName()+": "+(j+1) ), 
                    VISITED_SITE_LAYER  );
            }   // end for: through each site
        }   // end for: through each tour
        
        // Now add sites from dummy tour (not visited)
        final HTour dTour = soln.getHSolution().getDummyHTour();
        for( int j = 0; j < dTour.size(); j++ )
            {   final Site site = ((UVRSite) 
                    dTour.getHOrderAt(j)).getParentSite();
            this.add( makeJSite( site, false, site.getName() ), 
                NOT_VISITED_SITE_LAYER  );
        }   // end for: through each site

    }   // end addSites
    
    private final void addTours( Solution soln )
    {   HTour[] tours = soln.getHSolution().getHTours();
        
        for( int i = 0; i < tours.length; i++ )
        {   this.add( new RouteView( tours[i],
                ROUTE_COLORS[i%ROUTE_COLORS.length][JI] ),
                ROUTE_LAYER );
            Vehicle vehicle = ((UVRVehicle)tours[i].getHVehicle()).getParentVehicle();
            if( !vehicle.isAtHome() )
                this.add( makeJAlternateStart( vehicle ), ALT_START_LAYER );
        }   // end for: through each tour
    }   // end addTours
    
    private final void addBases( BaseList baseList )
    {
        Base[] bases = baseList.getBases();
        for( int i = 0; i < bases.length; i++ )
            this.add( makeJBase( bases[i] ), BASE_LAYER );
    }   // end addBases
    
    
/* ********  M A K E   A   S I T E   C O D E  ******** */
    
    private final JLabel makeJSite( Site site, boolean visited, String tooltip )
    {
        // Base label
        JLabel lblSite = new JLabel();
        
        // Tooltip
        lblSite.setToolTipText( tooltip );
        
        // Location
        Point pntCenter = latLongToPoint( 
            site.getLatitude(), site.getLongitude() );
        lblSite.setBounds( 
            pntCenter.x - SITE_WIDTH/2,
            pntCenter.y - SITE_HEIGHT/2,
            SITE_WIDTH, SITE_HEIGHT );
            
        // Coloring
        lblSite.setOpaque( true );
        lblSite.setBackground( visited 
            ? VISITED_COLOR[JI] : NOT_VISITED_COLOR[JI] );
        
        return lblSite;
    }   // end makeJSite
    
    private final JLabel makeJBase( Base base )
    {
        // Base label
        JLabel lblBase = new JLabel();
        
        // Tooltip
        lblBase.setToolTipText( base.getName() );
        
        // Location
        Point pntCenter = latLongToPoint( 
            base.getLatitude(), base.getLongitude() );
        lblBase.setBounds( 
            pntCenter.x - BASE_WIDTH/2,
            pntCenter.y - BASE_HEIGHT/2,
            BASE_WIDTH, BASE_HEIGHT );
            
        // Coloring
        lblBase.setOpaque( true );
        lblBase.setBackground( BASE_COLOR[JI] );
        
        return lblBase;
    }   // end makeJBase
    
    
    private final JLabel makeJAlternateStart( Vehicle vehicle )
    {
        // Alt start label
        JLabel label = new JLabel();
        
        // Tooltip
        label.setToolTipText( vehicle.getName() + ": " + 
            CoreUtilities.doubleLatToString(vehicle.getStartingLatitude(),kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT)) +
            ", " + CoreUtilities.doubleLonToString(vehicle.getStartingLongitude(),kernel.getPrefs().getProperty(AFITRouter.LAT_LON_FORMAT)) );
        
        // Location
        Point pntCenter = latLongToPoint( 
            vehicle.getStartingLatitude(), vehicle.getStartingLongitude() );
        label.setBounds( 
            pntCenter.x - BASE_WIDTH/2,
            pntCenter.y - BASE_HEIGHT/2,
            BASE_WIDTH, BASE_HEIGHT );
            
        // Coloring
        label.setOpaque( true );
        label.setBackground( ALT_START_COLOR[JI] );
        
        return label;
    }   // end makeJBase
    
    
/* ********  C O O R D I N A T E S   C O D E  ******** */
    
    private final void setupCoordinateSpace( Solution soln )
    {
        // Find the smallest and largest latitude and longitude
        double smallestLat = Double.MAX_VALUE;
        double smallestLon = Double.MAX_VALUE;
        double largestLat = -Double.MAX_VALUE;
        double largestLon = -Double.MAX_VALUE;
        HTour[] tours = soln.getHSolution().getHTours();
        for( int i = 0; i <= tours.length; i++ )
        {   final HTour tour = i < tours.length?tours[i] : soln.getHSolution().getDummyHTour() ;
            if( tour.getHVehicle() != null )
            {
                final Vehicle vehicle = ((UVRVehicle)tour.getHVehicle())
                    .getParentVehicle();
                final double vsLat = vehicle.getStartingLatitude();
                final double vsLon = vehicle.getStartingLongitude();
                final double veLat = vehicle.getEndingLatitude();
                final double veLon = vehicle.getEndingLongitude();
                // Starting
                if( vsLat < smallestLat )
                    smallestLat = vsLat;
                if( vsLon < smallestLon )
                    smallestLon = vsLon;
                if( vsLat > largestLat )
                    largestLat = vsLat;
                if( vsLon > largestLon )
                    largestLon = vsLon;
                // Ending
                if( veLat < smallestLat )
                    smallestLat = veLat;
                if( veLon < smallestLon )
                    smallestLon = veLon;
                if( veLat > largestLat )
                    largestLat = veLat;
                if( veLon > largestLon )
                    largestLon = veLon;
            }   // end if: not dummy tour
            
            // Sites
            for( int j = 0; j < tour.size(); j++ )
            {   final Site site = ((UVRSite) 
                    tour.getHOrderAt(j)).getParentSite();
                final double lat = site.getLatitude();
                final double lon = site.getLongitude();
                if( lat < smallestLat )
                    smallestLat = lat;
                if( lon < smallestLon )
                    smallestLon = lon;
                if( lat > largestLat )
                    largestLat = lat;
                if( lon > largestLon )
                    largestLon = lon;
            }   // end for: through each site
        }   // end for: through each tour
        
        
        // Find range of latitudes and longitudes
        final double latRange = largestLat - smallestLat;
        final double lonRange = largestLon - smallestLon;
        
        // Find scales
        final int width = this.getWidth() - forcedInsets.left - forcedInsets.right;
        final int height = this.getHeight() - forcedInsets.top - forcedInsets.bottom;
        double scale1 = width / lonRange;
        double scale2 = height / latRange;
        lonToXScale = latToYScale = Math.min( scale1, scale2 );
        
        // Find offsets-Bring it flush right
        lonToXOffset = -smallestLon;
        latToYOffset = -smallestLat;
        
        // Add a little more lonToXOffset to make the drawing
        // flush to the right side.
        double rightMost = (largestLon + lonToXOffset)*lonToXScale;
        extraXOffset = (int)(width - rightMost + forcedInsets.right);
    }   // end setupCoordinateSpace
    
    
    private final Point latLongToPoint( double lat, double lon )
    {
        final int x = (int) ( (lon + lonToXOffset) 
            * lonToXScale) + forcedInsets.left + extraXOffset;
        final int y = this.getHeight() - forcedInsets.top -
            (int)((lat + latToYOffset) * latToYScale);
        Point p = new Point( x, y );
        return p;
    }   // end latLongToPoint
    
    
/* ********  S U B C L A S S   R O U T E V I E W  ******** */
    
    
    private class RouteView 
    extends JComponent
    {
        //private GeneralPath path;
        private Polygon[] paths;
        private Point start;
        private Point end;
        private String strVehicle;
        private Color color;
        private int vehicle_y;
        private final float STROKE_WIDTH = 0.8f;
        private final float STROKE_FIRST_LEG = 3.0f;
        
        public RouteView( HTour tour, Color color )
        {
            this.color = color;
            this.setBounds( bounds );
            setOpaque( false );
            setup( tour );
        }   // end constructor
        
        
        public void paintComponent( Graphics g )
        {
            super.paintComponent( g );
            
            // If Java 2 is available, use its more sophisticated
            // drawing techniques. Otherwise just use the Java 1.1 way.
            if( JAVA2 )
            {
                Graphics2D g2D = (Graphics2D) g;
                
                // Turn on antialiasing if available
                g2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING,
                                      RenderingHints.VALUE_ANTIALIAS_ON );
                // Set color
                g2D.setPaint( color );
                
                // Draw first leg thicker than the rest
                if( paths.length >= 0 )
                {   g2D.setStroke( new BasicStroke( STROKE_FIRST_LEG ) );
                    g2D.draw( paths[0] );
                }   // end if: at least one leg
                
                // If there are more legs, change the stroke width and draw
                if( paths.length > 0 )
                {
                    // Set line width
                    g2D.setStroke( new BasicStroke( STROKE_WIDTH ) );
                    
                    // Draw path
                    for( int i = 1; i < paths.length; i++ )
                        g2D.draw( paths[i] );
                }   // end if: rest of paths
                
                // Turn off antialiasing
                g2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING,
                                      RenderingHints.VALUE_ANTIALIAS_OFF );
                g2D.drawString( strVehicle, VEHICLE_X, vehicle_y );
            }   // end if: Java 2 available.
            else
            {
                g.setColor( color );
                for( int i = 0; i < paths.length; i++ )
                    g.drawPolygon( paths[i] );
                
                g.drawString( strVehicle, VEHICLE_X, vehicle_y );
            }   // end else: doesn't have java 2 available.
            
        }   // end paintComponent
        
        
        
        protected void setup( HTour tour )
        {
            //path = new GeneralPath();
            Vehicle vehicle = ((UVRVehicle)tour.getHVehicle())
                .getParentVehicle();
            strVehicle = vehicle.getName();
            vehicle_y = VEHICLE_Y;
            VEHICLE_Y += Y_STEP;
            paths = new Polygon[ tour.size()+1 ];
            int iPath = 0;
            
            // Move to vehicle's location
            Point ps = start = latLongToPoint( 
                vehicle.getStartingLatitude(), vehicle.getStartingLongitude() );
                
            // Draw lines to each target
            Point prev = ps;
            for( int j = 0; j < tour.size(); j++ )
            {   Site site = ((UVRSite)tour.getHOrderAt(j)).getParentSite();
                Point p = latLongToPoint(
                    site.getLatitude(), site.getLongitude() );
                paths[iPath++] = makePolygon(prev,p);
                prev = p;
            }   // end for: nodes within tour
                
            // Draw line back to base
            Point p = end = latLongToPoint( 
                vehicle.getEndingLatitude(), vehicle.getEndingLongitude() );
            paths[iPath++] = makePolygon(prev,p);
            prev = p;
            validate();
        }   // end updateRoutePaths
        
        private Polygon makePolygon( Point start, Point end )
        {   int[] x = {start.x, end.x};
            int[] y = {start.y, end.y};
            return new Polygon( x, y, 2 );
        }   // end makePolygon
        
    }   // end sub-sub class RouteView
    
    
    
    
}   // end class SolutionVisualDisplayPanel