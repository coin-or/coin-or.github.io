package mil.af.afit.router.app;
import mil.af.afit.router.*;

//import mil.af.afit.solomon.*;
import mil.af.afit.uvr.*;

import java.util.*;
import java.awt.*;
import javax.swing.*;

public class SolverRunner implements HEngineListener
{
    //private AFITRouter parent;
    private Kernel kernel;
    private String solverName;
    private double effort;
    private Window parentWindow;
    private int numberOfThreads;
    private boolean startSolving = false;
    private ProgressMonitor monitor;
    private Solution bestSolution;
    private HEngine engine;
    
    public SolverRunner( Kernel kernel, Window parentWindow )
    {
        this.kernel = kernel;
        this.parentWindow = parentWindow;
    }   // end constructor
    
/* ********  S O L V I N G   C O D E  ******** */
    
    public final void startSolving()
    {   
//        kernel.startSolving( this );
AFITRouter.out( "SolverRunner.startSolving: Shame. Shame. You shouldn't be using this anymore." );        
    }   // end startSolving
    
    
    
    
/* ********  H E N G I N E L I S T E N E R   C O D E  ******** */
    
    public final void HEngineEventPerformed( HEngineEvent e )
    {
        int eventType = e.getEventType();
        HEngine engine = (HEngine) e.getSource();
        
        // Determine the type of event that was performed
        switch( eventType )
        {
            case HEngineEvent.PERCENT_DONE:
                handlePercentDone( engine );
                break;
            case HEngineEvent.ENGINE_STARTED:
                handleEngineStarted( engine );
                break;
            case HEngineEvent.SOLVER_STARTED:
                handleSolverStarted( engine );
                break;
            case HEngineEvent.ENGINE_FINISHED:
                handleEngineFinished( engine );
                break;
            case HEngineEvent.NEW_BEST_SOLUTION:
                handleNewBestSolution( engine );
                break;
            default:
                // Should never get here
                break;
        }   // end switch
        
    }   // end HEngineEventPerformed
    
    private final void handlePercentDone( HEngine engine )
    {   final float pd = engine.getPercentDone();
        
        // Check to see if the user has cancelled
        if( monitor.isCanceled() )
        {   stopSolving();
        }   // end if: canceled
        else
            monitor.setProgress( (int) (pd*100) );
    }   // end handlePercentDone
    
    
    private final void handleEngineStarted( HEngine engine )
    {
        // Set up progress bar
        monitor = new ProgressMonitor( parentWindow, 
            "Finding routes.",  // Main messge
            "Building initial tours...",   // Sub message
            0, 100 );   // Bounds.
    }   // end handleEngineStarted
    
    private final void handleSolverStarted( HEngine engine )
    {
    }   // end handleSolverStarted
    
    
    private final void handleEngineFinished( HEngine engine )
    {   
    }   // end handleEngineFinished
    
    
    private final void handleNewBestSolution( HEngine engine )
    {   
        // Some quick access variables
        HSolution soln = engine.getBestHSolution();
        this.bestSolution = new Solution( soln, null );
        
        // Update monitor with information.
        monitor.setNote( "Mission length: " 
            + this.bestSolution.getMissionLengthString() );
        
    }   // end handleNewBestSolution
    
    
    private final void stopSolving()
    {
        engine.stopSolving();
    }   // end stopSolving
    
    
}   // end class SolverRunner