package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class OpenSolveDialogAction
extends AbstractAction
{
    
    private final static String SOLVE_DIALOG_TITLE = "Solve";
    //private RouterFrame parentFrame;
    //private AFITRouter parent;
    private Kernel kernel;
    private Component parentComponent;
    
    public OpenSolveDialogAction( 
    Kernel kernel, Component parentComponent )
    {   this.parentComponent = parentComponent;
        this.kernel = kernel;
    }   // end constructor
    
    public void actionPerformed( ActionEvent e )
    {
        // If we need to later, verify that it was the solve
        // button that was pushed. For now, it's the only thing
        // generating events.
        
        // Open a dialog box that has some settings, and let
        // that do the rest of the work.
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   
                // Open dialog for solving here.
                /* code here */
                SolveOptionsPanel solveOptions = 
                    new SolveOptionsPanel( kernel );
                
                int response = JOptionPane.showConfirmDialog(
                    parentComponent, solveOptions,
                    SOLVE_DIALOG_TITLE, 
                    JOptionPane.OK_CANCEL_OPTION ) ;
                
                // Only do something if okay was selected
                if( response == JOptionPane.OK_OPTION )
                {
                    // Save prefs
                    //kernel.getPrefs().setLastSolverUsed( 
                    //    solveOptions.getSelectedSolverName() );
                    kernel.getPrefs().setUsePostOptimization(
                        solveOptions.usePostOptimization() );
                    kernel.getPrefs().setLastRequestedSolutionEffort(
                        solveOptions.getRequestedEffort() );
                    
                    // Solve
                    final ProgressMonitor Monitor = new ProgressMonitor(
                        parentComponent, // parent component
                        "Solving...",    // message
                        "Setting up...", // note
                        0, 100 );   // min-max
                    Monitor.setMillisToDecideToPopup( 0 );
                    Monitor.setMillisToPopup( 0 );
                    Thread.yield();
                    final Kernel kErnel = kernel;
                    kernel.startSolving( new KernelSolverListener()
                    {   public void kernelSolverEventPerformed( KernelSolverEvent e )
                        {   Thread.yield();
                            final int eventType = e.getEventType();
                            final KernelSolver Ks = e.getKernelSolver();
                            switch( eventType )
                            {   case KernelSolverEvent.PERCENT_DONE:
                                    Monitor.setProgress( (int)
                                        ( Ks.getPercentDone() * 100 ) );
                                    if( Monitor.isCanceled() )
                                        Ks.stopSolving();
                                case KernelSolverEvent.PRIORITY_MODEL_CHANGED:
                                    PriorityModel model = 
                                        Ks.getCurrentPriorityModel();
                                    if( model != null )
                                    {   Monitor.setNote( "Priority model: " +
                                            model.getName() );
                                    }   // end if: model not null
                                    break;
                                case KernelSolverEvent.SOLVER_FINISHED:
                                    AbstractAction act = new OpenSolutionsFrameAction( kErnel );
                                    act.actionPerformed( null );
                                    break;
                            }   // end switch: event type
                        }   // end kernelSolverEventPerformed
                    }); // end KernelSolverListener
                    
                }   // end if: continue solving
            }   // end run
        }); // end runnable, thread
        t.setDaemon( true );
        t.start();
    }   // end actionPerformed
    
    
}   // end class OpenSolveDialogAction