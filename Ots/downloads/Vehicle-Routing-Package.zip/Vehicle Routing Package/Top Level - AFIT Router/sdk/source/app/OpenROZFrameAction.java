package mil.af.afit.router.app;
import mil.af.afit.router.*;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class OpenROZFrameAction
extends AbstractAction
{
    private final static String
        //ROZS_FRAME_BOUNDS = "ROZs frame bounds",
        FRAME_BOUNDS_X = "window.roz.bounds.x",
        FRAME_BOUNDS_Y = "window.roz.bounds.y",
        FRAME_BOUNDS_WIDTH = "window.roz.bounds.width",
        FRAME_BOUNDS_HEIGHT = "window.roz.bounds.height";
        
    public final static String TOOLTIP = "Opens window with Restricted Operating Zones";
    
    private Kernel kernel;
    
    protected OpenROZFrameAction( Kernel kernel )
    {   super( "Restricted Operating Zones..." );
        this.kernel = kernel;
    }   // end constructor
    
    public void actionPerformed( ActionEvent e )
    {
        final Kernel kErnel = this.kernel;
        Thread t = new Thread( new Runnable()
        {   public void run()
            {   
                // Create frame to hold ROZs panel
                JFrame frame = new JFrame( "Restricted Operating Zones" );
                
                // Make a ROZs panel
                ROZsPanel panel = new ROZsPanel( kErnel );
                
                // Make a menu bar
                //setupMenu( frame, ROZsPanel );
                
                // Add ROZs panel to frame
                frame.getContentPane().add( panel, BorderLayout.CENTER );
                
                // Window handler
                final JFrame fRame = frame;
//                final Kernel keRnel = kErnel;
//                final ROZsPanel pAnel = panel;
                frame.addWindowListener( new WindowAdapter()
                {   public void windowClosing( WindowEvent e )
                    {   // Save bounds
                        Rectangle bounds = fRame.getBounds();
                        Preferences prefs = kErnel.getPrefs();
                        prefs.setProperty( FRAME_BOUNDS_X, ""+bounds.x );
                        prefs.setProperty( FRAME_BOUNDS_Y, ""+bounds.y );
                        prefs.setProperty( FRAME_BOUNDS_WIDTH, ""+bounds.width );
                        prefs.setProperty( FRAME_BOUNDS_HEIGHT, ""+bounds.height );
                    }   // end windowClosing
                    public void windowClosed( WindowEvent e )
                    {   //pAnel.dispose();
                        System.gc();
                    }   // end windowClosed
                }); // end addWindowListener
                
                // Read bounds. If there are errors, use defaults
                Preferences prefs = kernel.getPrefs();
                try
                {   int x = new Integer( prefs.getProperty( FRAME_BOUNDS_X ) ).intValue();
                    int y = new Integer( prefs.getProperty( FRAME_BOUNDS_Y ) ).intValue();
                    int width = new Integer( prefs.getProperty( FRAME_BOUNDS_WIDTH ) ).intValue();
                    int height = new Integer( prefs.getProperty( FRAME_BOUNDS_HEIGHT ) ).intValue();
                    frame.setBounds( new Rectangle( x, y, width, height ) );
                }   // end try
                catch( Exception ex )
                {   frame.pack();
                    frame.setLocation( prefs.getDefaultWindowX(), prefs.getDefaultWindowY() );
                }   // end catch
                
                // Make sure it fits
                Toolkit theKit = frame.getToolkit();
                Dimension screenSize = theKit.getScreenSize();
                if( frame.getLocation().x > screenSize.width 
                || frame.getLocation().y > screenSize.height )
                    frame.setLocation( prefs.getDefaultWindowX(), prefs.getDefaultWindowY() );

                final JFrame frAme = frame;
                SwingUtilities.invokeLater( new Runnable()
                {   public void run()
                    {   frAme.pack();
                        frAme.show();
                    }   // end run
                }); // end runnable, invokeLater

            }   // end run
        }); // end runnable, thread
        t.start();
    }   // end actionPerformed
    
    
    
}   // end class OpenROZFrameAction