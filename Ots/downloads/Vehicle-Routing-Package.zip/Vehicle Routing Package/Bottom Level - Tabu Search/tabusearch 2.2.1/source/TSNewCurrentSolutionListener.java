package net.usa.rharder.tabusearch22;



// Normal java programs should have their listeners extend
// EventListener like you can see in the commented-out lines,
// but to make this package as autonomous as possible, the
// Listeners extend nothing.
//import java.util.EventListener;


/**
 * An object that will listen for new current solutions to be found.
 * 
 * @author Robert Harder, rharder@usa.net
 * @see TSTabuEvent
 * @see TSSolution
 * @version 2.0
 * @since 1.1
 */
public interface TSNewCurrentSolutionListener// extends EventListener
{

    /**
     * Called when a new best solution is found.
     * 
     * @param e The <code>TSTabuEvent</code> referencing the <code>TSEngine</code> that found
     * the new best solution.
     * @see TSTabuEvent
     */
    public void newCurrentSolutionFound( TSTabuEvent e );
}   // end interface TSNewCurrentSolutionListener