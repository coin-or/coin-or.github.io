package net.usa.rharder.tabusearch22;


// Normal java programs should have their events extend
// EventObject like you can see in the commented-out lines,
// but to make this package as autonomous as possible, the
// events extend nothing.
//import java.util.EventObject;

/**
 * These events are fired off by the <code>TSEngine</code> and are useful
 * for extending the engine to include such things as long term memory
 * and other tabu extras. These are lightweight events that only contain
 * a reference to their source object.
 * 
 * @author Robert Harder, rharder@usa.net
 * @see TSEngine
 * @see TSEngineFinishedListener
 * @see TSEngineStartedListener
 * @see TSNewBestSolutionListener
 * @see TSNewCurrentSolutionListener
 * @see TSUnimprovingMoveListener
 * @version 2.0
 * @since 1.1
 */

public class TSTabuEvent// extends EventObject
{
    /**
     * Source of the event. Should always be a <code>TSEngine</code>.
     */
    private Object source;

    /**
     * Constructor that accepts the source of the event.
     * 
     * @param source The source of the event.
     */
    
    public TSTabuEvent( Object source )
    {   this.source = source;
    }   // end constructor

    /**
     * Returns the source of the event. Although it returns an
     * <code>Object</code>, it will always refer to the <code>TSEngine</code>
     * that produced the event.
     * 
     * @return The engine that produced the event.
     */
    
    public final Object getSource()
    {   return source;
    }   // end getSource
    
    /**
     * Casts the <code>source</code> as a <code>TSEngine</code>
     * prior to returning. It is equivalent to
     * <code>(TSEngine) getSource()</code>.
     * @return source as <code>TSEngine</code>
     */
    public final TSEngine getTSEngine()
    {   return (TSEngine) source;
    }   // end getTSEngine
    
}   // end class TSTabuEvent