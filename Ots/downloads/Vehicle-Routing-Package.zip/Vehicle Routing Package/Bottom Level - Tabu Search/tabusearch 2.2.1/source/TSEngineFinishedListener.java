package net.usa.rharder.tabusearch22;

// Normal java programs should have their listeners extend
// EventListener like you can see in the commented-out lines,
// but to make this package as autonomous as possible, the
// Listeners extend nothing.
//import java.util.EventListener;
/**
 * An object that will listen for the engine to finish.
 * 
 * @author Robert Harder
 * @see TSEngine
 * @see TSTabuEvent
 * @version 2.1
 * @since 2.1
 */

public interface TSEngineFinishedListener// extends EventListener
{

    /**
     * Called when the engine is done.
     * 
     * @param e The <code>TSTabuEvent</code> referencing 
     * the <code>TSEngine</code> that finished.
     * @see TSEngine
     * @see TSTabuEvent
     */
    public void engineFinished( TSTabuEvent e );
}   // end interface TSEngineFinishedListener