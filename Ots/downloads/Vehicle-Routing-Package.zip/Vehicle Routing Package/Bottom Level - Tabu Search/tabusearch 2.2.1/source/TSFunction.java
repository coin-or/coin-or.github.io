package net.usa.rharder.tabusearch22;

/**
 * This generic function can be used for anything that
 * evaluates a <code>TSSolution</code>. The <code>evaluate</code>
 * method is required.
 * <P>
 * Generally this class will be extended to define an
 * objective function and a constraint penalties function. These
 * two objects should return an array of equal length. Their results
 * are added together, element by element, to obtain a final solution
 * value.
 * 
 * @author Robert Harder, rharder@usa.net
 * @version 2.1
 * @since 2.1
 */
public interface TSFunction
{

    /**
     * The Tabu Search <code>TSEngine</code> expects an objective
     * function and constraint penalties function to be able
     * to evaluate its own worth. The <code>TSEngine</code> will
     * pass the <code>TSFunction</code> a <code>TSSolution</code>.
     * The <code>TSFunction</code> will then need to cast the
     * <code>TSSolution</code> to its own solution type.
     * <P>
     * Casting example:<BR>
     * <code>
     * public float evaluate( TSSolution soln )<BR>
     * {<BR>
     *     MySolutionClass solution = (MySolutionClass) soln;<BR>
     *     // continue with evaluation</code>
     * <P>
     * The array of returned values will later be compared
     * lexicographically in the classic "goal-programming"
     * style. If you want some goals to overpower higher goals,
     * use the style of weighting the levels with appropriate values.
     * Although all numbers are stored and calculated as <code>double</code>s,
     * they are cast to <code>float</code>s before being compared.
     * 
     * @param soln An object of type <code>TSSolution</code>.
     * @return The function's value.
     * @see TSSolution
     * @since 2.1
     */
    public abstract double[] evaluate( TSSolution soln );
}   // end class TSFunction
    