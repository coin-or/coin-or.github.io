package net.usa.rharder.tabusearch22;

// Normal java programs should have their listeners extend
// EventListener like you can see in the commented-out lines,
// but to make this package as autonomous as possible, the
// Listeners extend nothing.
//import java.util.EventListener;
/**
 * An object that will listen for the engine to make
 * unimproving moves.
 * 
 * @author Robert Harder, rharder@usa.net
 * @see TSTabuEvent
 * @version 2.1
 * @since 2.0
 */

public interface TSUnimprovingMoveListener// extends EventListener
{

    /**
     * Called when the engine is done.
     * 
     * @param e The <code>TSTabuEvent</code> referencing the <code>TSEngine</code>
     * that made an unimproving move.
     * @see TSTabuEvent
     * @see TSEngine
     */
    public void unimprovingMoveMade( TSTabuEvent e );
}   // end interface TSUnimprovingMoveListener