package net.usa.rharder.tabusearch22;

/**
 * This exception is thrown when <code>getAllMoves</code>
 * (in the <code>TSMoveManager</code>)returns no moves.
 * Execution does not stop. The <code>TSEngine</code> moves
 * on to the next iteration and again requests
 * <code>getAllMoves</code> from the <code>TSMoveManager</code>.
 * 
 * @author Robert Harder, rharder@usa.net
 * @version 2.1
 * @since 2.1
 */


public class NoMovesGeneratedException extends Exception
{
    /**
     * The iteration when the exception was thrown.
     */
    private int iteration = -1;
    
    /**
     * Constructs generic <code>NoMovesGeneratedException</code>.
     * This constructor only calls <code>super()</code> and quits.
     */
    public NoMovesGeneratedException()
    {   super();
    }   // end constructor
    
    /**
     * Constructs a <code>NoMovesGeneratedException</code> with
     * the specified string. This constructor calls
     * <code>super( s )</code> and quits.
     *
     * @param s <code>String</code> describing the exception
     **/
    public NoMovesGeneratedException( String s )
    {   super( s );
    }   // end constructor
    
    /**
     * Constructs a <code>NoMovesGeneratedException</code> and
     * specifies the iteration when the exception occurred.
     *
     * @param iteration the iteration when the exception occurred.
     */
    public NoMovesGeneratedException( int iteration )
    {   super();
        this.iteration = iteration;
    }   // end constructor
    
    /**
     * Returns a <code>String</code> representation of the
     * exception, specifiying the iteration of the exception,
     * if known.
     *
     * @return String representation of the exception.
     */
    public String toString()
    {   return "NoMovesGeneratedException" + 
            ( iteration >=0 ? " at iteration " + iteration : "" );
    }   // end toString
    
}   // end NoMovesGeneratedException