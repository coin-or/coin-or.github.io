package net.usa.rharder.tabusearch22;


/**
 * The <code>TSEngine</code> is the main source of control
 * for the programmer. The extended and instantiated
 * tabu objects are passed to the engine, and the engine
 * fires off relevant events to interested listeners. These
 * events make it easy to extend the tabu search to include
 * popular techniques such as intensification, diversification,
 * and strategic oscillation.
 * 
 * @author Robert Harder, rharder@usa.net
 * @version 2.2
 * @since 1.0
 */

public class TSEngine
{

    /**
     * When set to <code>true</code>, information will be printed
     * to <code>System.out</code> and <code>System.err</code> at various
     * points in the code.
     */
    protected final static boolean DEBUGGING = false;
    

    /**
     * The <code>TSEngineRunner</code> is the thread that does the
     * real work. The <code>TSEngine</code> object that the user interacts
     * with is not a thread. It just sits there while the
     * <codeTSEngineRunner</code> does its thing.
     * <P>
     * Most of the access methods available in the <code>TSEngine</code>
     * are duplicated in the <code>TSEngineRunner</code> but are only
     * accessed by the parent <code>TSEngine</code> object.
     * 
     * @since 2.0
     */
    // The runner that does the dirty work
    private TSEngineRunner runner;

    /**
     * If no number of threads is specified, this is used.
     * 
     * @since 2.0
     */
    // Some defaults
    private final static int defaultNumberOfThreads = 1;

    /**
     * If no maximizing value is set, this is used.
     * 
     * @since 2.0
     */
    private final static boolean defaultMaximizing = true;

    
/* ********  C O N S T R U C T O R S  ******** */
    
    /**
     * This most basic constructor assumes a maximization problem
     * and uses just one thread for searching.
     * 
     * @param initialSolution The initial solution
     * @param tabuList The tabu list
     * @param objectiveFunction The objective function. Note that the objective function
     * and the penalty function are really very much the same.
     * They are divided up for easier programming and for
     * possible future enhancements.
     * @param penaltyFunction The penalty function.
     * @param moveManager The Move Manager.
     * @see TSSolution
     * @see TSTabuList
     * @see TSFunction
     * @see TSMoveManager
     * @since 2.0
     */
    
    public TSEngine( TSSolution initialSolution, TSTabuList tabuList,
    TSFunction objectiveFunction, TSFunction penaltyFunction,
    TSMoveManager moveManager )
    {
        realConstructor( initialSolution, tabuList, 
            objectiveFunction, penaltyFunction, moveManager, 
            defaultMaximizing, defaultNumberOfThreads );
    }   // end basic constructor

    /**
     * This constructor lets you specify if you are maximizing
     * or minimizing.
     * 
     * @param initialSolution The initial solution
     * @param tabuList The tabu list
     * @param objectiveFunction The objective function. Note that the objective function
     * and the penalty function are really very much the same.
     * They are divided up for easier programming and for
     * possible future enhancements.
     * @param penaltyFunction The penalty function.
     * @param moveManager The Move Manager.
     * @param maximizing <code>true</code> if maximizing, </code>false</code> if minimizing
     * @see TSSolution
     * @see TSTabuList
     * @see TSFunction
     * @see TSMoveManager
     * @since 2.0
     */
    public TSEngine( TSSolution initialSolution, TSTabuList tabuList,
    TSFunction objectiveFunction, TSFunction penaltyFunction,
    TSMoveManager moveManager, boolean maximizing )
    {
        realConstructor( initialSolution, tabuList, objectiveFunction,
            penaltyFunction, moveManager, maximizing, defaultNumberOfThreads );
    }   // end constructor

    /**
     * This constructor lets you specify if you are maximizing
     * or minimizing. It also lets you specify the number of threads
     * to use during the search. If you are running on a multi-processor
     * computer and have a capable OS such as Solaris, NT, or MacOS X, 
     * with jdk1.2.x or better, you will see speed gains
     * by setting the number of threads to use equal to or greater
     * than the number of processors on the machine. If more than
     * one thread is specified, the moves at each iteration are divided
     * up among the threads and evaluated separately. On most computers
     * the speed gain may be only 10% since memory access is commonly
     * still handled in a one-at-a-time manner by most platforms.
     * 
     * @param initialSolution The initial solution
     * @param tabuList The tabu list
     * @param objectiveFunction The objective function. Note that the objective function
     * and the penalty function are really very much the same.
     * They are divided up for easier programming and for
     * possible future enhancements.
     * @param penaltyFunction The penalty function.
     * @param moveManager The Move Manager.
     * @param maximizing <code>true</code> if maximizing, </code>false</code> if minimizing
     * @param numberOfThreads number of threads to use when searching
     * @see TSSolution
     * @see TSTabuList
     * @see TSFunction
     * @see TSMoveManager
     * @since 2.0
     */
    public TSEngine( TSSolution initialSolution, TSTabuList tabuList,
    TSFunction objectiveFunction, TSFunction penaltyFunction,
    TSMoveManager moveManager, boolean maximizing, int numberOfThreads )
    {
        realConstructor( initialSolution, tabuList, objectiveFunction,
            penaltyFunction, moveManager, maximizing, numberOfThreads );
    }   // end constructor

    /**
     * The other constructors funnel into this method. The constructors
     * that do not specify all parameters will send default settings
     * to this "real" constructor.
     * 
     * @param initialSolution The initial solution.
     * @param tabuList The tabu list.
     * @param objectiveFunction The objective function.
     * @param penaltyFunction The penalty function.
     * @param moveManager The move manager.
     * @param maximizing <code>true</code> if maximizing, <code>false</code> if minimizing.
     * @param numberOfThreads number of threads to use. Useful when the computer has multiple
     * processors.
     * @see TSSolution
     * @see TSTabuList
     * @see TSFunction
     * @see TSMoveManager
     * @since 2.0
     */    
    
    private final void realConstructor( 
    TSSolution initialSolution, TSTabuList tabuList,
    TSFunction objectiveFunction, TSFunction penaltyFunction,
    TSMoveManager moveManager, boolean maximizing, int numberOfThreads )
    {
        runner = new TSEngineRunner( initialSolution, tabuList, objectiveFunction,
            penaltyFunction, moveManager, maximizing, numberOfThreads, this );
        
        Thread t = new Thread( runner );
        t.setDaemon( true );
        t.start();
        
    }   // end realConstructor

    
/* ********  C O N T R O L L E R   M E T H O D S  ******** */
    
/**
 * Starts the engine solving for the given number of iterations. If
 * the engine is already solving, the passed number of iterations
 * is added to the iterations remaining. If the engine has stopped,
 * it will start up again and fire an event to registered
 * <code>TSEngineStartedListener</code>s.
 * 
 * @param additionalIterations Additional iterations to solve.
 * @see TSEngineStartedListener
 * @since 1.0
 */
    public final void startSolving( int additionalIterations )
    {
        // Tell runner to solve additional iterations
        runner.startSolving( additionalIterations );
    }   // end startSolving

    /**
     * Stop the engine after the current iteration. Control
     * is not returned until the engine has stopped and
     * events have been fired to registered
     * <code>TSEngineFinishedListener</code>s.
     * 
     * @see TSEngineFinishedListener
     * @since 2.0
     */
    public final void stopSolving()
    {   runner.stopSolving();
    }   // end stopSolving


    /**
     * Returns control when the engine has stopped. A more
     * sophisticated way to handle waiting for the engine is
     * to use a <code>TSEngineFinishedListener</code>.
     * 
     * @see TSEngineFinishedListener
     */
    public final void waitToFinish()
    {   synchronized( runner )
        {   while( runner.getIterationsToGo() > 0 )
            {   runner.notifyAll();
                try
                {   runner.wait();
                }   // end try
                catch( InterruptedException e )
                {   error( e );
                }   // end catch
            }   // end synchronized
        }   // end while
    }   // end waitToFinish

/* ********  S E T   M E T H O D S  ******** */
    
    
    /**
     * Sets the current solution to a copy of the passed solution. This
     * is useful when implementing various intensification and
     * diversification techniques.
     *
     * @param solution The new solution
     * @see TSSolution
     * @since 2.1
     */
    public final void setCurrentSolutionToCopyOf( TSSolution solution )
    {   runner.setCurrentSolutionToCopyOf( solution );
    }   // end setCurrentSolutionToCopyOf
    
    /**
     * Sets the best solution to a copy of the passed solution. This
     * is useful when there is more than one <tt>TSEngine</tt>
     * working on the solution space.
     *
     * @param solution The new best solution
     * @see TSSolution
     * @since 2.1
     */
    public final void setBestSolutionToCopyOf( TSSolution solution )
    {   runner.setBestSolutionToCopyOf( solution );
    }   // end setBestSolution
    
    
    /**
     * Sets the best solution to a copy of the passed solution but only
     * if the new solution is better than the existing best solution.
     * This is useful when there is more than one <tt>TSEngine</tt>
     * working on the solution space.
     *
     * @param solution The new best solution
     * @see TSSolution
     * @since 2.1
     */
    public final void trySettingBestSolutionToCopyOf( TSSolution solution )
    {   runner.trySettingBestSolutionToCopyOf( solution );
    }   // end setBestSolution
    
    
/* ********  G E T   M E T H O D S  ******** */
    
    /**
     * Returns the number of milliseconds it took to solve the last
     * set of iterations. If iterations are added with the
     * <code>startSolving</code> method, the time returned will reflect
     * the time needed to solve the total number of iterations.
     * 
     * @return Number of milliseconds for last solve
     * @since 1.0
     */
    public final synchronized long getLastSolveMillis()
    {   return runner.getLastSolveMillis();
    }   // end getLastSolveMillis

    /**
     * Returns the best solution found so far.
     * 
     * @return The best solution found so far.
     * @see TSSolution
     * @since 1.0
     */
    public final TSSolution getBestSolution()
    {   return runner.getBestSolution();
    }   // end getBestSolution
    
    /**
     * Returns the iteration number when the best solution was found.
     *
     * @return iteration when best solution was found
     * @see TSSolution
     * @since 2.1
     */
    public final int getIterationOfBestSolution()
    {   return runner.getIterationOfBestSolution();
    }   // end getIterationOfBestSolution
    
    /**
     * Returns the current iteration of the engine.
     *
     * @return current iteration
     * @since 2.1
     */
    public final int getCurrentIteration()
    {   return runner.getCurrentIteration();
    }   // end getCurrentIteration


    /**
     * Returns the iterations left in the engine.
     *
     * @return iterations to go
     * @since 2.1
     */
    public final int getIterationsToGo()
    {   return runner.getIterationsToGo();
    }   // end getIterationsToGo

    /**
     * Returns the current solution.
     * 
     * @return the current solution.
     * @see TSSolution
     * @since 1.0
     */
    public final TSSolution getCurrentSolution()
    {   return runner.getCurrentSolution();
    }   // end getCurrentSolution

    /**
     * Returns the tabu list that is being used by the engine.
     * 
     * @return the tabu list.
     * @see TSTabuList
     * @since 1.0
     */
    
    public final TSTabuList getTabuList()
    {   return runner.getTabuList();
    }   // end getTabuList

    /**
     * Returns the objective function being used by the engine.
     * 
     * @return the objective function.
     * @see TSFunction
     * @since 1.0
     */
    
    public final TSFunction getObjectiveFunction()
    {   return runner.getObjectiveFunction();
    }   // end getObjectiveFunction

    /**
     * Returns the penalty function being used by the engine.
     * 
     * @return the penalty function.
     * @see TSFunction
     * @since 1.0
     */
    
    public final TSFunction getPenaltyFunction()
    {   return runner.getPenaltyFunction();
    }   // end getPenaltyFunction

    /**
     * Returns the move manager being used by the engine.
     * 
     * @return the move manager.
     * @see TSMoveManager
     * @since 1.0
     */
    
    public final TSMoveManager getMoveManager()
    {   return runner.getMoveManager();
    }   // end getMoveManager

    /**
     * Returns the moves that were used on the last iteration.
     *
     * @return moves used on last iteration
     * @see TSMove
     */
    public final TSMove[] getMovesUsedOnLastIteration()
    {   return runner.getMovesUsedOnLastIteration();
    }   // end getMovesUsedOnLastIteration
    

    
    
/* ********  E V E N T   C O D E  ******** */

    /**
     * This is the "lightweight" event that is used for all listeners.
     * Having one event object that gets passed around is faster than
     * instantiating new event objects at every firing.
     * 
     * @see TSTabuEvent
     * @since 2.0
     */
    private final TSTabuEvent tabuEvent = new TSTabuEvent( this );

    /**
     * An array of <code>TSNewBestSolutionListener</code>s. An array is
     * used instead of an <code>EventListenerList</code> or a
     * <code>Vector</code>. This reduces the tabu search package's
     * dependence on java's objects. Also arrays are much
     * faster to access and iterate through than other objects.
     * 
     * @see TSNewBestSolutionListener
     * @since 2.0
     */
    
    private TSNewBestSolutionListener[] newBestSolutionListenerList =
        new TSNewBestSolutionListener[0];

    /**
     * An array of <code>TSNewCurrentSolutionListener</code>s. An array is
     * used instead of an <code>EventListenerList</code> or a
     * <code>Vector</code>. This reduces the tabu search package's
     * dependence on java's objects. Also arrays are much
     * faster to access and iterate through than other objects.
     * 
     * @see TSNewCurrentSolutionListener
     * @since 2.0
     */
    
    private TSNewCurrentSolutionListener[] newCurrentSolutionListenerList =
        new TSNewCurrentSolutionListener[0];

    /**
     * An array of <code>TSUnimprovingMoveListener</code>s. An array is
     * used instead of an <code>EventListenerList</code> or a
     * <code>Vector</code>. This reduces the tabu search package's
     * dependence on java's objects. Also arrays are much
     * faster to access and iterate through than other objects.
     * 
     * @see TSUnimprovingMoveListener
     * @since 2.0
     */
    private TSUnimprovingMoveListener[] unimprovingMoveListenerList =
        new TSUnimprovingMoveListener[0];

    /**
     * An array of <code>TSEngineFinishedListener</code>s. An array is
     * used instead of an <code>EventListenerList</code> or a
     * <code>Vector</code>. This reduces the tabu search package's
     * dependence on java's objects. Also arrays are much
     * faster to access and iterate through than other objects.
     * 
     * @see TSEngineFinishedListener
     * @since 2.1
     */
    private TSEngineFinishedListener[] engineFinishedListenerList =
        new TSEngineFinishedListener[0];
        
    /**
     * An array of <code>TSEngineStartedListener</code>s. An array is
     * used instead of an <code>EventListenerList</code> or a
     * <code>Vector</code>. This reduces the tabu search package's
     * dependence on java's standard objects. Also arrays are much
     * faster to access and iterate through than other objects.
     * 
     * @see TSEngineStartedListener
     * @since 2.1
     */
    private TSEngineStartedListener[] engineStartedListenerList =
        new TSEngineStartedListener[0];
  
    // A D D   C O D E
    /**
     * Registers <code>listener</code> to receive tabu events when
     * a new best solution is found.
     * 
     * @param listener The <code>TSNewBestSolutionListener</code> to register.
     * @see TSNewBestSolutionListener
     * @since 1.1
     */
     public final synchronized void 
     addNewBestSolutionListener( TSNewBestSolutionListener listener )
     {  
        TSNewBestSolutionListener[] list = new TSNewBestSolutionListener[
            newBestSolutionListenerList.length + 1 ];
        System.arraycopy( newBestSolutionListenerList, 0,
            list, 0, newBestSolutionListenerList.length );
        //for( int i = 0; i < list.length - 1; i++ )
        //    list[i] = newBestSolutionListenerList[i];
            
        list[ list.length-1 ] = listener;
        newBestSolutionListenerList = list;
     }  // end addNewBestSolutionListener

     /**
      * Registers <code>listener</code> to receive tabu events when a
      * new current solution is found. 
      * 
      * @param listener <code>TSNewCurrentSolutionListener</code> to register.
      * @see TSNewCurrentSolutionListener
      * @since 1.1
      */
    
     public final synchronized void 
     addNewCurrentSolutionListener( TSNewCurrentSolutionListener listener )
     {  
        TSNewCurrentSolutionListener[] list = new TSNewCurrentSolutionListener[
            newCurrentSolutionListenerList.length + 1 ];
        System.arraycopy( newCurrentSolutionListenerList, 0,
            list, 0, newCurrentSolutionListenerList.length );
        //for( int i = 0; i < list.length - 1; i++ )
        //    list[i] = newCurrentSolutionListenerList[i];
        
        list[ list.length-1 ] = listener;
        newCurrentSolutionListenerList = list;
     }  // end addNewCurrentSolutionListener

     /**
      * Registers <code>listener</code> to receive tabu events when an
      * unimproving move is made.
      * 
      * @param listener <code>TSUnimprovingMoveListener</code> to register.
      * @see TSUnimprovingMoveListener
      * @since 2.0
      */
     public final synchronized void 
     addUnimprovingMoveListener( TSUnimprovingMoveListener listener )
     {  
        TSUnimprovingMoveListener[] list = new TSUnimprovingMoveListener[
            unimprovingMoveListenerList.length + 1 ];
        System.arraycopy( unimprovingMoveListenerList, 0,
            list, 0, unimprovingMoveListenerList.length );
        //for( int i = 0; i < list.length - 1; i++ )
        //    list[i] = unimprovingMoveListenerList[i];
        
        list[ list.length-1 ] = listener;
        unimprovingMoveListenerList = list;
     }  // end addUnimprovingMoveListener


    /**
     * Registers <code>listener</code> to receive tabu events when
     * the engine finishes.
     * 
     * @param listener that listens for the engine to finish
     * @see TSEngineFinishedListener
     * @since 2.1
     */
     public final synchronized void 
     addEngineFinishedListener( TSEngineFinishedListener listener )
     {  
        TSEngineFinishedListener[] list = new TSEngineFinishedListener[
            engineFinishedListenerList.length + 1 ];
        System.arraycopy( engineFinishedListenerList, 0,
            list, 0, engineFinishedListenerList.length );
            
        list[ list.length-1 ] = listener;
        engineFinishedListenerList = list;
     }  // end addEngineFinishedListener


    /**
     * Registers <code>listener</code> to receive tabu events when
     * the engine starts.
     * 
     * @param listener that listens for the engine to start
     * @see TSEngineStartedListener
     * @since 2.1
     */
     public final synchronized void 
     addEngineStartedListener( TSEngineStartedListener listener )
     {  
        TSEngineStartedListener[] list = new TSEngineStartedListener[
            engineStartedListenerList.length + 1 ];
        System.arraycopy( engineStartedListenerList, 0,
            list, 0, engineStartedListenerList.length );
            
        list[ list.length-1 ] = listener;
        engineStartedListenerList = list;
     }  // end addEngineStartedListener



     
     
     // R E M O V E  C O D E
     
     /**
      * Removes <code>listener</code> from list of objects to notify
      * when a new best solution is found.
      * 
      * @param listener <code>TSNewBestSolutionListener</code> to remove from notification list.
      * @see TSNewBestSolutionListener
      * @since 1.1
      */
     public final synchronized void 
     removeNewBestSolutionListener( TSNewBestSolutionListener listener )
     {  // Find location of listener to remove
        int index = -1;
        int j = 0;
        while( index < 0 && j < newBestSolutionListenerList.length )
        {   if( newBestSolutionListenerList[j] == listener )
                index = j;
            else j++;
        }   // end while: through list
        
        // If index is less than zero then it wasn't in the list
        if( index >= 0 )
        {   TSNewBestSolutionListener[] list = new TSNewBestSolutionListener[
                newBestSolutionListenerList.length - 1 ];
            for( int i = 0; i < list.length; i++ )
                list[i] = newBestSolutionListenerList[ i < index ? i : i + 1 ];
            newBestSolutionListenerList = list;
        }   // end if: listener was in the list
     }  // end removeNewBestSolutionListener

     /**
      * Removes <code>listener</code> from list of objects to notify when
      * a new current solution is found.
      * 
      * @param listener <code>TSNewCurrentSolutionListener</code> to remove from notification list.
      * @see TSNewCurrentSolutionListener
      * @since 1.1
      */
     
     public final synchronized void 
     removeNewCurrentSolutionListener( TSNewCurrentSolutionListener listener )
     {  // Find location of listener to remove
        int index = -1;
        int j = 0;
        while( index < 0 && j < newCurrentSolutionListenerList.length )
        {   if( newCurrentSolutionListenerList[j] == listener )
                index = j;
            else j++;
        }   // end while: through list
        
        // If index is less than zero then it wasn't in the list
        if( index >= 0 )
        {   TSNewCurrentSolutionListener[] list = new TSNewCurrentSolutionListener[
                newCurrentSolutionListenerList.length - 1 ];
            for( int i = 0; i < list.length; i++ )
                list[i] = newCurrentSolutionListenerList[ i < index ? i : i + 1 ];
            newCurrentSolutionListenerList = list;
        }   // end if: listener was in the list
     }  // end removeNewCurrentSolutionListener

     /**
      * Removes <code>listener</code> from list of objects to notify
      * when an unimproving move is made.
      * 
      * @param listener <code>TSUnimprovingMoveListener</code> to remove from notification list.
      * @see TSUnimprovingMoveListener
      * @since 2.0
      */
     public final synchronized void 
     removeUnimprovingMoveListener( TSUnimprovingMoveListener listener )
     {  // Find location of listener to remove
        int index = -1;
        int j = 0;
        while( index < 0 && j < unimprovingMoveListenerList.length )
        {   if( unimprovingMoveListenerList[j] == listener )
                index = j;
            else j++;
        }   // end while: through list
        
        // If index is less than zero then it wasn't in the list
        if( index >= 0 )
        {   TSUnimprovingMoveListener[] list = new TSUnimprovingMoveListener[
                unimprovingMoveListenerList.length - 1 ];
            for( int i = 0; i < list.length; i++ )
                list[i] = unimprovingMoveListenerList[ i < index ? i : i + 1 ];
            unimprovingMoveListenerList = list;
        }   // end if: listener was in the list
     }  // end removeUnimprovingMoveListener


     /**
      * Removes <code>listener</code> from list of objects to notify
      * when the engine finished its appointed iterations.
      * 
      * @param listener <code>TSEngineFinishedListener</code> to 
      * remove from notification list.
      * @see TSEngineFinishedListener
      * @since 2.0
      */
     public final synchronized void 
     removeEngineFinishedListener( TSEngineFinishedListener listener )
     {  // Find location of listener to remove
        int index = -1;
        int j = 0;
        while( index < 0 && j < engineFinishedListenerList.length )
        {   if( engineFinishedListenerList[j] == listener )
                index = j;
            else j++;
        }   // end while: through list
        
        // If index is less than zero then it wasn't in the list
        if( index >= 0 )
        {   TSEngineFinishedListener[] list = 
                new TSEngineFinishedListener[
                engineFinishedListenerList.length - 1 ];
            for( int i = 0; i < list.length; i++ )
                list[i] = engineFinishedListenerList[ i < index ? i : i + 1 ];
            engineFinishedListenerList = list;
        }   // end if: listener was in the list
     }  // end removeEngineFinishedListener


     /**
      * Removes <code>listener</code> from list of objects to notify
      * when the engine starts its appointed iterations.
      * 
      * @param listener <code>TSEngineStartedListener</code> to 
      * remove from notification list.
      * @see TSEngineStartedListener
      * @since 2.0
      */
     public final synchronized void 
     removeEngineStartedListener( TSEngineStartedListener listener )
     {  // Find location of listener to remove
        int index = -1;
        int j = 0;
        while( index < 0 && j < engineStartedListenerList.length )
        {   if( engineStartedListenerList[j] == listener )
                index = j;
            else j++;
        }   // end while: through list
        
        // If index is less than zero then it wasn't in the list
        if( index >= 0 )
        {   TSEngineStartedListener[] list = 
                new TSEngineStartedListener[
                engineStartedListenerList.length - 1 ];
            for( int i = 0; i < list.length; i++ )
                list[i] = engineStartedListenerList[ i < index ? i : i + 1 ];
            engineStartedListenerList = list;
        }   // end if: listener was in the list
     }  // end removeEngineStartedListener




    // F I R E   C O D E
    
    
    /**
     * This quick method is called when a new best solution is found.
     * The <code>TSTabuEvent</code> sent to the listeners is a 
     * "lightweight" event, specifying only the source object,
     * <code>this</code>.
     *
     * @see TSTabuEvent
     */
    protected final void fireNewBestSolution()
    {   synchronized( this )
        {   for( int i = 0; i < newBestSolutionListenerList.length; i++ )
                newBestSolutionListenerList[i].newBestSolutionFound( tabuEvent );
        }   // end synchronized
    }   // end fireNewBestSolution
    
    /**
     * This quick method is called when a new current solution is found.
     * The <code>TSTabuEvent</code> sent to the listeners is a 
     * "lightweight" event, specifying only the source object,
     * <code>this</code>.
     *
     * @see TSTabuEvent
     */
    protected final void fireNewCurrentSolution()
    {   synchronized( this )
        {   for( int i = 0; i < newCurrentSolutionListenerList.length; i++ )
                newCurrentSolutionListenerList[i].newCurrentSolutionFound( tabuEvent );
        }   // end synchronized
    }   // end fireNewCurrentSolution
    
    /**
     * This quick method is called when an unimproving move is made.
     * The <code>TSTabuEvent</code> sent to the listeners is a 
     * "lightweight" event, specifying only the source object,
     * <code>this</code>.
     *
     * @see TSTabuEvent
     */
    protected final void fireUnimprovingMoveMade()
    {   synchronized( this )
        {   for( int i = 0; i < unimprovingMoveListenerList.length; i++ )
                unimprovingMoveListenerList[i].unimprovingMoveMade( tabuEvent );
        }   // end synchronized
    }   // end fireUnimprovingMoveMade


    /**
     * This quick method is called when the engine finishes.
     * The <code>TSTabuEvent</code> sent to the listeners is a 
     * "lightweight" event, specifying only the source object,
     * <code>this</code>.
     *
     * @see TSTabuEvent
     */
    protected final void fireEngineFinished()
    {   synchronized( this )
        {   for( int i = 0; i < engineFinishedListenerList.length; i++ )
                engineFinishedListenerList[i].engineFinished( tabuEvent );
        }   // end synchronized
    }   // end fireEngineFinished


    /**
     * This quick method is called when the engine starts.
     * The <code>TSTabuEvent</code> sent to the listeners is a 
     * "lightweight" event, specifying only the source object,
     * <code>this</code>.
     *
     * @see TSTabuEvent
     */
    protected final void fireEngineStarted()
    {   synchronized( this )
        {   for( int i = 0; i < engineStartedListenerList.length; i++ )
                engineStartedListenerList[i].engineStarted( tabuEvent );
        }   // end synchronized
    }   // end fireEngineStarted



    
    
/* ********  M I S C E L L A N E O U S   M E T H O D S  ******** */
    
    /**
     * This method is used as a simple way to output
     * <code>Exception</code>s to <code>System.out</code>.
     * 
     * @param e The <code>Exception</code> to display.
     */
    private void error( Exception e )
    {   if( TSEngine.DEBUGGING )
            System.out.println( e );
    }   // end error
    
    
    
}   // end class TSEngine