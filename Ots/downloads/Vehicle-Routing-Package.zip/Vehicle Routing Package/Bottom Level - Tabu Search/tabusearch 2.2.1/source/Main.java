package net.usa.rharder.tabusearch22;

/**
 * This class runs if someone mistakenly double-clicks on the tabusearch22.jar file
 * or runs <tt>java -jar tabusearch22.jar</tt>.
 *
 * @author Robert Harder, rharder@usa.net
 * @since 2.2
 */
public class Main
{   
    private final static String[] credits =
        { "Java Tabu Search",
          "Version 2.2.1",
          "Robert Harder",
          "rharder@usa.net",
          "",
          "Use this jar file to help",
          "you build a structured and",
          "efficient Java tabu search"
        };
          
    
    public static void main( String[] args )
    {   
        System.out.println("");
        for( int i = 0; i < credits.length; i++ )
            System.out.println( credits[i] );
        System.out.println("");
        
        try
        {   java.awt.Frame f = new java.awt.Frame( credits[0] );
            f.setLayout( new java.awt.GridLayout(credits.length,1) );
            for( int i = 0; i < credits.length; i++ )
                f.add( new java.awt.Label( credits[i], java.awt.Label.CENTER ) );
            f.pack();
            java.awt.Toolkit t = f.getToolkit();
            f.setLocation( (t.getScreenSize().width-f.getSize().width)/2, (t.getScreenSize().height-f.getSize().height)/2 );
            f.addWindowListener( new java.awt.event.WindowAdapter()
            {   public void windowClosing( java.awt.event.WindowEvent e )
                {   System.exit(0);
                }   // end windowClosed
            }); // end WindowAdapter
            f.show();
        }   // end try
        catch( Exception e ){}
    }   // end main
}   // end class Main