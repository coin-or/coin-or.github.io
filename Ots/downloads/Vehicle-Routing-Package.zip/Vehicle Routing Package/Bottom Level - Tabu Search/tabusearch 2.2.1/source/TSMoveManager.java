package net.usa.rharder.tabusearch22;

/**
 * The <code>TSMoveManager</code> determines which moves are available
 * at any given time (or given solution). As a performance boost, you
 * may want to consider reusing <code>TSMove</code>s after each
 * iteration to avoid expensive instantiation.
 * 
 * @author Robert Harder
 * @see TSMove
 * @see TSSolution
 * @version 1.0
 * @since 1.0
 */

public interface TSMoveManager
{
    /**
     * This method should return an array of all possible
     * moves to try at an iteration based on the passed
     * current solution. Note that the moves generated should
     * not depend on this exact solution object being the
     * one to be operated on. It is always a copy of the current
     * solution that is operated on.
     * 
     * @param solution The current solution.
     * @return All possible moves from given solution.
     * @see TSSolution
     * @see TSMove
     * @since 1.0
     */
            
    public abstract TSMove[] getAllMoves( TSSolution solution );



}   // end class TSMoveManager
    
    