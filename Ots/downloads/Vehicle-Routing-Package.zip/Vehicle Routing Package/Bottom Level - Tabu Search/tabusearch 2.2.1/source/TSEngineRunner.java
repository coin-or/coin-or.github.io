package net.usa.rharder.tabusearch22;

/**
 * The runner does all the real work. It does the iterations and
 * tracks solutions.
 * 
 * @author Robert Harder
 * @version 2.1
 * @since 2.1
 */


class TSEngineRunner implements Runnable
{
    // Tabu objects
    private TSSolution currentSolution;
    private TSSolution bestSolution;
    private TSTabuList tabuList;
    private TSFunction objectiveFunction;
    private TSFunction penaltyFunction;
    private TSMoveManager moveManager;
    
    
    // Search threads
    TSNeighborhoodSearchAgent[] searchAgents;
    TSMove[] movesUsedOnLastIteration;
    
    // Some engine settings
    private TSEngine engine;
    private int numberOfThreads;
    private boolean maximizing;
    
    // Work that is on order
    private int iterationsToGo = 0;
    
    // Some state variables
    private long timeAtLastStart = System.currentTimeMillis();
    private long lastSolveMillis = 0;
    private int currentIteration = 0;
    private boolean betweenIterations = true;
    private int iterationOfBestSolution = 0;

    /**
     * The only constructor. Accepts all necessary objects.
     * 
     * @param initialTSSolution The initial solution.
     * @param tabuList The tabu list.
     * @param objectiveFunction The objective function.
     * @param penaltyFunction The penalty function.
     * @param moveManager The move manager.
     * @param maximizing <code>true</code> if maximizing, <code>false</code> if minimizing.
     * @param numberOfThreads Number of threads to use. Useful for multiple-processor computers.
     * @param engine The parent <code>TSEngine</code>.
     */
    public TSEngineRunner( TSSolution initialTSSolution, TSTabuList tabuList,
    TSFunction objectiveFunction, TSFunction penaltyFunction,
    TSMoveManager moveManager, boolean maximizing, int numberOfThreads,
    TSEngine engine)
    {
        // Set up tabu objects
        this.tabuList = tabuList;
        this.objectiveFunction = objectiveFunction;
        this.penaltyFunction = penaltyFunction;
        this.moveManager = moveManager;
        
        // Evaluate initial solution
//        synchronized( initialTSSolution )
//        {   synchronized( objectiveFunction )
//            {   synchronized( penaltyFunction )
//                {
                    this.currentSolution = (TSSolution) initialTSSolution.clone();
                    this.currentSolution.setObjectiveValue( 
                        this.objectiveFunction.evaluate( this.currentSolution ) );
                    this.currentSolution.setPenaltyValue( 
                        this.penaltyFunction.evaluate( this.currentSolution ) );
                    this.bestSolution = getCopyOfCurrentSolution();
//                }   // end synchronized: penaltyFunction
//            }   // end synchronized: objectiveFunction
//        }   // end synchronized: initialTSSolution
        
        // Setttings
        this.engine = engine;
        this.maximizing = maximizing;
        this.numberOfThreads = numberOfThreads;
        
        // Set up neighborhood search agents
        searchAgents = new TSNeighborhoodSearchAgent[ this.numberOfThreads ];
        
        for( int i = 0; i < searchAgents.length; i++ )
        {
            searchAgents[i] = new TSNeighborhoodSearchAgent( tabuList,
                objectiveFunction, penaltyFunction, this );
            Thread t = new Thread( searchAgents[i] );
            t.setDaemon( true );
            t.start();
        }   // end for: set up search agents
        
        
    }   // end parentTSEngine

    
/* ********  R U N   C O D E  ******** */
    
    public void run()
    {
        // Runs indefinitely, being destroyed only when the engine object
        // owning it is destroyed.
        while( true )
        {
            // Go all over again
            
            // Handle notification of being between iterations.
            synchronized( this )
            {
                // Set state to being in between iterations.
                setBetweenIterations( true );
                
                // Notify interested events but instead of waiting
                // just exit synchronized block to release control. A
                // wait() statement would wait forever if there were no
                // interested threads.
                this.notifyAll();
            }   // end synchronized
            
            
            
            // Waiting for work
            // Synchronized for safety
            synchronized( this )
            {   
                // If there is no work scheduled, wait until notified
                // and then make sure that the notification was regarding
                // more work
                if( iterationsToGo <= 0 )
                {   solverStoppedOrStopping();  // Stopping statistics
                }   // end if: stopping
                
                while( iterationsToGo <= 0 )
                {   try
                    {   this.notifyAll();           // Wake up interested threads
                        this.wait();                // Wait for notification
                        if( iterationsToGo > 0 )
                            solverMayBeStarting();  // Starting statistics
                    }   // end try
                    catch( InterruptedException e )
                    {   error( e );
                    }   // end catch
                }   // end while
                
                // Work has been ordered. 
                // Set state to being in the middle of an iteration
                setBetweenIterations( false );
                
                // Increase the currentIteration counter while still synchronized.
                currentIteration++;
                
            }   // end synchronized
            
            // Work has been ordered. Perform one tabu iteration
            // after locking down the current solution and associated
            // tabu objects.
            synchronized( currentSolution )
            {   synchronized( objectiveFunction )
                {   synchronized( penaltyFunction )
                    {   synchronized( tabuList )
                        {   synchronized( moveManager )
                            {
                                try
                                {   performOneTabuIteration();
                                }   // end try
                                catch( NoMovesGeneratedException e )
                                {   System.err.println( e );
                                }   // end catch
                            }   // end synchronized: moveManager
                        }   // end synchronized: tabuList
                    }   // end synchronized: penaltyFunction
                }   // end synchronized: objectiveFunction
            }   // end synchronized: currentSolution
            
            // Fire a new current solution event
            //fireNewCurrentSolution();
            
            // Decrease iterations to go counter
            iterationsToGo--;
            
        }   // end while: infinite loop
        
    }   // end run
    
/* ********  T I M E R   M E T H O D S  ******** */
    
    private final void solverStoppedOrStopping()
    {   
        // This does not need to be synchronized because it is only called
        // from a synchronized block. This ensures atomicity which in turn
        // ensures that the 'long' operations below are not interrupted.

        lastSolveMillis = System.currentTimeMillis() - timeAtLastStart;
        fireEngineFinished();
    }   // end solverMayBeStopping
    
    private final void solverMayBeStarting()
    {   
        // This does not need to be synchronized because it is only called
        // from a synchronized block. This ensures atomicity which in turn
        // ensures that the 'long' operations below are not interrupted.
        
        timeAtLastStart = System.currentTimeMillis();
        
        // Report the starting.
        fireEngineStarted();
    }   // end solverMayBeStarting
    
    
    
/* ********  C O N T R O L L E R   M E T H O D S  ******** */
    
    public final void startSolving( int additionalIterations )
    {
        synchronized( this )
        {   iterationsToGo = Math.max(0, iterationsToGo) + additionalIterations;
            this.notifyAll();
        }   // end synchronized
    }   // end startSolving
    
    
    public final void stopSolving()
    {
        // Clear work list. This does not need to be synchronized since
        // int assignments are atomic.
        iterationsToGo = 0;
        
        // Don't return until current iteration is finished
        synchronized( this )
        {   while( ! isBetweenIterations() )
            {   try
                {   this.notifyAll();
                    this.wait();
                }   // end try
                catch( InterruptedException e )
                {   error( e );
                }   // end catch
            }   // end while
        }   // end synchronized
    }   // end stopSolving
    
    
/* ******** I T E R A T I O N   M E T H O D S  ******** */
    
    
    private final void performOneTabuIteration() throws NoMovesGeneratedException
    {
        // If the user wishes to modify the moveManager dynamically, he/she
        // should synchronize the necessary components in the move manager.
        TSMove[] neighborhoodMoves = moveManager.getAllMoves( currentSolution );
        
        // If no moves were returned, throw an exception
        if( 
         neighborhoodMoves == null  // null was returned
         ||
         neighborhoodMoves.length == 0 ) // not null, but of length zero
            throw new NoMovesGeneratedException( currentIteration );
        
        // Start agents on this iteration
        startAgentsOnAnotherIteration( neighborhoodMoves );
        
        // Wait for agents to finish
        waitForAgentsToFinish();

        // Combine agents' neighborhoods into one array
        TSNeighbor[] neighbors = new TSNeighbor[ neighborhoodMoves.length ];
        combineAgentsTSNeighborhoods( neighbors );

        // Determine which neighbors and their moves are to
        // be used for this iteration.
        TSNeighbor[] neighborsToUse;
        neighborsToUse = getTSNeighborsToUse( neighbors );
        
        // Update the current solution with these neighbors
        updateCurrentSolution( neighborsToUse );
        
        // Update best solution, if necessary
        updateBestSolution();
        
    }   // end performOneTabuIteration
    
    
    
    
    private final void startAgentsOnAnotherIteration( TSMove[] neighborhoodMoves )
    {
        // Split up the moves among the search agents
        int movesEach = neighborhoodMoves.length / searchAgents.length;
        
        // Integer division: there may be moves left in remainder
        int remainingMoves = 
            neighborhoodMoves.length - (movesEach * searchAgents.length);
        
        // Hand out moves and start agents
        int firstMoveIndexForAgent = 0;
        for( int i = 0; i < searchAgents.length; i++ )
        {
            // How much does this agent get?
            int numOfMoves = movesEach + ( remainingMoves-- > 0 ? 1 : 0 );
            
            // Set up an array for this agent's moves
            TSMove[] thisAgentsMoves = new TSMove[ numOfMoves ];
            for( int j = 0; j < thisAgentsMoves.length; j++ )
                thisAgentsMoves[j] = neighborhoodMoves[ firstMoveIndexForAgent + j ];
            
            // Reset firstMoveIndexForAgent for the next agent
            firstMoveIndexForAgent += thisAgentsMoves.length;
            
            // Agent should be ready, but if not, wait for it to be ready
            synchronized( searchAgents[i] )
            {   while( searchAgents[i].workIsWaiting() )
                {   try
                    {   searchAgents[i].wait();
                    }   // end try
                    catch( InterruptedException e )
                    {   error( e );
                    }   // end catch
                }   // end while
                
                // Before releasing synchronized lock, set parameters
                searchAgents[i].setMoves( thisAgentsMoves );
                searchAgents[i].setSolution( this.getCopyOfCurrentSolution() );
                searchAgents[i].setBestSolutionValueToCopyOf(
                    bestSolution.getValue() );
                
                // Notify agent that it has work to do
                searchAgents[i].setWorkWaiting( true );
                searchAgents[i].notifyAll();
            }   // end synchronized
        }   // end for: through each search agent
    }   // end startAgentsOnAnotherIteration
    
    
    private final void waitForAgentsToFinish()
    {
        // All agents have been set to work. Wait for them
        // to finish their work. Even though they may not finish
        // in the same order they started, this construct will work
        // fine since we need them all to be finished before doing
        // anything else.
        for( int i = 0; i < searchAgents.length; i++ )
        {   synchronized( searchAgents[i])
            {   while( searchAgents[i].workIsWaiting() )
                {   try
                    {   searchAgents[i].wait();
                    }   // end try
                    catch( InterruptedException e )
                    {   error( e );
                    }   // end catch
                }   // end while
            }   // end synchronized
        }   // end for: waiting for agents to finish
    }   // end waitForAgentsToFinish
    
    
    private final void combineAgentsTSNeighborhoods( TSNeighbor[] neighbors )
    {
        // All agents have finished. Combine their neighborhood results
        // into one array. We can ignore synchronization since by design
        // the agents will already be idle.
        int index = 0;
        
        for( int i = 0; i < searchAgents.length; i++ )
        {   
            // Get agents neighbors
            TSNeighbor[] agentsNeighbors = searchAgents[i].getNeighbors();

            // Add neighbors to master neighbor list
            System.arraycopy(
                agentsNeighbors,                // Source
                0,                              // Start
                neighbors,                      // Destination
                index,                          // Start
                agentsNeighbors.length );       // Length
            
            // update the index
            index += agentsNeighbors.length;
            
            //for( int j = 0; j < agentsNeighbors.length; j++, index++ )
            //{   neighbors[index] = agentsNeighbors[j];
            //}   // end for
        }   // end for: through each agent

    }   // end combineAgentsNeighborhoods
    
    
    
    
    private final TSNeighbor[] getTSNeighborsToUse( 
    TSNeighbor[] neighbors )
    {
        // Quick access variables
        final int neighborsLength = neighbors.length;

        // Find best move
        int bestIndex = -1;
        
        // Find first tabu valid move
        for( int i = 0; i < neighborsLength; i++ )
            if( neighbors[i].isTabuValid() )
            {
                bestIndex = i;
                break;
            }   // end if
        
        // If the best index was not set, then no moves were
        // valid by the tabu's criteria. Instead, choose zero
        // arbitrarily and skip the next section of code entirely.
        int num = 0;
        int[] indeces = new int[ neighborsLength ];
        if( bestIndex < 0 )
        {
            bestIndex = 0;
        }   // end if
        else
        {
            // bestIndex should now contain the first move
            // that is ok'd on the tabu list. It should not disappear
            // in this next section, unless the previous block defaulted
            // to the original zero value.

            
            for( int i = 0; i < neighborsLength; i++ )
            {
                if( neighbors[i] != null )
                {
                    if( neighbors[i].isTabuValid() )
                    {   
                        //if( isImproving( neighbors[i].getContribution() ) )
                        {
                            int j = i + 1;
                            while( (neighbors[i] != null) && j < neighborsLength )
                            {
                                if( neighbors[j] != null )
                                {
                                    if( neighbors[j].isTabuValid() )
                                    {   
                                        //if( isImproving( neighbors[j].getContribution() ) )
                                        {
                                            if( neighbors[i].getMove().conflictsWith(
                                            neighbors[j].getMove() ) )
                                            {
                                                if( firstIsBetterThanSecond(
                                                neighbors[j].getContribution(),
                                                neighbors[i].getContribution() ) )
                                                {
                                                    neighbors[i] = null;
                                                }   // end if: j is better than i
                                                else
                                                    neighbors[j] = null;
                                            }   // end if: conflict
                                            
                                        }   // end if: n[j] improving
                                    }   // end if: tabu valid
                                }   // end if: n[j] not null
                                
                                // Increment j
                                j++;
                                
                            }   // end while: through other neighbors
                            
                            // If i made it this far it must be improving and independent
                            if( neighbors[i] != null )
                            {    indeces[ num++ ] = i;
                            }
                        }   // end if: n[i] improving
                        
                    }   // end if: was tabuValid
                    
                }   // end if: n[i] not null
                
            }   // end for: through all neighbors

        }   // end else: at least one move was valid


        // If a solitary unimproving move was chosen, add it to list
        if( num == 0 )
            indeces[ num++ ] = bestIndex;
        
        // Make neighbor array and return
        TSNeighbor[] neighborsToUse = new TSNeighbor[ num ];
        for( int i = 0; i < num; i++ )
            neighborsToUse[i] = neighbors[ indeces[i] ];
        
        return neighborsToUse;

    }   // end getTSNeighborsToUse
    
    
    
    
    
    // No synchronization needed since this is only called from
    // within a block already synchronized on the current solution.
    private final void updateCurrentSolution( TSNeighbor[] neighborsToUse )
    {
        
        // These are used in the for loop but are declared here
        // for speed.
        int i, j;
        double[] objContrib;
        double[] penContrib;
        
        // Get existing values of objective and penalty values
        double[] objVal = currentSolution.getObjectiveValue();
        double[] penVal = currentSolution.getPenaltyValue();
        double[] oldVal = currentSolution.getValue();
        
        // Frequently used
        final int neighborLength = neighborsToUse.length;

        // Make array of moves to register with tabu list
        TSMove[] moves = new TSMove[ neighborLength ];
        for( i = 0; i < neighborLength; i++ )
        {
            moves[i] = neighborsToUse[i].getMove();
        }   // end for
        
        // Set moves used this iterations
        movesUsedOnLastIteration = moves;
        
        // This loop is used for the following tasks:
        //   Determine new objective value
        //   Determine new penalty value
        //   Operate on solution
        for( i = 0; i < neighborLength; i++ )
        {
            objContrib = neighborsToUse[i].getContributionToObjectiveFunction();
            penContrib = neighborsToUse[i].getContributionToPenaltyFunction();
            final int valLength = objContrib.length;
            for( j = 0; j < valLength; j++ )
            {
                objVal[j] += objContrib[j];
                penVal[j] += penContrib[j];
            }   // end for
            neighborsToUse[i].getMove().operateOn( currentSolution );
        }   // end for: through each neighbor
        
        // Set new current solution values
        currentSolution.setObjectiveValue( objVal );
        currentSolution.setPenaltyValue( penVal );

        // Register moves with the newly updated solution
        tabuList.registerMoves( moves, currentSolution );

        
        if( firstIsBetterThanSecond( oldVal, currentSolution.getValue() ) )
            fireUnimprovingMoveMade();
        
        fireNewCurrentSolution();
    }   // end updateCurrentSolution
    
    
    
    
    
    
    private final void updateBestSolution()
    {
        synchronized( bestSolution )
        {
            if( firstIsBetterThanSecond( 
            currentSolution.getValue(), getBestSolutionValue() ) )
            {   // New solution is better than the previous bet
                TSSolution newBest = getCopyOfCurrentSolution();
                bestSolution = newBest;
                iterationOfBestSolution = currentIteration;
                fireNewBestSolution();
            }   // end if: new solution was better
        }   // end sync: bestSolution
    }   // end udpateBestSolution
    
    
    
/* ********  G E T   M E T H O D S  ******** */
    
    public final TSMove[] getMovesUsedOnLastIteration()
    {   return movesUsedOnLastIteration;
    }   // end getMovesUsedOnLastIteration
    
    public final TSSolution getCurrentSolution()
    {   return currentSolution;
    }   // end getCurrentSolution
    
    public final TSSolution getBestSolution()
    {   return bestSolution;
    }   // end getBestSolution
    
    private final double[] getBestSolutionValue()
    {   return bestSolution.getValue();
    }   // end getBestSolutionValue
    
    
    public final TSTabuList getTabuList()
    {   return tabuList;
    }   // end getTSTabuList
    
    public final TSFunction getObjectiveFunction()
    {   return objectiveFunction;
    }   // end getObjectiveFunction
    
    public final TSFunction getPenaltyFunction()
    {   return penaltyFunction;
    }   // end getPenaltyFunction
    
    public final TSMoveManager getMoveManager()
    {   return moveManager;
    }   // end getTSMoveManager
    
    
    // No synchronization needed since it's only called from within
    // a block synchronized on the current solution
    private final TSSolution getCopyOfCurrentSolution()
    {   TSSolution soln = (TSSolution) currentSolution.clone();
    
        // Since arrays are pass-by-reference, we have to explicitly copy
        // the arrays with the objective and penalty function values.
        
        // Original arrays
        double[] currentObjectiveValue = currentSolution.getObjectiveValue();
        double[] currentPenaltyValue = currentSolution.getPenaltyValue();
        
        // New arrays
        double[] newObjectiveValue = new double[ currentObjectiveValue.length ];
        double[] newPenaltyValue = new double[ currentPenaltyValue.length ];
        
        // Copy original arrays into new arrays
        System.arraycopy( currentObjectiveValue, 0, newObjectiveValue, 0, newObjectiveValue.length );
        System.arraycopy( currentPenaltyValue, 0, newPenaltyValue, 0, newPenaltyValue.length );
        
        // Save the new arrays in the newly copied solution
        soln.setObjectiveValue( newObjectiveValue );
        soln.setPenaltyValue( newPenaltyValue );
        
        // Return copied solution
        return soln;
    }   // end getCopyOfCurrentSolution
        
    
    public final synchronized long getLastSolveMillis()
    {   return lastSolveMillis;
    }   // end getLastSolveMillis
    
    public final int getIterationsToGo()
    {   return iterationsToGo;
    }   // end getIterationsToGo
    
    public final int getCurrentIteration()
    {   return currentIteration;
    }   // end getCurrentIteration
    
    public final int getIterationOfBestSolution()
    {   return iterationOfBestSolution;
    }   // end getIterationOfBestSolution
    
    
/* ********  S E T   M E T H O D S  ******** */
    
    private final void setBetweenIterations( boolean state )
    {   betweenIterations = state;
    }   // end setBetweenIterations
    
    
    protected final void setCurrentSolutionToCopyOf( TSSolution solution )
    {   // A copy is made to preserve the thread-safe nature
        // of the TSEngineRunner.
        TSSolution copy = (TSSolution) solution.clone();
        setCurrentSolution( copy );
    }   // end setCurrentSolutionToCopyOf
    
    protected final void setCurrentSolution( TSSolution solution )
    {   
        // Evaluate the new solution
        synchronized( currentSolution )
        {   synchronized( solution )
            {   
//                synchronized( objectiveFunction )
//                {   synchronized( penaltyFunction )
//                    {
                        this.currentSolution = solution;
                        this.currentSolution.setObjectiveValue( 
                            this.objectiveFunction.evaluate( this.currentSolution ) );
                        this.currentSolution.setPenaltyValue( 
                            this.penaltyFunction.evaluate( this.currentSolution ) );
//                    }   // end synchronized: penaltyFunction
//                }   // end synchronized: objectiveFunction
            }   // end synchronized: solution
        }   //end synchronized: currentSolution
    }   // end setCurrentSolution
    
    private final void setBestSolution( TSSolution solution )
    {   
        // Evaluate the new solution
        synchronized( bestSolution )
        {   synchronized( solution )
            {   
                this.bestSolution = solution;
                this.bestSolution.setObjectiveValue( 
                    this.objectiveFunction.evaluate( this.bestSolution ) );
                this.bestSolution.setPenaltyValue( 
                    this.penaltyFunction.evaluate( this.bestSolution ) );
            }   // end synchronized: solution
        }   //end synchronized: bestSolution
    }   // end setBestSolution
    
    protected final void setBestSolutionToCopyOf( TSSolution solution )
    {   // A copy is made to preserve the thread-safe nature
        // of the TSEngineRunner.
        TSSolution copy = (TSSolution) solution.clone();
        setBestSolution( copy );
    }   // end setBestSolutionToCopyOf
    
    protected final void trySettingBestSolutionToCopyOf( TSSolution solution )
    {
        // Make sure that the new solution is better than the best known
        synchronized( bestSolution )
        {
            if( firstIsBetterThanSecond( 
                solution.getValue(), bestSolution.getValue() ) )
            {   
                setBestSolutionToCopyOf( solution );
            }   // end if: new solution is better.
        }   // end sync: bestSolution
    }   // end trySettingBestSolutionToCopyOf

    
/* ********  Q U E R Y   M E T H O D S  ******** */
    
    private final boolean isBetweenIterations()
    {   return betweenIterations;
    }   // end isBetweenIterations

    /**
     * This single method is called many times to compare solutions.
     * Although all data is stored as doubles, they are cast to floats
     * before they are compared. This ensures that the inevitable
     * errors associated with all floating point numbers do not affect
     * the likely intent of the numbers.
     */
    protected final boolean firstIsBetterThanSecond( 
    double[] first, double[] second )
    {
        int i=0;
        int valLength = first.length;
        boolean result = false;
        
        for( i = 0; i < valLength; i++ )
        {
            if( (float)first[i] > (float)second[i] )
            {
                result = maximizing ? true : false;
                break;
            }   // end if
            else if( (float)first[i] < (float)second[i] )
            {
                result = maximizing ? false : true;
                break;
            }   // end else
            // else it must have been equal
        }   // end for: through each value
        
        return result;
    }   // end firstIsBetterThanSecond

    
    private final boolean isImproving( double[] value )
    {   
        int i;
        final int valLength = value.length;
        boolean result = false;
        
        for( i = 0; i < valLength; i++ )
        {
            if( (float)value[i] > 0 )
            {
                result = maximizing ? true : false;
                break;
            }   // end if
            else if( (float)value[i] < 0 )
            {
                result = maximizing ? false : true;
                break;
            }   // end else
            // else it must have been equal
        }   // end for: through each value
        
        return result;
    }   // end isImproving
    
    
    
    
    
/* ********  E V E N T   M E T H O D S  ******** */
    
    private final void fireEngineStarted()
    {   engine.fireEngineStarted();
    }   // end fireEngineStarted
    
    private final void fireEngineFinished()
    {   engine.fireEngineFinished();
    }   // end fireEngineFinished
    
    private final void fireNewBestSolution()
    {   engine.fireNewBestSolution();
    }   // end fireNewBestSolution
    
    
    private final void fireNewCurrentSolution()
    {
        engine.fireNewCurrentSolution();
    }   // end fireNewCurrentSolution
    
    
    private final void fireUnimprovingMoveMade()
    {
        engine.fireUnimprovingMoveMade();
    }   // end fireUnimprovingMoveMade
    
    
/* ********  M I S C E L L A N E O U S   M E T H O D S  ******** */
    
    private void error( Exception e )
    {   if( TSEngine.DEBUGGING )
            System.out.println( "Iteration " + getCurrentIteration() + ": " +e );
    }   // end error
    
}   // end class TSEngineRunner