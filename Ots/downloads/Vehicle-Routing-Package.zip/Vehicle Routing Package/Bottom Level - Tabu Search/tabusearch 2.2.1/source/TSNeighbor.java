package net.usa.rharder.tabusearch22;

/**
 * This internal class tracks each neighbor at an iteration.
 * For performance reasons they are reused at each iteration instead
 * of reinstantiating them.
 *
 * @author Robert Harder, rharder@usa.net
 * @see TSMove
 */

class TSNeighbor
{
    /**
     * The move that resulted in this neighbor.
     * @see TSMove
     */
    private TSMove move;
    
    /**
     * The contribution to the objective function portion
     * of the solution. This is not the new objective function
     * value, only the "delta" portion.
     * @see TSFunction
     */
    private double[] contributionToObjectiveFunction;
    
    /**
     * The contribution to the penalty function portion
     * of the solution. This is not the new penalty function
     * value, only the "delta" portion.
     * @see TSFunction
     */
    private double[] contributionToPenaltyFunction;
    
    /**
     * Whether or not the move to get to this neighbor was
     * accepted (<code>true</code>) or denied (<code>false</code>)
     * by the tabu list.
     * @see TSTabuList
     */
    private boolean tabuValid;
    
    /**
     * Creates a new <code>TSNeighbor</code> based on the
     * passed move.
     * @param move The move that got to this neighbor.
     * @see TSMove
     */
    public TSNeighbor( TSMove move )
    {   this.move = move;
    }   // end constructor
    
    /**
     * Returns the move associated with this neighbor.
     * @return move associated with this neighbor.
     * @see TSMove
     */
    public final TSMove getMove()
    {   return move;
    }   // end getMove
    
    /**
     * Sets the move associated with this neighbor.
     * @param move the move associated with this neighbor.
     * @see TSMove
     */
    public final void setMove( TSMove move )
    {   this.move = move;
    }   // end setMove
    
    /**
     * Returns the total contribution. This is the sum of the
     * objective function and penalty function contributions.
     * @return total contribution to solution value
     * @see TSFunction
     */
    public final double[] getContribution()
    {   
        int i;
        final int valLength = contributionToObjectiveFunction.length;
        double[] value = new double[ valLength ];
        
        for( i = 0; i < valLength; i++ )
            value[i] = contributionToObjectiveFunction[i]
                     + contributionToPenaltyFunction[i];
        
        return value;
    }   // end getContribution
    
    /**
     * Returns the contribution to the objective function value.
     * @return contribution to the objective function value.
     * @see TSFunction
     */
    public final double[] getContributionToObjectiveFunction()
    {   return contributionToObjectiveFunction;
    }   // end getContributionToObjectiveFunction
    
    /**
     * Returns the contribution to the penalty function value.
     * @return contribution to the penalty function value.
     * @see TSFunction
     */
    public final double[] getContributionToPenaltyFunction()
    {   return contributionToPenaltyFunction;
    }   // end getContributionToPenaltyFunction
    
    /**
     * Sets the contribution to the objective function value.
     * @param contribution contribution to the objective function value.
     * @see TSFunction
     */
    public final void setContributionToObjectiveFunction( double[] contribution )
    {   contributionToObjectiveFunction = contribution;
    }   // setContributionToObjectiveFunction
    
    
    /**
     * Sets the contribution to the penalty function value.
     * @param contribution contribution to the penalty function value.
     * @see TSFunction
     */
    public final void setContributionToPenaltyFunction( double[] contribution )
    {   contributionToPenaltyFunction = contribution;
    }   // setContributionToPenaltyFunction
    
    /**
     * Sets whether the move was accepted or denied by the tabu list.
     * @param state true if the move was accepted by the tabu list. False otherwise.
     * @see TSTabuList
     */
    public final void setTabuValid( boolean state )
    {   this.tabuValid = state;
    }   // end setTabuValid
    
    /**
     * Returns whether the move was accepted or denied by the tabu list.
     * @return whether the move was accepted (<code>true</code>)
     *         or denied (<code>false</code>) by the tabu list.
     * @see TSTabuList
     */
    public final boolean isTabuValid()
    {   return this.tabuValid;
    }   // end getTabuValid
    
    /**
     * Returns a string representation of the neighbor.
     */
    public String toString()
    {
        String self = "";
        self += "Move: " + getMove() + "  Obj: " + 
            getContributionToObjectiveFunction() + "  Pen: " +
            getContributionToPenaltyFunction() + "  Val: " + 
            getContribution();
        return self;
    }   // end toString
        
}   // end class TSNeighbor
