package net.usa.rharder.tabusearch22;
   

/**
 * The <code>TSTabuList</code> tracks which moves
 * are tabu and for how long.
 * 
 * @author Robert Harder, rharder@usa.net
 * @see TSMove
 * @see TSSolution
 * @version 2.0
 * @since 1.0
 */
    
public interface TSTabuList
{

    /**
     * This method accepts an array of <code>TSMove</code>s as
     * an argument and updates the tabu list as necessary.
     * <P>
     * Although the tabu list may not use both of the passed
     * arguments, both must be included in the definition.
     * 
     * @param moves The moves to register
     * @param solution The solution that these move(s) operated on (past tense).
     * @see TSMove
     * @see TSSolution
     * @since 2.0
     */
    public abstract void registerMoves( TSMove[] moves, TSSolution solution );
        
        
        

    /**
     * This function should be able to determine if
     * a given move is on the tabu list.
     * 
     * @param move A move
     * @param solution The solution resulting from the move's operation.
     * @return whether or not the tabu list permits the move.
     * @see TSMove
     * @see TSSolution
     */
    public abstract boolean allowMove( TSMove move, TSSolution solution );
}   // end TSTabuList

