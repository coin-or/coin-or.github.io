package net.usa.rharder.tabusearch22;


/**
 * This runs in another thread and evaluates the neighborhood.
 * If multiple threads was specified in the <code>TSEngine</code>
 * then multiple <code>TSNeighborhoodSearchAgent</code>s will be
 * created.
 *
 * @author Robert Harder, rharder@usa.net
 * @see TSEngine
 */
class TSNeighborhoodSearchAgent implements Runnable
{
    // These are reset at each iteraion
    private TSSolution currentSolution; // Current solution
    private TSMove[] moves;             // Moves to use on this solution
    private double[] bestSolutionValue; // Previous best known solution value
    
    // Some tabu search items
    private TSFunction objectiveFunction;   // Objective function object
    private TSFunction penaltyFunction;     // Penalty function object
    private TSTabuList tabuList;            // Tabu list object
    
    // Parent runner
    TSEngineRunner parent;              // Parent TSEngineRunner
    
    // neighborhood search
    private TSNeighbor[] neighbors;     // Neighbors being created
    
    // Keep a list of neighbors to avoid
    // excess instantiation
    private TSNeighbor[] supplyOfNeighbors   // Reuse neighbors to
        = new TSNeighbor[10];                // to avoid reinstantiation
    private int availableNeighborsCount = 0; // Number of reusable neighbors
    private int nextAvailableNeighbor = 0;   // Index of next free neighbor
    
    // Some state variables
    private boolean workWaiting = false;     // New moves waiting to go.
    
    /**
     * Creates a search agent based on the given objects.
     */
    protected TSNeighborhoodSearchAgent( TSTabuList tabuList,
    TSFunction objectiveFunction, TSFunction penaltyFunction,
    TSEngineRunner parent )
    {   this.tabuList = tabuList;
        this.objectiveFunction = objectiveFunction;
        this.penaltyFunction = penaltyFunction;
        this.parent = parent;
    }   // end constructor
    
    /**
     * Keeps running until destroyed. It sleeps when it's not working,
     * so there's no drain on the computer's processor.
     */
    public void run()
    {
        // Runs indefinitely, being destroyed only when the runner object
        // owning it is destroyed.
        while( true )
        {
            // If there's no work to do, wait around, but notify interested parties
            synchronized( this )
            {   while( ! workIsWaiting() )
                {   try
                    {   this.notifyAll();
                        this.wait();
                    }   // end try
                    catch( Exception e )
                    {   error( e );
                    }   // end catch
                }   // end while
            }   // end synchronized
            
            // There is work to do. Continue.
            evaluateNeighborhood();
            
            // Set state such that work has been dealt with
            setWorkWaiting( false );
            
        }   // end while: infinite loop
    }   // end run
    
    
/* ********  E V A L U A T I O N   M E T H O D S  ******** */
    
    /**
     * Evaluates waiting moves.
     */
    private final void evaluateNeighborhood()
    {
        int i, j;
        // Get current solution's value
        final double[] currentObjectiveValue =  new double[ currentSolution.getObjectiveValue().length ];
        final double[] currentPenaltyValue = new double[ currentSolution.getPenaltyValue().length ];
        
        System.arraycopy(currentSolution.getObjectiveValue(), 
            0, currentObjectiveValue, 0, currentObjectiveValue.length );
        System.arraycopy(currentSolution.getPenaltyValue(), 
            0, currentPenaltyValue, 0, currentPenaltyValue.length );
        
        // One neighbor for each move
        neighbors = new TSNeighbor[ moves.length ];
        
        // Go through each move and determine neighbor's value
        final int neighborsLength = neighbors.length;
        TSNeighbor currentNeighbor;
        for( i = 0; i < neighborsLength; i++ )
        {
            // Set neighbor's move
            neighbors[i] = getNeighbor( moves[i] );
            
            // Set current neighbor from array
            currentNeighbor = neighbors[i];
            
            // Operate on solution
            moves[i].operateOn( currentSolution );
            
            // Evaluate and set neighbor's contribution
            double[] oldVal = currentObjectiveValue;
            double[] newVal = objectiveFunction.evaluate( currentSolution );
            final int valLength = newVal.length;
            double[] contrib = new double[ valLength ];
            for( j = 0; j < valLength; j++ )
                contrib[j] = newVal[j] - oldVal[j];
            currentNeighbor.setContributionToObjectiveFunction( contrib );
            
            // Now, penalty function
            newVal = penaltyFunction.evaluate( currentSolution );
            oldVal = currentPenaltyValue;
            double[] contrib2 = new double[ valLength ];
            for( j = 0; j < valLength; j++ )
                contrib2[j] = newVal[j] - oldVal[j];
            currentNeighbor.setContributionToPenaltyFunction( contrib2 );
            
            // Determine if this move is tabuValid.
            currentNeighbor.setTabuValid( tabuValid( currentNeighbor ) );

            // Undo operation
            moves[i].undoOperation( currentSolution );
        }   // end for: through each move
    }   // end evaluateNeighborhood
    
    
    // Includes aspiration criteria conisderation.
    /**
     * Determines from tabu list if the move is allowed or denied.
     * If the move results in the best solution ever found, it
     * is accepted regardless of the tabu list's report.
     */
    private final boolean tabuValid( TSNeighbor neighbor )
    {
        int i;
        boolean result = true;
        
        // See if move is tabu
        // The solution passed to the tabu list should be the solution
        // that results from the move's operation.
        if( ! tabuList.allowMove( neighbor.getMove(), currentSolution ) )
        {
            // If it's not the best solution ever, restrict move
            double[] curVal = currentSolution.getValue();
            double[] contribVal = neighbor.getContribution();
            final int valLength = curVal.length;
            double[] sum = new double[ valLength ];
            
            for( i = 0; i < valLength; i++ )
                sum[i] = curVal[i] + contribVal[i];
            
            if( ! parent.firstIsBetterThanSecond( sum, bestSolutionValue ) )
                result = false;
        }   // end if: move was tabu
        
        return result;
    }   // end tabuValid
    
    
    
    
/* ********  G E T   M E T H O D S  ******** */
    
    /**
     * Returns neighbors evaluated.
     */
    protected final synchronized TSNeighbor[] getNeighbors()
    {   return neighbors;
    }   // end getNeighbors
    
    /**
     * Makes a new neighbor or reuses an old one based on
     * the given move.
     */
    protected final TSNeighbor getNeighbor( TSMove move )
    {   
        TSNeighbor neighbor;
        
        // See if there's one we can reuse
        if( nextAvailableNeighbor < availableNeighborsCount )
        {   // Yes. Reuse this neighbor.
            neighbor = supplyOfNeighbors[ nextAvailableNeighbor++ ];
            neighbor.setMove( move );
        }   // end if: Reused a neighbor
        else    // Need to make a new neighbor.
        {   // See if we need to increase the array that holds
            // the extra neighbors
            if( supplyOfNeighbors.length <= nextAvailableNeighbor )
            {   
                // Every time the array needs to be increased, double
                // the length. This prevents a lot of unnecessary
                // array copying. Multiply by two by left-shifting bits.
                TSNeighbor[] temp = 
                    new TSNeighbor[ supplyOfNeighbors.length << 1 ];
                System.arraycopy( supplyOfNeighbors, 0, 
                    temp, 0, availableNeighborsCount );
                supplyOfNeighbors = temp;
            }   // end if: make array much bigger
            
            neighbor = new TSNeighbor( move );
            supplyOfNeighbors[ nextAvailableNeighbor++ ] = neighbor;
            availableNeighborsCount++;
        }   // Make a new neighbor
        
        return neighbor;
        //return new TSNeighbor( move );
    }   // end getNeighbor
    
    
/* ********  Q U E R Y   M E T H O D S  ******** */
    
    /**
     * Returns <code>true</code> if the agent should wake up
     * and start working.
     */
    protected final boolean workIsWaiting()
    {   return workWaiting;
    }   // end workIsWaiting
    
    
/* ********  S E T   M E T H O D S  ******** */
    
    /**
     * Set whether or not there is work waiting.
     */
    protected final void setWorkWaiting( boolean state )
    {   workWaiting = state;
        if( state )
        {   nextAvailableNeighbor = 0;
        }   // end if: reset counter for available neighbors
    }   // end setWorkWaiting
    
    
    /**
     * Sets the current solution on which to operate.
     */
    // Not synchronized because it is called from a synchronized
    // block in the EngineRunner
    protected final void setSolution( TSSolution solution )
    {   currentSolution = solution;
    }   // end setCurrentSolution
    
    /**
     * Sets moves to operate on the current solution
     */
    // Not synchronized because it is called from a synchronized
    // block in the EngineRunner
    protected final void setMoves( TSMove[] moves )
    {   this.moves = moves;
    }   // end setMoves
    
    /**
     * This copy of the best known solution's value helps
     * speed up comparisons.
     */
    protected final void setBestSolutionValueToCopyOf( double[] val )
    {   int valLength = val.length;
        bestSolutionValue = new double[ valLength ];
        System.arraycopy( val, 0, bestSolutionValue, 0, valLength );
    }   // end setBestSolutionValueToCopyOf
    
    
/* ********  M I S C E L L A N E O U S   M E T H O D S  ******** */

    /**
     * Displays exception to standard error.
     */
    private final void error( Exception e )
    {   if( TSEngine.DEBUGGING )
            System.err.println( e );
    }   // end error
    
    
}   // end class TSNeighborhoodSearchAgent
