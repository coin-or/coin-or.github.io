package net.usa.rharder.tabusearch22;

/**
 * The user has complete flexibility in describing a
 * solution. It could be an array of integers or booleans.
 * It could be a collection of objects, some "active"
 * and some not. The important thing is that it stand on its own.
 * As solutions get evaluated here and there in the engine, it
 * is necessary that a solution object be able to completely
 * describe its state, especially if incremental techniques 
 * are used to save processing time.
 * 
 * @author Robert Harder, rharder@usa.net
 * @version 2.1
 * @since 2.1
 */
    
public abstract class TSSolution implements Cloneable
{

    /**
     * A common Java method that returns of copy of the object. This
     * should do whatever is necessary to ensure that the returned
     * <code>TSSolution</code> is identical to <code>this</code.
     * Be careful of only copying references to arrays and other objects
     * when a full copy is what may be needed.
     * 
     * @return A copy of <code>this</code>.
     */
        
    public abstract Object clone();
        
    private double[] objectiveValue;    // Objective function value
    private double[] penaltyValue;      // Penalty function value
    private double[] value;             // Sum of the above two.
    private boolean valueValid = false; // If the sum needs to be updated,
                                        // this will say so.
    
    /**
     * Empty constructor
     */
    public TSSolution(){}
    
    /**
     * Aids in cloning. Call <code>super( copyThis )</code> in
     * a constructor to copy the objective and penalty function
     * values.
     * @param copyThis solution to copy.
     */
    public TSSolution( TSSolution copyThis )
    {
        double[] copyThisObjVal = copyThis.getObjectiveValue();
        double[] copyThisPenVal = copyThis.getPenaltyValue();
        
        // Make sure the arrays aren't null
        if( copyThisObjVal != null && copyThisPenVal != null )
        {
            this.objectiveValue = new double[ copyThisObjVal.length ];
            this.penaltyValue = new double[ copyThisPenVal.length ];
            
            System.arraycopy( copyThisObjVal, 0,
                this.objectiveValue, 0, objectiveValue.length );
            System.arraycopy( copyThisPenVal, 0,
                this.penaltyValue, 0, penaltyValue.length );
        }   // end if: arrays not null
    }   // end constructor


    /**
     * If the value has been set for this solution, then the value will
     * be returned. Be careful if this returns zero since this may
     * indicate that the <code>TSEngine</code> has not yet
     * set the solution's value.
     * 
     * @return The value of the solution (<code>this</code>).
     */
    public final double[] getValue()
    {
        if( objectiveValue != null && penaltyValue != null )
        {
            if( ! valueValid )
            {
                final int valLength = objectiveValue.length;
                value = new double[valLength];
                for( int i = 0; i < valLength; i++ )
                    value[i] = penaltyValue[i] + objectiveValue[i];
                valueValid = true;
            }
            
            return this.value;
        }   // end if: values not null
        else return null;
    }   // end getValue

    /**
     * Generally used by the <code>TSEngine</code> to set the value of the
     * objective function (without penalties).
     * 
     * @param objValue The objective function value.
     */
    
    public final void setObjectiveValue( double[] objValue )
    {
        this.objectiveValue = objValue;
        valueValid = false;
    }   // end setObjectiveValue

    /**
     * This is the value without the penalties. The objective function
     * evaluates this value. Be careful if the value is zero. This could
     * be the actual value, or it could be that the solution has not yet
     * been evaluated.
     * 
     * @return The objective function value or zero if the value has not been set.
     */
    
    public final double[] getObjectiveValue()
    {
        return this.objectiveValue;
    }   // end getObjectiveValue

    /**
     * Generally used by the <code>TSEngine</code> to set the penalties
     * for the solution.
     * 
     * @param penValue The value of the penalties.
     */
    
    public final void setPenaltyValue( double[] penValue )
    {
        this.penaltyValue = penValue;
        valueValid = false;
    }   // end setPenaltyValue

    /**
     * Gets the value of the penalties for the solution. Be careful if the 
     * value is zero. It could indicate that the solution has not been
     * evaluated or the penalties really could be zero.
     * 
     * @return The value for the penalties.
     */
    
    public final double[] getPenaltyValue()
    {
        return this.penaltyValue;
    }   // end getPenaltyValue
    
    
}   // end TSSolution class
