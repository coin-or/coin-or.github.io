echo
echo If you don't specify a tenure and number of iterations, 10 and 100 will be used
echo
java -classpath classes;tabusearch22.jar Main customers.txt %1 %2 10 100