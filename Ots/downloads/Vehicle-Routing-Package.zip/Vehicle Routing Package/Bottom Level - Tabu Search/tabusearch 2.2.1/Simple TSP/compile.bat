md classes
javac -classpath classes;tabusearch22.jar -d classes source\*.java