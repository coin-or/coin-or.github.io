import net.usa.rharder.tabusearch22.*;


public class TSPSwapMove
implements TSMove
{
    private int index1;
    private int index2;
    
    public TSPSwapMove( int indexOne, int indexTwo )
    {   this.index1 = indexOne;
        this.index2 = indexTwo;
    }   // end constructor
    
    public int getIndex1()
    {   return index1;
    }   // end getIndex1
    
    public int getIndex2()
    {   return index2;
    }   // end getIndex2
    
    
/* ********  T S M O V E   M E T H O D S  ******** */
    
    public void operateOn( TSSolution solution )
    {   
        // Cast solution to our type
        TSPSolution soln = (TSPSolution) solution;
        
        // Get tour
        int[] tour = soln.getTour();
        
        // Swap customers
        int cust1 = tour[ index1 ];
        int cust2 = tour[ index2 ];
        tour[ index1 ] = cust2;
        tour[ index2 ] = cust1;
    }   // end operateOn
    
    public void undoOperation( TSSolution solution )
    {   // Since the inverse of a swap is the same swap, just
        // pass this solution to the operateOn method.
        operateOn( solution );
    }   // end undoOperation
    
    public boolean conflictsWith( TSMove move )
    {   return true;    // Moves are not independent
    }   // end conflictsWith
    
}   // end class TSMove