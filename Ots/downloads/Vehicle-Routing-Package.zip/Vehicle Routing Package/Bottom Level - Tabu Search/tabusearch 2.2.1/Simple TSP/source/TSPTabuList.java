import net.usa.rharder.tabusearch22.*;


public class TSPTabuList
implements TSTabuList
{
    // The tabu list will contain a list of indeces that have been swapped.
    // Since this is so restrictive, you'll probably not want a very long tenure.
    
    // Make the zero-th element of the list the one just about to fall off.
    int[] list;
    
    public TSPTabuList( int tenure )
    {   list = new int[ tenure ];
    }   // end constructor
    
    
/* ********  T S T A B U L I S T   M E T H O D S  ******** */
    
    public void registerMoves( TSMove[] moves, TSSolution toSolution )
    {   // Go through each move. Of course we should only see one move at a time.
        for( int i = 0; i < moves.length; i++ )
        {   // Get indeces that were swapped
            TSPSwapMove move = (TSPSwapMove) moves[i];
            int index1 = move.getIndex1();
            int index2 = move.getIndex2();
            System.arraycopy( list, 2, list, 0, list.length-2 );
            list[ list.length-2 ] = index1;
            list[ list.length-1 ] = index2;
        }   // end for: each move
    }   // end registerMoves
    
    
    public boolean allowMove( TSMove move, TSSolution toSolution )
    {
        TSPSwapMove m = (TSPSwapMove) move;
        boolean allow = true;
        int i = 0;
        while( allow && i < list.length )
            if( list[i] == m.getIndex1() || list[i] == m.getIndex2() )
                allow = false;
            else i++;
        return allow;
    }   // end allowMove
    
    
}   // end class TSPTabuList