import net.usa.rharder.tabusearch22.*;
import java.util.*;

public class TSPMoveManager
implements TSMoveManager, TSNewBestSolutionListener, TSUnimprovingMoveListener
{
    private boolean makeMoreExtensiveMoves = false;
    
    
/* ********  T S M O V E M A N A G E R   M E T H O D S  ******** */
    
    public TSMove[] getAllMoves( TSSolution solution )
    {
        // Cast solution
        TSPSolution soln = (TSPSolution) solution;
        
        // No matter what the current solution is, we're going to generate
        // the same set of swap moves.
        Vector moves = new Vector();
        int[] tour = soln.getTour();
        
        // Add pair swap moves
        for( int i = 0; i < tour.length-1; i++ )
            moves.addElement( new TSPSwapMove( i, 
                i==tour.length-1 
                ? 0         // Last and first customers
                : i+1 ) );  // ith and (i+1)th move
        
        // Making the extra types of moves
        if( makeMoreExtensiveMoves )
        {   // Generate i and i+k swaps
            for( int i = 0; i < tour.length-2; i++ )
                for( int k = 2; k < tour.length>>2; k++ )
                    moves.addElement( new TSPSwapMove( i, 
                        i>=tour.length-k 
                        ? tour.length-k % i   // Wrap around to first customers
                        : i+k ) );  // ith and (i+1)th move
            
            // Generate some silly moves
            for( int i = 0; i < tour.length; i++ )
                moves.addElement( new TSPSwapMove( i, tour.length - i - 1) );
        }   // end if: makeMoreExtensiveMoves
        
        // Convert vector to array
        TSPSwapMove[] movesArray = new TSPSwapMove[ moves.size() ];
        for( int i = 0; i < movesArray.length; i++ )
            movesArray[i] = (TSPSwapMove) moves.elementAt(i);

        return movesArray;
    }   // end getAllMoves
    
    
/* ********  T S N E W B E S T S O L U T I O N   L I S T E N E R  ******** */
    
    public void newBestSolutionFound( TSTabuEvent e )
    {
        // When we've found a best solution, stop generating the more
        // esoteric moves.
        makeMoreExtensiveMoves = false;
    }   //
    
/* ********  T S U N I M P R O V I N G M O V E   L I S T E N E R  ******** */    

    public void unimprovingMoveMade( TSTabuEvent e )
    {
        // When we've started making unimproving moves, start making
        // the more esoteric moves.
        makeMoreExtensiveMoves = true;
    }   // end unimprovingMoveMade
    
    
    
}   // end class TSPMoveManager