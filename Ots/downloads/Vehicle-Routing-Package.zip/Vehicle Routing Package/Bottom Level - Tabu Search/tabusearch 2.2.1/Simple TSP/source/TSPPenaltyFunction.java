import net.usa.rharder.tabusearch22.*;


public class TSPPenaltyFunction
implements TSFunction
{
    // We're not using any penalties, so just return zero for the required
    // 'evaluate' method
    private final double[] zero = { 0 };
    
    public final double[] evaluate( TSSolution solution )
    {   return zero;
    }   // end evaluate
    
}   // end class TSPPenaltyFunction