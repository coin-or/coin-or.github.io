import net.usa.rharder.tabusearch22.*;


public class TSPSolution
extends TSSolution
{
    // Each element is the number of a customer. Customers are visited
    // in the sequence they appear in the array.
    private int[] tour;
    
    
    public TSPSolution( int[] tour )
    {   this.tour = new int[ tour.length ];
        System.arraycopy(tour, 0, this.tour, 0, tour.length);
    }   // end constructor
    
/* ********  M E T H O D S  ******** */
    
    public int[] getTour()
    {   return tour;
    }   // end getTour
    
    public String toString()
    {   StringBuffer s = new StringBuffer("[");
        
        // Add cost
        java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
        nf.setMaximumFractionDigits(2);
        double cost = super.getValue()[0];
        s.append( "cost=" + nf.format(cost) );
        
        // Comma
        s.append( ", " );
        
        // Tour
        s.append( "tour=(" );
        for( int i = 0; i < tour.length; i++ )
            s.append( tour[i] + (i<tour.length-1 ? ", " : "") );
        s.append( "}" );
        
        // Closing
        s.append( "]" );
        
        return s.toString();
    }   // end toString
    
/* ********  T S S O L U T I O N   M E T H O D S  ******* */
    
    public Object clone()
    {   return new TSPSolution( this.getTour() );
    }   // end clone
    
    
}   // end class TSPSolution