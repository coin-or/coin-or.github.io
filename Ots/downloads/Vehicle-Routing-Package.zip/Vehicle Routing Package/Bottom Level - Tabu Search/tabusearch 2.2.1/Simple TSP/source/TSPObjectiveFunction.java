import net.usa.rharder.tabusearch22.*;


public class TSPObjectiveFunction
implements TSFunction
{
    private double[][] costMatrix;
    
    public TSPObjectiveFunction( double[][] matrix )
    {   this.costMatrix = matrix;
    }   // end constructor
    
    
    
/* ********  T S F U N C T I O N   M E T H O D S  ******** */
    
    public double[] evaluate( TSSolution solution )
    {
        // Cast solution to our type of solution
        TSPSolution soln = (TSPSolution) solution;
        
        // Get tour
        int[] tour = soln.getTour();
        
        // Sum distances in tour
        double distance = 0;
        for( int i = 0; i < tour.length; i++ )
            distance += costMatrix
                [ tour[i] ] // From
                [ tour[i==tour.length-1 ? 0 : i+1] ];   // To. Check if we're at
                                                        // the end of the tour
        // Convert to array of length one. We could have more than one cost
        // and let the tabu search compare them lexicographically, but we're not.
        double[] distanceArray = { distance };
        
        return distanceArray;
    }   // end evaluate
    
}   // end class TSPObjectiveFunction