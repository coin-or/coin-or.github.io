import net.usa.rharder.tabusearch22.*;

import java.io.*;
import java.util.*;

public class Main
{
    public final static int
        DEFAULT_TENURE = 10,
        DEFAULT_ITERATIONS = 100;
    
    public static void main( String[] args )
    {
        // If no file was specified in args, say so and quit
        if( args.length < 3 )
        {   System.out.println( "Usage: java Main filename tenure iterations" );
            System.out.println( "where filename is the file with x,y pairs," );
            System.out.println( "      tenure is the tabu list tenure, and" );
            System.out.println( "      iterations is the number of iterations to do." );
            System.exit(1);
        }   // end if: no file specifed
        
        // Read customers from file
        System.out.print( "Loading customers from file..." );
        double[][] customerLocations = getCustomerLocationsFromFile( args[0] );
        if( customerLocations == null )
        {   System.out.println( "Customers weren't loaded." );
            System.exit(1);
        }   // end if: customers not loaded
        System.out.println( "done" );
        
        // Make cost matrix
        System.out.print( "Calculating cost matrix..." );
        double[][] costMatrix = calculateCostMatrix( customerLocations );
        System.out.println( "done" );
        
        // Create starting tour
        System.out.print( "Creating initial solution..." );
        int[] startingTour = new int[ customerLocations.length ];
        for( int i = 0; i < startingTour.length; i++ )
            startingTour[i] = i;
        System.out.println( "done" );
        
        // Instantiate tabu search objects
        System.out.println( "Instantiating tabu objects..." );
        System.out.print( "  solution..." );
            TSPSolution startingSolution = new TSPSolution( startingTour );
            System.out.println( "done" );
        System.out.print( "  objective function..." );
            TSPObjectiveFunction objFunc = new TSPObjectiveFunction( costMatrix );
            System.out.println( "done" );
        System.out.print( "  penalty function..." );
            TSPPenaltyFunction penFunc = new TSPPenaltyFunction();
            System.out.println( "done" );
        System.out.print( "  move manager..." );
            TSPMoveManager moveManager = new TSPMoveManager();
            System.out.println( "done" );
        
        // Tabu list
        System.out.print( "  tabu list..." );
            int tenure = DEFAULT_TENURE;   // default
            try{ tenure = new Integer( args[1] ).intValue(); }
            catch( Exception e ){ e.printStackTrace(); }
            TSPTabuList tabuList = new TSPTabuList( tenure );
            System.out.println( "done (" + tenure + ")" );
        
        // Create a tabu search engine
        System.out.print( "Instantiating TSEngine..." );
        TSEngine engine = new TSEngine(
            startingSolution,
            tabuList,
            objFunc,
            penFunc,
            moveManager,
            false); // Maximizing == false therefore we're minimizing
        System.out.println( "done" );
        
        // Make the move manager a listener
        System.out.print( "adding move manager as two listeners..." );
            engine.addNewBestSolutionListener( moveManager );
            engine.addUnimprovingMoveListener( moveManager );
            System.out.println( "done" );
        
        // Start tabu search. Try to get iterations as second parameter from user
        System.out.print( "Setting iterations..." );
            int iterations = DEFAULT_ITERATIONS;   // default
            try{ iterations = new Integer( args[2] ).intValue(); }
            catch( Exception e ){ e.printStackTrace(); }
            System.out.println( "done (" + iterations + ")" );
        System.out.print( "Starting engine..." );
            engine.startSolving( iterations );
            System.out.println( "done" );
        
        // We could let the rest be event driven, but instead we'll just wait around.
        System.out.print( "Waiting to finish..." );
            engine.waitToFinish();
            System.out.println( "done" );
        
        // Output best solution
        System.out.println( "Best Solution:" );
        System.out.println( engine.getBestSolution() );
        
    }   // end main
    
    
/* ********  S U P P O R T   M E T H O D S  ******** */
    
    private static double[][] getCustomerLocationsFromFile( String filename )
    {
        // A lot of things could go wrong trying to read this, so if
        // anything gets screwed up, just print the exception and bail.
        try
        {   
            File file = new File( filename );
            FileInputStream fis = new FileInputStream( file );
            StreamTokenizer stream = new StreamTokenizer( 
                new BufferedReader( new InputStreamReader( fis ) ) );
            
            // Notice end of lines
            stream.eolIsSignificant(true);
            
            // Go through file, adding points to a vector
            Vector points = new Vector();
            Double x1 = null;
            Double x2 = null;
            while( stream.nextToken() != stream.TT_EOF )
            {   if( stream.ttype == stream.TT_EOL )
                {   x1 = null;
                    x2 = null;
                }   // end if: end of line
                else
                {   if( stream.ttype == stream.TT_NUMBER )
                    {   // If the numbers aren't already set
                        if( x1 == null || x2 == null )
                        {   // If the first point hasn't been set
                            if( x1 == null )
                                x1 = new Double( stream.nval );
                            // Else if the second point hasn't been set
                            else if( x2 == null )
                            {   x2 = new Double( stream.nval );
                                double[] x = new double[2];
                                x[0] = x1.doubleValue();
                                x[1] = x2.doubleValue();
                                points.addElement(x);
                            }   // end else: x1 hadn't been set
                        }   // end if: at least one of the numbers hadn't been set
                    }   // end if: was a number
                }   // end else: not end of line
            }   // end while: not end of file
            
            // Convert vector of tuples to matrix
            double[][] locations = new double[ points.size() ][];
            for( int i = 0; i < locations.length; i++ )
            {   // Extract tuple
                double[] tuple = (double[]) points.elementAt( i );
                locations[i] = tuple;
            }   // end for: through each pair
            
            return locations;
        }   //end try
        catch( Exception e )
        {   e.printStackTrace();
            return null;
        }   // end catch
    }   // end getCustomerLocationsFromFile
    
    
    private static double[][] calculateCostMatrix( double[][] locations )
    {
        // Make matrix
        double[][] costMatrix = new double[ locations.length ][ locations.length ];
        
        // Go through double loop and fill matrix. Try to take advantage of the
        // fact that the matrix is symmetrical. Of course we could have made the
        // matrix triangular, but we're not.
        for( int i = 0; i < costMatrix.length; i++ )
            for( int j = 0; j < costMatrix[i].length; j++ )
                costMatrix[i][j] = distanceBetween(
                    locations[i][0],    // first, x
                    locations[i][1],    // first, y
                    locations[j][0],    // second, x
                    locations[j][1] );  // second, y
        
        return costMatrix;
    }   // end calculateCostMatrix
    
    
    private static double distanceBetween( double x1, double y1, double x2, double y2 )
    {   // Use Pythagorean theorem.
        double xd2 = x2 - x1;
        double yd2 = y2 - y1;
        xd2 *= xd2;
        yd2 *= yd2;
        return Math.sqrt( xd2 + yd2 );
    }   // end distanceBetween
    
    
}   // end class Main