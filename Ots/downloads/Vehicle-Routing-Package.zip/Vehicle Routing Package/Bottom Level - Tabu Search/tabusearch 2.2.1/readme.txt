Java Tabu Search v2.2.1
~~~~~~~~~~~~~~~~~~~~~
Author: Robert Harder
        rharder@usa.net

See the web site available from www.iHarder.net for the latest information.

This package provides a structured way to implement a tabu search. Read the javadoc-generated API guide in the 'docs' folder for more information.

To install, copy the tabusearch22.jar file to jdk1.x/jre/lib/ext directory where jdk1.x is the directory containing your jdk. Alternatively you can include the jar file at runtime with -classpath tabusearch22.jar.

Version 2.2.1 fixed a bug that caused the engine to select the first move in the list when no moves were improving.